/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Supabase Plain CRUD Data Service for RAMA777.
 * Handles plain direct CRUD operations on 'markets', 'bids', and 'transactions'
 * without enforcing user authentication checks.
 *
 * Resilience & Guarantees:
 * - Executes direct queries on Supabase tables.
 * - Catches any errors with descriptive console.error logging.
 * - Always falls back to local optimistic state if network or Supabase queries fail.
 * - Realtime channel subscriptions broadcast live updates immediately.
 */

import { supabase } from '../supabase';
import {
  UserProfile,
  Transaction,
  FundHistoryItem,
  BankAccount,
  GameBid,
  AppNotification,
  MarketItem,
} from '../types';
import { secureStorage } from '../utils/security';
import {
  sanitizeText,
  sanitizeAmount,
  sanitizeUtr,
  sanitizeIfsc,
  sanitizeBankAccount,
} from '../utils/sanitizer';
import { formatRemainingDuration, parseTimeString, formatMarketResult, getDigitFromPana } from '../utils/marketEngine';

export interface ManualUpiConfig {
  enabled: boolean;
  upiId: string;
  merchantName: string;
  qrCodeUrl: string;
  requireScreenshot?: boolean;
  instructions?: string;
}

export interface PaymentGatewayConfig {
  merchantVpa: string;
  merchantName: string;
  status: 'active' | 'maintenance';
  minDeposit: number;
  maxDeposit?: number;
  minWithdrawal: number;
  welcomeBonusEnabled: boolean;
  bonusAmount: number;
  activeGateway?: string;
  manualUpi?: ManualUpiConfig;
  phonepe?: {
    enabled?: boolean;
    merchantId?: string;
  };
  paytm?: {
    enabled?: boolean;
    mid?: string;
  };
  razorpay?: {
    enabled?: boolean;
    keyId?: string;
  };
  updatedAt?: string;
}

export const DEFAULT_GATEWAY_CONFIG: PaymentGatewayConfig = {
  merchantVpa: '0793748A0296660.bqr@kotak',
  merchantName: 'RAMA77 GAMING ENTERPRISES',
  status: 'active',
  minDeposit: 100,
  maxDeposit: 100000,
  minWithdrawal: 300,
  welcomeBonusEnabled: true,
  bonusAmount: 100,
  activeGateway: 'manual_upi',
  manualUpi: {
    enabled: true,
    upiId: '0793748A0296660.bqr@kotak',
    merchantName: 'RAMA77 GAMING ENTERPRISES',
    qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=upi://pay?pa=0793748A0296660.bqr@kotak&pn=RAMA77%20GAMING&cu=INR',
    requireScreenshot: true,
    instructions: 'Scan QR code or copy UPI ID. Pay using any UPI app and enter the 12-digit UTR/Ref No.',
  },
};

export interface UserAuthScope {
  uid: string;
  phone: string;
}

// Local Encrypted Cache Keys for Optimistic Fallback
const STORAGE_KEYS = {
  USERS: 'rama777_users_data',
  WITHDRAWALS: 'rama777_withdrawals_data',
  DEPOSITS: 'rama777_deposits_data',
  TRANSACTIONS: 'rama777_transactions_data',
  BIDS: 'rama777_bids_data',
  BANKS: 'rama777_banks_data',
  NOTIFICATIONS: 'rama777_notifications_data',
  GATEWAY: 'rama777_gateway_data',
  MARKETS: 'rama777_markets_data',
};

// Event bus for real-time reactivity across components
type EventCallback = () => void;
const eventListeners: Record<string, Set<EventCallback>> = {};

function emitChangeEvent(key: string) {
  if (eventListeners[key]) {
    eventListeners[key].forEach((cb) => {
      try {
        cb();
      } catch (e) {
        console.warn('Listener notification warning:', e);
      }
    });
  }
}

function addStorageListener(key: string, callback: EventCallback): () => void {
  if (!eventListeners[key]) {
    eventListeners[key] = new Set();
  }
  eventListeners[key].add(callback);
  return () => {
    eventListeners[key]?.delete(callback);
  };
}

function getStoredJson<T>(key: string, defaultValue: T): T {
  return secureStorage.getItem<T>(key, defaultValue);
}

function setStoredJson<T>(key: string, value: T): void {
  try {
    secureStorage.setItem(key, value);
    emitChangeEvent(key);
  } catch (e) {
    console.warn('SecureStorage save notice:', e);
  }
}

export function resolveUserAuthScope(userParam?: Partial<UserProfile> | string | null): UserAuthScope {
  let uid = '';
  let phone = '';

  if (typeof userParam === 'string') {
    const digits = userParam.replace(/\D/g, '');
    if (digits.length === 10) phone = digits;
    if (!uid) uid = userParam.trim();
  } else if (userParam && typeof userParam === 'object') {
    if (userParam.uid) uid = String(userParam.uid).trim();
    else if (userParam.id) uid = String(userParam.id).trim();
    if (userParam.phone) {
      const digits = String(userParam.phone).replace(/\D/g, '');
      if (digits) phone = digits;
    }
  }

  if (!uid && typeof window !== 'undefined') {
    const storedUid = localStorage.getItem('rama777_user_uid');
    if (storedUid) uid = storedUid.trim();
  }

  if (!phone && typeof window !== 'undefined') {
    const storedPhone = localStorage.getItem('rama777_user_phone');
    if (storedPhone) phone = storedPhone.replace(/\D/g, '');
  }

  if (!uid && phone) {
    uid = phone;
  }

  return { uid, phone };
}

export function getUserIdentifier(userOrPhone?: Partial<UserProfile> | string | null): string {
  const scope = resolveUserAuthScope(userOrPhone);
  return scope.uid || scope.phone;
}

export function toSupabaseUuid(rawId: string): string {
  if (!rawId) return '00000000-0000-0000-0000-000000000000';
  if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(rawId)) {
    return rawId;
  }
  let hex = '';
  for (let i = 0; i < rawId.length; i++) {
    hex += rawId.charCodeAt(i).toString(16);
  }
  hex = hex.padEnd(32, '0').slice(0, 32);
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-4${hex.slice(13, 16)}-a${hex.slice(17, 20)}-${hex.slice(20, 32)}`;
}

// ==========================================
// 1. User Profile & Live Wallet Sync
// ==========================================
export function subscribeToUserWallet(
  userParam: string | Partial<UserProfile>,
  onUpdate: (userData: Partial<UserProfile>) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);
  const targetId = scope.uid || scope.phone || 'default';

  // Optimistic read from local storage immediately
  const allUsers = getStoredJson<Record<string, Partial<UserProfile>>>(STORAGE_KEYS.USERS, {});
  const stored = allUsers[targetId] || allUsers[scope.phone] || {};
  if (stored && typeof stored.walletBalance === 'number') {
    onUpdate({
      uid: targetId,
      id: targetId,
      ...stored,
    });
  }

  // Listen to local changes
  const unsubStorage = addStorageListener(STORAGE_KEYS.USERS, () => {
    const latest = getStoredJson<Record<string, Partial<UserProfile>>>(STORAGE_KEYS.USERS, {});
    const cur = latest[targetId] || latest[scope.phone] || {};
    onUpdate({
      uid: targetId,
      id: targetId,
      ...cur,
    });
  });

  return unsubStorage;
}

export async function syncUserToFirestore(user: UserProfile): Promise<void> {
  const scope = resolveUserAuthScope(user);
  const uid = scope.uid || scope.phone || 'default';
  const allUsers = getStoredJson<Record<string, Partial<UserProfile>>>(STORAGE_KEYS.USERS, {});
  allUsers[uid] = { ...allUsers[uid], ...user, uid, id: uid };
  if (scope.phone) allUsers[scope.phone] = allUsers[uid];
  setStoredJson(STORAGE_KEYS.USERS, allUsers);
}

// ==========================================
// 2. Withdrawal Requests Sync ('withdrawals')
// ==========================================
export function subscribeToWithdrawals(
  userParam: string | Partial<UserProfile>,
  onUpdate: (withdrawals: FundHistoryItem[], hasData: boolean) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);

  const readData = () => {
    const all = getStoredJson<FundHistoryItem[]>(STORAGE_KEYS.WITHDRAWALS, []);
    const filtered = all.filter((item) => {
      if (!scope.phone && !scope.uid) return true;
      const itemPhone = (item as any).userPhone || (item as any).phone || '';
      const itemUid = (item as any).userId || (item as any).uid || '';
      return (
        (scope.phone && itemPhone.includes(scope.phone)) ||
        (scope.uid && itemUid === scope.uid) ||
        (!itemPhone && !itemUid)
      );
    });
    onUpdate(filtered, filtered.length > 0);
  };

  readData();
  return addStorageListener(STORAGE_KEYS.WITHDRAWALS, readData);
}

export async function createWithdrawalInFirestore(
  item: FundHistoryItem,
  user: UserProfile
): Promise<void> {
  const scope = resolveUserAuthScope(user);
  const cleanAmountResult = sanitizeAmount(item.amount, 100, 100000);
  const safeAmount = cleanAmountResult.isValid ? cleanAmountResult.amount : item.amount;
  const safeBankName = sanitizeText(item.bankName || '', 50);
  const safeAccount = sanitizeBankAccount(item.accountNumber || '').accountNumber || item.accountNumber || '';
  const safeIfsc = sanitizeIfsc(item.ifscCode || '').ifsc || item.ifscCode || '';

  // 1. Optimistic Local Update immediately
  const all = getStoredJson<FundHistoryItem[]>(STORAGE_KEYS.WITHDRAWALS, []);
  const newItem = {
    ...item,
    amount: safeAmount,
    bankName: safeBankName,
    accountNumber: safeAccount,
    ifscCode: safeIfsc,
    userId: scope.uid,
    userPhone: scope.phone,
    userName: sanitizeText(user.name, 50),
  };
  setStoredJson(STORAGE_KEYS.WITHDRAWALS, [newItem, ...all.filter((w) => w.id !== item.id)]);

  // 2. Plain Direct CRUD into Supabase 'transactions' table without auth checks
  try {
    const userUuid = toSupabaseUuid(scope.uid || scope.phone || '');
    const { error } = await supabase.from('transactions').insert({
      user_id: userUuid,
      amount: safeAmount,
      type: 'WITHDRAWAL',
      status: 'PENDING',
      payment_gateway: 'Bank Transfer',
    });
    if (error) {
      console.error('[Supabase Error] Direct withdrawal transaction insert failed:', error.message, error.details);
    }
  } catch (err) {
    console.error('[Supabase Network Failure] Withdrawal insert fell back to local state:', err);
  }
}

// ==========================================
// 3. Deposits Sync ('deposits')
// ==========================================
export function subscribeToDeposits(
  userParam: string | Partial<UserProfile>,
  onUpdate: (deposits: FundHistoryItem[], hasData: boolean) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);

  const readData = () => {
    const all = getStoredJson<FundHistoryItem[]>(STORAGE_KEYS.DEPOSITS, []);
    const filtered = all.filter((item) => {
      if (!scope.phone && !scope.uid) return true;
      const itemPhone = (item as any).userPhone || (item as any).phone || '';
      const itemUid = (item as any).userId || (item as any).uid || '';
      return (
        (scope.phone && itemPhone.includes(scope.phone)) ||
        (scope.uid && itemUid === scope.uid) ||
        (!itemPhone && !itemUid)
      );
    });
    onUpdate(filtered, filtered.length > 0);
  };

  readData();
  return addStorageListener(STORAGE_KEYS.DEPOSITS, readData);
}

export async function createDepositInFirestore(
  item: FundHistoryItem,
  user: UserProfile,
  bonus: number = 0
): Promise<void> {
  const scope = resolveUserAuthScope(user);
  const cleanAmountResult = sanitizeAmount(item.amount, 1, 500000);
  const safeAmount = cleanAmountResult.isValid ? cleanAmountResult.amount : item.amount;
  const safeBonusResult = sanitizeAmount(bonus, 0, 50000);
  const safeBonus = safeBonusResult.isValid ? safeBonusResult.amount : bonus;
  const safeUtr = item.utrOrReference ? sanitizeUtr(item.utrOrReference).utr : '';

  // 1. Optimistic Local Update immediately
  const all = getStoredJson<FundHistoryItem[]>(STORAGE_KEYS.DEPOSITS, []);
  const newItem = {
    ...item,
    amount: safeAmount,
    bonus: safeBonus,
    utrOrReference: safeUtr || item.utrOrReference,
    userId: scope.uid,
    userPhone: scope.phone,
    userName: sanitizeText(user.name, 50),
  };
  setStoredJson(STORAGE_KEYS.DEPOSITS, [newItem, ...all.filter((d) => d.id !== item.id)]);

  // 2. Plain Direct CRUD into Supabase 'transactions' table without auth checks
  try {
    const userUuid = toSupabaseUuid(scope.uid || scope.phone || '');
    const { error } = await supabase.from('transactions').insert({
      user_id: userUuid,
      amount: safeAmount + safeBonus,
      type: 'DEPOSIT',
      status: item.status === 'Pending' ? 'PENDING' : 'SUCCESS',
      payment_gateway: item.depositMode || 'UPI',
    });
    if (error) {
      console.error('[Supabase Error] Direct deposit transaction insert failed:', error.message, error.details);
    }
  } catch (err) {
    console.error('[Supabase Network Failure] Deposit insert fell back to local state:', err);
  }
}

// ==========================================
// 4. Passbook Transactions Sync with Plain Direct CRUD & Realtime
// ==========================================
export function subscribeToTransactions(
  userParam: string | Partial<UserProfile>,
  onUpdate: (transactions: Transaction[], hasData: boolean) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);
  let isMounted = true;

  // 1. Optimistic Local State Fetch
  const emitLocal = () => {
    const all = getStoredJson<Transaction[]>(STORAGE_KEYS.TRANSACTIONS, []);
    const filtered = all.filter((tx) => {
      if (!scope.phone && !scope.uid) return true;
      const txUid = (tx as any).userId || (tx as any).uid || '';
      const txPhone = (tx as any).userPhone || (tx as any).phone || '';
      return (
        (scope.phone && txPhone.includes(scope.phone)) ||
        (scope.uid && txUid === scope.uid) ||
        (!txUid && !txPhone)
      );
    });
    if (isMounted) {
      onUpdate(filtered, filtered.length > 0);
    }
  };

  emitLocal();
  const unsubStorage = addStorageListener(STORAGE_KEYS.TRANSACTIONS, emitLocal);

  // 2. Direct plain query on Supabase 'transactions' table without auth checks
  const queryDirectTransactions = async () => {
    try {
      const { data, error } = await supabase
        .from('transactions')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) {
        console.error('[Supabase Error] Query transactions failed:', error.message, error.details);
        return; // Retains optimistic local state
      }

      if (data && isMounted) {
        const userUuid = toSupabaseUuid(scope.uid || scope.phone || '');
        const items: Transaction[] = data
          .filter((row) => !row.user_id || row.user_id === userUuid || row.user_id === '00000000-0000-0000-0000-000000000000')
          .map((row) => {
            const isDebit =
              String(row.type).toUpperCase().includes('WITHDRAW') ||
              String(row.type).toUpperCase().includes('DEBIT') ||
              String(row.type).toUpperCase().includes('BET');
            return {
              id: row.id || `tx-${Date.now()}`,
              referenceId: row.id ? `TXN-${String(row.id).slice(-8).toUpperCase()}` : `TXN-${Date.now()}`,
              title: `${row.type || 'Transaction'} |  ${row.amount}`,
              description: `Gateway: ${row.payment_gateway || 'UPI'} - Status: ${row.status || 'SUCCESS'}`,
              amount: Number(row.amount) || 0,
              type: isDebit ? 'debit' : 'credit',
              status: row.status === 'SUCCESS' ? 'SUCCESS' : row.status === 'FAILED' ? 'FAILED' : 'PENDING',
              date: row.created_at ? new Date(row.created_at).toLocaleString() : new Date().toLocaleString(),
              previousBalance: 0,
              currentBalance: Number(row.amount) || 0,
            };
          });

        if (items.length > 0) {
          const currentLocal = getStoredJson<Transaction[]>(STORAGE_KEYS.TRANSACTIONS, []);
          // Merge remote items with local
          const merged = [...items];
          for (const loc of currentLocal) {
            if (!merged.some((m) => m.id === loc.id)) {
              merged.push(loc);
            }
          }
          setStoredJson(STORAGE_KEYS.TRANSACTIONS, merged);
          onUpdate(merged, true);
        }
      }
    } catch (err) {
      console.error('[Supabase Network Failure] Failed fetching transactions:', err);
    }
  };

  queryDirectTransactions();

  // 3. Realtime Subscription on 'transactions' table
  const channel = supabase
    .channel('public:transactions:realtime')
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'transactions' },
      (payload) => {
        if (!isMounted) return;
        console.log('[Supabase Realtime] Transactions table event:', payload.eventType);
        queryDirectTransactions();
      }
    )
    .subscribe();

  return () => {
    isMounted = false;
    unsubStorage();
    supabase.removeChannel(channel);
  };
}

export async function recordTransactionInFirestore(
  tx: Transaction,
  userParam: string | Partial<UserProfile>
): Promise<void> {
  const scope = resolveUserAuthScope(userParam);
  const txId = tx.referenceId || tx.id;

  // 1. Optimistic Local Update immediately
  const all = getStoredJson<Transaction[]>(STORAGE_KEYS.TRANSACTIONS, []);
  const newTx = { ...tx, userId: scope.uid, userPhone: scope.phone };
  setStoredJson(STORAGE_KEYS.TRANSACTIONS, [newTx, ...all.filter((t) => t.id !== tx.id)]);

  // 2. Direct plain insert into Supabase 'transactions' table without auth checks
  try {
    const userUuid = toSupabaseUuid(scope.uid || scope.phone || '00000000-0000-0000-0000-000000000000');
    const { error } = await supabase.from('transactions').insert({
      user_id: userUuid,
      amount: tx.amount,
      type: tx.type === 'debit' ? 'BET_OR_WITHDRAWAL' : 'DEPOSIT',
      status: tx.status === 'SUCCESS' ? 'SUCCESS' : tx.status === 'FAILED' ? 'FAILED' : 'PENDING',
      payment_gateway: 'RAMA_WALLET',
    });
    if (error) {
      console.error('[Supabase Error] Direct recordTransaction failed:', error.message, error.details);
    }
  } catch (err) {
    console.error('[Supabase Network Failure] Transaction record fell back to local state:', err);
  }
}

// ==========================================
// 5. Game Bids & Win History with Plain Direct CRUD & Realtime
// ==========================================
export function subscribeToBids(
  userParam: string | Partial<UserProfile>,
  onUpdate: (bids: GameBid[], hasData: boolean) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);
  let isMounted = true;

  // 1. Optimistic Local State Fetch
  const emitLocal = () => {
    const all = getStoredJson<GameBid[]>(STORAGE_KEYS.BIDS, []);
    const filtered = all.filter((bid) => {
      if (!scope.phone && !scope.uid) return true;
      const bidUid = (bid as any).userId || (bid as any).uid || '';
      const bidPhone = (bid as any).userPhone || (bid as any).phone || '';
      return (
        (scope.phone && bidPhone.includes(scope.phone)) ||
        (scope.uid && bidUid === scope.uid) ||
        (!bidUid && !bidPhone)
      );
    });
    if (isMounted) {
      onUpdate(filtered, filtered.length > 0);
    }
  };

  emitLocal();
  const unsubStorage = addStorageListener(STORAGE_KEYS.BIDS, emitLocal);

  // 2. Direct plain query on Supabase 'bids' table without auth checks
  const queryDirectBids = async () => {
    try {
      const { data, error } = await supabase
        .from('bids')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) {
        console.error('[Supabase Error] Direct query bids failed:', error.message, error.details);
        return; // Retains optimistic local state
      }

      if (data && isMounted) {
        const userUuid = toSupabaseUuid(scope.uid || scope.phone || '');
        const items: GameBid[] = data
          .filter((row) => !row.user_id || row.user_id === userUuid || row.user_id === '00000000-0000-0000-0000-000000000000')
          .map((row) => ({
            id: row.id,
            marketName: 'Matka Market',
            gameType: row.game_type || 'SINGLE DIGIT',
            session: 'Open',
            digitOrPana: String(row.digits ?? ''),
            points: Number(row.points) || 0,
            date: row.created_at ? new Date(row.created_at).toLocaleString() : 'Recent',
            status: row.status === 'WON' ? 'Won' : row.status === 'LOST' ? 'Lost' : 'Placed',
          }));

        if (items.length > 0) {
          const currentLocal = getStoredJson<GameBid[]>(STORAGE_KEYS.BIDS, []);
          const merged = [...items];
          for (const loc of currentLocal) {
            if (!merged.some((m) => m.id === loc.id)) {
              merged.push(loc);
            }
          }
          setStoredJson(STORAGE_KEYS.BIDS, merged);
          onUpdate(merged, true);
        }
      }
    } catch (err) {
      console.error('[Supabase Network Failure] Direct bids query error:', err);
    }
  };

  queryDirectBids();

  // 3. Realtime Subscription on 'bids' table
  const channel = supabase
    .channel('public:bids:realtime')
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'bids' },
      (payload) => {
        if (!isMounted) return;
        console.log('[Supabase Realtime] Bids table event:', payload.eventType);
        queryDirectBids();
      }
    )
    .subscribe();

  return () => {
    isMounted = false;
    unsubStorage();
    supabase.removeChannel(channel);
  };
}

export async function placeBidInFirestore(
  bid: Omit<GameBid, 'id' | 'date' | 'status'>,
  user: UserProfile
): Promise<string> {
  const scope = resolveUserAuthScope(user);
  const now = new Date();
  const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
    .toString()
    .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  })}`;
  const bidId = `bid-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const cleanPointsResult = sanitizeAmount(bid.points, 1, 100000);
  const safePoints = cleanPointsResult.isValid ? cleanPointsResult.amount : bid.points;

  // 1. Optimistic Local Update immediately
  const newBid: GameBid = {
    ...bid,
    marketName: sanitizeText(bid.marketName, 50),
    gameType: sanitizeText(bid.gameType, 50),
    digitOrPana: sanitizeText(bid.digitOrPana, 10),
    points: safePoints,
    id: bidId,
    date: dateStr,
    status: 'Placed',
    userId: scope.uid,
    userPhone: scope.phone,
    userName: sanitizeText(user.name, 50),
  } as any;

  const all = getStoredJson<GameBid[]>(STORAGE_KEYS.BIDS, []);
  setStoredJson(STORAGE_KEYS.BIDS, [newBid, ...all]);

  // 2. Direct plain insert into Supabase 'bids' table without auth checks
  try {
    const userUuid = toSupabaseUuid(scope.uid || scope.phone || '00000000-0000-0000-0000-000000000000');
    const marketUuid = toSupabaseUuid((bid as any).marketId || bid.marketName || '00000000-0000-0000-0000-000000000000');

    const { error } = await supabase.from('bids').insert({
      user_id: userUuid,
      market_id: marketUuid,
      game_type: sanitizeText(bid.gameType, 50),
      digits: sanitizeText(bid.digitOrPana, 10),
      points: safePoints,
      status: 'PENDING',
    });

    if (error) {
      console.error('[Supabase Error] Direct placeBid failed:', error.message, error.details);
    }
  } catch (err) {
    console.error('[Supabase Network Failure] Place bid fell back to optimistic local state:', err);
  }

  return bidId;
}

// ==========================================
// 6. Payment Gateway Config
// ==========================================
export function subscribeToPaymentGateway(
  onUpdate: (config: PaymentGatewayConfig) => void
): () => void {
  const readData = () => {
    const cfg = getStoredJson<PaymentGatewayConfig>(STORAGE_KEYS.GATEWAY, DEFAULT_GATEWAY_CONFIG);
    onUpdate(cfg);
  };
  readData();
  return addStorageListener(STORAGE_KEYS.GATEWAY, readData);
}

export async function updatePaymentGatewayConfig(
  config: Partial<PaymentGatewayConfig>
): Promise<void> {
  const current = getStoredJson<PaymentGatewayConfig>(STORAGE_KEYS.GATEWAY, DEFAULT_GATEWAY_CONFIG);
  const updated = { ...current, ...config, updatedAt: new Date().toISOString() };
  setStoredJson(STORAGE_KEYS.GATEWAY, updated);
}

// ==========================================
// 7. Bank Accounts
// ==========================================
export function subscribeToBankAccounts(
  userParam: string | Partial<UserProfile>,
  onUpdate: (banks: BankAccount[], hasData: boolean) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);
  const readData = () => {
    const all = getStoredJson<BankAccount[]>(STORAGE_KEYS.BANKS, []);
    const filtered = all.filter((b) => {
      if (!scope.phone && !scope.uid) return true;
      const bUid = (b as any).userId || (b as any).uid || '';
      const bPhone = (b as any).userPhone || (b as any).phone || '';
      return (
        (scope.phone && bPhone.includes(scope.phone)) ||
        (scope.uid && bUid === scope.uid) ||
        (!bUid && !bPhone)
      );
    });
    onUpdate(filtered, filtered.length > 0);
  };
  readData();
  return addStorageListener(STORAGE_KEYS.BANKS, readData);
}

export async function addBankAccountToFirestore(
  bank: Omit<BankAccount, 'id' | 'updatedAt'>,
  user: UserProfile
): Promise<void> {
  const scope = resolveUserAuthScope(user);
  const now = new Date();
  const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
    .toString()
    .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  })}`;
  const lockDate = new Date();
  lockDate.setDate(lockDate.getDate() + 30);
  const lockDateStr = `${lockDate.getDate().toString().padStart(2, '0')}/${(lockDate.getMonth() + 1)
    .toString()
    .padStart(2, '0')}/${lockDate.getFullYear()}`;

  const cleanAccount = sanitizeBankAccount(bank.accountNumber).accountNumber || bank.accountNumber;
  const cleanIfsc = sanitizeIfsc(bank.ifscCode).ifsc || bank.ifscCode;
  const cleanHolder = sanitizeText(bank.accountHolder, 60);
  const cleanBankName = sanitizeText(bank.bankName, 60);

  const newBank: BankAccount = {
    ...bank,
    accountHolder: cleanHolder,
    bankName: cleanBankName,
    accountNumber: cleanAccount,
    ifscCode: cleanIfsc,
    id: `bank-${Date.now()}`,
    updatedAt: dateStr,
    lockUntil: lockDateStr,
    status: bank.status || 'Success',
    userId: scope.uid,
    userPhone: scope.phone,
  } as any;

  const all = getStoredJson<BankAccount[]>(STORAGE_KEYS.BANKS, []);
  setStoredJson(STORAGE_KEYS.BANKS, [newBank, ...all]);
}

// ==========================================
// 8. Notifications with Supabase Real-Time Channel & Tables
// ==========================================
export function subscribeToNotifications(
  userParam: string | Partial<UserProfile>,
  onUpdate: (notifications: AppNotification[], hasData: boolean) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);
  let isMounted = true;

  // 1. Initial Local Cache Load
  const emitLocal = () => {
    const all = getStoredJson<AppNotification[]>(STORAGE_KEYS.NOTIFICATIONS, [
      {
        id: 'n-1',
        title: 'Welcome to RAMA777!',
        message: 'Fast & secure mobile Matka platform powered by Supabase. Enjoy instant withdrawals and 24/7 support.',
        time: 'Just now',
        read: false,
        type: 'bonus',
      },
      {
        id: 'n-2',
        title: 'Kalyan Market Bids Open',
        message: 'Kalyan Day is running for Open bids until 04:15 PM. Place your lucky digit bids now!',
        time: '1h ago',
        read: false,
        type: 'bid',
      },
    ]);
    const filtered = all.filter((n) => {
      const target = (n as any).targetPhone;
      if (!target || target === 'all') return true;
      return scope.phone && target.includes(scope.phone);
    });
    if (isMounted) {
      onUpdate(filtered, filtered.length > 0);
    }
  };

  emitLocal();
  const unsubStorage = addStorageListener(STORAGE_KEYS.NOTIFICATIONS, emitLocal);

  // 2. Direct Query Supabase 'notifications' table if available
  const querySupabaseNotifications = async () => {
    try {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (!error && data && data.length > 0 && isMounted) {
        const remoteItems: AppNotification[] = data.map((row) => ({
          id: String(row.id || `notif-${Date.now()}`),
          title: String(row.title || 'Notice'),
          message: String(row.message || row.description || ''),
          time: row.created_at ? new Date(row.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Just now',
          read: Boolean(row.read || false),
          type: (row.type || 'alert') as any,
          targetPhone: row.target_phone || row.targetPhone || 'all',
        } as any));

        const currentLocal = getStoredJson<AppNotification[]>(STORAGE_KEYS.NOTIFICATIONS, []);
        const merged = [...remoteItems];
        for (const loc of currentLocal) {
          if (!merged.some((m) => m.id === loc.id)) {
            merged.push(loc);
          }
        }
        setStoredJson(STORAGE_KEYS.NOTIFICATIONS, merged);
      }
    } catch (err) {
      // Table doesn't exist yet or offline; fallback to realtime broadcast channel
    }
  };

  querySupabaseNotifications();

  // 3. Realtime Supabase Channel listening to both postgres_changes and live broadcast events
  const channel = supabase
    .channel('public:notifications')
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'notifications' },
      async (payload) => {
        if (!isMounted) return;
        console.log('[Supabase Realtime] notifications table event:', payload.eventType);
        querySupabaseNotifications();
      }
    )
    .on('broadcast', { event: 'admin_notification' }, (payload) => {
      if (!isMounted || !payload?.payload) return;
      console.log('[Supabase Realtime] Received live admin broadcast notification:', payload.payload);
      const incoming = payload.payload;
      const newNotif: AppNotification = {
        id: incoming.id || `notif-${Date.now()}`,
        title: incoming.title || 'Admin Announcement',
        message: incoming.message || '',
        time: 'Just now',
        read: false,
        type: incoming.type || 'alert',
        targetPhone: incoming.targetPhone || 'all',
      } as any;

      const current = getStoredJson<AppNotification[]>(STORAGE_KEYS.NOTIFICATIONS, []);
      if (!current.some((n) => n.id === newNotif.id)) {
        const updated = [newNotif, ...current];
        setStoredJson(STORAGE_KEYS.NOTIFICATIONS, updated);
      }
    })
    .subscribe((status) => {
      console.log('[Supabase Realtime] notifications channel status:', status);
    });

  return () => {
    isMounted = false;
    unsubStorage();
    supabase.removeChannel(channel);
  };
}

export async function broadcastNotificationInFirestore(
  notif: Omit<AppNotification, 'id'> & { id?: string; targetPhone?: string }
): Promise<void> {
  const notifId = notif.id || `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
  const newNotif: AppNotification = {
    ...notif,
    id: notifId,
    read: false,
  };

  // 1. Optimistic Local Cache Update
  const all = getStoredJson<AppNotification[]>(STORAGE_KEYS.NOTIFICATIONS, []);
  setStoredJson(STORAGE_KEYS.NOTIFICATIONS, [newNotif, ...all]);

  // 2. Direct Insert into Supabase 'notifications' table (if table exists)
  try {
    await supabase.from('notifications').insert({
      id: notifId,
      title: notif.title,
      message: notif.message,
      type: notif.type || 'alert',
      target_phone: notif.targetPhone || 'all',
      read: false,
      created_at: new Date().toISOString(),
    });
  } catch (err) {
    // Continue to broadcast channel
  }

  // 3. Broadcast dynamically through Supabase Realtime channel so all connected players see it immediately
  try {
    const channel = supabase.channel('public:notifications');
    await channel.send({
      type: 'broadcast',
      event: 'admin_notification',
      payload: newNotif,
    });
  } catch (err) {
    console.error('[Supabase Error] Broadcast notification error:', err);
  }
}

export async function seedInitialDataToFirestore(): Promise<void> {
  // Pure local storage operation - no-op
}
