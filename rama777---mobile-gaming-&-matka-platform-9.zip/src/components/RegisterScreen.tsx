/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  User,
  Phone,
  Lock,
  Eye,
  EyeOff,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  ArrowLeft,
  Sparkles,
  Gift,
  KeyRound,
  Check,
  Loader2,
} from 'lucide-react';
import { UserProfile } from '../types';
import { registerUserInSupabase } from '../services/supabaseAuthService';

interface RegisterScreenProps {
  onRegisterSuccess: (newUser: UserProfile) => void;
  onNavigateToLogin: () => void;
}

export const RegisterScreen: React.FC<RegisterScreenProps> = ({
  onRegisterSuccess,
  onNavigateToLogin,
}) => {
  const [name, setName] = useState<string>('');
  const [mobileNumber, setMobileNumber] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [mpin, setMpin] = useState<string>('');
  const [agreeTerms, setAgreeTerms] = useState<boolean>(true);

  // Status and animation states
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [successMessage, setSuccessMessage] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const handleMobileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, '').slice(0, 10);
    setMobileNumber(val);
    setErrorMessage('');
  };

  const handleMpinChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, '').slice(0, 4);
    setMpin(val);
    setErrorMessage('');
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    if (!name.trim()) {
      setErrorMessage('Please enter your full name.');
      return;
    }

    const cleanPhone = mobileNumber.replace(/\D/g, '');
    if (cleanPhone.length !== 10) {
      setErrorMessage('Please enter a valid 10-digit mobile number.');
      return;
    }

    if (!password || password.length < 4) {
      setErrorMessage('Password must be at least 4 characters.');
      return;
    }

    if (!mpin || mpin.length !== 4) {
      setErrorMessage('Security MPIN must be exactly 4 digits.');
      return;
    }

    if (!agreeTerms) {
      setErrorMessage('Please accept the RAMA777 Fair Play Rules to register.');
      return;
    }

    setIsSubmitting(true);

    try {
      // Upsert directly into Supabase 'users' table
      const result = await registerUserInSupabase({
        name: name.trim(),
        mobile: cleanPhone,
        password: password,
        mpin: mpin,
      });

      if (result.success && result.user) {
        setSuccessMessage('Registration successful! ₹500 Welcome Bonus credited.');
        setTimeout(() => {
          if (result.user) {
            onRegisterSuccess(result.user);
          }
        }, 800);
      } else {
        setErrorMessage(result.message || 'Registration failed. Please try again.');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Network error occurred during registration. Please retry.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-full bg-white flex flex-col justify-between p-6">
      <div className="w-full max-w-sm mx-auto">
        {/* Navigation & Header */}
        <div className="flex items-center justify-between mb-4">
          <button
            type="button"
            onClick={onNavigateToLogin}
            className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 py-1.5 px-3 rounded-lg transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Login</span>
          </button>
          <div className="flex items-center gap-1 bg-amber-50 border border-amber-200 text-amber-700 px-2.5 py-1 rounded-full text-[11px] font-semibold">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
            <span>Secure 256-Bit SSL</span>
          </div>
        </div>

        {/* Brand Banner */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center gap-2 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#FF7700] to-amber-400 flex items-center justify-center shadow-md">
              <span className="text-white font-black text-xl tracking-tight">R</span>
            </div>
            <h1 className="text-3xl font-black text-[#FF7700] tracking-wider drop-shadow-sm">
              RAMA<span className="text-slate-800">777</span>
            </h1>
          </div>
          <p className="text-xs text-slate-500 font-medium">Create your official player account</p>

          {/* Welcome Bonus pill */}
          <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-orange-50 to-amber-50 border border-orange-200 rounded-full text-xs font-bold text-[#FF7700]">
            <Gift className="w-4 h-4 text-[#FF7700]" />
            <span>₹500 Free Welcome Bonus on Sign Up!</span>
          </div>
        </div>

        {/* Error / Success Feedback */}
        {errorMessage && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl flex items-start gap-2.5 text-xs text-red-700">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
            <span className="font-medium">{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2.5 text-xs text-emerald-800">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            <span className="font-semibold">{successMessage}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleRegister} className="space-y-4">
          {/* Field 1: Full Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Full Name <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <User className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  setErrorMessage('');
                }}
                placeholder="Enter your full name"
                className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:border-[#FF7700] focus:ring-2 focus:ring-[#FF7700]/20 transition-all"
                required
              />
            </div>
          </div>

          {/* Field 2: 10-Digit Mobile Number */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              10-Digit Mobile Number <span className="text-red-500">*</span>
            </label>
            <div className="relative flex">
              <div className="inline-flex items-center px-3 bg-slate-100 border border-r-0 border-slate-300 rounded-l-xl text-xs font-bold text-slate-700">
                <Phone className="w-3.5 h-3.5 mr-1 text-[#FF7700]" />
                +91
              </div>
              <input
                type="tel"
                value={mobileNumber}
                onChange={handleMobileChange}
                placeholder="Enter 10-digit number"
                className="w-full pl-3 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-r-xl text-sm font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:border-[#FF7700] focus:ring-2 focus:ring-[#FF7700]/20 tracking-wider transition-all"
                maxLength={10}
                required
              />
            </div>
            <p className="text-[11px] text-slate-400 mt-1">Used for login and instant payout verification</p>
          </div>

          {/* Field 3: Password */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Account Password <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Lock className="w-4 h-4" />
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setErrorMessage('');
                }}
                placeholder="Create secure password"
                className="w-full pl-9 pr-10 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:border-[#FF7700] focus:ring-2 focus:ring-[#FF7700]/20 transition-all"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Field 4: 4-Digit Security MPIN Setup */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold text-slate-700">
                4-Digit Security MPIN <span className="text-red-500">*</span>
              </label>
              <span className="text-[11px] text-[#FF7700] font-semibold">For Quick 1-Tap Login</span>
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <KeyRound className="w-4 h-4 text-[#FF7700]" />
              </div>
              <input
                type="password"
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={4}
                value={mpin}
                onChange={handleMpinChange}
                placeholder="Set 4-digit PIN (e.g. 7777)"
                className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold tracking-widest text-slate-800 placeholder-slate-400 focus:outline-none focus:border-[#FF7700] focus:ring-2 focus:ring-[#FF7700]/20 transition-all"
                required
              />
            </div>
            <div className="flex items-center gap-1.5 mt-1.5">
              {[0, 1, 2, 3].map((idx) => (
                <div
                  key={idx}
                  className={`h-1.5 flex-1 rounded-full transition-all duration-200 ${
                    idx < mpin.length ? 'bg-[#FF7700]' : 'bg-slate-200'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Fair Play & Terms Checkbox */}
          <div className="pt-1">
            <label className="flex items-start gap-2.5 cursor-pointer">
              <div
                onClick={() => setAgreeTerms(!agreeTerms)}
                className={`w-4 h-4 mt-0.5 rounded border flex items-center justify-center transition-colors cursor-pointer ${
                  agreeTerms
                    ? 'bg-[#FF7700] border-[#FF7700] text-white'
                    : 'border-slate-300 bg-white'
                }`}
              >
                {agreeTerms && <Check className="w-3 h-3 stroke-[3]" />}
              </div>
              <span className="text-xs text-slate-600 font-medium">
                I agree to the RAMA777 <span className="text-[#FF7700] font-bold">Terms & Conditions</span> and verify I am 18+ years of age.
              </span>
            </label>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className={`w-full py-3.5 px-4 rounded-xl font-bold text-sm text-white shadow-lg shadow-orange-500/20 flex items-center justify-center gap-2 transition-all cursor-pointer ${
              isSubmitting
                ? 'bg-orange-400 cursor-not-allowed'
                : 'bg-[#FF7700] hover:bg-[#E06600] active:scale-[0.98]'
            }`}
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Creating Account on Supabase...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Register & Claim ₹500 Bonus</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* Footer: Navigate to Login */}
      <div className="mt-6 pt-4 border-t border-slate-100 text-center">
        <p className="text-xs text-slate-500">
          Already have an account?{' '}
          <button
            type="button"
            onClick={onNavigateToLogin}
            className="text-[#FF7700] font-bold hover:underline cursor-pointer ml-1 inline-flex items-center gap-0.5"
          >
            Log In Directly
          </button>
        </p>
        <p className="text-[11px] text-slate-400 mt-2 font-medium">
          RAMA777 v1.0.2 • Trusted by 1 Million Users
        </p>
      </div>
    </div>
  );
};
