import React from 'react';
import { Volume2 } from 'lucide-react';
import { MarketItem } from '../types';
import { MarketCard } from './MarketCard';

interface HomeTabProps {
  markets: MarketItem[];
  currentTime: Date;
  onPlayMarket: (market: MarketItem) => void;
  onOpenChart: (marketName: string) => void;
  onOpenStarline: () => void;
  onOpenJackpot: () => void;
  onSetSimulatedTime?: (hour: number, minute: number, addDays?: number) => void;
  onResetRealTime?: () => void;
  isSimulated?: boolean;
}

export const HomeTab: React.FC<HomeTabProps> = ({
  markets,
  onPlayMarket,
  onOpenChart,
  onOpenStarline,
  onOpenJackpot,
}) => {
  const activeMarketsCount = markets.filter((m) => m.isOpen).length;

  return (
    <div className="flex-1 min-h-0 flex flex-col h-full overflow-hidden bg-[#FFFFFF]">
      {/* 1. FIXED TOP SECTION: Notification Banner & Quick Action Cards (Static - never scrolls) */}
      <div className="shrink-0 pt-2.5 px-3.5 space-y-2.5 pb-2 bg-white border-b border-slate-100 z-10 shadow-xs">
        {/* Orange Scrolling Notice Bar directly under header */}
        <div className="bg-orange-50 border border-orange-200 rounded-xl px-3 py-2 flex items-center gap-2 overflow-hidden shadow-2xs">
          <Volume2 className="w-4 h-4 text-[#FF7700] shrink-0" />
          <div className="overflow-hidden whitespace-nowrap w-full">
            <div className="animate-marquee flex gap-8 items-center text-xs font-semibold text-orange-950">
              <span>Current minimum deposit limit Rs. 300 • Instant Automatic Result Declaration • 24x7 Support Available</span>
              <span>Current minimum deposit limit Rs. 300 • Instant Automatic Result Declaration • 24x7 Support Available</span>
            </div>
          </div>
        </div>

        {/* Quick Action Banners for Bombay Starline & Bombay Jackpot */}
        <div className="grid grid-cols-2 gap-2.5">
          <button
            onClick={onOpenStarline}
            className="h-[76px] rounded-2xl bg-gradient-to-br from-[#FF7700] via-[#F26500] to-[#E65100] hover:brightness-105 text-white p-2.5 flex flex-col justify-between shadow-md shadow-orange-500/20 active:scale-[0.98] transition-all cursor-pointer text-left border border-orange-400/40"
          >
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-black uppercase tracking-wider bg-black/20 backdrop-blur-xs text-white px-2 py-0.5 rounded-full border border-white/30">
                Hourly
              </span>
              <span className="text-base">🎰</span>
            </div>
            <div>
              <h4 className="font-black text-xs sm:text-sm tracking-tight leading-tight text-white">
                Bombay Starline
              </h4>
              <p className="text-[10px] text-orange-100 font-medium">Hourly Results</p>
            </div>
          </button>

          <button
            onClick={onOpenJackpot}
            className="h-[76px] rounded-2xl bg-gradient-to-br from-[#FF7700] via-[#F26500] to-[#E65100] hover:brightness-105 text-white p-2.5 flex flex-col justify-between shadow-md shadow-orange-500/20 active:scale-[0.98] transition-all cursor-pointer text-left border border-orange-400/40"
          >
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-black uppercase tracking-wider bg-black/20 backdrop-blur-xs text-white px-2 py-0.5 rounded-full border border-white/30">
                10x Payout
              </span>
              <span className="text-base">💰</span>
            </div>
            <div>
              <h4 className="font-black text-xs sm:text-sm tracking-tight leading-tight text-white">
                Bombay Jackpot
              </h4>
              <p className="text-[10px] text-orange-100 font-medium">Instant Jodi Draws</p>
            </div>
          </button>
        </div>

        {/* Market Cards List Header with Live Counter */}
        <div className="flex items-center justify-between pt-0.5">
          <h3 className="font-black text-xs uppercase tracking-wider text-slate-800">
            Live &amp; Regular Markets
          </h3>
          <span className="text-[11px] font-bold text-orange-600 flex items-center gap-1.5 bg-orange-50 px-2.5 py-0.5 rounded-full border border-orange-200">
            <span className="w-2 h-2 rounded-full bg-[#FF7700] animate-pulse" />
            {activeMarketsCount} Active
          </span>
        </div>
      </div>

      {/* 2. DEDICATED INDEPENDENT SCROLLABLE CONTAINER: Only market cards scroll */}
      <div
        className="flex-1 min-h-0 overflow-y-auto px-3.5 pt-2.5 pb-6 space-y-3 overscroll-contain bg-[#FFFFFF]"
        style={{
          WebkitOverflowScrolling: 'touch',
        }}
      >
        {markets.map((market) => (
          <MarketCard
            key={market.id}
            market={market}
            onPlay={onPlayMarket}
            onOpenChart={onOpenChart}
          />
        ))}
      </div>
    </div>
  );
};
