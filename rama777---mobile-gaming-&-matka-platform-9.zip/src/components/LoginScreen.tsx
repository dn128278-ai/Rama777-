/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Phone,
  Lock,
  Eye,
  EyeOff,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  Delete,
  RotateCcw,
  KeyRound,
  ArrowRight,
  Loader2,
  Sparkles,
  HelpCircle,
} from 'lucide-react';
import { UserProfile } from '../types';
import {
  loginWithSupabaseMpin,
  loginWithSupabasePassword,
} from '../services/supabaseAuthService';

interface LoginScreenProps {
  onLoginSuccess: (userProfile: UserProfile) => void;
  savedMpin?: string;
  onUpdateMpin?: (newMpin: string) => void;
  phone?: string;
  onNavigateToRegister: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  onLoginSuccess,
  phone = '',
  onNavigateToRegister,
}) => {
  // Primary Login Method: 'mpin', Alternative: 'password'
  const [loginMethod, setLoginMethod] = useState<'mpin' | 'password'>('mpin');

  // Input states
  const [mobileNumber, setMobileNumber] = useState<string>(() => {
    const saved = localStorage.getItem('rama777_user_phone');
    if (saved && saved.replace(/\D/g, '').length === 10) {
      return saved.replace(/\D/g, '');
    }
    return phone ? phone.replace(/\D/g, '') : '6377972674';
  });

  const [enteredPin, setEnteredPin] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);

  // Status and animation states
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [successMessage, setSuccessMessage] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Quick reset helper modal
  const [showHelpModal, setShowHelpModal] = useState<boolean>(false);

  const handleMobileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, '').slice(0, 10);
    setMobileNumber(val);
    setErrorMessage('');
  };

  // Handle number keypad clicks for MPIN
  const handlePinPress = (digit: string) => {
    if (enteredPin.length < 4 && !isLoading) {
      const nextPin = enteredPin + digit;
      setEnteredPin(nextPin);
      setErrorMessage('');

      if (nextPin.length === 4) {
        // Auto trigger verification when 4th digit is pressed
        setTimeout(() => {
          executeMpinLogin(mobileNumber, nextPin);
        }, 150);
      }
    }
  };

  const handleBackspace = () => {
    if (!isLoading) {
      setEnteredPin((prev) => prev.slice(0, -1));
      setErrorMessage('');
    }
  };

  const handleClearPin = () => {
    if (!isLoading) {
      setEnteredPin('');
      setErrorMessage('');
    }
  };

  // Perform MPIN Login
  const executeMpinLogin = async (mobile: string, pin: string) => {
    const cleanMobile = mobile.replace(/\D/g, '');
    if (cleanMobile.length !== 10) {
      setErrorMessage('Please enter a valid 10-digit mobile number.');
      setEnteredPin('');
      return;
    }
    if (pin.length !== 4) {
      setErrorMessage('Please enter complete 4-digit security MPIN.');
      return;
    }

    setIsLoading(true);
    setErrorMessage('');
    setSuccessMessage('');

    try {
      const result = await loginWithSupabaseMpin(cleanMobile, pin);
      if (result.success && result.user) {
        setSuccessMessage('MPIN Verified! Access Granted.');
        setTimeout(() => {
          if (result.user) {
            onLoginSuccess(result.user);
          }
        }, 400);
      } else {
        setErrorMessage(result.message || 'Incorrect MPIN or user not found.');
        setEnteredPin('');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Login error occurred. Please try again.');
      setEnteredPin('');
    } finally {
      setIsLoading(false);
    }
  };

  // Perform Password Login
  const handlePasswordLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanMobile = mobileNumber.replace(/\D/g, '');
    if (cleanMobile.length !== 10) {
      setErrorMessage('Please enter a valid 10-digit mobile number.');
      return;
    }
    if (!password) {
      setErrorMessage('Please enter your account password.');
      return;
    }

    setIsLoading(true);
    setErrorMessage('');
    setSuccessMessage('');

    try {
      const result = await loginWithSupabasePassword(cleanMobile, password);
      if (result.success && result.user) {
        setSuccessMessage('Password Verified! Access Granted.');
        setTimeout(() => {
          if (result.user) {
            onLoginSuccess(result.user);
          }
        }, 400);
      } else {
        setErrorMessage(result.message || 'Incorrect password or user not found.');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Login error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-full bg-white flex flex-col justify-between p-5 select-none">
      <div className="w-full max-w-sm mx-auto">
        {/* Header: Clean RAMA777 Orange Logo */}
        <div className="text-center pt-2 pb-4">
          <div className="inline-flex items-center justify-center gap-2 mb-1.5">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-[#FF7700] to-amber-400 flex items-center justify-center shadow-md shadow-orange-500/20">
              <span className="text-white font-black text-2xl tracking-tight">R</span>
            </div>
            <h1 className="text-3xl font-black text-[#FF7700] tracking-wider drop-shadow-sm">
              RAMA<span className="text-slate-900">777</span>
            </h1>
          </div>
          <p className="text-xs font-semibold text-slate-500 tracking-wide">
            India's Most Trusted & Fastest Matka Platform
          </p>
        </div>

        {/* Tab Toggle: MPIN Login vs Password Login */}
        <div className="bg-slate-100 p-1 rounded-xl flex items-center mb-4">
          <button
            type="button"
            onClick={() => {
              setLoginMethod('mpin');
              setErrorMessage('');
              setEnteredPin('');
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              loginMethod === 'mpin'
                ? 'bg-[#FF7700] text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>4-Digit MPIN</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setLoginMethod('password');
              setErrorMessage('');
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              loginMethod === 'password'
                ? 'bg-[#FF7700] text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Password Login</span>
          </button>
        </div>

        {/* Mobile Number Input (Common to both methods) */}
        <div className="mb-4">
          <label className="block text-xs font-bold text-slate-700 mb-1.5">
            Registered Mobile Number <span className="text-red-500">*</span>
          </label>
          <div className="relative flex">
            <div className="inline-flex items-center px-3 bg-slate-100 border border-r-0 border-slate-300 rounded-l-xl text-xs font-bold text-slate-700">
              <Phone className="w-3.5 h-3.5 mr-1 text-[#FF7700]" />
              +91
            </div>
            <input
              type="tel"
              value={mobileNumber}
              onChange={handleMobileChange}
              placeholder="Enter 10-digit mobile"
              className="w-full pl-3 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-r-xl text-sm font-semibold tracking-wider text-slate-800 placeholder-slate-400 focus:outline-none focus:border-[#FF7700] focus:ring-2 focus:ring-[#FF7700]/20 transition-all"
              maxLength={10}
            />
          </div>
        </div>

        {/* Error / Success Feedback */}
        {errorMessage && (
          <div className="mb-3 p-2.5 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2 text-xs text-red-700">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
            <span className="font-medium">{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="mb-3 p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-xs text-emerald-800">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            <span className="font-semibold">{successMessage}</span>
          </div>
        )}

        {/* METHOD 1: 4-Digit MPIN Screen */}
        {loginMethod === 'mpin' && (
          <div className="flex flex-col items-center">
            <div className="text-center mb-2">
              <span className="text-xs font-bold text-slate-700">Enter 4-Digit Security MPIN</span>
              <p className="text-[11px] text-slate-400">Quick 1-Tap authentication</p>
            </div>

            {/* 4 Pin visual dots */}
            <div className="flex items-center justify-center gap-3.5 my-3">
              {[0, 1, 2, 3].map((index) => {
                const isFilled = index < enteredPin.length;
                return (
                  <div
                    key={index}
                    className={`w-11 h-12 rounded-xl flex items-center justify-center border-2 transition-all duration-200 ${
                      isFilled
                        ? 'border-[#FF7700] bg-orange-50/60 shadow-sm scale-105'
                        : 'border-slate-200 bg-slate-50'
                    }`}
                  >
                    {isFilled ? (
                      <div className="w-3.5 h-3.5 rounded-full bg-[#FF7700] shadow-sm animate-scaleIn" />
                    ) : (
                      <div className="w-2 h-2 rounded-full bg-slate-300" />
                    )}
                  </div>
                );
              })}
            </div>

            {/* Loading Indicator */}
            {isLoading && (
              <div className="flex items-center gap-1.5 text-xs text-[#FF7700] font-semibold my-1">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Verifying on Supabase...</span>
              </div>
            )}

            {/* Numeric Keypad for MPIN */}
            <div className="w-full max-w-[280px] grid grid-cols-3 gap-2.5 mt-2">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                <button
                  key={digit}
                  type="button"
                  onClick={() => handlePinPress(digit)}
                  disabled={isLoading}
                  className="h-12 bg-slate-50 hover:bg-orange-50 active:bg-orange-100 border border-slate-200 hover:border-orange-200 rounded-xl text-lg font-bold text-slate-800 active:text-[#FF7700] transition-all flex items-center justify-center cursor-pointer shadow-sm active:scale-95 disabled:opacity-50"
                >
                  {digit}
                </button>
              ))}

              {/* Clear button */}
              <button
                type="button"
                onClick={handleClearPin}
                disabled={isLoading || enteredPin.length === 0}
                className="h-12 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-500 hover:text-slate-800 transition-all flex items-center justify-center gap-1 cursor-pointer active:scale-95 disabled:opacity-40"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>CLEAR</span>
              </button>

              {/* Zero digit */}
              <button
                type="button"
                onClick={() => handlePinPress('0')}
                disabled={isLoading}
                className="h-12 bg-slate-50 hover:bg-orange-50 active:bg-orange-100 border border-slate-200 hover:border-orange-200 rounded-xl text-lg font-bold text-slate-800 active:text-[#FF7700] transition-all flex items-center justify-center cursor-pointer shadow-sm active:scale-95 disabled:opacity-50"
              >
                0
              </button>

              {/* Backspace button */}
              <button
                type="button"
                onClick={handleBackspace}
                disabled={isLoading || enteredPin.length === 0}
                className="h-12 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-slate-600 hover:text-slate-900 transition-all flex items-center justify-center cursor-pointer active:scale-95 disabled:opacity-40"
              >
                <Delete className="w-5 h-5 text-slate-600" />
              </button>
            </div>

            {/* Test hint info */}
            <div className="mt-3 flex items-center justify-between w-full max-w-[280px] text-[11px] text-slate-400">
              <span className="font-medium">Quick Test MPIN: <strong className="text-slate-600">7777</strong> or <strong className="text-slate-600">1234</strong></span>
              <button
                type="button"
                onClick={() => setShowHelpModal(true)}
                className="text-[#FF7700] font-bold hover:underline cursor-pointer"
              >
                Need Help?
              </button>
            </div>
          </div>
        )}

        {/* METHOD 2: Password Login Screen */}
        {loginMethod === 'password' && (
          <form onSubmit={handlePasswordLogin} className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-bold text-slate-700">
                  Account Password <span className="text-red-500">*</span>
                </label>
                <button
                  type="button"
                  onClick={() => setShowHelpModal(true)}
                  className="text-[11px] text-[#FF7700] font-bold hover:underline cursor-pointer"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setErrorMessage('');
                  }}
                  placeholder="Enter your account password"
                  className="w-full pl-9 pr-10 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:border-[#FF7700] focus:ring-2 focus:ring-[#FF7700]/20 transition-all"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Demo accounts: password is <strong className="text-slate-600">rama123</strong> or <strong className="text-slate-600">admin777</strong>
              </p>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className={`w-full py-3.5 px-4 rounded-xl font-bold text-sm text-white shadow-lg shadow-orange-500/20 flex items-center justify-center gap-2 transition-all cursor-pointer ${
                isLoading
                  ? 'bg-orange-400 cursor-not-allowed'
                  : 'bg-[#FF7700] hover:bg-[#E06600] active:scale-[0.98]'
              }`}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Verifying with Supabase...</span>
                </>
              ) : (
                <>
                  <span>Sign In</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}
      </div>

      {/* Footer: Don't have an account? Register */}
      <div className="mt-6 pt-4 border-t border-slate-100 text-center">
        <p className="text-xs text-slate-600 font-medium">
          Don't have an account?{' '}
          <button
            type="button"
            onClick={onNavigateToRegister}
            className="text-[#FF7700] font-black hover:underline cursor-pointer ml-1 inline-flex items-center gap-0.5"
          >
            <span>Register Now</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </p>

        {/* Security badge and version */}
        <div className="flex items-center justify-center gap-2 mt-3 text-[11px] text-slate-400 font-medium">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span>App Version: 1.0.2 • Trusted by 1 Million Users</span>
        </div>
      </div>

      {/* Quick Help Modal */}
      {showHelpModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xs w-full p-5 shadow-2xl border border-slate-100 animate-scaleIn">
            <div className="flex items-center gap-2 text-slate-800 font-bold text-sm mb-3">
              <HelpCircle className="w-4 h-4 text-[#FF7700]" />
              <span>RAMA777 Login Help</span>
            </div>
            <div className="text-xs text-slate-600 space-y-2 mb-4 leading-relaxed">
              <p>
                <strong>Default Player Demo:</strong><br />
                Mobile: <code className="bg-slate-100 px-1 py-0.5 rounded text-[#FF7700]">6377972674</code><br />
                MPIN: <code className="bg-slate-100 px-1 py-0.5 rounded text-[#FF7700]">7777</code> or <code className="bg-slate-100 px-1 py-0.5 rounded text-[#FF7700]">1234</code><br />
                Password: <code className="bg-slate-100 px-1 py-0.5 rounded text-[#FF7700]">rama123</code>
              </p>
              <p>
                <strong>Admin Demo:</strong><br />
                Mobile: <code className="bg-slate-100 px-1 py-0.5 rounded text-[#FF7700]">9876543210</code><br />
                MPIN: <code className="bg-slate-100 px-1 py-0.5 rounded text-[#FF7700]">9999</code><br />
                Password: <code className="bg-slate-100 px-1 py-0.5 rounded text-[#FF7700]">admin777</code>
              </p>
              <p className="text-slate-500 text-[11px]">
                You can also create a brand new account using the "Register" button below!
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowHelpModal(false)}
              className="w-full py-2 bg-[#FF7700] text-white font-bold rounded-xl text-xs hover:bg-[#E06600] transition-colors cursor-pointer"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
