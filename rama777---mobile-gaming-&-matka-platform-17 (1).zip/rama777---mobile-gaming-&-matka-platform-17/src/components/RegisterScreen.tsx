/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RAMA777 Official 3-Step Registration Flow
 * Clean Orange (#FF7700) and White Theme with:
 * - Step 1: Full Name input with user icon and "Next" button
 * - Step 2: "Setup your Account" with Mobile Number (+91) and "Sign In / Continue" button
 * - Step 3: Native HTML <input type="tel" inputmode="numeric"> boxes for "Enter your mPin" and "Confirm mPin"
 * - Auto-advances across all 8 PIN boxes, triggers native mobile numeric keypad, zero custom keypad
 * - Completely removes any referral code input box
 * - "M PIN set successfully!" toast notification and direct Supabase registration
 */

import React, { useState, useRef } from 'react';
import {
  User,
  Phone,
  Headphones,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  ArrowLeft,
} from 'lucide-react';
import { UserProfile } from '../types';
import { registerUserInSupabase } from '../services/supabaseAuthService';

interface RegisterScreenProps {
  onRegisterSuccess: (newUser: UserProfile) => void;
  onNavigateToLogin: () => void;
}

export const RegisterScreen: React.FC<RegisterScreenProps> = ({
  onRegisterSuccess,
  onNavigateToLogin,
}) => {
  // Step state: 1 -> Full Name, 2 -> Mobile Number, 3 -> Create MPIN
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3>(1);

  // Form values
  const [name, setName] = useState<string>('');
  const [mobileNumber, setMobileNumber] = useState<string>('');

  // Step 3 PIN native digit arrays
  const [enterDigits, setEnterDigits] = useState<string[]>(['', '', '', '']);
  const [confirmDigits, setConfirmDigits] = useState<string[]>(['', '', '', '']);

  const enterRefs = [
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
  ];

  const confirmRefs = [
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
  ];

  // Status and animation states
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [isStepLoading, setIsStepLoading] = useState<boolean>(false);
  const [showRegisteredToast, setShowRegisteredToast] = useState<boolean>(false);
  const [showMpinSuccessToast, setShowMpinSuccessToast] = useState<boolean>(false);
  const [showSupportModal, setShowSupportModal] = useState<boolean>(false);

  // Step 1: Submit Full Name -> Advance to Step 2
  const handleNextFromStep1 = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!name.trim() || name.trim().length < 2) {
      setErrorMessage('Please enter your full name (minimum 2 characters).');
      return;
    }

    setIsStepLoading(true);
    setTimeout(() => {
      setIsStepLoading(false);
      setCurrentStep(2);
    }, 250);
  };

  // Step 2: Submit Mobile Number -> Advance to Step 3
  const handleNextFromStep2 = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const cleanPhone = mobileNumber.replace(/\D/g, '');
    if (cleanPhone.length !== 10) {
      setErrorMessage('Please enter a valid 10-digit mobile number.');
      return;
    }

    setIsStepLoading(true);
    setTimeout(() => {
      setIsStepLoading(false);
      setCurrentStep(3);
      setShowRegisteredToast(true);
      setTimeout(() => setShowRegisteredToast(false), 2200);
      setTimeout(() => {
        enterRefs[0].current?.focus();
      }, 100);
    }, 250);
  };

  // Step 3: Handle native digit entry for "Enter your mPin"
  const handleEnterDigitChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.replace(/\D/g, '');
    const char = raw.slice(-1);
    const updated = [...enterDigits];
    updated[index] = char;
    setEnterDigits(updated);
    setErrorMessage('');

    if (char && index < 3) {
      enterRefs[index + 1].current?.focus();
    } else if (char && index === 3) {
      // Advance to first box of Confirm mPin
      confirmRefs[0].current?.focus();
    }
  };

  const handleEnterKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      if (!enterDigits[index] && index > 0) {
        const updated = [...enterDigits];
        updated[index - 1] = '';
        setEnterDigits(updated);
        enterRefs[index - 1].current?.focus();
      } else {
        const updated = [...enterDigits];
        updated[index] = '';
        setEnterDigits(updated);
      }
    }
  };

  // Step 3: Handle native digit entry for "Confirm mPin"
  const handleConfirmDigitChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.replace(/\D/g, '');
    const char = raw.slice(-1);
    const updated = [...confirmDigits];
    updated[index] = char;
    setConfirmDigits(updated);
    setErrorMessage('');

    if (char && index < 3) {
      confirmRefs[index + 1].current?.focus();
    } else if (char && index === 3) {
      // Both sections filled: trigger finalize
      const enteredMpin = enterDigits.join('');
      const confirmedMpin = updated.join('');
      if (enteredMpin.length === 4 && confirmedMpin.length === 4) {
        setTimeout(() => {
          finalizeRegistration(enteredMpin, confirmedMpin);
        }, 100);
      }
    }
  };

  const handleConfirmKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      if (!confirmDigits[index] && index > 0) {
        const updated = [...confirmDigits];
        updated[index - 1] = '';
        setConfirmDigits(updated);
        confirmRefs[index - 1].current?.focus();
      } else if (!confirmDigits[index] && index === 0) {
        enterRefs[3].current?.focus();
      } else {
        const updated = [...confirmDigits];
        updated[index] = '';
        setConfirmDigits(updated);
      }
    }
  };

  // Step 3: Finalize Registration in Supabase
  const finalizeRegistration = async (mPinVal: string, confirmVal: string) => {
    if (mPinVal.length !== 4) {
      setErrorMessage('Please enter complete 4-digit mPin.');
      enterRefs[0].current?.focus();
      return;
    }

    if (confirmVal.length !== 4) {
      setErrorMessage('Please confirm your 4-digit mPin.');
      confirmRefs[0].current?.focus();
      return;
    }

    if (mPinVal !== confirmVal) {
      setErrorMessage('mPin and Confirm mPin do not match.');
      setConfirmDigits(['', '', '', '']);
      confirmRefs[0].current?.focus();
      return;
    }

    setIsStepLoading(true);
    setErrorMessage('');

    try {
      const cleanPhone = mobileNumber.replace(/\D/g, '');
      const result = await registerUserInSupabase({
        name: name.trim(),
        mobile: cleanPhone,
        mpin: mPinVal,
      });

      if (result.success && result.user) {
        localStorage.setItem('rama777_user_phone', cleanPhone);
        localStorage.setItem('rama777_post_register_notice', 'true');
        setShowMpinSuccessToast(true);
        setTimeout(() => {
          if (result.user) {
            onRegisterSuccess(result.user);
          }
        }, 900);
      } else {
        setErrorMessage(result.message || 'Registration failed. Mobile may already be registered.');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Network error during registration.');
    } finally {
      setIsStepLoading(false);
    }
  };

  const enterPinStr = enterDigits.join('');
  const confirmPinStr = confirmDigits.join('');

  return (
    <div className="min-h-full bg-white text-slate-800 flex flex-col justify-between p-4 sm:p-5 select-none relative">
      {/* Subtle orange ambiance glow at top */}
      <div className="absolute top-0 left-0 right-0 h-44 bg-gradient-to-b from-[#FF7700]/10 via-[#FF7700]/5 to-transparent pointer-events-none" />

      {/* Top Bar with Back Arrow and Support Button matching video */}
      <div className="w-full max-w-sm mx-auto flex items-center justify-between relative z-20 pt-1 pb-2">
        {currentStep > 1 ? (
          <button
            type="button"
            onClick={() => {
              setErrorMessage('');
              setCurrentStep((prev) => (prev > 1 ? ((prev - 1) as 1 | 2 | 3) : 1));
            }}
            className="w-8 h-8 rounded-full bg-white border border-slate-200 text-slate-700 flex items-center justify-center shadow-xs hover:border-[#FF7700] cursor-pointer active:scale-95 transition-all"
            title="Go back"
          >
            <ArrowLeft className="w-4 h-4 text-slate-700" />
          </button>
        ) : (
          <div className="w-8 h-8" />
        )}

        <button
          type="button"
          onClick={() => setShowSupportModal(true)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white border border-slate-200 text-slate-700 hover:text-[#FF7700] hover:border-[#FF7700]/50 shadow-xs text-xs font-bold transition-all cursor-pointer active:scale-95"
        >
          <Headphones className="w-3.5 h-3.5 text-[#FF7700]" />
          <span>Support</span>
        </button>
      </div>

      {/* Main Multi-Step Form Container */}
      <div className="w-full max-w-sm mx-auto relative z-10 flex-1 flex flex-col justify-center">
        {/* Floating Error Banner */}
        {errorMessage && (
          <div className="mb-3 p-3 bg-red-50 border border-red-200 rounded-2xl flex items-center justify-between gap-2.5 shadow-sm animate-in fade-in slide-in-from-top-2 duration-200">
            <div className="flex items-center gap-2 text-xs font-bold text-red-700">
              <div className="w-5 h-5 rounded-full bg-red-100 flex items-center justify-center shrink-0">
                <AlertCircle className="w-3.5 h-3.5 text-red-600" />
              </div>
              <span>{errorMessage}</span>
            </div>
            <button
              type="button"
              onClick={() => setErrorMessage('')}
              className="px-2.5 py-1 bg-red-600 hover:bg-red-700 active:scale-95 text-white text-[10px] font-extrabold rounded-lg shadow-xs cursor-pointer transition-all shrink-0"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* ---------------- STEP 1: Full Name (Matching Video Frame 00:02 - 00:09) ---------------- */}
        {currentStep === 1 && (
          <div className="space-y-4 animate-in fade-in duration-200">
            {/* Header: Welcome To RAMA777 */}
            <div className="text-left pt-1 pb-2">
              <h1 className="text-2xl font-black text-slate-900 tracking-tight">
                Welcome To <span className="text-[#FF7700] italic">RAMA777</span>
              </h1>
              <p className="text-xs font-semibold text-slate-500 mt-1">
                India&apos;s best Satta Matka Application welcomes you!!!
              </p>
            </div>

            {/* Step 1 Card: User icon + Enter Full Name + Next button */}
            <div className="bg-white rounded-3xl border border-slate-200 shadow-md shadow-slate-200/50 p-6 sm:p-7 space-y-4">
              <form onSubmit={handleNextFromStep1} className="space-y-4">
                <div>
                  <div className="relative flex items-center px-4 py-3.5 rounded-2xl border-2 border-slate-200 bg-slate-50/70 focus-within:border-[#FF7700] focus-within:bg-orange-50/20 focus-within:ring-3 focus-within:ring-[#FF7700]/15 transition-all">
                    <User className="w-4 h-4 mr-2.5 text-slate-400 shrink-0" />
                    <input
                      type="text"
                      required
                      autoFocus
                      value={name}
                      onChange={(e) => {
                        setName(e.target.value);
                        setErrorMessage('');
                      }}
                      placeholder="Enter Full Name."
                      className="w-full bg-transparent text-sm font-bold text-slate-800 placeholder-slate-400 focus:outline-none"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isStepLoading || !name.trim()}
                  className={`w-full py-3.5 px-5 font-extrabold text-sm rounded-2xl shadow-md transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer ${
                    name.trim() && !isStepLoading
                      ? 'bg-gradient-to-r from-[#FF7700] via-[#F26500] to-[#E65100] hover:brightness-105 active:scale-[0.98] text-white shadow-orange-500/25 border border-orange-400/30'
                      : 'bg-slate-300 text-slate-500 cursor-not-allowed opacity-80'
                  }`}
                >
                  {isStepLoading ? (
                    <div className="flex items-center gap-1.5 py-0.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-white animate-bounce [animation-delay:-0.3s]" />
                      <div className="w-2.5 h-2.5 rounded-full bg-white animate-bounce [animation-delay:-0.15s]" />
                      <div className="w-2.5 h-2.5 rounded-full bg-white animate-bounce" />
                    </div>
                  ) : (
                    <span>Next</span>
                  )}
                </button>
              </form>
            </div>
          </div>
        )}

        {/* ---------------- STEP 2: Phone Number (Matching Video Frame 00:00 - 00:01) ---------------- */}
        {currentStep === 2 && (
          <div className="space-y-4 animate-in fade-in duration-200">
            {/* Center Emblem: Rupee pouch / Crown badge matching video */}
            <div className="text-center pt-1 pb-2">
              <div className="w-18 h-18 rounded-full bg-gradient-to-tr from-[#FF7700]/25 via-amber-400/20 to-transparent flex items-center justify-center p-1.5 mx-auto mb-2.5 shadow-md shadow-orange-500/15">
                <div className="w-full h-full rounded-full bg-white border-2 border-orange-200 flex items-center justify-center shadow-inner">
                  <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-[#E65100] via-[#FF7700] to-amber-500 flex items-center justify-center text-white shadow-md shadow-orange-500/25">
                    <span className="font-black text-2xl drop-shadow-xs">₹</span>
                  </div>
                </div>
              </div>
              <h2 className="text-xl font-black text-slate-900 tracking-tight">
                Setup your Account
              </h2>
            </div>

            {/* Step 2 Card: Phone Number label + Box + Sign In button */}
            <div className="bg-white rounded-3xl border border-slate-200 shadow-md shadow-slate-200/50 p-6 sm:p-7 space-y-4">
              <form onSubmit={handleNextFromStep2} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Phone Number
                  </label>
                  <div className="relative flex items-center px-4 py-3.5 rounded-2xl border-2 border-slate-200 bg-slate-50/70 focus-within:border-[#FF7700] focus-within:bg-orange-50/20 focus-within:ring-3 focus-within:ring-[#FF7700]/15 transition-all">
                    <Phone className="w-4 h-4 mr-2 text-slate-400 shrink-0" />
                    <span className="text-xs font-extrabold text-slate-600 mr-2">+91</span>
                    <input
                      type="tel"
                      required
                      autoFocus
                      maxLength={10}
                      value={mobileNumber}
                      onChange={(e) => {
                        setMobileNumber(e.target.value.replace(/\D/g, '').slice(0, 10));
                        setErrorMessage('');
                      }}
                      placeholder="6377267426"
                      className="w-full bg-transparent text-sm font-bold tracking-wider text-slate-800 placeholder-slate-400 focus:outline-none"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isStepLoading || mobileNumber.replace(/\D/g, '').length !== 10}
                  className={`w-full py-3.5 px-5 font-extrabold text-sm rounded-2xl shadow-md transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer ${
                    mobileNumber.replace(/\D/g, '').length === 10 && !isStepLoading
                      ? 'bg-gradient-to-r from-[#FF7700] via-[#F26500] to-[#E65100] hover:brightness-105 active:scale-[0.98] text-white shadow-orange-500/25 border border-orange-400/30'
                      : 'bg-slate-300 text-slate-500 cursor-not-allowed opacity-80'
                  }`}
                >
                  {isStepLoading ? (
                    <div className="flex items-center gap-1.5 py-0.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-white animate-bounce [animation-delay:-0.3s]" />
                      <div className="w-2.5 h-2.5 rounded-full bg-white animate-bounce [animation-delay:-0.15s]" />
                      <div className="w-2.5 h-2.5 rounded-full bg-white animate-bounce" />
                    </div>
                  ) : (
                    <span>Sign In</span>
                  )}
                </button>
              </form>
            </div>
          </div>
        )}

        {/* ---------------- STEP 3: Create your mPIN (Matching Video Frame 00:11 - 00:20) ---------------- */}
        {currentStep === 3 && (
          <div className="space-y-4 animate-in fade-in duration-200">
            {/* Header: RAMA777 title */}
            <div className="text-center pt-1 pb-1">
              <h1 className="text-3xl font-black text-[#FF7700] italic tracking-tight">
                RAMA777
              </h1>
            </div>

            {/* Step 3 Card: Native Numeric Inputs for Enter mPin + Confirm mPin */}
            <div className="bg-white rounded-3xl border border-slate-200 shadow-md shadow-slate-200/50 p-5 sm:p-6 space-y-4">
              <div className="text-center">
                <h2 className="text-base font-extrabold text-slate-800 tracking-tight">
                  Create your mPIN
                </h2>
                <p className="text-[11px] font-medium text-slate-500 mt-0.5">
                  You can login using this mPIN for next time
                </p>
              </div>

              {/* Section 1: Enter your mPin with 4 Native HTML Numeric Inputs */}
              <div>
                <div className="mb-1.5 px-1">
                  <span className="text-xs font-bold text-[#FF7700]">
                    Enter your mPin
                  </span>
                </div>

                <div className="flex items-center justify-center gap-3 py-1">
                  {[0, 1, 2, 3].map((idx) => {
                    const hasVal = enterDigits[idx] !== '';
                    return (
                      <input
                        key={idx}
                        ref={enterRefs[idx]}
                        type="tel"
                        inputMode="numeric"
                        pattern="[0-9]*"
                        maxLength={1}
                        value={enterDigits[idx]}
                        onChange={(e) => handleEnterDigitChange(idx, e)}
                        onKeyDown={(e) => handleEnterKeyDown(idx, e)}
                        onFocus={(e) => e.target.select()}
                        disabled={isStepLoading}
                        autoComplete="off"
                        aria-label={`Enter MPIN Digit ${idx + 1}`}
                        className={`w-12 h-13 text-center font-mono font-black text-xl rounded-xl border-2 transition-all outline-none caret-[#FF7700] ${
                          hasVal
                            ? 'border-[#FF7700] bg-orange-50/70 text-[#FF7700] shadow-xs'
                            : 'border-slate-300 bg-white text-slate-900 focus:border-[#FF7700] focus:ring-2 focus:ring-[#FF7700]/20'
                        }`}
                      />
                    );
                  })}
                </div>
              </div>

              {/* Section 2: Confirm mPin with 4 Native HTML Numeric Inputs */}
              <div>
                <div className="mb-1.5 px-1">
                  <span className="text-xs font-bold text-[#FF7700]">
                    Confirm mPin
                  </span>
                </div>

                <div className="flex items-center justify-center gap-3 py-1">
                  {[0, 1, 2, 3].map((idx) => {
                    const hasVal = confirmDigits[idx] !== '';
                    return (
                      <input
                        key={idx}
                        ref={confirmRefs[idx]}
                        type="tel"
                        inputMode="numeric"
                        pattern="[0-9]*"
                        maxLength={1}
                        value={confirmDigits[idx]}
                        onChange={(e) => handleConfirmDigitChange(idx, e)}
                        onKeyDown={(e) => handleConfirmKeyDown(idx, e)}
                        onFocus={(e) => e.target.select()}
                        disabled={isStepLoading}
                        autoComplete="off"
                        aria-label={`Confirm MPIN Digit ${idx + 1}`}
                        className={`w-12 h-13 text-center font-mono font-black text-xl rounded-xl border-2 transition-all outline-none caret-[#FF7700] ${
                          hasVal
                            ? 'border-[#FF7700] bg-orange-50/70 text-[#FF7700] shadow-xs'
                            : 'border-slate-300 bg-white text-slate-900 focus:border-[#FF7700] focus:ring-2 focus:ring-[#FF7700]/20'
                        }`}
                      />
                    );
                  })}
                </div>
              </div>

              {/* Button: Create mPIN */}
              <button
                type="button"
                disabled={isStepLoading || enterPinStr.length !== 4 || confirmPinStr.length !== 4}
                onClick={() => finalizeRegistration(enterPinStr, confirmPinStr)}
                className={`w-full py-3.5 px-5 font-extrabold text-sm rounded-2xl shadow-md transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer ${
                  enterPinStr.length === 4 && confirmPinStr.length === 4 && !isStepLoading
                    ? 'bg-gradient-to-r from-[#FF7700] via-[#F26500] to-[#E65100] hover:brightness-105 active:scale-[0.98] text-white shadow-orange-500/25 border border-orange-400/30'
                    : 'bg-slate-300 text-slate-500 cursor-not-allowed opacity-80'
                }`}
              >
                {isStepLoading ? (
                  <div className="flex items-center gap-1.5 py-0.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-white animate-bounce [animation-delay:-0.3s]" />
                    <div className="w-2.5 h-2.5 rounded-full bg-white animate-bounce [animation-delay:-0.15s]" />
                    <div className="w-2.5 h-2.5 rounded-full bg-white animate-bounce" />
                  </div>
                ) : (
                  <span>Create mPIN</span>
                )}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Footer Navigation & Trusted Badge matching video */}
      <div className="w-full max-w-sm mx-auto pt-3 pb-1 text-center relative z-10 border-t border-slate-100 mt-2 space-y-2">
        <p className="text-xs text-slate-600 font-medium">
          Already have an account?{' '}
          <button
            type="button"
            onClick={onNavigateToLogin}
            className="text-[#FF7700] hover:text-[#E65100] font-extrabold underline cursor-pointer ml-1 inline-flex items-center gap-0.5"
          >
            <span>Sign In</span>
          </button>
        </p>

        {/* "Trusted by more than 1 Lakh Users" matching video bottom badge */}
        <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400 font-semibold pt-0.5">
          <ShieldCheck className="w-3.5 h-3.5 text-[#FF7700]" />
          <span>Trusted by more than 1 Lakh Users</span>
        </div>
      </div>

      {/* Video-style Floating "Registered Successfully!" Toast matching video frame 00:11-00:14 */}
      {showRegisteredToast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-slate-800/90 backdrop-blur-md text-white px-4 py-2 rounded-full shadow-xl flex items-center gap-2 animate-in fade-in slide-in-from-top-3 duration-200">
          <div className="w-4 h-4 rounded-full bg-blue-500 flex items-center justify-center">
            <CheckCircle2 className="w-3 h-3 text-white" />
          </div>
          <span className="text-xs font-bold">Registered Successfully!</span>
        </div>
      )}

      {/* Post-Registration Success Toast */}
      {showMpinSuccessToast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-slate-900/95 backdrop-blur-md text-white px-5 py-3 rounded-full shadow-2xl flex items-center gap-2.5 animate-in fade-in slide-in-from-bottom-4 duration-300 border border-[#FF7700]/50 max-w-[90%] text-center">
          <div className="w-5 h-5 rounded-full bg-[#FF7700] flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-3.5 h-3.5 text-white stroke-[3]" />
          </div>
          <span className="text-xs font-bold tracking-wide">
            Registration Successful! Please login with your new MPIN
          </span>
        </div>
      )}

      {/* Support Modal */}
      {showSupportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl p-5 max-w-xs w-full space-y-4 shadow-2xl border border-slate-100">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-orange-50 text-[#FF7700] flex items-center justify-center font-bold">
                  <Headphones className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-black text-slate-900">RAMA777 Support</h4>
                  <p className="text-[10px] text-slate-500 font-medium">24x7 Help Desk</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowSupportModal(false)}
                className="w-7 h-7 rounded-lg bg-slate-100 text-slate-500 hover:text-slate-800 flex items-center justify-center text-xs font-bold cursor-pointer"
              >
                &times;
              </button>
            </div>

            <div className="space-y-2 text-xs text-slate-600">
              <p>Need assistance with your registration? Our support team is online 24x7.</p>
              <div className="p-3 bg-orange-50 rounded-2xl border border-orange-100 space-y-2">
                <div className="flex items-center gap-2 font-bold text-slate-800">
                  <Phone className="w-3.5 h-3.5 text-[#FF7700]" />
                  <span>WhatsApp: +91 6377972674</span>
                </div>
                <div className="text-[11px] text-slate-500">
                  Instant registration assistance and welcome bonus claim.
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowSupportModal(false)}
              className="w-full py-2.5 bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white text-xs font-extrabold rounded-xl shadow-xs cursor-pointer active:scale-95"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
