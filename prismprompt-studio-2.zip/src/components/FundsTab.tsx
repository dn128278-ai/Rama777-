import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Wallet,
  FileClock,
  Building2,
  ChevronRight,
  ArrowLeft,
  Gift,
  CheckCircle2,
  AlertCircle,
  Plus,
  ShieldAlert,
  Lock,
  Clock,
  XCircle,
  Sparkles,
  Smartphone,
  Info,
  Calendar,
  Check,
  Zap,
  Copy,
  ExternalLink,
  ShieldCheck,
  ArrowRight,
  Download,
  Share2,
  User,
  Landmark,
} from 'lucide-react';
import { UserProfile, FundHistoryItem, BankAccount } from '../types';
import {
  sanitizeAmount,
  sanitizeBankAccount,
  sanitizeIfsc,
  sanitizeText,
} from '../utils/sanitizer';
import {
  subscribeToPaymentGateway,
  createDepositInFirestore,
  PaymentGatewayConfig,
  DEFAULT_GATEWAY_CONFIG,
} from '../services/firestoreSyncService';

interface FundsTabProps {
  user: UserProfile;
  addFundsHistory: FundHistoryItem[];
  withdrawFundsHistory: FundHistoryItem[];
  bankAccounts: BankAccount[];
  onAddFunds: (
    amount: number,
    bonus?: number,
    depositMode?: string,
    utr?: string,
    status?: 'Success' | 'Pending'
  ) => void;
  onAddFundsFailure?: (orderId: string, amount: number, depositMode: string, reason: string) => void;
  onWithdrawFunds: (amount: number, bankId: string) => boolean;
  onAddBank: (bank: Omit<BankAccount, 'id' | 'updatedAt'>) => void;
  gatewayConfig?: PaymentGatewayConfig;
}

export const FundsTab: React.FC<FundsTabProps> = ({
  user,
  addFundsHistory,
  withdrawFundsHistory,
  bankAccounts,
  onAddFunds,
  onAddFundsFailure,
  onWithdrawFunds,
  onAddBank,
  gatewayConfig: initialGatewayConfig,
}) => {
  const [subView, setSubView] = useState<string | null>(null);

  // Dynamic Payment Gateway Configuration synced with Firestore admin panel
  const [liveGatewayConfig, setLiveGatewayConfig] = useState<PaymentGatewayConfig>(
    initialGatewayConfig || DEFAULT_GATEWAY_CONFIG
  );

  useEffect(() => {
    const unsub = subscribeToPaymentGateway((cfg) => {
      setLiveGatewayConfig(cfg);
    });
    return () => unsub();
  }, []);

  const ACTIVE_VPA = liveGatewayConfig.merchantVpa || DEFAULT_GATEWAY_CONFIG.merchantVpa;
  const ACTIVE_MERCHANT = liveGatewayConfig.merchantName || DEFAULT_GATEWAY_CONFIG.merchantName;
  const MIN_DEPOSIT = liveGatewayConfig.minDeposit || 100;
  const MAX_DEPOSIT = liveGatewayConfig.maxDeposit || 100000;

  // Add Funds state
  const [depositAmount, setDepositAmount] = useState<string>('500');
  const [showBonusSheet, setShowBonusSheet] = useState<boolean>(false);
  const [showSecurityInfoModal, setShowSecurityInfoModal] = useState<boolean>(false);
  const [depositError, setDepositError] = useState<string>('');
  const [activePaymentType, setActivePaymentType] = useState<'normal' | 'bonus'>('normal');
  const [addFundsSuccess, setAddFundsSuccess] = useState<string>('');
  const [addFundsFilter, setAddFundsFilter] = useState<'ALL' | 'Success' | 'Pending' | 'Failure'>('ALL');

  // Withdrawal state
  const [withdrawAmount, setWithdrawAmount] = useState<string>('');
  const [withdrawError, setWithdrawError] = useState<string>('');
  const [withdrawSuccess, setWithdrawSuccess] = useState<string>('');
  const [withdrawFilter, setWithdrawFilter] = useState<'ALL' | 'Success' | 'Pending' | 'Failure'>('ALL');

  // Bank state
  const [accountHolder, setAccountHolder] = useState<string>('');
  const [bankName, setBankName] = useState<string>('');
  const [accountNumber, setAccountNumber] = useState<string>('');
  const [confirmAccountNumber, setConfirmAccountNumber] = useState<string>('');
  const [ifscCode, setIfscCode] = useState<string>('');
  const [bankAgreement, setBankAgreement] = useState<boolean>(false);
  const [bankSuccess, setBankSuccess] = useState<string>('');
  const [bankError, setBankError] = useState<string>('');

  // Selected receipt modal
  const [selectedReceipt, setSelectedReceipt] = useState<FundHistoryItem | null>(null);

  const fundsMenu = [
    { id: 'add_funds', label: 'Add Fund', desc: 'Instant top-up via UPI & Netbanking', icon: 'wallet-up' },
    { id: 'withdraw_funds', label: 'Withdraw Fund', desc: 'Instant withdrawal to bank account', icon: 'wallet-down' },
    { id: 'add_funds_history', label: 'Add Fund History', desc: 'Check deposit status & receipts', icon: 'history' },
    { id: 'withdraw_funds_history', label: 'Withdraw Fund History', desc: 'Check payout status & UTR', icon: 'history' },
    { id: 'bank_details', label: 'Add Bank Details', desc: 'Link your savings or current account', icon: 'bank' },
    { id: 'bank_details_history', label: 'Bank Details History', desc: 'View linked & verified accounts', icon: 'bank-check' },
  ];

  const popularBanks = [
    'State Bank of India',
    'HDFC Bank',
    'ICICI Bank',
    'Kotak Mahindra Bank',
    'Punjab National Bank',
    'Bank of Baroda',
    'Axis Bank',
    'Canara Bank',
  ];

  // Direct Add Fund: immediately credits local wallet balance without any payment modal
  const handleDirectAddFund = () => {
    const cleanAmt = sanitizeAmount(depositAmount, MIN_DEPOSIT, MAX_DEPOSIT);
    if (!cleanAmt.isValid) {
      setDepositError(cleanAmt.error || `Please enter a valid amount (Min: ₹${MIN_DEPOSIT}, Max: ₹${MAX_DEPOSIT})`);
      return;
    }
    const amt = cleanAmt.amount;
    setDepositError('');

    const orderId = `RAMA-${Math.floor(100000 + Math.random() * 900000)}`;
    onAddFunds(amt, 0, 'Instant Wallet Topup', orderId, 'Success');
    setAddFundsSuccess(`✓ ₹${amt.toLocaleString('en-IN')} successfully added to your wallet! (Ref: ${orderId})`);

    setTimeout(() => {
      setAddFundsSuccess('');
    }, 4500);
  };

  // Direct UPI Intent Launch & instant local deposit completion
  const handleLaunchKotakUpi = (appScheme: 'upi' | 'phonepe' | 'gpay' | 'paytm', appTitle: string) => {
    const cleanAmt = sanitizeAmount(depositAmount, MIN_DEPOSIT, MAX_DEPOSIT);
    const amt = activePaymentType === 'bonus' ? 1 : (cleanAmt.isValid ? cleanAmt.amount : 500);
    const bonusAmt = activePaymentType === 'bonus' ? 99 : 0;
    const orderId = `KTK-${Math.floor(100000 + Math.random() * 900000)}`;
    let deepLink = '';
    if (appScheme === 'phonepe') {
      deepLink = `phonepe://pay?pa=${ACTIVE_VPA}&pn=${encodeURIComponent(ACTIVE_MERCHANT)}&am=${amt}&tn=Wallet_Topup&cu=INR&mcc=0000&mode=02`;
    } else if (appScheme === 'gpay') {
      deepLink = `tez://upi/pay?pa=${ACTIVE_VPA}&pn=${encodeURIComponent(ACTIVE_MERCHANT)}&am=${amt}&tn=Wallet_Topup&cu=INR&mcc=0000&mode=02`;
    } else if (appScheme === 'paytm') {
      deepLink = `paytmmp://pay?pa=${ACTIVE_VPA}&pn=${encodeURIComponent(ACTIVE_MERCHANT)}&am=${amt}&tn=Wallet_Topup&cu=INR&mcc=0000&mode=02`;
    } else {
      deepLink = `upi://pay?pa=${ACTIVE_VPA}&pn=${encodeURIComponent(ACTIVE_MERCHANT)}&am=${amt}&tn=Wallet_Topup&cu=INR&mcc=0000&mode=02`;
    }
    try {
      if (typeof window !== 'undefined' && /android|iphone|ipad/i.test(navigator.userAgent)) {
        window.location.href = deepLink;
      }
    } catch {}
    // Instant local deposit recording and wallet crediting
    onAddFunds(amt, bonusAmt, appTitle, orderId, 'Success');
    setAddFundsSuccess(`✓ Payment Successful! ₹${amt + bonusAmt} credited to wallet via ${appTitle} (Ref: ${orderId})`);
    setTimeout(() => {
      setAddFundsSuccess('');
      setSubView('add_funds_history');
    }, 1500);
  };

  const handleWithdrawSubmit = () => {
    const cleanAmt = sanitizeAmount(withdrawAmount, 300, 100000);
    if (!cleanAmt.isValid) {
      setWithdrawError(cleanAmt.error || 'Minimum withdrawal limit is ₹300');
      return;
    }
    const amt = cleanAmt.amount;

    if (amt > user.walletBalance) {
      setWithdrawError(`Insufficient balance. Current balance is ₹${user.walletBalance}`);
      return;
    }
    if (bankAccounts.length === 0) {
      setWithdrawError('Please add a verified bank account first');
      return;
    }

    const defaultBank = bankAccounts.find((b) => b.isDefault) || bankAccounts[0];
    const success = onWithdrawFunds(amt, defaultBank.id);
    if (success) {
      setWithdrawError('');
      setWithdrawSuccess(`Withdrawal request of ₹${amt} initiated successfully!`);
      setTimeout(() => {
        setWithdrawSuccess('');
        setSubView('withdraw_funds_history');
      }, 1500);
    }
  };

  const handleAddBankSubmit = () => {
    const cleanHolder = sanitizeText(accountHolder, 50).toUpperCase();
    const cleanBank = sanitizeText(bankName, 50);
    const cleanAccCheck = sanitizeBankAccount(accountNumber);
    const cleanConfirmAcc = sanitizeBankAccount(confirmAccountNumber);
    const cleanIfscCheck = sanitizeIfsc(ifscCode);

    if (!cleanHolder || !cleanBank || !cleanAccCheck.isValid || !cleanIfscCheck.isValid) {
      setBankError('Please fill all bank details accurately.');
      return;
    }
    if (cleanAccCheck.accountNumber !== cleanConfirmAcc.accountNumber) {
      setBankError('Account numbers do not match. Please verify.');
      return;
    }
    if (!bankAgreement) {
      setBankError('Please acknowledge the 30-day update policy checkbox.');
      return;
    }

    onAddBank({
      accountHolder: cleanHolder,
      bankName: cleanBank,
      branch: 'MAIN BRANCH',
      ifscCode: cleanIfscCheck.ifsc,
      accountNumber: cleanAccCheck.accountNumber,
      isDefault: bankAccounts.length === 0,
      status: 'Success',
    });

    setBankSuccess('Bank account added & verified successfully!');
    setBankError('');
    setTimeout(() => {
      setBankSuccess('');
      setSubView('bank_details_history');
    }, 1200);
  };

  const filteredAddFunds = addFundsHistory.filter(
    (item) => addFundsFilter === 'ALL' || item.status === addFundsFilter
  );

  const filteredWithdrawFunds = withdrawFundsHistory.filter(
    (item) => withdrawFilter === 'ALL' || item.status === withdrawFilter
  );

  // Check if bank update is locked under 30 days
  const latestBank = bankAccounts[0];
  const isBankUpdateLocked = !!(latestBank && latestBank.lockUntil);

  return (
    <div className="pb-6 pt-2 px-4 transition-colors min-h-full bg-white text-slate-800">
      {!subView ? (
        /* Funds Menu with clean white background and orange/amber branding */
        <div className="space-y-4">
          {/* Quick Balance Header Card */}
          <div className="bg-gradient-to-r from-orange-500 via-orange-600 to-amber-600 rounded-3xl p-5 text-white shadow-lg relative overflow-hidden">
            <div className="absolute -right-6 -bottom-6 w-32 h-32 rounded-full bg-white/10 blur-xl pointer-events-none" />
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs uppercase tracking-wider text-orange-100 font-bold block">
                  Total Wallet Balance
                </span>
                <div className="text-3xl font-black font-mono tracking-tight mt-1 text-white">
                  ₹{Number(user.walletBalance || 0).toLocaleString('en-IN')}
                </div>
              </div>
              <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center text-white shadow-md">
                <Wallet className="w-6 h-6" />
              </div>
            </div>

            {/* Main Wallet & Winning Wallet breakdown chips */}
            <div className="mt-3 flex items-center gap-2">
              <div className="bg-white/15 backdrop-blur-xs px-2.5 py-1 rounded-xl flex items-center gap-1.5 border border-white/20">
                <span className="text-[10px] uppercase font-bold text-orange-100">Main:</span>
                <span className="text-xs font-black font-mono text-white">
                  ₹{Number(user.mainWallet ?? user.walletBalance ?? 0).toLocaleString('en-IN')}
                </span>
              </div>
              <div className="bg-emerald-500/30 backdrop-blur-xs px-2.5 py-1 rounded-xl flex items-center gap-1.5 border border-emerald-300/30">
                <span className="text-[10px] uppercase font-bold text-emerald-100">Winning:</span>
                <span className="text-xs font-black font-mono text-emerald-200">
                  ₹{Number(user.winningWallet ?? 0).toLocaleString('en-IN')}
                </span>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-white/20 flex items-center justify-between text-xs">
              <span className="text-orange-100">Safe & Instant Deposits/Withdrawals</span>
              <button
                onClick={() => setSubView('add_funds')}
                className="px-4 py-1.5 rounded-full bg-white text-orange-600 font-black text-xs active:scale-95 transition-all shadow-md cursor-pointer hover:bg-orange-50"
              >
                + Add Funds
              </button>
            </div>
          </div>

          {/* Menu Options */}
          <div className="space-y-3">
            {fundsMenu.map((item) => (
              <button
                key={item.id}
                onClick={() => setSubView(item.id)}
                className="w-full bg-white hover:bg-slate-50 rounded-2xl p-4 border border-slate-200 flex items-center justify-between shadow-xs hover:border-[#FF7700] active:scale-[0.99] transition-all cursor-pointer text-left"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-md shadow-orange-600/25 shrink-0">
                    {item.icon === 'wallet-up' || item.icon === 'wallet-down' ? (
                      <Wallet className="w-5 h-5" />
                    ) : item.icon === 'bank' || item.icon === 'bank-check' ? (
                      <Building2 className="w-5 h-5" />
                    ) : (
                      <FileClock className="w-5 h-5" />
                    )}
                  </div>
                  <div>
                    <span className="font-bold text-slate-900 text-sm block">
                      {item.label}
                    </span>
                    <span className="text-[11px] text-slate-500 block mt-0.5">
                      {item.desc}
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-400 shrink-0" />
              </button>
            ))}
          </div>
        </div>
      ) : subView === 'add_funds' ? (
        /* Clean Add Fund screen in light mode */
        <div className="flex flex-col min-h-[calc(100vh-140px)] justify-between space-y-4 bg-white">
          <div>
            {/* Top Bar */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setSubView(null)}
                  className="w-10 h-10 rounded-full bg-slate-100 shadow-xs border border-slate-200 text-slate-700 flex items-center justify-center cursor-pointer active:scale-95 transition-all hover:bg-slate-200"
                  aria-label="Back"
                >
                  <ArrowLeft className="w-5 h-5 stroke-[2.2]" />
                </button>
                <h1 className="text-xl font-black text-slate-900 tracking-tight">
                  Add Fund
                </h1>
              </div>

              {/* Wallet Pill */}
              <div className="bg-orange-50 text-[#FF7700] border border-orange-200 rounded-full px-3.5 py-1.5 flex items-center gap-1.5 shadow-xs">
                <Wallet className="w-3.5 h-3.5 text-[#FF7700] shrink-0" />
                <span className="text-xs font-bold font-mono tracking-tight text-[#FF7700]">
                  ₹{Number(user.walletBalance || 0).toFixed(2)}
                </span>
              </div>
            </div>

            {/* User Profile Summary Card */}
            <div className="relative overflow-hidden rounded-2xl bg-slate-50 p-4 text-slate-800 border border-slate-200 shadow-xs mb-4">
              <div className="flex items-center justify-between relative z-10">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-[#FF7700] text-white flex items-center justify-center shrink-0 shadow-md">
                    <User className="w-6 h-6 stroke-[2.5]" />
                  </div>
                  <div>
                    <h2 className="font-bold text-base text-slate-900 tracking-tight leading-tight">
                      {user.name || 'Girish12'}
                    </h2>
                    <p className="text-xs text-slate-500 font-mono mt-0.5 tracking-wide">
                      {user.phone ? (user.phone.replace(/\D/g, '').length === 10 ? user.phone.replace(/\D/g, '') : user.phone) : '6377972674'}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <div className="flex items-center justify-end gap-1 text-[11px] font-medium text-slate-500 mb-0.5">
                    <Wallet className="w-3 h-3 text-[#FF7700]" />
                    <span>Available Balance</span>
                  </div>
                  <div className="text-lg font-black font-mono tracking-tight text-slate-900">
                    ₹ {Number(user.walletBalance || 0).toFixed(2)}
                  </div>
                </div>
              </div>
            </div>

            {/* Success confirmation message banner */}
            {addFundsSuccess && (
              <div className="mb-4 p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs sm:text-sm font-semibold flex items-center gap-3 shadow-xs animate-in fade-in zoom-in-95">
                <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                <span className="leading-snug">{addFundsSuccess}</span>
              </div>
            )}

            {/* Section 1: Add Fund Input */}
            <div className="mb-4">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                Add Fund
              </label>
              <div className="bg-slate-50 rounded-2xl border border-slate-200 p-3 px-3.5 flex items-center justify-between focus-within:border-[#FF7700] focus-within:ring-2 focus-within:ring-orange-500/20 transition-all">
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <div className="w-10 h-10 rounded-full bg-orange-100 text-[#FF7700] flex items-center justify-center shrink-0 shadow-xs">
                    <Building2 className="w-5 h-5 stroke-[2.2]" />
                  </div>
                  <input
                    type="number"
                    inputMode="numeric"
                    value={depositAmount}
                    onChange={(e) => {
                      setDepositAmount(e.target.value);
                      if (depositError) setDepositError('');
                    }}
                    placeholder="Enter Amount"
                    className="w-full bg-transparent text-base sm:text-lg font-black text-slate-900 placeholder:text-slate-400 outline-none"
                  />
                </div>
                <span className="text-[#FF7700] font-black text-lg pr-2 select-none">
                  ₹
                </span>
              </div>
              {depositError && (
                <p className="text-xs font-semibold text-rose-600 mt-1.5 pl-1 flex items-center gap-1.5 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{depositError}</span>
                </p>
              )}
            </div>

            {/* Section 2: Quick Select Buttons */}
            <div className="mb-5">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                Quick Select
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { label: '₹500', value: '500' },
                  { label: '₹1,000', value: '1000' },
                  { label: '₹5,000', value: '5000' },
                  { label: '₹10,000', value: '10000' },
                ].map((opt) => {
                  const isSelected = depositAmount === opt.value;
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => {
                        setDepositAmount(opt.value);
                        if (depositError) setDepositError('');
                      }}
                      className={`py-3 px-1 rounded-xl text-xs sm:text-sm text-center transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-black shadow-md shadow-orange-500/25 scale-[1.02]'
                          : 'bg-white border border-slate-200 text-slate-700 hover:border-[#FF7700] hover:text-[#FF7700] font-bold shadow-2xs'
                      }`}
                    >
                      {opt.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Section 3: 100% Secure Transactions Card */}
            <div
              onClick={() => setShowSecurityInfoModal(true)}
              className="bg-white border border-slate-200 hover:border-[#FF7700] rounded-2xl p-4 flex items-center justify-between shadow-xs mb-4 cursor-pointer transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-orange-50 border border-orange-200 text-[#FF7700] flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-6 h-6 stroke-[2.2]" />
                </div>
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-slate-900 leading-snug">
                    100% Secure Transactions
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Your money is safe with us
                  </p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
            </div>

            {/* Quick Helper Links */}
            <div className="flex items-center justify-between text-xs px-1 text-slate-500 mb-2">
              <button
                type="button"
                onClick={() => setSubView('add_funds_history')}
                className="hover:text-[#FF7700] flex items-center gap-1 cursor-pointer font-semibold"
              >
                <FileClock className="w-3.5 h-3.5" />
                <span>View Deposit History</span>
              </button>

              <button
                type="button"
                onClick={() => setShowBonusSheet(true)}
                className="text-[#FF7700] hover:text-orange-600 flex items-center gap-1 cursor-pointer font-bold"
              >
                <Gift className="w-3.5 h-3.5" />
                <span>Claim ₹100 Bonus</span>
              </button>
            </div>
          </div>

          {/* Section 4: Action Button */}
          <div className="pt-3 pb-2">
            <button
              type="button"
              onClick={handleDirectAddFund}
              className={`w-full rounded-2xl py-4 px-4 flex items-center justify-between transition-all cursor-pointer shadow-lg active:scale-[0.99] ${
                depositAmount && parseInt(depositAmount, 10) >= MIN_DEPOSIT
                  ? 'bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-black shadow-orange-500/25'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              <div className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-xs flex items-center justify-center text-white shrink-0">
                <Lock className="w-4 h-4" />
              </div>
              <span className="font-black text-sm sm:text-base tracking-wide uppercase">
                Add Fund {depositAmount && parseInt(depositAmount, 10) > 0 ? `• ₹${depositAmount}` : ''}
              </span>
              <ArrowRight className="w-5 h-5 text-white shrink-0 stroke-[2.5]" />
            </button>
          </div>

          {/* Modal: 100% Secure Transactions Modal */}
          {showSecurityInfoModal && (
            <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
              <div className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 relative space-y-4 text-slate-800">
                <button
                  onClick={() => setShowSecurityInfoModal(false)}
                  className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 text-sm font-bold cursor-pointer"
                >
                  ✕
                </button>

                <div className="w-12 h-12 rounded-2xl bg-orange-50 border border-orange-200 text-[#FF7700] flex items-center justify-center mx-auto shadow-xs">
                  <ShieldCheck className="w-7 h-7" />
                </div>

                <div className="text-center">
                  <h3 className="text-base font-bold text-slate-900">
                    100% Secure & Regulated
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Your transactions are protected with industry-grade security protocols.
                  </p>
                </div>

                <div className="space-y-2.5 text-xs text-slate-700">
                  <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-slate-900 block font-bold">Bank Grade 256-Bit SSL</strong>
                      <span className="text-slate-500 text-[11px]">All payment links and UPI intent payloads are encrypted end-to-end.</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-slate-900 block font-bold">Direct Wallet Settlement</strong>
                      <span className="text-slate-500 text-[11px]">Points are credited directly to your local balance without delays.</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-slate-900 block font-bold">Instant Passbook Recording</strong>
                      <span className="text-slate-500 text-[11px]">View deposit history and balance receipts any time.</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setShowSecurityInfoModal(false)}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-black text-xs active:scale-95 transition-all cursor-pointer shadow-md shadow-orange-500/25"
                >
                  Understood
                </button>
              </div>
            </div>
          )}

          {/* Welcome Bonus Bottom Sheet Modal */}
          {showBonusSheet && (
            <div className="absolute inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
              <div className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 text-center animate-in slide-in-from-bottom duration-200 relative text-slate-800">
                <button
                  onClick={() => setShowBonusSheet(false)}
                  className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 text-sm font-bold cursor-pointer"
                >
                  ✕
                </button>

                <div className="w-20 h-20 mx-auto mb-3 relative flex items-center justify-center">
                  <div className="w-16 h-14 bg-gradient-to-tr from-[#FF7700] to-[#E65100] rounded-2xl shadow-md flex items-center justify-center text-white">
                    <Gift className="w-8 h-8 text-white" />
                  </div>
                  <div className="absolute -top-2 w-8 h-8 rounded-full bg-amber-400 border-2 border-white shadow-md flex items-center justify-center text-slate-950 font-black text-xs">
                    ₹
                  </div>
                </div>

                <div className="inline-block px-3 py-1 rounded-full border border-orange-200 bg-orange-50 text-xs font-bold text-[#FF7700] mb-2">
                  Welcome Bonus
                </div>

                <h3 className="text-lg font-black text-slate-900">
                  Pay ₹1, Get ₹100
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5 mb-5 font-medium">
                  *New Users Only, instant bonus credited to your wallet balance
                </p>

                <div className="space-y-2">
                  <button
                    onClick={() => {
                      setActivePaymentType('bonus');
                      setShowBonusSheet(false);
                      handleLaunchKotakUpi('phonepe', 'PhonePe Welcome Bonus');
                    }}
                    className="w-full py-3.5 rounded-2xl bg-[#5f259f] hover:bg-[#501f87] text-white font-extrabold text-sm shadow-md active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <span>Pay ₹1 via PhonePe</span>
                  </button>
                  <button
                    onClick={() => {
                      setActivePaymentType('bonus');
                      setShowBonusSheet(false);
                      handleLaunchKotakUpi('upi', 'Kotak UPI Welcome Bonus');
                    }}
                    className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-black text-sm shadow-md shadow-orange-500/25 active:scale-95 transition-all cursor-pointer"
                  >
                    Pay ₹1 via Any UPI
                  </button>
                  <button
                    onClick={() => setShowBonusSheet(false)}
                    className="w-full py-2 text-xs font-bold text-slate-400 hover:text-slate-700 cursor-pointer"
                  >
                    Skip for now
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>
      ) : subView === 'add_funds_history' ? (
        /* Add Funds History */
        <div className="space-y-4 bg-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setSubView(null)}
                className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <h2 className="text-base font-extrabold text-[#FF7700]">Add Funds History</h2>
            </div>
            <span className="text-xs font-mono text-slate-400">
              {filteredAddFunds.length} records
            </span>
          </div>

          {/* Status Filter Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {(['ALL', 'Success', 'Pending', 'Failure'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setAddFundsFilter(filter)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                  addFundsFilter === filter
                    ? 'bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-bold shadow-xs'
                    : 'bg-white border border-slate-200 text-slate-600 hover:text-[#FF7700]'
                }`}
              >
                {filter === 'ALL' ? 'All' : filter}
              </button>
            ))}
          </div>

          <div className="space-y-3">
            {filteredAddFunds.length === 0 ? (
              <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center shadow-xs">
                <FileClock className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-600">
                  No {addFundsFilter !== 'ALL' ? addFundsFilter.toLowerCase() : ''} records found
                </p>
              </div>
            ) : (
              filteredAddFunds.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedReceipt(item)}
                  className="bg-white rounded-3xl p-4 border border-slate-200 shadow-xs space-y-3 cursor-pointer hover:border-[#FF7700] transition-all text-slate-800"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-500 font-mono flex items-center gap-1.5">
                      📅 {item.date}
                    </span>
                    <span className="text-base font-black text-[#FF7700] font-mono">
                      +₹{item.amount}
                    </span>
                  </div>

                  <div className="bg-slate-50 rounded-2xl p-3 flex items-center justify-between border border-slate-100">
                    <div>
                      <span className="text-[10px] text-slate-500 font-semibold block uppercase">
                        Order Id
                      </span>
                      <span className="text-xs font-bold text-slate-800 font-mono">
                        {item.orderId}
                      </span>
                    </div>

                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 ${
                        item.status === 'Failure'
                          ? 'bg-rose-50 text-rose-700 border border-rose-200'
                          : item.status === 'Pending'
                          ? 'bg-amber-50 text-amber-700 border border-amber-200'
                          : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      }`}
                    >
                      {item.status === 'Failure' ? (
                        <XCircle className="w-3.5 h-3.5" />
                      ) : item.status === 'Pending' ? (
                        <Clock className="w-3.5 h-3.5" />
                      ) : (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      )}
                      <span>{item.status}</span>
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-1">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Request Type</span>
                      <span className="font-semibold text-emerald-600">{item.requestType}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block">Deposit Mode</span>
                      <span className="font-semibold text-slate-700">
                        {item.depositMode}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      ) : subView === 'withdraw_funds' ? (
        /* Withdraw Funds Flow */
        <div className="space-y-4 bg-white">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setSubView(null)}
              className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <h2 className="text-base font-extrabold text-[#FF7700]">Withdraw Funds</h2>
          </div>

          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4 text-slate-800">
            <div className="flex items-center justify-between text-xs pb-3 border-b border-slate-100">
              <span className="text-slate-500 font-semibold">Available for Withdrawal</span>
              <span className="font-black text-base text-[#FF7700] font-mono">
                ₹{Number(user.walletBalance || 0).toLocaleString('en-IN')}
              </span>
            </div>
            {(user.winningWallet !== undefined || user.mainWallet !== undefined) && (
              <div className="flex items-center justify-between text-[11px] text-slate-500 -mt-2 pb-2 border-b border-slate-50">
                <span>Winning Wallet (Withdrawable):</span>
                <span className="font-bold text-emerald-600 font-mono">
                  ₹{Number(user.winningWallet ?? 0).toLocaleString('en-IN')}
                </span>
              </div>
            )}

            {withdrawError && (
              <div className="p-3.5 rounded-xl bg-rose-50 text-rose-700 border border-rose-200 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{withdrawError}</span>
              </div>
            )}
            {withdrawSuccess && (
              <div className="p-3.5 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-semibold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{withdrawSuccess}</span>
              </div>
            )}

            <div>
              <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-1">
                Enter Amount (Min. ₹300)
              </label>
              <input
                type="number"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
                placeholder="300"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-base font-bold font-mono outline-none text-slate-900 focus:border-[#FF7700]"
              />

              {/* Preset Quick Chips for Withdrawal */}
              <div className="grid grid-cols-4 gap-2 mt-2">
                {['300', '500', '1000'].map((amt) => (
                  <button
                    key={amt}
                    onClick={() => setWithdrawAmount(amt)}
                    className="py-1.5 rounded-xl text-xs font-bold font-mono bg-white border border-slate-200 hover:border-[#FF7700] text-slate-700 transition-all cursor-pointer"
                  >
                    ₹{amt}
                  </button>
                ))}
                <button
                  onClick={() => setWithdrawAmount(user.walletBalance.toString())}
                  className="py-1.5 rounded-xl text-xs font-bold font-mono bg-orange-50 border border-orange-200 text-[#FF7700] hover:bg-orange-100 transition-all cursor-pointer"
                >
                  Max (All)
                </button>
              </div>
            </div>

            {/* Select Bank */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                  Transfer to Bank Account
                </label>
                <button
                  onClick={() => setSubView('bank_details_history')}
                  className="text-[11px] font-bold text-[#FF7700] hover:underline cursor-pointer"
                >
                  Manage Bank
                </button>
              </div>

              {bankAccounts.length === 0 ? (
                <button
                  onClick={() => setSubView('add_bank_details')}
                  className="w-full p-3 rounded-2xl border border-dashed border-[#FF7700] text-[#FF7700] text-xs font-bold flex items-center justify-center gap-2 cursor-pointer bg-orange-50 hover:bg-orange-100"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Bank Account First</span>
                </button>
              ) : (
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-[#FF7700]" />
                      <span>{bankAccounts[0].bankName}</span>
                      <span className="text-[10px] px-2 py-0.2 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-300 font-bold">
                        Verified
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono mt-1">
                      A/c: {bankAccounts[0].accountNumber} · IFSC: {bankAccounts[0].ifscCode}
                    </div>
                  </div>
                  <span className="text-xs text-slate-600 font-bold uppercase">
                    {bankAccounts[0].accountHolder}
                  </span>
                </div>
              )}
            </div>

            {/* Withdrawal Guidelines Card */}
            <div className="p-3 rounded-2xl bg-orange-50 border border-orange-200 text-slate-700 text-[11px] space-y-1">
              <div className="font-bold flex items-center gap-1 text-[#FF7700]">
                <Info className="w-3.5 h-3.5 shrink-0" />
                <span>Withdrawal Policy</span>
              </div>
              <ul className="list-disc pl-4 space-y-0.5 text-[10.5px] text-slate-600">
                <li>Withdrawal Timing: 10:00 AM to 05:00 PM daily.</li>
                <li>Minimum withdrawal ₹300, Maximum ₹50,000 per request.</li>
                <li>Transfers processed instantly via IMPS / NEFT.</li>
              </ul>
            </div>

            <button
              onClick={handleWithdrawSubmit}
              disabled={bankAccounts.length === 0}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-black text-sm shadow-md shadow-orange-500/25 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
            >
              Submit Withdrawal Request
            </button>
          </div>
        </div>
      ) : subView === 'withdraw_funds_history' ? (
        /* Withdraw Funds History */
        <div className="space-y-4 bg-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setSubView(null)}
                className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <h2 className="text-base font-extrabold text-[#FF7700]">Withdraw Funds History</h2>
            </div>
            <span className="text-xs font-mono text-slate-500">
              {filteredWithdrawFunds.length} records
            </span>
          </div>

          {/* Status Filter Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {(['ALL', 'Success', 'Pending', 'Failure'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setWithdrawFilter(filter)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                  withdrawFilter === filter
                    ? 'bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-bold shadow-xs'
                    : 'bg-white border border-slate-200 text-slate-600 hover:text-[#FF7700]'
                }`}
              >
                {filter === 'ALL' ? 'All' : filter}
              </button>
            ))}
          </div>

          <div className="space-y-3">
            {filteredWithdrawFunds.length === 0 ? (
              <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center shadow-xs">
                <FileClock className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-600">
                  No {withdrawFilter !== 'ALL' ? withdrawFilter.toLowerCase() : ''} withdrawal records found
                </p>
              </div>
            ) : (
              filteredWithdrawFunds.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedReceipt(item)}
                  className="bg-white rounded-3xl p-4 border border-slate-200 shadow-xs space-y-3 cursor-pointer hover:border-[#FF7700] transition-all text-slate-800"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-500 font-mono flex items-center gap-1.5">
                      📅 {item.date}
                    </span>
                    <span className="text-base font-black text-rose-600 font-mono">
                      -₹{item.amount}
                    </span>
                  </div>

                  <div className="bg-slate-50 rounded-2xl p-3 flex items-center justify-between border border-slate-100">
                    <div>
                      <span className="text-[10px] text-slate-400 font-semibold block uppercase">
                        Order Id
                      </span>
                      <span className="text-xs font-bold text-slate-800 font-mono">
                        {item.orderId}
                      </span>
                    </div>

                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 ${
                        item.status === 'Failure'
                          ? 'bg-rose-50 text-rose-700 border border-rose-200'
                          : item.status === 'Pending'
                          ? 'bg-amber-50 text-amber-700 border border-amber-200'
                          : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      }`}
                    >
                      {item.status === 'Failure' ? (
                        <XCircle className="w-3.5 h-3.5" />
                      ) : item.status === 'Pending' ? (
                        <Clock className="w-3.5 h-3.5" />
                      ) : (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      )}
                      <span>{item.status}</span>
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-xs pt-1 text-slate-500">
                    <div>
                      <span className="text-[10px] block">Bank Name</span>
                      <span className="font-semibold text-slate-800 truncate block">
                        {item.bankName || 'Bank of Baroda'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] block">Account Number</span>
                      <span className="font-semibold text-slate-800 font-mono truncate block">
                        {item.accountNumber || '•••• 4600'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] block">IFSC Code</span>
                      <span className="font-semibold text-slate-800 font-mono truncate block">
                        {item.ifscCode || 'BARB0DHAKAR'}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      ) : subView === 'add_bank_details' ? (
        /* Add Bank Details */
        <div className="space-y-4 bg-white">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setSubView(null)}
              className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <h2 className="text-base font-extrabold text-[#FF7700]">Add Bank Details</h2>
          </div>

          <div className="p-4 rounded-3xl bg-orange-50 border border-orange-200 shadow-xs space-y-2">
            <div className="flex items-center gap-2 text-[#FF7700] font-black text-xs uppercase tracking-wider">
              <ShieldAlert className="w-4 h-4 text-[#FF7700] shrink-0" />
              <span>30-Day Security Restriction Policy</span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed">
              <strong>Notice:</strong> For your account safety and fraud prevention, bank details can only be updated or added once every <strong>30 days</strong>. Please verify your Account Number and IFSC Code carefully before submitting.
            </p>
            {isBankUpdateLocked && latestBank.lockUntil && (
              <div className="p-2 rounded-xl bg-amber-50 border border-amber-200 text-[11px] font-bold text-amber-800 flex items-center gap-1.5 font-mono">
                <Lock className="w-3.5 h-3.5 shrink-0 text-amber-600" />
                <span>Existing Bank account is locked until {latestBank.lockUntil}.</span>
              </div>
            )}
          </div>

          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3.5 text-slate-800">
            {bankError && (
              <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{bankError}</span>
              </div>
            )}
            {bankSuccess && (
              <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-semibold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{bankSuccess}</span>
              </div>
            )}

            <div>
              <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-1">
                Account Holder Name
              </label>
              <input
                type="text"
                value={accountHolder}
                onChange={(e) => setAccountHolder(e.target.value)}
                placeholder={user.name ? user.name.toUpperCase() : "Account Holder Name"}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-900 outline-none focus:border-[#FF7700]"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-1">
                Bank Name
              </label>
              <input
                type="text"
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
                placeholder="e.g. State Bank of India"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-900 outline-none focus:border-[#FF7700]"
              />

              <div className="flex flex-wrap gap-1.5 mt-2">
                {popularBanks.map((b) => (
                  <button
                    key={b}
                    type="button"
                    onClick={() => setBankName(b)}
                    className={`text-[10px] px-2.5 py-1 rounded-lg font-medium transition-all cursor-pointer ${
                      bankName === b
                        ? 'bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-bold'
                        : 'bg-white border border-slate-200 text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {b}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-1">
                Account Number
              </label>
              <input
                type="text"
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                placeholder="Enter Account Number"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-bold font-mono text-slate-900 outline-none focus:border-[#FF7700]"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-1">
                Confirm Account Number
              </label>
              <input
                type="text"
                value={confirmAccountNumber}
                onChange={(e) => setConfirmAccountNumber(e.target.value)}
                placeholder="Re-enter Account Number"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-bold font-mono text-slate-900 outline-none focus:border-[#FF7700]"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-1">
                IFSC Code
              </label>
              <input
                type="text"
                value={ifscCode}
                onChange={(e) => setIfscCode(e.target.value.toUpperCase())}
                placeholder="e.g. SBIN0001234"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-bold font-mono uppercase text-slate-900 outline-none focus:border-[#FF7700]"
              />
            </div>

            <label className="flex items-start gap-2.5 pt-2 cursor-pointer">
              <input
                type="checkbox"
                checked={bankAgreement}
                onChange={(e) => setBankAgreement(e.target.checked)}
                className="mt-0.5 accent-[#FF7700] w-4 h-4 cursor-pointer"
              />
              <span className="text-xs text-slate-600 leading-snug">
                I understand that this bank account will be locked for <strong>30 days</strong> and cannot be modified until the lock period expires.
              </span>
            </label>

            <button
              onClick={handleAddBankSubmit}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-black text-sm shadow-md shadow-orange-500/25 active:scale-95 transition-all cursor-pointer mt-2"
            >
              Save & Lock Bank Details (30 Days)
            </button>
          </div>
        </div>
      ) : (
        /* Bank Details History */
        <div className="space-y-4 bg-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setSubView(null)}
                className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <h2 className="text-base font-extrabold text-[#FF7700]">My Bank Details</h2>
            </div>
            <button
              onClick={() => setSubView('add_bank_details')}
              className="text-xs font-bold text-[#FF7700] flex items-center gap-1 hover:underline cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add New</span>
            </button>
          </div>

          <div className="p-4 rounded-3xl bg-orange-50 border border-orange-200 shadow-xs space-y-2">
            <div className="flex items-center gap-2 text-[#FF7700] font-extrabold text-xs uppercase tracking-wide">
              <Lock className="w-4 h-4 text-[#FF7700] shrink-0" />
              <span>30-Day Modification Rule Active</span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed">
              As per security regulations, bank account modifications are restricted for <strong>30 days</strong> from the update date.
            </p>
            {latestBank && latestBank.lockUntil && (
              <div className="flex items-center justify-between pt-1 text-[11px] font-mono text-[#FF7700] border-t border-orange-200">
                <span>Last Updated: {latestBank.updatedAt}</span>
                <span className="font-bold text-[#FF7700]">Locked Until: {latestBank.lockUntil}</span>
              </div>
            )}
          </div>

          <div className="space-y-3">
            {bankAccounts.length === 0 ? (
              <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center shadow-xs">
                <Building2 className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-600">
                  No bank accounts linked yet
                </p>
                <button
                  onClick={() => setSubView('add_bank_details')}
                  className="mt-3 px-4 py-2 rounded-xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-bold text-xs shadow-xs cursor-pointer"
                >
                  Add Bank Account
                </button>
              </div>
            ) : (
              bankAccounts.map((b) => (
                <div
                  key={b.id}
                  className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3 relative text-slate-800"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-extrabold text-sm text-slate-900 uppercase tracking-wide">
                        {b.accountHolder}
                      </h3>
                      <p className="text-xs font-semibold text-[#FF7700] mt-0.5">{b.bankName}</p>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {b.isDefault && (
                        <span className="px-2.5 py-0.5 rounded-full bg-orange-50 text-[#FF7700] border border-orange-200 text-[10px] font-bold">
                          Default
                        </span>
                      )}
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 ${
                          b.status === 'Failure'
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : b.status === 'Pending'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        }`}
                      >
                        <Check className="w-3 h-3" />
                        <span>{b.status || 'Verified'}</span>
                      </span>
                    </div>
                  </div>

                  <div className="text-xs text-slate-600 space-y-1 bg-slate-50 p-3 rounded-2xl border border-slate-100">
                    <p className="uppercase text-[11px] font-medium text-slate-500">Branch: {b.branch}</p>
                    <p className="font-mono">IFSC Code : <strong className="text-slate-900">{b.ifscCode}</strong></p>
                    <p className="font-mono">A/c Number : <strong className="text-slate-900">{b.accountNumber}</strong></p>
                    <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                      <span>Updated: {b.updatedAt}</span>
                      {b.lockUntil && (
                        <span className="text-[#FF7700] flex items-center gap-1">
                          <Lock className="w-3 h-3" />
                          Lock: {b.lockUntil}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Full Receipt Modal */}
      {selectedReceipt && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 space-y-4 text-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-extrabold text-sm text-slate-900">
                Transaction Details
              </h3>
              <button
                onClick={() => setSelectedReceipt(null)}
                className="text-slate-400 hover:text-slate-700 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="text-center py-2">
              <span className="text-xs text-slate-500 block font-medium">Amount</span>
              <span className="text-3xl font-black text-[#FF7700] font-mono">
                ₹{selectedReceipt.amount}
              </span>
              <div className="mt-2">
                <span
                  className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${
                    selectedReceipt.status === 'Failure'
                      ? 'bg-rose-50 text-rose-700 border border-rose-200'
                      : selectedReceipt.status === 'Pending'
                      ? 'bg-amber-50 text-amber-700 border border-amber-200'
                      : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                  }`}
                >
                  ● {selectedReceipt.status}
                </span>
              </div>
            </div>

            <div className="space-y-2 text-xs text-slate-700 bg-slate-50 p-3.5 rounded-2xl font-mono border border-slate-100">
              <div className="flex justify-between">
                <span className="text-slate-500">Order ID:</span>
                <span className="font-bold text-slate-900">{selectedReceipt.orderId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Date & Time:</span>
                <span>{selectedReceipt.date}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Type:</span>
                <span className="text-[#FF7700] font-bold">{selectedReceipt.requestType}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Payment Mode:</span>
                <span>{selectedReceipt.depositMode}</span>
              </div>
              {selectedReceipt.bankName && selectedReceipt.bankName !== 'N/A' && (
                <div className="flex justify-between">
                  <span className="text-slate-500">Bank:</span>
                  <span>{selectedReceipt.bankName}</span>
                </div>
              )}
            </div>

            <button
              onClick={() => setSelectedReceipt(null)}
              className="w-full py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs active:scale-95 transition-all cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
