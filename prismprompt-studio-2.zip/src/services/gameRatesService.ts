/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Supabase-backed Game Rates and Winning Payout Calculation Service for RAMA777.
 * Fetches game rates dynamically from Supabase 'game_rates' table,
 * computes estimated returns, and handles real-time winning payouts.
 */

import { supabase } from '../supabase';
import { getDigitFromPana } from '../utils/marketEngine';
import { isMatchingUser, toSupabaseUuid } from '../utils/userScope';

export interface GameRateItem {
  id?: string | number;
  name: string;
  ratio: string; // e.g. "1 ka 10", "1 ka 160", "1 ka 100"
  multiplier: number; // e.g. 10, 160, 100, 300, 900, 1000, 10000
  icon: string;
  category: string; // 'RAMA777' | 'BOMBAY STARLINE' | 'BOMBAY JACKPOT'
}

export interface GameRateSection {
  category: string;
  sectionKey: 'RAMA777' | 'BOMBAY STARLINE' | 'BOMBAY JACKPOT';
  items: GameRateItem[];
}

export const DEFAULT_GAME_RATES: GameRateSection[] = [
  {
    category: 'RAMA777 Game Win Ratio',
    sectionKey: 'RAMA777',
    items: [
      { name: 'Single Digit', ratio: '1 ka 10', multiplier: 10, icon: 'dice-1', category: 'RAMA777' },
      { name: 'Single Pana', ratio: '1 ka 160', multiplier: 160, icon: 'spade', category: 'RAMA777' },
      { name: 'Jodi Digit', ratio: '1 ka 100', multiplier: 100, icon: 'dice-2', category: 'RAMA777' },
      { name: 'Double Pana', ratio: '1 ka 300', multiplier: 300, icon: 'spade-pair', category: 'RAMA777' },
      { name: 'Red Brackets', ratio: '1 ka 100', multiplier: 100, icon: 'brackets', category: 'RAMA777' },
      { name: 'Triple Pana', ratio: '1 ka 900', multiplier: 900, icon: 'cards-3', category: 'RAMA777' },
      { name: 'Half Sangam A', ratio: '1 ka 1000', multiplier: 1000, icon: 'coin-a', category: 'RAMA777' },
      { name: 'Half Sangam B', ratio: '1 ka 1000', multiplier: 1000, icon: 'coin-b', category: 'RAMA777' },
      { name: 'Full Sangam Digits', ratio: '1 ka 10000', multiplier: 10000, icon: 'coin-gold', category: 'RAMA777' },
    ],
  },
  {
    category: 'Bombay Starline Game Win Ratio',
    sectionKey: 'BOMBAY STARLINE',
    items: [
      { name: 'Single Digit', ratio: '1 ka 10', multiplier: 10, icon: 'dice-1', category: 'BOMBAY STARLINE' },
      { name: 'Single Pana', ratio: '1 ka 160', multiplier: 160, icon: 'spade', category: 'BOMBAY STARLINE' },
      { name: 'Double Pana', ratio: '1 ka 320', multiplier: 320, icon: 'spade-pair', category: 'BOMBAY STARLINE' },
      { name: 'Triple Pana', ratio: '1 ka 1000', multiplier: 1000, icon: 'cards-3', category: 'BOMBAY STARLINE' },
    ],
  },
  {
    category: 'Bombay Jackpot Game Win Ratio',
    sectionKey: 'BOMBAY JACKPOT',
    items: [
      { name: 'Jackpot', ratio: '1 ka 10', multiplier: 10, icon: 'spade', category: 'BOMBAY JACKPOT' },
    ],
  },
];

// In-memory cache of parsed rates for synchronous multiplier queries during fast bid typing
const cachedRatesMap: Record<string, number> = {
  // RAMA777 standard mappings
  'single_digit': 10,
  'single digit': 10,
  'single_digit_bulk': 10,
  'single digit bulk': 10,
  'odd_even': 10,
  'odd even': 10,
  'jodi_digit': 100,
  'jodi digit': 100,
  'jodi digits': 100,
  'jodi_digit_bulk': 100,
  'jodi bulk': 100,
  'group_jodi': 100,
  'group jodi': 100,
  'red_brackets': 100,
  'red brackets': 100,
  'single_pana': 160,
  'single pana': 160,
  'single_pana_bulk': 160,
  'single pana bulk': 160,
  'sp_motor': 160,
  'sp motor': 160,
  'double_pana': 300,
  'double pana': 300,
  'double_pana_bulk': 300,
  'double pana bulk': 300,
  'dp_motor': 300,
  'dp motor': 300,
  'triple_pana': 900,
  'triple pana': 900,
  'triple_pana_bulk': 900,
  'triple pana bulk': 900,
  'half_sangam': 1000,
  'half sangam': 1000,
  'half sangam a': 1000,
  'half sangam b': 1000,
  'full_sangam': 10000,
  'full sangam': 10000,
  'full sangam digits': 10000,
  // Starline mappings
  'starline_single_digit': 10,
  'starline_single_pana': 160,
  'starline_double_pana': 320,
  'starline_triple_pana': 1000,
  // Jackpot mappings
  'jackpot': 10,
  'bombay_jackpot': 10,
};

/**
 * Extracts a numeric multiplier from ratio string like "1 ka 10", "1:100", or raw number
 */
export function parseRatioMultiplier(ratioStr: string | number | undefined, defaultMult: number = 10): number {
  if (typeof ratioStr === 'number' && !isNaN(ratioStr)) {
    return ratioStr;
  }
  if (!ratioStr) return defaultMult;

  const str = String(ratioStr).trim();
  const match = str.match(/(?:1\s*(?:ka|:|\/)\s*)?(\d+)/i);
  if (match && match[1]) {
    const val = parseInt(match[1], 10);
    return isNaN(val) ? defaultMult : val;
  }
  return defaultMult;
}

function normalizeSectionKey(catName: string = ''): 'RAMA777' | 'BOMBAY STARLINE' | 'BOMBAY JACKPOT' {
  const lower = catName.toLowerCase();
  if (lower.includes('jackpot')) return 'BOMBAY JACKPOT';
  if (lower.includes('starline')) return 'BOMBAY STARLINE';
  return 'RAMA777';
}

async function seedDefaultGameRatesToSupabase(): Promise<void> {
  try {
    const flatRows: any[] = [];
    for (const section of DEFAULT_GAME_RATES) {
      for (const item of section.items) {
        flatRows.push({
          game_name: item.name,
          category: section.sectionKey,
          win_ratio: item.ratio,
          ratio: item.ratio,
          multiplier: item.multiplier,
          icon: item.icon,
          updated_at: new Date().toISOString(),
        });
      }
    }
    await supabase.from('game_rates').upsert(flatRows, { onConflict: 'game_name,category' });
  } catch (err) {
    console.warn('Game rates auto-seed note:', err);
  }
}

/**
 * Fetches game rates directly from Supabase 'game_rates' table.
 * Dynamically categorizes them into RAMA777, BOMBAY STARLINE, and BOMBAY JACKPOT sections.
 */
export async function fetchGameRatesFromSupabase(): Promise<GameRateSection[]> {
  try {
    const { data, error } = await supabase
      .from('game_rates')
      .select('*')
      .order('id', { ascending: true });

    if (error) {
      console.warn('[Supabase Error] Query game_rates failed, using cached defaults:', error.message);
      return DEFAULT_GAME_RATES;
    }

    if (!data || data.length === 0) {
      seedDefaultGameRatesToSupabase();
      return DEFAULT_GAME_RATES;
    }

    const ramaItems: GameRateItem[] = [];
    const starlineItems: GameRateItem[] = [];
    const jackpotItems: GameRateItem[] = [];

    for (const row of data) {
      const name = row.game_name || row.name || 'Game';
      const categoryRaw = row.category || row.game_category || row.section || '';
      const sectionKey = normalizeSectionKey(categoryRaw);
      const ratioStr = row.win_ratio || row.ratio || '1 ka 10';
      const multiplier = row.multiplier ? Number(row.multiplier) : parseRatioMultiplier(ratioStr);
      const icon = row.icon || 'dice-1';

      const item: GameRateItem = {
        id: row.id,
        name,
        ratio: ratioStr,
        multiplier,
        icon,
        category: sectionKey,
      };

      const key = name.toLowerCase().trim();
      cachedRatesMap[key] = multiplier;
      cachedRatesMap[key.replace(/\s+/g, '_')] = multiplier;

      if (sectionKey === 'BOMBAY STARLINE') {
        starlineItems.push(item);
      } else if (sectionKey === 'BOMBAY JACKPOT') {
        jackpotItems.push(item);
      } else {
        ramaItems.push(item);
      }
    }

    const sections: GameRateSection[] = [
      {
        category: 'RAMA777 Game Win Ratio',
        sectionKey: 'RAMA777',
        items: ramaItems.length > 0 ? ramaItems : DEFAULT_GAME_RATES[0].items,
      },
      {
        category: 'Bombay Starline Game Win Ratio',
        sectionKey: 'BOMBAY STARLINE',
        items: starlineItems.length > 0 ? starlineItems : DEFAULT_GAME_RATES[1].items,
      },
      {
        category: 'Bombay Jackpot Game Win Ratio',
        sectionKey: 'BOMBAY JACKPOT',
        items: jackpotItems.length > 0 ? jackpotItems : DEFAULT_GAME_RATES[2].items,
      },
    ];

    return sections;
  } catch (err) {
    console.error('Network failure fetching game rates:', err);
    return DEFAULT_GAME_RATES;
  }
}

/**
 * Subscribes to real-time updates from Supabase 'game_rates' table
 */
export function subscribeToGameRates(
  onUpdate: (sections: GameRateSection[]) => void
): () => void {
  let isMounted = true;

  fetchGameRatesFromSupabase().then((sections) => {
    if (isMounted) onUpdate(sections);
  });

  const channel = supabase
    .channel('public:game_rates:realtime')
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'game_rates' },
      () => {
        if (!isMounted) return;
        fetchGameRatesFromSupabase().then((sections) => {
          if (isMounted) onUpdate(sections);
        });
      }
    )
    .subscribe();

  return () => {
    isMounted = false;
    supabase.removeChannel(channel);
  };
}

/**
 * Get dynamic multiplier for any game type or game ID
 */
export function getGameMultiplier(
  gameIdentifier: string,
  category: 'RAMA777' | 'BOMBAY STARLINE' | 'BOMBAY JACKPOT' = 'RAMA777'
): number {
  if (!gameIdentifier) return 10;
  const clean = gameIdentifier.toLowerCase().trim();

  // Starline specific checks
  if (category === 'BOMBAY STARLINE' || clean.includes('starline')) {
    if (clean.includes('triple')) return cachedRatesMap['starline_triple_pana'] || 1000;
    if (clean.includes('double')) return cachedRatesMap['starline_double_pana'] || 320;
    if (clean.includes('pana')) return cachedRatesMap['starline_single_pana'] || 160;
    return cachedRatesMap['starline_single_digit'] || 10;
  }

  // Jackpot specific check
  if (category === 'BOMBAY JACKPOT' || clean.includes('jackpot')) {
    return cachedRatesMap['jackpot'] || 10;
  }

  if (cachedRatesMap[clean]) return cachedRatesMap[clean];
  const underscored = clean.replace(/\s+/g, '_');
  if (cachedRatesMap[underscored]) return cachedRatesMap[underscored];

  // Pattern matching
  if (clean.includes('full sangam') || clean === 'full_sangam') return 10000;
  if (clean.includes('half sangam') || clean === 'half_sangam') return 1000;
  if (clean.includes('triple') || clean.includes('tripple')) return 900;
  if (clean.includes('double') || clean.includes('dp_motor')) return 300;
  if (clean.includes('single pana') || clean.includes('sp_motor')) return 160;
  if (clean.includes('jodi') || clean.includes('bracket')) return 100;
  if (clean.includes('single') || clean.includes('odd') || clean.includes('even')) return 10;

  return 10;
}

/**
 * Calculate dynamic estimated winning returns on placing bids
 */
export function calculateEstimatedPayout(
  gameIdentifier: string,
  points: number,
  category: 'RAMA777' | 'BOMBAY STARLINE' | 'BOMBAY JACKPOT' = 'RAMA777'
): { multiplier: number; estimatedWin: number; ratioDisplay: string } {
  const multiplier = getGameMultiplier(gameIdentifier, category);
  const safePoints = Math.max(0, points || 0);
  const estimatedWin = safePoints * multiplier;
  const ratioDisplay = `1 ka ${multiplier}`;

  return { multiplier, estimatedWin, ratioDisplay };
}

/**
 * Real-time listener for winning bets & wallet credits from Supabase.
 * Triggers a callback whenever a player's bid is marked WON or a winning credit transaction arrives.
 */
export function listenToWinningCredits(
  userId: string,
  userPhone: string,
  onWinCredit: (winData: {
    bidId: string;
    marketName: string;
    gameType: string;
    amount: number;
    digits: string;
    multiplier: number;
  }) => void
): () => void {
  let isMounted = true;
  const cleanPhone = (userPhone || '').replace(/\D/g, '');
  const userTarget = { uid: userId, id: userId, phone: cleanPhone };

  // 1. Subscribe to Supabase 'bids' table for winning bets
  const bidsChannel = supabase
    .channel(`public:bids:winning:${cleanPhone || userId || 'all'}`)
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'bids' },
      (payload) => {
        if (!isMounted) return;
        const newRecord = payload.new as any;
        if (!newRecord) return;

        const isUserMatch = isMatchingUser(
          newRecord.user_id,
          userTarget,
          newRecord.phone || newRecord.mobile
        );

        const statusUpper = String(newRecord.status || '').toUpperCase();
        if (isUserMatch && (statusUpper === 'WON' || statusUpper === 'WIN')) {
          const gameType = newRecord.game_type || 'Single Digit';
          const points = Number(newRecord.points) || 10;
          const mult = getGameMultiplier(gameType);
          const winAmount = Number(newRecord.win_amount) || points * mult;

          onWinCredit({
            bidId: newRecord.id || `win-${Date.now()}`,
            marketName: newRecord.market_name || 'Market',
            gameType,
            amount: winAmount,
            digits: String(newRecord.digits || ''),
            multiplier: mult,
          });
        }
      }
    )
    .subscribe();

  // 2. Also subscribe to Supabase 'transactions' table for WINNING credits
  const txChannel = supabase
    .channel(`public:transactions:win:${cleanPhone || userId || 'all'}`)
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'transactions' },
      (payload) => {
        if (!isMounted) return;
        const tx = payload.new as any;
        if (!tx) return;

        const isUserMatch = isMatchingUser(
          tx.user_id,
          userTarget,
          tx.phone || tx.mobile
        );

        const typeStr = String(tx.type || '').toUpperCase();
        const gatewayStr = String(tx.payment_gateway || '').toUpperCase();
        const titleStr = String(tx.title || '').toUpperCase();
        const descStr = String(tx.description || '').toUpperCase();

        const isWin =
          typeStr.includes('WIN') ||
          typeStr.includes('PRIZE') ||
          gatewayStr.includes('WIN') ||
          titleStr.includes('WIN') ||
          descStr.includes('WIN') ||
          (typeStr.includes('CREDIT') && Number(tx.amount) > 0 && gatewayStr.includes('WIN'));

        const isSuccess = !tx.status || String(tx.status).toUpperCase() === 'SUCCESS';

        if (isUserMatch && isWin && isSuccess && Number(tx.amount) > 0) {
          onWinCredit({
            bidId: tx.referenceId || tx.id || `tx-win-${Date.now()}`,
            marketName: tx.title || 'Market Winner',
            gameType: 'Winning Payout',
            amount: Number(tx.amount) || 0,
            digits: '',
            multiplier: 10,
          });
        }
      }
    )
    .subscribe();

  return () => {
    isMounted = false;
    supabase.removeChannel(bidsChannel);
    supabase.removeChannel(txChannel);
  };
}

/**
 * Evaluates pending bids against declared results and calculates winning payouts
 * using the exact dynamic game multipliers, crediting the user's wallet in real-time.
 */
export async function evaluateAndSettleBidsForMarket(params: {
  marketId: string;
  marketName: string;
  openPana: string;
  jodi: string;
  closePana: string;
  currentUserPhone?: string;
  currentUserId?: string;
}): Promise<{ wonBidsCount: number; totalWonPayout: number }> {
  const { marketId, marketName, openPana, jodi, closePana, currentUserPhone, currentUserId } = params;

  const isOpenValid = /^\d{3}$/.test(openPana);
  const isCloseValid = /^\d{3}$/.test(closePana);
  const openDigit = isOpenValid ? String(getDigitFromPana(openPana)) : '';
  const closeDigit = isCloseValid ? String(getDigitFromPana(closePana)) : '';

  let wonBidsCount = 0;
  let totalWonPayout = 0;

  // Helper to test if a bid has won based on market results
  const checkIsWon = (
    gameType: string,
    digitOrPana: string,
    session: string
  ): { isWon: boolean; canEvaluate: boolean } => {
    const gType = (gameType || '').toLowerCase().trim();
    const cleanDigits = (digitOrPana || '').trim();
    const isSessionOpen = !session || session.toLowerCase().includes('open');

    // 1. Single Digit & Odd/Even
    if (gType.includes('single digit') || gType.includes('odd') || gType.includes('even')) {
      if (isSessionOpen) {
        if (!isOpenValid) return { isWon: false, canEvaluate: false };
        if (gType.includes('odd')) return { isWon: Number(openDigit) % 2 !== 0, canEvaluate: true };
        if (gType.includes('even')) return { isWon: Number(openDigit) % 2 === 0, canEvaluate: true };
        return { isWon: cleanDigits === openDigit, canEvaluate: true };
      } else {
        if (!isCloseValid) return { isWon: false, canEvaluate: false };
        if (gType.includes('odd')) return { isWon: Number(closeDigit) % 2 !== 0, canEvaluate: true };
        if (gType.includes('even')) return { isWon: Number(closeDigit) % 2 === 0, canEvaluate: true };
        return { isWon: cleanDigits === closeDigit, canEvaluate: true };
      }
    }

    // 2. Jodi Digit, Group Jodi, Red Brackets
    if (gType.includes('jodi') || gType.includes('bracket')) {
      if (!isOpenValid || !isCloseValid) return { isWon: false, canEvaluate: false };
      return { isWon: cleanDigits === jodi, canEvaluate: true };
    }

    // 3. Single Pana, SP Motor
    if (gType.includes('single pana') || gType.includes('sp motor')) {
      if (isSessionOpen) {
        if (!isOpenValid) return { isWon: false, canEvaluate: false };
        return { isWon: cleanDigits === openPana, canEvaluate: true };
      } else {
        if (!isCloseValid) return { isWon: false, canEvaluate: false };
        return { isWon: cleanDigits === closePana, canEvaluate: true };
      }
    }

    // 4. Double Pana, DP Motor
    if (gType.includes('double pana') || gType.includes('dp motor')) {
      if (isSessionOpen) {
        if (!isOpenValid) return { isWon: false, canEvaluate: false };
        return { isWon: cleanDigits === openPana, canEvaluate: true };
      } else {
        if (!isCloseValid) return { isWon: false, canEvaluate: false };
        return { isWon: cleanDigits === closePana, canEvaluate: true };
      }
    }

    // 5. Triple Pana
    if (gType.includes('triple pana')) {
      if (isSessionOpen) {
        if (!isOpenValid) return { isWon: false, canEvaluate: false };
        return { isWon: cleanDigits === openPana, canEvaluate: true };
      } else {
        if (!isCloseValid) return { isWon: false, canEvaluate: false };
        return { isWon: cleanDigits === closePana, canEvaluate: true };
      }
    }

    // 6. Half Sangam
    if (gType.includes('half sangam')) {
      if (!isOpenValid || !isCloseValid) return { isWon: false, canEvaluate: false };
      const matchA = cleanDigits.includes(openPana) && cleanDigits.includes(closeDigit);
      const matchB = cleanDigits.includes(closePana) && cleanDigits.includes(openDigit);
      return { isWon: matchA || matchB, canEvaluate: true };
    }

    // 7. Full Sangam
    if (gType.includes('full sangam')) {
      if (!isOpenValid || !isCloseValid) return { isWon: false, canEvaluate: false };
      const matchFull = cleanDigits.includes(openPana) && cleanDigits.includes(closePana);
      return { isWon: matchFull, canEvaluate: true };
    }

    // 8. General fallback for Pana or Digit
    if (cleanDigits.length === 1) {
      if (isSessionOpen && isOpenValid) return { isWon: cleanDigits === openDigit, canEvaluate: true };
      if (!isSessionOpen && isCloseValid) return { isWon: cleanDigits === closeDigit, canEvaluate: true };
    } else if (cleanDigits.length === 2) {
      if (isOpenValid && isCloseValid) return { isWon: cleanDigits === jodi, canEvaluate: true };
    } else if (cleanDigits.length === 3) {
      if (isSessionOpen && isOpenValid) return { isWon: cleanDigits === openPana, canEvaluate: true };
      if (!isSessionOpen && isCloseValid) return { isWon: cleanDigits === closePana, canEvaluate: true };
    }

    return { isWon: false, canEvaluate: false };
  };

  // Helper to credit wallet and log transaction locally
  const creditUserWalletLocally = (payout: number, mName: string, gType: string, digits: string, mult: number, bidId: string) => {
    try {
      // 1. Update user session storage
      const userRaw = localStorage.getItem('rama777_user_session') || localStorage.getItem('rama777_user_profile_v2');
      let prevBal = 0;
      let newBal = payout;
      if (userRaw) {
        const u = JSON.parse(userRaw);
        prevBal = Number(u.walletBalance) || 0;
        const prevWin = Number(u.winningWallet || 0);
        const newWin = prevWin + payout;
        newBal = prevBal + payout;
        u.walletBalance = newBal;
        u.winningWallet = newWin;
        localStorage.setItem('rama777_user_session', JSON.stringify(u));
        localStorage.setItem('rama777_user_profile_v2', JSON.stringify(u));
      }

      // Also update rama777_users_data key
      try {
        const allUsersRaw = localStorage.getItem('rama777_users_data');
        if (allUsersRaw) {
          const allU = JSON.parse(allUsersRaw);
          for (const k of Object.keys(allU)) {
            allU[k].walletBalance = (Number(allU[k].walletBalance) || 0) + payout;
            allU[k].winningWallet = (Number(allU[k].winningWallet) || 0) + payout;
          }
          localStorage.setItem('rama777_users_data', JSON.stringify(allU));
        }
      } catch {}

      // 2. Add WINNING transaction to passbook
      const winTx = {
        id: `tx-win-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        title: `${mName} Win Payout`,
        referenceId: `WIN-${Date.now()}-${bidId.slice(-4)}`,
        description: `Won ${gType} #${digits} at 1 ka ${mult} ratio!`,
        amount: payout,
        type: 'credit',
        status: 'SUCCESS',
        date: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        previousBalance: prevBal,
        currentBalance: newBal,
      };

      const existingTxRaw = localStorage.getItem('rama777_transactions_data');
      const txList = existingTxRaw ? JSON.parse(existingTxRaw) : [];
      localStorage.setItem('rama777_transactions_data', JSON.stringify([winTx, ...txList]));

      // 3. Dispatch event for instant UI celebration and wallet balance update
      if (typeof window !== 'undefined') {
        window.dispatchEvent(
          new CustomEvent('rama777:bet_won', {
            detail: {
              bidId,
              marketName: mName,
              gameType: gType,
              amount: payout,
              digits,
              multiplier: mult,
            },
          })
        );
      }
    } catch (err) {
      console.warn('Local winning credit note:', err);
    }
  };

  // 1. Evaluate Bids in Local Storage
  const storageKeys = ['rama777_bids_data', 'rama777_game_bids_v2'];
  for (const sKey of storageKeys) {
    try {
      const raw = localStorage.getItem(sKey);
      if (!raw) continue;
      const list = JSON.parse(raw);
      if (!Array.isArray(list)) continue;

      let changed = false;
      for (const b of list) {
        if (b.status !== 'Placed') continue;

        const bMarket = String(b.marketName || b.marketId || '').toLowerCase();
        const targetId = marketId.toLowerCase();
        const targetName = marketName.toLowerCase();
        if (!bMarket.includes(targetId) && !bMarket.includes(targetName) && !targetId.includes(bMarket) && !targetName.includes(bMarket)) {
          continue;
        }

        const evaluation = checkIsWon(b.gameType, b.digitOrPana, b.session);
        if (!evaluation.canEvaluate) continue;

        if (evaluation.isWon) {
          const mult = getGameMultiplier(b.gameType);
          const winPayout = (Number(b.points) || 10) * mult;
          b.status = 'Won';
          b.winAmount = winPayout;
          wonBidsCount++;
          totalWonPayout += winPayout;
          changed = true;

          // Credit wallet and record transaction
          creditUserWalletLocally(winPayout, b.marketName || marketName, b.gameType, b.digitOrPana, mult, b.id || `bid-${Date.now()}`);

          // Update Supabase if bid exists remotely
          if (b.id) {
            supabase
              .from('bids')
              .update({ status: 'WON' })
              .eq('id', b.id)
              .then(() => {}, () => {});
          }
        } else if (isOpenValid && isCloseValid) {
          // Market is completely closed, non-winning bet becomes Lost
          b.status = 'Lost';
          changed = true;
          if (b.id) {
            supabase
              .from('bids')
              .update({ status: 'LOST' })
              .eq('id', b.id)
              .then(() => {}, () => {});
          }
        }
      }

      if (changed) {
        localStorage.setItem(sKey, JSON.stringify(list));
      }
    } catch (err) {
      console.warn('Local storage bid evaluation notice:', err);
    }
  }

  // 2. Query and settle Supabase 'bids' table rows directly
  try {
    const { data: dbBids, error: bidsErr } = await supabase
      .from('bids')
      .select('*')
      .in('status', ['PENDING', 'Placed', 'pending', 'placed']);

    if (!bidsErr && dbBids && dbBids.length > 0) {
      for (const row of dbBids) {
        const bMarket = String(row.market_name || row.market_id || '').toLowerCase();
        const targetId = marketId.toLowerCase();
        const targetName = marketName.toLowerCase();

        // Check if row matches the settled market
        const isMarketMatch =
          bMarket.includes(targetId) ||
          bMarket.includes(targetName) ||
          targetId.includes(bMarket) ||
          targetName.includes(bMarket);

        if (!isMarketMatch) continue;

        const evaluation = checkIsWon(row.game_type, String(row.digits || ''), 'Open');
        if (!evaluation.canEvaluate) continue;

        if (evaluation.isWon) {
          const mult = getGameMultiplier(row.game_type);
          const winAmount = (Number(row.points) || 10) * mult;

          // Update Supabase bids to WON (only standard columns)
          await supabase
            .from('bids')
            .update({ status: 'WON' })
            .eq('id', row.id);

          // Insert winning credit transaction into Supabase transactions
          await supabase.from('transactions').insert({
            user_id: row.user_id,
            amount: winAmount,
            type: 'WINNING_PAYOUT',
            status: 'SUCCESS',
            payment_gateway: 'RAMA_WALLET_WIN',
          });

          // Also credit user in Supabase users table if user_id is provided
          if (row.user_id) {
            try {
              const { data: uData } = await supabase
                .from('users')
                .select('wallet_balance')
                .eq('id', row.user_id)
                .single();
              if (uData) {
                const currentBal = Number(uData.wallet_balance) || 0;
                await supabase
                  .from('users')
                  .update({ wallet_balance: currentBal + winAmount })
                  .eq('id', row.user_id);
              }
            } catch (uErr) {
              console.warn('Supabase user balance update note:', uErr);
            }
          }

          wonBidsCount++;
          totalWonPayout += winAmount;

          // Local credit in case this user is in current session
          creditUserWalletLocally(winAmount, marketName, row.game_type, String(row.digits || ''), mult, row.id);
        } else if (isOpenValid && isCloseValid) {
          // Mark lost on Supabase
          await supabase
            .from('bids')
            .update({ status: 'LOST' })
            .eq('id', row.id);
        }
      }
    }
  } catch (err) {
    console.warn('Supabase DB settlement notice:', err);
  }

  return { wonBidsCount, totalWonPayout };
}
