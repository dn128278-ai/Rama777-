export type UserRole = 'user' | 'admin';

export type PermissionFlag =
  | 'bet_play'
  | 'deposit'
  | 'withdraw'
  | 'view_passbook'
  | 'manage_markets'
  | 'declare_results'
  | 'manage_users'
  | 'approve_deposits'
  | 'system_settings';

export interface UserProfile {
  id?: string;
  uid?: string;
  name: string;
  username?: string;
  phone: string;
  email?: string;
  walletBalance: number;
  mpin: string;
  biometricEnabled: boolean;
  avatarUrl?: string;
  appVersion: string;
  role?: UserRole;
  permissions?: PermissionFlag[];
  createdAt?: string;
  lastLoginAt?: string;
}

export interface UserAccount {
  id: string;
  name: string;
  username: string;
  phone: string;
  email?: string;
  passwordHash: string; // Plain/hashed password for local verification
  mpin: string; // 4-digit MPIN
  role: UserRole;
  walletBalance: number;
  biometricEnabled: boolean;
  registeredAt: string;
  lastLoginAt?: string;
  referralCode?: string;
  status: 'active' | 'suspended';
}

export type MainTab = 'history' | 'passbook' | 'home' | 'funds' | 'support';

export interface MarketItem {
  id: string;
  marketId?: string;
  name: string;
  openPana: string;
  jodi: string;
  closePana: string;
  lastResult?: string;
  openTime: string;
  closeTime: string;
  status: 'Running for Open' | 'Running for Close' | 'Closed for Today';
  isOpen: boolean;
  openHour?: number;
  openMinute?: number;
  closeHour?: number;
  closeMinute?: number;
  countdownText?: string;
  allowedSession?: 'all' | 'close_only' | 'none';
  timeRemainingMs?: number;
  marketDate?: string;
  order?: number;
}

export interface StarlineResult {
  time: string;
  date: string;
  result: string;
}

export interface Transaction {
  id: string;
  title: string;
  referenceId: string;
  description: string;
  amount: number;
  type: 'credit' | 'debit';
  status: 'SUCCESS' | 'PENDING' | 'FAILED';
  date: string;
  previousBalance: number;
  currentBalance: number;
}

export interface FundHistoryItem {
  id: string;
  orderId: string;
  date: string;
  amount: number;
  status: 'Success' | 'Pending' | 'Failure';
  requestType: 'Credit' | 'Debit';
  depositMode: 'Budypay' | 'UPI' | 'Bank Transfer' | 'Penny Drop' | 'Kotak Merchant UPI' | string;
  bankName?: string;
  accountNumber?: string;
  ifscCode?: string;
  accountHolder?: string;
  upiId?: string;
  adminRemark?: string;
  utrOrReference?: string;
}

export interface BankAccount {
  id: string;
  accountHolder: string;
  bankName: string;
  branch: string;
  ifscCode: string;
  accountNumber: string;
  isDefault: boolean;
  updatedAt: string;
  status: 'Success' | 'Pending' | 'Failure' | 'Verified';
  lockUntil?: string;
}

export interface GameBid {
  id: string;
  marketId?: string;
  marketName: string;
  gameType: string;
  session: 'Open' | 'Close';
  digitOrPana: string;
  points: number;
  date: string;
  status: 'Placed' | 'Won' | 'Lost' | 'WIN' | 'PENDING' | 'LOST';
  winAmount?: number;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: 'bonus' | 'bid' | 'alert';
}

export interface SupportChatMessage {
  id: string;
  sender: 'user' | 'agent';
  text: string;
  timestamp: string;
}

export type WeekdayKey = 'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat' | 'sun';

export interface MarketResultRecord {
  id: string; // e.g. `${marketId}_${dateKey}`
  marketId: string;
  marketName: string;
  date: string; // DD-MM-YYYY
  dateKey: string; // YYYY-MM-DD
  dayOfWeek: WeekdayKey;
  openPana: string;
  jodi: string;
  closePana: string;
  status: 'declared' | 'partial_open' | 'pending';
  updatedAt?: string;
  source?: 'admin' | 'automated' | 'seed';
}

export interface MarketChartDayCell {
  dateStr: string;
  dateKey: string;
  openPana: string;
  jodi: string;
  closePana: string;
  isRedJodi: boolean;
  isDeclared: boolean;
  isOpenOnly: boolean;
  isToday: boolean;
  isFuture: boolean;
}

export interface MarketChartRow {
  range: string; // "DD-MM-YY\nDD-MM-YY"
  startDate: string;
  endDate: string;
  isCurrentWeek: boolean;
  days: Record<WeekdayKey, MarketChartDayCell>;
}

