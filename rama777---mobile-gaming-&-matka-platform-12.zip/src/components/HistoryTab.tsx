import React, { useState } from 'react';
import {
  Clock,
  FileCheck2,
  ChevronRight,
  ArrowLeft,
  Trophy,
} from 'lucide-react';
import { GameBid, StarlineResult, MarketItem } from '../types';
import { getGameMultiplier } from '../services/gameRatesService';

interface HistoryTabProps {
  bids: GameBid[];
  starlineResults: StarlineResult[];
  markets?: MarketItem[];
}

export const HistoryTab: React.FC<HistoryTabProps> = ({ bids, starlineResults, markets = [] }) => {
  const [activeSubView, setActiveSubView] = useState<string | null>(null);
  const [selectedDate] = useState<string>(
    new Date().toLocaleDateString('en-GB')
  );

  const historyOptions = [
    { id: 'game_bid_history', title: 'Game Bid History', type: 'clock' },
    { id: 'starline_bid_history', title: 'Starline Bid History', type: 'clock' },
    { id: 'jackpot_bid_history', title: 'Jackpot Bid History', type: 'clock' },
    { id: 'game_result_history', title: 'Game Result History', type: 'check' },
    { id: 'starline_result_history', title: 'Starline Result History', type: 'check' },
    { id: 'jackpot_result_history', title: 'Jackpot Result History', type: 'check' },
  ];

  // Helper to dynamically resolve market name from markets list or ID
  const resolveBidMarketName = (bid: GameBid): string => {
    if (bid.marketName && bid.marketName !== 'Matka Market') {
      return bid.marketName;
    }
    if (bid.marketId && markets.length > 0) {
      const cleanBId = String(bid.marketId).toLowerCase();
      const found = markets.find(
        (m) =>
          m.id.toLowerCase() === cleanBId ||
          (m as any).market_id?.toLowerCase() === cleanBId ||
          m.name.toLowerCase() === cleanBId
      );
      if (found) return found.name;
    }
    return 'Madhur Kalyan';
  };

  return (
    <div className="pb-6 pt-2 px-4 transition-colors bg-white">
      {!activeSubView ? (
        <div className="space-y-3">
          {historyOptions.map((opt) => (
            <button
              key={opt.id}
              onClick={() => setActiveSubView(opt.id)}
              className="w-full bg-white rounded-2xl p-3.5 border border-slate-200 flex items-center justify-between shadow-xs hover:border-[#FF7700] hover:bg-slate-50 active:scale-[0.99] transition-all cursor-pointer text-left"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs shrink-0">
                  {opt.type === 'clock' ? (
                    <Clock className="w-5 h-5" />
                  ) : (
                    <FileCheck2 className="w-5 h-5" />
                  )}
                </div>
                <span className="font-bold text-slate-800 text-sm">
                  {opt.title}
                </span>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-400 shrink-0" />
            </button>
          ))}
        </div>
      ) : activeSubView === 'starline_result_history' ? (
        /* Starline Result History */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setActiveSubView(null)}
                className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <h2 className="text-base font-extrabold text-[#FF7700]">
                Starline Result History
              </h2>
            </div>
          </div>

          {/* Date Selector Row */}
          <div className="flex items-center justify-between bg-white rounded-2xl p-3 border border-slate-200 shadow-xs">
            <span className="text-xs font-bold text-slate-700">
              Select Date :
            </span>
            <div className="border border-[#FF7700] text-[#FF7700] bg-orange-50 px-4 py-1.5 rounded-full text-xs font-bold font-mono">
              {selectedDate}
            </div>
          </div>

          {/* Hourly Result Cards */}
          <div className="space-y-2.5">
            {starlineResults.map((sr, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl p-3.5 border border-slate-200 flex items-center justify-between shadow-xs"
              >
                <div>
                  <div className="font-extrabold text-sm text-slate-900">
                    {sr.time}
                  </div>
                  <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                    {sr.date}
                  </div>
                </div>

                <div className="w-28 py-2 rounded-xl bg-orange-50 text-center font-black font-mono text-sm text-[#FF7700] tracking-wider border border-orange-200">
                  {sr.result}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : activeSubView === 'game_result_history' ? (
        /* Game Result History */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setActiveSubView(null)}
                className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <h2 className="text-base font-extrabold text-[#FF7700]">
                Game Result History
              </h2>
            </div>
          </div>

          {/* Date Selector Row */}
          <div className="flex items-center justify-between bg-white rounded-2xl p-3 border border-slate-200 shadow-xs">
            <span className="text-xs font-bold text-slate-700">
              Today's Results :
            </span>
            <div className="border border-[#FF7700] text-[#FF7700] bg-orange-50 px-4 py-1.5 rounded-full text-xs font-bold font-mono">
              {selectedDate}
            </div>
          </div>

          {/* Market Results List */}
          <div className="space-y-2.5">
            {markets.map((m) => {
              const hasOpen = m.openPana && m.openPana !== '***';
              const hasClose = m.closePana && m.closePana !== '***';
              const isDeclared = hasOpen || hasClose;

              return (
                <div
                  key={m.id}
                  className="bg-white rounded-2xl p-3.5 border border-slate-200 flex items-center justify-between shadow-xs"
                >
                  <div>
                    <div className="font-extrabold text-sm text-slate-900">
                      {m.name}
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                      Open: {m.openTime} | Close: {m.closeTime}
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="px-3 py-1.5 rounded-xl bg-orange-50 text-center font-black font-mono text-xs text-[#FF7700] tracking-wider border border-orange-200">
                      {m.openPana || '***'}-{m.jodi || '**'}-{m.closePana || '***'}
                    </div>
                    <span
                      className={`text-[9px] font-bold font-mono mt-1 block ${
                        isDeclared ? 'text-emerald-600' : 'text-slate-400'
                      }`}
                    >
                      {isDeclared ? 'Declared' : 'Pending'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* Subview for Game Bid History, Starline Bid History, Jackpot Bid History */
        <div className="space-y-4">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setActiveSubView(null)}
              className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <h2 className="text-base font-extrabold text-[#FF7700]">
              {historyOptions.find((o) => o.id === activeSubView)?.title}
            </h2>
          </div>

          {(() => {
            const relevantBids = bids.filter((b) => {
              const bMName = (b.marketName || '').toLowerCase();
              if (activeSubView === 'starline_bid_history') {
                return bMName.includes('starline');
              }
              if (activeSubView === 'jackpot_bid_history') {
                return bMName.includes('jackpot');
              }
              if (activeSubView === 'game_bid_history') {
                return (
                  !bMName.includes('starline') &&
                  !bMName.includes('jackpot')
                );
              }
              return true;
            });

            return relevantBids.length === 0 ? (
              <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center shadow-xs">
                <Clock className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-700">
                  No history records found for today
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  Place a bid in Kalyan or other markets to see records here.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {relevantBids.map((bid) => {
                  const marketDisplayName = resolveBidMarketName(bid);
                  const isWon = bid.status === 'Won' || bid.status === 'WIN';
                  const isLost = bid.status === 'Lost' || bid.status === 'LOST';
                  const mult = getGameMultiplier(bid.gameType);
                  const payoutAmount = bid.winAmount || (Number(bid.points) || 10) * mult;

                  return (
                    <div
                      key={bid.id}
                      className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-extrabold text-sm text-slate-900">
                            {marketDisplayName}
                          </h4>
                          <p className="text-xs text-slate-500 font-medium">
                            {bid.gameType} · {bid.session} Session
                          </p>
                        </div>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            isWon
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-300'
                              : isLost
                              ? 'bg-rose-50 text-rose-700 border border-rose-300'
                              : 'bg-orange-50 text-orange-700 border border-orange-300'
                          }`}
                        >
                          {isWon
                            ? `Won · ₹${payoutAmount}`
                            : isLost
                            ? 'Lost'
                            : 'Placed'}
                        </span>
                      </div>

                      {/* Prominent Winning Payout Card if won */}
                      {isWon && (
                        <div className="mt-2.5 bg-emerald-50 rounded-xl px-3 py-2 border border-emerald-200 flex items-center justify-between">
                          <span className="text-[11px] font-bold text-emerald-800 flex items-center gap-1.5">
                            <Trophy className="w-3.5 h-3.5 text-emerald-600" />
                            Winning Payout Credited:
                          </span>
                          <span className="text-xs font-black font-mono text-emerald-700">
                            +₹{payoutAmount} ({mult}x Rate)
                          </span>
                        </div>
                      )}

                      <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                        <span className="text-slate-500 font-mono">
                          Digit/Pana: <strong className="text-slate-800 font-bold">#{bid.digitOrPana}</strong>
                        </span>
                        <div className="text-right">
                          <span className="text-[10px] text-slate-400 mr-1.5">Points:</span>
                          <span className="font-bold text-[#FF7700] font-mono text-sm">
                            ₹{bid.points}
                          </span>
                        </div>
                      </div>

                      {bid.date && (
                        <div className="mt-1 text-[10px] text-slate-400 font-mono">
                          {bid.date}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            );
          })()}
        </div>
      )}
    </div>
  );
};
