import React from 'react';
import { Menu, Bell, Wallet, Crown, ShieldCheck } from 'lucide-react';
import { MainTab, UserRole } from '../types';

interface HeaderProps {
  currentTab: MainTab;
  walletBalance: number;
  unreadNotificationsCount: number;
  userRole?: UserRole;
  onOpenDrawer: () => void;
  onOpenNotifications: () => void;
  onNavigateToFunds: () => void;
  onOpenAdminHub?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  walletBalance,
  unreadNotificationsCount,
  userRole,
  onOpenDrawer,
  onOpenNotifications,
  onNavigateToFunds,
  onOpenAdminHub,
}) => {
  const getTabTitle = () => {
    switch (currentTab) {
      case 'history':
        return 'History';
      case 'passbook':
        return 'Passbook';
      case 'funds':
        return 'Funds';
      case 'support':
        return 'Support';
      default:
        return null;
    }
  };

  const title = getTabTitle();

  return (
    <header
      style={{ flexShrink: 0 }}
      className="shrink-0 z-30 bg-white border-b border-slate-100 px-4 py-3 flex items-center justify-between text-slate-800 transition-colors shadow-xs"
    >
      {/* Left: Hamburger Menu and Title or Logo */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenDrawer}
          className="w-10 h-10 rounded-xl flex items-center justify-center text-slate-700 hover:bg-slate-100 active:scale-95 transition-all cursor-pointer"
          aria-label="Open menu"
        >
          <Menu className="w-6 h-6" />
        </button>

        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#E65100] to-[#FF7700] flex items-center justify-center shadow-md shadow-orange-500/20">
            <span className="text-white font-extrabold text-base tracking-tighter">R</span>
          </div>
          <div>
            <span className="text-lg font-black tracking-tight text-[#FF7700] block leading-none">
              RAMA777
            </span>
            {title && (
              <span className="text-[10px] font-bold text-slate-500 block leading-none mt-0.5 uppercase tracking-wider">
                {title}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Right: Admin Shortcut (if admin), Wallet Balance Pill & Bell Notification Icon */}
      <div className="flex items-center gap-2">
        {userRole === 'admin' && onOpenAdminHub && (
          <button
            onClick={onOpenAdminHub}
            className="bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-300 rounded-full px-2.5 py-1 flex items-center gap-1 transition-all cursor-pointer active:scale-95 shadow-2xs"
            title="Open Admin Control Hub"
          >
            <Crown className="w-3.5 h-3.5 text-amber-600" />
            <span className="text-[10px] font-black uppercase tracking-wider font-mono">
              ADMIN
            </span>
          </button>
        )}

        <button
          onClick={onNavigateToFunds}
          className="bg-orange-50/80 hover:bg-orange-100/80 border border-orange-200 rounded-full px-3 py-1 flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-2xs"
          title="View Wallet Funds"
        >
          <div className="flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-emerald-600 shrink-0" />
            <Wallet className="w-3.5 h-3.5 text-[#FF7700] shrink-0" />
          </div>
          <span className="text-xs font-black text-slate-900 font-mono tracking-tight">
            ₹{Number(walletBalance || 0).toFixed(2)}
          </span>
        </button>

        <button
          onClick={onOpenNotifications}
          className="relative w-10 h-10 rounded-xl flex items-center justify-center text-slate-700 hover:bg-slate-100 active:scale-95 transition-all cursor-pointer"
          aria-label="Notifications"
        >
          <Bell className="w-5 h-5" />
          {unreadNotificationsCount > 0 && (
            <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-[#FF7700] ring-2 ring-white" />
          )}
        </button>
      </div>
    </header>
  );
};
