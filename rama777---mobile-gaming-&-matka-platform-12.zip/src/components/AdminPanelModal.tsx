/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  X,
  Crown,
  ShieldCheck,
  Users,
  Trophy,
  Wallet,
  Settings,
  PlusCircle,
  MinusCircle,
  CheckCircle2,
  AlertCircle,
  Search,
  Sparkles,
  ArrowRight,
  TrendingUp,
  RefreshCw,
  Clock,
  BarChart3,
  Bell,
  Send,
  Building2,
  Copy,
  Check,
  XCircle,
  CreditCard,
  Table,
  LayoutGrid,
} from 'lucide-react';
import { MarketItem, UserProfile, UserAccount } from '../types';
import {
  getRegisteredAccounts,
  adjustUserBalance,
  switchUserRole,
  saveRegisteredAccounts,
} from '../services/authService';
import { declareMarketResult } from '../services/marketResultService';
import { formatMarketResult, getDigitFromPana } from '../utils/marketEngine';
import {
  broadcastNotificationInFirestore,
  resolveMarketNameFromId,
  toSupabaseUuid,
} from '../services/firestoreSyncService';
import { supabase } from '../supabase';

interface AdminPanelModalProps {
  currentUser: UserProfile;
  markets: MarketItem[];
  currentTime: Date;
  onClose: () => void;
  onUpdateMarkets?: (updated: MarketItem[]) => void;
  onSwitchUser?: (newUser: UserProfile) => void;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  currentUser,
  markets,
  currentTime,
  onClose,
  onUpdateMarkets,
  onSwitchUser,
}) => {
  const isAdmin = currentUser.role === 'admin';

  // Sub-tabs in Admin Panel: 'results' | 'withdrawals' | 'users' | 'markets' | 'analytics' | 'notices'
  const [activeTab, setActiveTab] = useState<'results' | 'withdrawals' | 'users' | 'markets' | 'analytics' | 'notices'>('results');

  // Live Supabase bids for Bet Analytics
  const [liveBids, setLiveBids] = useState<any[]>([]);
  const [analyticsMarketFilter, setAnalyticsMarketFilter] = useState<string>('all');
  const [analyticsGameTypeFilter, setAnalyticsGameTypeFilter] = useState<string>('all');
  const [isLoadingBids, setIsLoadingBids] = useState<boolean>(false);

  // Subscribe to live bids from Supabase 'bids' table with instant postgres_changes
  useEffect(() => {
    let isMounted = true;

    const fetchBids = async () => {
      setIsLoadingBids(true);
      try {
        const { data, error } = await supabase
          .from('bids')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(100);

        if (!isMounted) return;
        if (error) {
          console.error('[Supabase Error] Fetch live bids failed:', error.message);
          return;
        }
        if (data) {
          setLiveBids(data);
        }
      } catch (err) {
        console.error('[Supabase Network Failure] Error fetching bids:', err);
      } finally {
        if (isMounted) setIsLoadingBids(false);
      }
    };

    fetchBids();

    const channel = supabase
      .channel('public:admin:bids:realtime')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'bids' },
        (payload) => {
          if (!isMounted) return;
          console.log('[Supabase Realtime] Admin live bids event:', payload.eventType);
          fetchBids();
        }
      )
      .subscribe();

    return () => {
      isMounted = false;
      supabase.removeChannel(channel);
    };
  }, []);

  // Subscribe to live Supabase 'users' table with instant postgres_changes
  useEffect(() => {
    let isMounted = true;
    const fetchUsers = async () => {
      try {
        const { data, error } = await supabase.from('users').select('*');
        if (!error && data && isMounted) {
          const localAccs = getRegisteredAccounts();
          const merged = [...localAccs];
          for (const u of data) {
            const phone = u.mobile || '';
            const existingIdx = merged.findIndex((a) => a.phone === phone || a.id === u.id);
            const bal = Number(u.main_wallet ?? u.gaming_wallet ?? 500);
            if (existingIdx >= 0) {
              merged[existingIdx] = {
                ...merged[existingIdx],
                name: u.name || merged[existingIdx].name,
                walletBalance: bal,
                role: u.role === 'admin' ? 'admin' : 'user',
              };
            } else if (phone) {
              merged.push({
                id: u.id,
                name: u.name || `User ${phone.slice(-4)}`,
                username: phone,
                phone: phone,
                passwordHash: 'rama123',
                mpin: '7777',
                role: u.role === 'admin' ? 'admin' : 'user',
                walletBalance: bal,
                biometricEnabled: true,
                registeredAt: u.created_at || new Date().toISOString(),
                status: 'active',
              });
            }
          }
          setAccounts(merged);
        }
      } catch (e) {
        console.warn('Error fetching Supabase users in Admin:', e);
      }
    };

    fetchUsers();

    const channel = supabase
      .channel('public:admin:users:realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'users' }, () => {
        if (!isMounted) return;
        fetchUsers();
      })
      .subscribe();

    return () => {
      isMounted = false;
      supabase.removeChannel(channel);
    };
  }, []);

  // ==========================================
  // Live Supabase Withdrawals State & Subscription
  // ==========================================
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [isLoadingWithdrawals, setIsLoadingWithdrawals] = useState<boolean>(false);
  const [withdrawalFilter, setWithdrawalFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');
  const [withdrawalSearch, setWithdrawalSearch] = useState<string>('');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [processingWithdrawalId, setProcessingWithdrawalId] = useState<string | null>(null);
  const [withdrawalViewMode, setWithdrawalViewMode] = useState<'table' | 'card'>('table');

  useEffect(() => {
    let isMounted = true;
    const fetchWithdrawals = async () => {
      setIsLoadingWithdrawals(true);
      try {
        const { data, error } = await supabase
          .from('withdrawals')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(100);

        if (!isMounted) return;
        if (!error && data) {
          setWithdrawals(data);
        }
      } catch (err) {
        console.error('[Supabase Network Failure] Fetch withdrawals error:', err);
      } finally {
        if (isMounted) setIsLoadingWithdrawals(false);
      }
    };

    fetchWithdrawals();

    const channel = supabase
      .channel('public:admin:withdrawals:realtime')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'withdrawals' },
        (payload) => {
          if (!isMounted) return;
          console.log('[Supabase Realtime] Admin withdrawals changed:', payload.eventType);
          fetchWithdrawals();
        }
      )
      .subscribe();

    return () => {
      isMounted = false;
      supabase.removeChannel(channel);
    };
  }, []);

  const parseWithdrawalBank = (raw: any, fallbackPhone?: string, fallbackUserId?: string) => {
    let parsed: any = {};
    if (typeof raw === 'string') {
      try {
        parsed = JSON.parse(raw);
      } catch {
        parsed = {};
      }
    } else if (raw && typeof raw === 'object') {
      parsed = raw;
    }

    const matchedAccount = accounts.find(
      (a) =>
        (fallbackPhone && a.phone === fallbackPhone) ||
        (fallbackUserId && a.id === fallbackUserId)
    );

    const bankName =
      parsed.bankName ||
      parsed.bank_name ||
      parsed.bank ||
      'Bank of Baroda';

    const accountHolder =
      parsed.accountHolder ||
      parsed.account_holder ||
      parsed.holderName ||
      parsed.holder_name ||
      parsed.userName ||
      parsed.user_name ||
      matchedAccount?.name ||
      'GIRISH MEENA';

    const accountNumber =
      parsed.accountNumber ||
      parsed.account_number ||
      parsed.account ||
      '57360100004600';

    const ifsc =
      parsed.ifsc ||
      parsed.ifscCode ||
      parsed.ifsc_code ||
      'BARB0DHANBA';

    const upiId =
      parsed.upiId ||
      parsed.upi_id ||
      (fallbackPhone ? `${fallbackPhone}@upi` : '6377972674@upi');

    return { bankName, accountNumber, ifsc, accountHolder, upiId };
  };

  const handleCopyText = (text: string, key: string) => {
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(text);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 2000);
    }
  };

  const handleApproveWithdrawal = async (req: any) => {
    setProcessingWithdrawalId(req.id);
    try {
      const { error } = await supabase
        .from('withdrawals')
        .update({ status: 'Approved' })
        .eq('id', req.id);

      if (error) throw error;

      const details = parseWithdrawalBank(req.bank_details, req.mobile);
      const userUuid = req.user_id || toSupabaseUuid(req.mobile || '');
      const amtNum = Number(req.amount) || 0;

      // Passbook entry
      await supabase.from('passbook').insert({
        user_id: userUuid,
        mobile: req.mobile || '',
        type: 'debit',
        amount: amtNum,
        description: `Withdrawal Approved & Processed to ${details.bankName} (A/C: ${details.accountNumber.slice(-4) || '****'}) · Holder: ${details.accountHolder}`,
        status: 'SUCCESS',
      });

      // Transactions entry
      await supabase.from('transactions').insert({
        user_id: userUuid,
        amount: amtNum,
        type: 'WITHDRAWAL',
        status: 'SUCCESS',
        payment_gateway: 'Bank Transfer',
      });

      setWithdrawals((prev) =>
        prev.map((w) => (w.id === req.id ? { ...w, status: 'Approved' } : w))
      );

      setActionNotice(`✓ Payout of ₹${amtNum.toLocaleString('en-IN')} Approved successfully for ${req.mobile || details.accountHolder}!`);
    } catch (err: any) {
      console.error('Failed to approve payout:', err);
      setActionNotice(`Error approving payout: ${err.message || 'Network error'}`);
    } finally {
      setProcessingWithdrawalId(null);
    }
  };

  const handleRejectWithdrawal = async (req: any) => {
    setProcessingWithdrawalId(req.id);
    const refundAmt = Number(req.amount) || 0;
    try {
      const { error } = await supabase
        .from('withdrawals')
        .update({ status: 'Rejected' })
        .eq('id', req.id);

      if (error) throw error;

      const userUuid = req.user_id || toSupabaseUuid(req.mobile || '');
      const details = parseWithdrawalBank(req.bank_details, req.mobile);

      // Refund user wallet
      let currentBal = 0;
      const targetUser = accounts.find((a) => a.phone === req.mobile || a.id === req.user_id);
      if (targetUser) {
        currentBal = targetUser.walletBalance;
      }

      const { data: dbUser } = await supabase
        .from('users')
        .select('main_wallet, gaming_wallet')
        .or(`id.eq.${userUuid},mobile.eq.${req.mobile}`)
        .maybeSingle();

      if (dbUser) {
        currentBal = Number(dbUser.main_wallet ?? dbUser.gaming_wallet ?? currentBal);
      }

      const refundedBal = currentBal + refundAmt;

      // Update Supabase users balance
      let userUpdate = supabase.from('users').update({
        main_wallet: refundedBal,
        gaming_wallet: refundedBal,
      });
      if (req.user_id) {
        userUpdate = userUpdate.eq('id', req.user_id);
      } else {
        userUpdate = userUpdate.eq('mobile', req.mobile);
      }
      await userUpdate;

      // Record refund in passbook
      await supabase.from('passbook').insert({
        user_id: userUuid,
        mobile: req.mobile || '',
        type: 'credit',
        amount: refundAmt,
        description: `Refund: Withdrawal Request Rejected (₹${refundAmt} credited back to wallet)`,
        status: 'SUCCESS',
      });

      // Record in transactions
      await supabase.from('transactions').insert({
        user_id: userUuid,
        amount: refundAmt,
        type: 'REFUND',
        status: 'SUCCESS',
        payment_gateway: 'ADMIN_REVERSAL',
      });

      if (targetUser) {
        adjustUserBalance(targetUser.id, refundedBal);
        setAccounts(getRegisteredAccounts());
      }

      setWithdrawals((prev) =>
        prev.map((w) => (w.id === req.id ? { ...w, status: 'Rejected' } : w))
      );

      setActionNotice(`✕ Withdrawal of ₹${refundAmt.toLocaleString('en-IN')} Rejected. Funds refunded back to ${req.mobile || details.accountHolder}.`);
    } catch (err: any) {
      console.error('Failed to reject payout:', err);
      setActionNotice(`Error rejecting payout: ${err.message || 'Network error'}`);
    } finally {
      setProcessingWithdrawalId(null);
    }
  };

  const pendingWithdrawalsCount = withdrawals.filter(
    (w) => String(w.status).toLowerCase() === 'pending'
  ).length;

  const filteredWithdrawals = withdrawals.filter((w) => {
    const statusMatch =
      withdrawalFilter === 'all' ||
      String(w.status).toLowerCase() === withdrawalFilter.toLowerCase();

    if (!statusMatch) return false;

    if (!withdrawalSearch.trim()) return true;

    const q = withdrawalSearch.toLowerCase();
    const rawBank = w.bank_details || (w as any).payment_details;
    const details = parseWithdrawalBank(rawBank, w.mobile, w.user_id);

    return (
      (w.mobile && w.mobile.toLowerCase().includes(q)) ||
      (w.user_id && w.user_id.toLowerCase().includes(q)) ||
      (w.id && String(w.id).toLowerCase().includes(q)) ||
      details.bankName.toLowerCase().includes(q) ||
      details.accountNumber.toLowerCase().includes(q) ||
      details.ifsc.toLowerCase().includes(q) ||
      details.accountHolder.toLowerCase().includes(q) ||
      details.upiId.toLowerCase().includes(q)
    );
  });

  // Admin elevation passcode for standard users
  const [adminPasscode, setAdminPasscode] = useState<string>('');
  const [authError, setAuthError] = useState<string>('');
  const [actionNotice, setActionNotice] = useState<string>('');

  // Results declaration state
  const [selectedMarketId, setSelectedMarketId] = useState<string>(markets[0]?.id || 'kalyan');
  const [openPanaInput, setOpenPanaInput] = useState<string>('');
  const [closePanaInput, setClosePanaInput] = useState<string>('');
  const [isSubmittingResult, setIsSubmittingResult] = useState<boolean>(false);

  // Users management state
  const [accounts, setAccounts] = useState<UserAccount[]>(() => getRegisteredAccounts());
  const [userSearchQuery, setUserSearchQuery] = useState<string>('');
  const [adjustAmount, setAdjustAmount] = useState<string>('500');

  // Selected market derived
  const selectedMarket = markets.find((m) => m.id === selectedMarketId) || markets[0];
  const currentOpenDigit =
    openPanaInput.length === 3 ? getDigitFromPana(openPanaInput) : null;
  const currentCloseDigit =
    closePanaInput.length === 3 ? getDigitFromPana(closePanaInput) : null;
  const previewJodi =
    currentOpenDigit !== null && currentCloseDigit !== null
      ? `${currentOpenDigit}${currentCloseDigit}`
      : currentOpenDigit !== null
      ? `${currentOpenDigit}*`
      : currentCloseDigit !== null
      ? `*${currentCloseDigit}`
      : '**';

  // Market creation state
  const [showAddMarket, setShowAddMarket] = useState<boolean>(false);
  const [newMarketIdType, setNewMarketIdType] = useState<'mkt_prefix' | 'slug' | 'auto'>('mkt_prefix');
  const [newMarketName, setNewMarketName] = useState<string>('');
  const [newMarketOpenTime, setNewMarketOpenTime] = useState<string>('11:00 AM');
  const [newMarketCloseTime, setNewMarketCloseTime] = useState<string>('01:00 PM');
  const [newMarketLastResult, setNewMarketLastResult] = useState<string>('***-**-***');
  const [isCreatingMarket, setIsCreatingMarket] = useState<boolean>(false);

  // Admin Broadcast Notification state
  const [notifTitle, setNotifTitle] = useState<string>('');
  const [notifMessage, setNotifMessage] = useState<string>('');
  const [notifType, setNotifType] = useState<'alert' | 'bonus' | 'bid'>('alert');
  const [isSendingNotif, setIsSendingNotif] = useState<boolean>(false);

  const handleSendBroadcastNotification = async () => {
    if (!notifTitle.trim() || !notifMessage.trim()) {
      setActionNotice('Please enter both title and message for notification.');
      return;
    }
    setIsSendingNotif(true);
    try {
      await broadcastNotificationInFirestore({
        title: notifTitle.trim(),
        message: notifMessage.trim(),
        type: notifType,
        time: 'Just now',
        read: false,
        targetPhone: 'all',
      });
      setActionNotice('Live broadcast notification sent to all connected players!');
      setNotifTitle('');
      setNotifMessage('');
    } catch (err: any) {
      setActionNotice(`Notification broadcast error: ${err.message}`);
    } finally {
      setIsSendingNotif(false);
    }
  };

  const handleToggleMarketStatus = async (market: MarketItem) => {
    try {
      const nextIsOpen = !market.isOpen;
      const nextStatus = nextIsOpen ? 'ACTIVE' : 'CLOSED';
      const { error } = await supabase
        .from('markets')
        .update({
          status: nextStatus,
          updated_at: new Date().toISOString(),
        })
        .or(`id.eq.${market.id},name.ilike.${market.name}`);

      if (error) throw error;
      setActionNotice(`${market.name} is now ${nextIsOpen ? 'ACTIVE' : 'CLOSED'}`);
    } catch (err: any) {
      setActionNotice(`Failed to toggle: ${err.message}`);
    }
  };

  const handleCreateMarket = async () => {
    if (!newMarketName.trim()) {
      setActionNotice('Please enter a market name.');
      return;
    }

    setIsCreatingMarket(true);
    try {
      const payload = {
        name: newMarketName.trim().toUpperCase(),
        open_time: newMarketOpenTime.trim() || '11:00 AM',
        close_time: newMarketCloseTime.trim() || '01:00 PM',
        status: 'ACTIVE',
        open_pana: '***',
        close_pana: '***',
        jodi: '**',
        updated_at: new Date().toISOString(),
      };

      const { data, error } = await supabase.from('markets').insert(payload).select();
      if (error) throw error;
      const createdId = data && data[0] ? data[0].id : '';
      setActionNotice(`Market "${newMarketName.toUpperCase()}" created in Supabase! (ID: ${createdId.slice(0, 8)})`);
      setNewMarketName('');
      setShowAddMarket(false);
    } catch (err: any) {
      setActionNotice(`Failed to create market: ${err.message}`);
    } finally {
      setIsCreatingMarket(false);
    }
  };
  const handleElevateToAdmin = () => {
    if (adminPasscode === '9999' || adminPasscode === 'admin777') {
      const elevated = switchUserRole(currentUser.id || currentUser.phone, 'admin');
      if (elevated && onSwitchUser) {
        onSwitchUser(elevated);
      }
      setAuthError('');
      setActionNotice('Admin access granted successfully.');
    } else {
      setAuthError('Invalid Admin Passcode. Use "9999" or switch to the Admin account.');
    }
  };

  // Declare Result Handler
  const handleDeclareResult = async () => {
    if (!openPanaInput && !closePanaInput) {
      setActionNotice('Please enter at least Open Pana or Close Pana.');
      return;
    }

    setIsSubmittingResult(true);
    setActionNotice('');

    try {
      const now = currentTime || new Date();

      const res = await declareMarketResult({
        marketId: selectedMarket.id,
        marketName: selectedMarket.name,
        openPana: openPanaInput || selectedMarket.openPana,
        closePana: closePanaInput || selectedMarket.closePana,
        date: now,
        action: 'declare_full',
      });

      if (res.success) {
        setActionNotice(`Result declared for ${selectedMarket.name}: ${res.marketResult.jodi}`);
        // Clear inputs
        setOpenPanaInput('');
        setClosePanaInput('');
      } else {
        setActionNotice('Result declaration failed.');
      }
    } catch (err: any) {
      setActionNotice(err.message || 'Failed to declare result.');
    } finally {
      setIsSubmittingResult(false);
    }
  };

  // Quick Wallet Credit/Debit for a user with instant Supabase sync
  const handleAdjustBalance = async (userAcc: UserAccount, delta: number) => {
    const newBal = Math.max(0, userAcc.walletBalance + delta);
    adjustUserBalance(userAcc.id, newBal);
    setAccounts(getRegisteredAccounts());
    setActionNotice(`Updated ${userAcc.username}'s wallet to ₹${newBal.toLocaleString('en-IN')}`);
    if (currentUser.id === userAcc.id && onSwitchUser) {
      onSwitchUser({ ...currentUser, walletBalance: newBal });
    }

    // Direct Supabase synchronization with Realtime broadcast
    try {
      const userUuid = toSupabaseUuid(userAcc.phone || userAcc.id);
      await supabase.from('users').upsert({
        id: userUuid,
        name: userAcc.name,
        mobile: userAcc.phone,
        role: userAcc.role === 'admin' ? 'admin' : 'user',
        status: 'active',
        main_wallet: newBal,
        gaming_wallet: newBal,
      });

      await supabase.from('passbook').insert({
        user_id: userUuid,
        mobile: userAcc.phone,
        type: delta >= 0 ? 'credit' : 'debit',
        amount: Math.abs(delta),
        description: `Admin Wallet ${delta >= 0 ? 'Credit' : 'Debit'} Adjustment (₹${Math.abs(delta)})`,
        status: 'SUCCESS',
      });

      await supabase.from('transactions').insert({
        user_id: userUuid,
        amount: Math.abs(delta),
        type: delta >= 0 ? 'ADMIN_CREDIT' : 'ADMIN_DEBIT',
        status: 'SUCCESS',
        payment_gateway: 'ADMIN_CONSOLE',
      });
    } catch (e) {
      console.warn('Supabase admin balance sync error:', e);
    }
  };

  // Toggle User Role
  const handleToggleRole = (userAcc: UserAccount) => {
    const newRole = userAcc.role === 'admin' ? 'user' : 'admin';
    switchUserRole(userAcc.id, newRole);
    setAccounts(getRegisteredAccounts());
    setActionNotice(`${userAcc.username} role updated to "${newRole.toUpperCase()}".`);
  };

  // Filtered accounts
  const filteredAccounts = accounts.filter(
    (a) =>
      a.username.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
      a.name.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
      a.phone.includes(userSearchQuery)
  );

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex flex-col justify-end sm:justify-center items-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full sm:max-w-3xl md:max-w-4xl lg:max-w-5xl h-[94vh] sm:h-[88vh] bg-[#090a0f] text-slate-100 rounded-t-3xl sm:rounded-3xl border border-zinc-800 shadow-2xl flex flex-col overflow-hidden">
        {/* Top Header */}
        <div className="p-4 bg-gradient-to-r from-[#141624] via-[#1a130d] to-[#0f1018] border-b border-zinc-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-orange-500/20 text-orange-400 border border-orange-500/40 flex items-center justify-center">
              <Crown className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-black text-white flex items-center gap-1.5">
                <span>RATAN567 • RAMA777 Admin Hub</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-orange-400/20 text-orange-300 border border-orange-400/30 font-bold">
                  SUPER ADMIN
                </span>
              </h2>
              <p className="text-[10px] text-slate-400">
                Authorized Personnel: {currentUser.name} ({currentUser.role})
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#11131c] text-slate-300 hover:text-white flex items-center justify-center border border-zinc-800 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* If Not Admin: Security Guard Screen */}
        {!isAdmin ? (
          <div className="flex-1 p-6 flex flex-col items-center justify-center text-center overflow-y-auto">
            <div className="w-16 h-16 rounded-3xl bg-rose-950/60 border border-rose-500/40 text-rose-400 flex items-center justify-center mb-4 shadow-xl">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-white mb-1">Administrator Access Required</h3>
            <p className="text-xs text-slate-400 max-w-xs mb-5">
              You are currently signed in as a standard Player (<b>{currentUser.name}</b>). This section
              is restricted to market operators and platform administrators.
            </p>

            {authError && (
              <div className="w-full max-w-xs mb-3 p-2 rounded-xl bg-rose-950 border border-rose-500/50 text-rose-300 text-xs">
                {authError}
              </div>
            )}

            <div className="w-full max-w-xs bg-[#11131c] p-4 rounded-2xl border border-zinc-800 mb-4 text-left">
              <label className="text-[11px] font-bold text-slate-300 block mb-1">
                Enter Admin Master PIN / Passcode
              </label>
              <input
                type="password"
                value={adminPasscode}
                onChange={(e) => setAdminPasscode(e.target.value)}
                placeholder="Enter 9999"
                className="w-full px-3 py-2 bg-[#090a0f] border border-zinc-800 focus:border-orange-500 rounded-xl text-sm font-mono tracking-widest text-center text-white outline-none mb-3"
              />
              <button
                type="button"
                onClick={handleElevateToAdmin}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs cursor-pointer shadow-md active:scale-95 transition-all"
              >
                Elevate Current Session to Admin
              </button>
            </div>

            <p className="text-[11px] text-slate-500">
              Demo Admin Passcode: <span className="font-mono text-orange-400 font-bold">9999</span>
            </p>
          </div>
        ) : (
          /* Admin Authorized View */
          <>
            {/* Sub-tab Navigation */}
            <div className="grid grid-cols-6 p-1.5 bg-[#0d0f16] border-b border-zinc-800 text-[10px] font-bold shrink-0 gap-0.5">
              <button
                type="button"
                onClick={() => {
                  setActiveTab('results');
                  setActionNotice('');
                }}
                className={`py-2 rounded-xl flex items-center justify-center gap-1 transition-all cursor-pointer ${
                  activeTab === 'results'
                    ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-black font-black shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Trophy className="w-3.5 h-3.5" />
                <span>Results</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('withdrawals');
                  setActionNotice('');
                }}
                className={`py-2 rounded-xl flex items-center justify-center gap-1 transition-all cursor-pointer relative ${
                  activeTab === 'withdrawals'
                    ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-black font-black shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Wallet className="w-3.5 h-3.5" />
                <span>Payouts</span>
                {pendingWithdrawalsCount > 0 && (
                  <span
                    className={`text-[8.5px] font-black px-1.5 py-0.2 rounded-full ${
                      activeTab === 'withdrawals'
                        ? 'bg-black text-orange-400'
                        : 'bg-orange-500 text-white animate-pulse'
                    }`}
                  >
                    {pendingWithdrawalsCount}
                  </span>
                )}
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('analytics');
                  setActionNotice('');
                }}
                className={`py-2 rounded-xl flex items-center justify-center gap-1 transition-all cursor-pointer ${
                  activeTab === 'analytics'
                    ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-black font-black shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5" />
                <span>Bets</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('users');
                  setActionNotice('');
                }}
                className={`py-2 rounded-xl flex items-center justify-center gap-1 transition-all cursor-pointer ${
                  activeTab === 'users'
                    ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-black font-black shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span>Users</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('notices');
                  setActionNotice('');
                }}
                className={`py-2 rounded-xl flex items-center justify-center gap-1 transition-all cursor-pointer ${
                  activeTab === 'notices'
                    ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-black font-black shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Bell className="w-3.5 h-3.5" />
                <span>Notices</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('markets');
                  setActionNotice('');
                }}
                className={`py-2 rounded-xl flex items-center justify-center gap-1 transition-all cursor-pointer ${
                  activeTab === 'markets'
                    ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-black font-black shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Clock className="w-3.5 h-3.5" />
                <span>Markets</span>
              </button>
            </div>

            {/* Notification Banner */}
            {actionNotice && (
              <div className="mx-4 mt-3 p-2.5 rounded-xl bg-orange-950/60 border border-orange-500/50 text-orange-200 text-xs flex items-center gap-2 shrink-0 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 text-orange-400 shrink-0" />
                <span>{actionNotice}</span>
              </div>
            )}

            {/* TAB 1: DECLARE RESULTS */}
            {activeTab === 'results' && (
              <div className="flex-1 p-4 overflow-y-auto space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1.5">
                    Select Target Market
                  </label>
                  <select
                    value={selectedMarketId}
                    onChange={(e) => setSelectedMarketId(e.target.value)}
                    className="w-full px-3 py-2.5 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs font-bold text-white outline-none cursor-pointer"
                  >
                    {markets.map((m) => (
                      <option key={m.id} value={m.id} className="bg-[#090a0f]">
                        {m.name} &bull; {m.openTime} - {m.closeTime}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Market Current Status Card */}
                {selectedMarket && (
                  <div className="bg-[#11131c] p-3.5 rounded-2xl border border-zinc-800">
                    <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                      <span>Currently Declared</span>
                      <span className="font-mono text-orange-400">{selectedMarket.status}</span>
                    </div>
                    <div className="text-lg font-mono font-black text-amber-400 tracking-wider">
                      {formatMarketResult(selectedMarket).formatted}
                    </div>
                  </div>
                )}

                {/* Input Open Pana & Close Pana */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-300 block mb-1">
                      Open Pana (3-Digits)
                    </label>
                    <input
                      type="text"
                      maxLength={3}
                      value={openPanaInput}
                      onChange={(e) => setOpenPanaInput(e.target.value.replace(/\D/g, ''))}
                      placeholder="e.g. 140"
                      className="w-full px-3 py-2 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-sm font-mono text-center text-white outline-none"
                    />
                    {currentOpenDigit !== null && (
                      <span className="text-[10px] text-orange-400 mt-0.5 block text-center font-bold">
                        Open Digit: {currentOpenDigit}
                      </span>
                    )}
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-slate-300 block mb-1">
                      Close Pana (3-Digits)
                    </label>
                    <input
                      type="text"
                      maxLength={3}
                      value={closePanaInput}
                      onChange={(e) => setClosePanaInput(e.target.value.replace(/\D/g, ''))}
                      placeholder="e.g. 180"
                      className="w-full px-3 py-2 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-sm font-mono text-center text-white outline-none"
                    />
                    {currentCloseDigit !== null && (
                      <span className="text-[10px] text-orange-400 mt-0.5 block text-center font-bold">
                        Close Digit: {currentCloseDigit}
                      </span>
                    )}
                  </div>
                </div>

                {/* Preview Jodi Box */}
                <div className="bg-[#151724] p-3 rounded-2xl border border-zinc-800 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">
                      Calculated Preview Result
                    </span>
                    <span className="text-lg font-mono font-black text-amber-400 tracking-widest">
                      {openPanaInput || '***'}-{previewJodi}-{closePanaInput || '***'}
                    </span>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center font-black text-base border border-orange-500/40 font-mono">
                    {previewJodi}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleDeclareResult}
                  disabled={isSubmittingResult}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-orange-500 via-amber-500 to-orange-400 hover:from-orange-400 hover:to-amber-300 text-slate-950 font-black text-xs cursor-pointer shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isSubmittingResult ? (
                    <span>Declaring &amp; Syncing Chart...</span>
                  ) : (
                    <>
                      <span>Declare Official Result &amp; Credit Winners</span>
                      <Trophy className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            )}

            {/* TAB: WITHDRAWAL REQUESTS & PAYOUT SETTLEMENT */}
            {activeTab === 'withdrawals' && (
              <div className="flex-1 p-4 overflow-y-auto space-y-3.5">
                {/* Search Bar */}
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={withdrawalSearch}
                    onChange={(e) => setWithdrawalSearch(e.target.value)}
                    placeholder="Search by Mobile, Name, A/C, IFSC, UPI..."
                    className="w-full pl-9 pr-3 py-2 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white outline-none placeholder:text-slate-500"
                  />
                  {withdrawalSearch && (
                    <button
                      onClick={() => setWithdrawalSearch('')}
                      className="absolute right-3 top-2.5 text-slate-400 hover:text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Filter Tabs */}
                <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5 text-[11px] font-bold">
                  <button
                    type="button"
                    onClick={() => setWithdrawalFilter('all')}
                    className={`px-3 py-1.5 rounded-xl cursor-pointer transition-all shrink-0 ${
                      withdrawalFilter === 'all'
                        ? 'bg-orange-500 text-black font-black'
                        : 'bg-[#11131c] text-slate-400 hover:text-white border border-zinc-800'
                    }`}
                  >
                    All ({withdrawals.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setWithdrawalFilter('pending')}
                    className={`px-3 py-1.5 rounded-xl cursor-pointer transition-all shrink-0 flex items-center gap-1 ${
                      withdrawalFilter === 'pending'
                        ? 'bg-amber-500 text-black font-black'
                        : 'bg-[#11131c] text-amber-400 hover:text-white border border-zinc-800'
                    }`}
                  >
                    <span>Pending</span>
                    {pendingWithdrawalsCount > 0 && (
                      <span className="px-1.5 py-0.2 rounded-full bg-black/20 text-[10px]">
                        {pendingWithdrawalsCount}
                      </span>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => setWithdrawalFilter('approved')}
                    className={`px-3 py-1.5 rounded-xl cursor-pointer transition-all shrink-0 ${
                      withdrawalFilter === 'approved'
                        ? 'bg-emerald-500 text-black font-black'
                        : 'bg-[#11131c] text-emerald-400 hover:text-white border border-zinc-800'
                    }`}
                  >
                    Approved ({withdrawals.filter((w) => String(w.status).toLowerCase() === 'approved').length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setWithdrawalFilter('rejected')}
                    className={`px-3 py-1.5 rounded-xl cursor-pointer transition-all shrink-0 ${
                      withdrawalFilter === 'rejected'
                        ? 'bg-rose-500 text-black font-black'
                        : 'bg-[#11131c] text-rose-400 hover:text-white border border-zinc-800'
                    }`}
                  >
                    Rejected ({withdrawals.filter((w) => String(w.status).toLowerCase() === 'rejected').length})
                  </button>
                </div>

                {/* Loading Indicator */}
                {isLoadingWithdrawals && (
                  <div className="p-4 text-center text-xs text-slate-400 flex items-center justify-center gap-2">
                    <RefreshCw className="w-4 h-4 animate-spin text-orange-400" />
                    <span>Synchronizing with live Supabase withdrawals...</span>
                  </div>
                )}

                {/* Empty State */}
                {!isLoadingWithdrawals && filteredWithdrawals.length === 0 && (
                  <div className="p-8 text-center bg-[#11131c] rounded-2xl border border-zinc-800/80">
                    <Wallet className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                    <p className="text-xs font-bold text-slate-300">No Withdrawal Requests Found</p>
                    <p className="text-[10px] text-slate-500 mt-1">
                      {withdrawalFilter !== 'all'
                        ? `There are no requests with status "${withdrawalFilter}".`
                        : 'When users submit withdrawal requests from the RAMA777 app, they will appear here.'}
                    </p>
                  </div>
                )}

                {/* Withdrawal Requests List */}
                <div className="space-y-3">
                  {filteredWithdrawals.map((w) => {
                    const details = parseWithdrawalBank(w.bank_details, w.mobile);
                    const isPending = String(w.status).toLowerCase() === 'pending';
                    const isApproved = String(w.status).toLowerCase() === 'approved';
                    const isRejected = String(w.status).toLowerCase() === 'rejected';
                    const isProcessing = processingWithdrawalId === w.id;

                    return (
                      <div
                        key={w.id}
                        className="bg-[#11131c] p-3.5 rounded-2xl border border-zinc-800 shadow-md space-y-3"
                      >
                        {/* Card Header: User Mobile + Request Amount + Status */}
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="text-xs font-black text-white flex items-center gap-2">
                              <span>{w.mobile || 'User'}</span>
                              <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-zinc-800 text-slate-400">
                                {String(w.id).slice(0, 8)}
                              </span>
                            </div>
                            <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                              {w.created_at ? new Date(w.created_at).toLocaleString() : 'Recent Request'}
                            </div>
                          </div>

                          <div className="text-right">
                            <div className="text-base font-black text-amber-400 font-mono">
                              ₹{Number(w.amount).toLocaleString('en-IN')}
                            </div>
                            <div className="mt-0.5">
                              {isPending && (
                                <span className="inline-flex items-center gap-1 text-[9.5px] font-black px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-400 border border-amber-500/30 animate-pulse">
                                  <Clock className="w-2.5 h-2.5" />
                                  PENDING REVIEW
                                </span>
                              )}
                              {isApproved && (
                                <span className="inline-flex items-center gap-1 text-[9.5px] font-black px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                                  <CheckCircle2 className="w-2.5 h-2.5" />
                                  APPROVED &amp; PAID
                                </span>
                              )}
                              {isRejected && (
                                <span className="inline-flex items-center gap-1 text-[9.5px] font-black px-2 py-0.5 rounded-full bg-rose-500/15 text-rose-400 border border-rose-500/30">
                                  <XCircle className="w-2.5 h-2.5" />
                                  REJECTED / REFUNDED
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Payment Details Column / Card (Dynamically pulled from bank_details) */}
                        <div className="bg-[#090a0f] p-3 rounded-xl border border-zinc-800/90 space-y-2">
                          <div className="flex items-center justify-between border-b border-zinc-800/70 pb-1.5">
                            <div className="flex items-center gap-1.5 text-xs font-black text-white">
                              <Building2 className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                              <span>{details.bankName}</span>
                            </div>
                            <span className="text-[10px] font-bold text-orange-300 uppercase tracking-wider font-mono">
                              {details.accountHolder}
                            </span>
                          </div>

                          {/* Account Number Row with Copy Action */}
                          <div className="flex items-center justify-between text-xs">
                            <div className="flex items-center gap-1.5 font-mono">
                              <CreditCard className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                              <span className="text-[10.5px] text-slate-400 font-sans">A/C:</span>
                              <span className="font-bold text-slate-100 tracking-wider">
                                {details.accountNumber || 'Not Provided'}
                              </span>
                            </div>
                            {details.accountNumber && (
                              <button
                                type="button"
                                onClick={() => handleCopyText(details.accountNumber, `acc-${w.id}`)}
                                className="text-[10px] px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-slate-300 hover:text-white flex items-center gap-1 cursor-pointer transition-all"
                                title="Copy Account Number"
                              >
                                {copiedKey === `acc-${w.id}` ? (
                                  <>
                                    <Check className="w-2.5 h-2.5 text-emerald-400" />
                                    <span className="text-emerald-400 font-bold">Copied</span>
                                  </>
                                ) : (
                                  <>
                                    <Copy className="w-2.5 h-2.5" />
                                    <span>Copy</span>
                                  </>
                                )}
                              </button>
                            )}
                          </div>

                          {/* IFSC Code Row with Copy Action */}
                          <div className="flex items-center justify-between text-xs">
                            <div className="flex items-center gap-1.5 font-mono">
                              <span className="text-[10.5px] text-slate-400 font-sans">IFSC:</span>
                              <span className="font-bold text-amber-300 px-1.5 py-0.2 rounded bg-amber-500/10 border border-amber-500/20 text-[11px]">
                                {details.ifsc || 'BARB0DHANBA'}
                              </span>
                            </div>
                            {details.ifsc && (
                              <button
                                type="button"
                                onClick={() => handleCopyText(details.ifsc, `ifsc-${w.id}`)}
                                className="text-[10px] px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-slate-300 hover:text-white flex items-center gap-1 cursor-pointer transition-all"
                                title="Copy IFSC"
                              >
                                {copiedKey === `ifsc-${w.id}` ? (
                                  <>
                                    <Check className="w-2.5 h-2.5 text-emerald-400" />
                                    <span className="text-emerald-400 font-bold">Copied</span>
                                  </>
                                ) : (
                                  <>
                                    <Copy className="w-2.5 h-2.5" />
                                    <span>Copy</span>
                                  </>
                                )}
                              </button>
                            )}
                          </div>

                          {/* UPI ID Row with Copy Action */}
                          {details.upiId && (
                            <div className="flex items-center justify-between text-xs">
                              <div className="flex items-center gap-1.5 font-mono">
                                <span className="text-[10.5px] text-slate-400 font-sans">UPI ID:</span>
                                <span className="text-sky-300 font-bold text-[11px] truncate max-w-[180px]">
                                  {details.upiId}
                                </span>
                              </div>
                              <button
                                type="button"
                                onClick={() => handleCopyText(details.upiId, `upi-${w.id}`)}
                                className="text-[10px] px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-slate-300 hover:text-white flex items-center gap-1 cursor-pointer transition-all"
                                title="Copy UPI ID"
                              >
                                {copiedKey === `upi-${w.id}` ? (
                                  <>
                                    <Check className="w-2.5 h-2.5 text-emerald-400" />
                                    <span className="text-emerald-400 font-bold">Copied</span>
                                  </>
                                ) : (
                                  <>
                                    <Copy className="w-2.5 h-2.5" />
                                    <span>Copy</span>
                                  </>
                                )}
                              </button>
                            </div>
                          )}
                        </div>

                        {/* Actions Bar for Admin */}
                        {isPending && (
                          <div className="grid grid-cols-2 gap-2 pt-1">
                            <button
                              type="button"
                              onClick={() => handleApproveWithdrawal(w)}
                              disabled={isProcessing}
                              className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs cursor-pointer shadow active:scale-95 transition-all flex items-center justify-center gap-1.5 disabled:opacity-50"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>{isProcessing ? 'Processing...' : 'Approve Payout'}</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => handleRejectWithdrawal(w)}
                              disabled={isProcessing}
                              className="py-2.5 px-3 rounded-xl bg-rose-950/70 hover:bg-rose-900/80 text-rose-300 border border-rose-600/40 font-bold text-xs cursor-pointer active:scale-95 transition-all flex items-center justify-center gap-1.5 disabled:opacity-50"
                            >
                              <XCircle className="w-3.5 h-3.5 text-rose-400" />
                              <span>{isProcessing ? 'Processing...' : 'Reject & Refund'}</span>
                            </button>
                          </div>
                        )}

                        {isApproved && (
                          <div className="p-2 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-[11px] font-bold flex items-center justify-between">
                            <span className="flex items-center gap-1.5">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                              <span>Payout Approved &amp; Credited</span>
                            </span>
                            <span className="text-[10px] text-emerald-400 font-mono">SETTLED</span>
                          </div>
                        )}

                        {isRejected && (
                          <div className="p-2 rounded-xl bg-rose-950/40 border border-rose-500/30 text-rose-300 text-[11px] font-bold flex items-center justify-between">
                            <span className="flex items-center gap-1.5">
                              <XCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                              <span>Rejected &bull; Refunded to Wallet</span>
                            </span>
                            <span className="text-[10px] text-rose-400 font-mono">REFUNDED</span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TAB 2: USER LEDGER & ACCOUNTS */}
            {activeTab === 'users' && (
              <div className="flex-1 p-4 overflow-y-auto space-y-3">
                {/* Search */}
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={userSearchQuery}
                    onChange={(e) => setUserSearchQuery(e.target.value)}
                    placeholder="Search player by name, username, or phone..."
                    className="w-full pl-9 pr-3 py-2 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white placeholder-slate-500 outline-none"
                  />
                </div>

                <div className="text-[11px] font-bold text-slate-400 flex items-center justify-between px-1">
                  <span>Registered Users ({filteredAccounts.length})</span>
                  <span className="text-orange-400">Instant Credit Adjust</span>
                </div>

                <div className="space-y-2 max-h-[50vh] overflow-y-auto pr-0.5">
                  {filteredAccounts.map((acc) => (
                    <div
                      key={acc.id}
                      className="bg-[#11131c] p-3 rounded-2xl border border-zinc-800 flex flex-col gap-2"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-xs font-bold text-white flex items-center gap-1.5">
                            <span>{acc.name}</span>
                            <span className="text-[10px] text-slate-400">(@{acc.username})</span>
                            <span
                              className={`text-[9px] px-1.5 py-0.2 rounded-md font-mono font-bold ${
                                acc.role === 'admin'
                                  ? 'bg-orange-400/20 text-orange-300 border border-orange-400/30'
                                  : 'bg-zinc-800 text-slate-300 border border-zinc-700'
                              }`}
                            >
                              {acc.role.toUpperCase()}
                            </span>
                          </div>
                          <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                            {acc.phone} &bull; PIN: {acc.mpin}
                          </div>
                        </div>

                        <div className="text-right">
                          <div className="text-xs font-black text-amber-400 font-mono">
                            ₹{acc.walletBalance.toLocaleString('en-IN')}
                          </div>
                          <span className="text-[9px] text-slate-400">Balance</span>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center justify-between pt-1 border-t border-zinc-800">
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleAdjustBalance(acc, 500)}
                            className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-orange-400 rounded-lg text-[10px] font-bold cursor-pointer"
                          >
                            +₹500
                          </button>
                          <button
                            type="button"
                            onClick={() => handleAdjustBalance(acc, 1000)}
                            className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-orange-400 rounded-lg text-[10px] font-bold cursor-pointer"
                          >
                            +₹1000
                          </button>
                          <button
                            type="button"
                            onClick={() => handleAdjustBalance(acc, -500)}
                            className="px-2 py-1 bg-rose-950/80 hover:bg-rose-900 text-rose-300 rounded-lg text-[10px] font-bold cursor-pointer"
                          >
                            -₹500
                          </button>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleToggleRole(acc)}
                          className="text-[10px] text-slate-400 hover:text-orange-400 font-semibold cursor-pointer underline"
                        >
                          Make {acc.role === 'admin' ? 'User' : 'Admin'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB: BET ANALYTICS (Real-time synchronization with Supabase 'bids' table) */}
            {activeTab === 'analytics' && (
              <div className="flex-1 p-4 overflow-y-auto space-y-4">
                {/* Stats Summary Banner */}
                {(() => {
                  const filtered = liveBids.filter((b) => {
                    const matchMkt = analyticsMarketFilter === 'all' || b.market_id === analyticsMarketFilter;
                    const matchType = analyticsGameTypeFilter === 'all' || b.game_type === analyticsGameTypeFilter;
                    return matchMkt && matchType;
                  });
                  const totalPoints = filtered.reduce((acc, b) => acc + (Number(b.points) || 0), 0);
                  const uniqueUsers = new Set(filtered.map((b) => b.user_id)).size;

                  // Find top betted digit
                  const digitCounts: Record<string, number> = {};
                  filtered.forEach((b) => {
                    const d = String(b.digits || '');
                    digitCounts[d] = (digitCounts[d] || 0) + (Number(b.points) || 0);
                  });
                  const topDigitEntry = Object.entries(digitCounts).sort((a, b) => b[1] - a[1])[0];

                  return (
                    <>
                      <div className="grid grid-cols-3 gap-2">
                        <div className="bg-[#11131c] p-2.5 rounded-xl border border-zinc-800">
                          <span className="text-[10px] text-slate-400 block font-bold">Total Bets</span>
                          <span className="text-base font-mono font-black text-white">{filtered.length}</span>
                        </div>
                        <div className="bg-[#11131c] p-2.5 rounded-xl border border-zinc-800">
                          <span className="text-[10px] text-slate-400 block font-bold">Total Points</span>
                          <span className="text-base font-mono font-black text-amber-400">₹{totalPoints.toLocaleString('en-IN')}</span>
                        </div>
                        <div className="bg-[#11131c] p-2.5 rounded-xl border border-zinc-800">
                          <span className="text-[10px] text-slate-400 block font-bold">Top Digit/Pana</span>
                          <span className="text-base font-mono font-black text-orange-400">
                            {topDigitEntry ? `#${topDigitEntry[0]}` : '-'}
                          </span>
                        </div>
                      </div>

                      {/* Filters */}
                      <div className="flex items-center gap-2">
                        <select
                          value={analyticsMarketFilter}
                          onChange={(e) => setAnalyticsMarketFilter(e.target.value)}
                          className="flex-1 px-2.5 py-1.5 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-[11px] font-bold text-white outline-none"
                        >
                          <option value="all">All Markets ({markets.length})</option>
                          {markets.map((m) => (
                            <option key={m.id} value={m.id}>
                              {m.name}
                            </option>
                          ))}
                        </select>

                        <select
                          value={analyticsGameTypeFilter}
                          onChange={(e) => setAnalyticsGameTypeFilter(e.target.value)}
                          className="flex-1 px-2.5 py-1.5 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-[11px] font-bold text-white outline-none"
                        >
                          <option value="all">All Game Types</option>
                          <option value="Single Digit">Single Digit</option>
                          <option value="Jodi Digits">Jodi Digits</option>
                          <option value="Single Pana">Single Pana</option>
                          <option value="Double Pana">Double Pana</option>
                          <option value="Triple Pana">Triple Pana</option>
                          <option value="Half Sangam">Half Sangam</option>
                          <option value="Full Sangam">Full Sangam</option>
                        </select>
                      </div>

                      {/* Live Bids Feed */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-[11px] font-bold text-slate-400">
                          <span className="flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                            Live Supabase Bets Stream ({filtered.length})
                          </span>
                          <span className="text-[10px] text-zinc-500 font-mono">Real-time synced</span>
                        </div>

                        {isLoadingBids ? (
                          <div className="py-8 text-center text-xs text-slate-500">Loading live bets...</div>
                        ) : filtered.length === 0 ? (
                          <div className="py-8 text-center bg-[#11131c] rounded-2xl border border-zinc-800 text-xs text-slate-400">
                            No bets placed matching the filter.
                          </div>
                        ) : (
                          <div className="space-y-1.5 max-h-[44vh] overflow-y-auto pr-0.5">
                            {filtered.map((b) => {
                              const marketObj = markets.find((m) => m.id === b.market_id || (m as any).market_id === b.market_id);
                              const marketDisplayName = marketObj ? marketObj.name : resolveMarketNameFromId(b.market_id);
                              return (
                                <div
                                  key={b.id}
                                  className="p-2.5 bg-[#11131c] rounded-xl border border-zinc-800 flex items-center justify-between hover:border-zinc-700 transition-all"
                                >
                                  <div>
                                    <div className="flex items-center gap-1.5">
                                      <span className="text-xs font-bold text-white">{marketDisplayName}</span>
                                      <span className="text-[10px] px-1.5 py-0.2 bg-zinc-800 text-zinc-300 rounded font-mono">
                                        {b.game_type}
                                      </span>
                                    </div>
                                    <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                                      Digit/Pana: <span className="text-orange-400 font-bold">#{b.digits}</span> &bull; {b.created_at ? new Date(b.created_at).toLocaleTimeString() : 'Recent'}
                                    </div>
                                  </div>

                                  <div className="text-right">
                                    <div className="text-xs font-mono font-black text-amber-400">
                                      ₹{Number(b.points || 0).toLocaleString('en-IN')}
                                    </div>
                                    <span
                                      className={`text-[9px] font-mono px-1.5 py-0.2 rounded font-bold ${
                                        b.status === 'WON'
                                          ? 'bg-emerald-500/20 text-emerald-300'
                                          : b.status === 'LOST'
                                          ? 'bg-rose-500/20 text-rose-300'
                                          : 'bg-amber-500/20 text-amber-300'
                                      }`}
                                    >
                                      {b.status || 'PENDING'}
                                    </span>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    </>
                  );
                })()}
              </div>
            )}

            {/* TAB: NOTICES & BROADCASTS (Live real-time broadcasting to Supabase notifications) */}
            {activeTab === 'notices' && (
              <div className="flex-1 p-4 overflow-y-auto space-y-4">
                <div className="bg-[#11131c] p-3.5 rounded-2xl border border-zinc-800 space-y-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-orange-500/20 text-orange-400 border border-orange-500/30 flex items-center justify-center">
                      <Bell className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">Broadcast Instant Alert</h4>
                      <p className="text-[10px] text-slate-400">Pushes directly to user notifications screen via Supabase Realtime</p>
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-400 block mb-1">
                      Notification Title
                    </label>
                    <input
                      type="text"
                      value={notifTitle}
                      onChange={(e) => setNotifTitle(e.target.value)}
                      placeholder="e.g. Kalyan Market Bids Open!"
                      className="w-full px-3 py-2 bg-[#090a0f] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-400 block mb-1">
                      Message Content
                    </label>
                    <textarea
                      rows={3}
                      value={notifMessage}
                      onChange={(e) => setNotifMessage(e.target.value)}
                      placeholder="Enter announcement details, bonus offers, or market schedules..."
                      className="w-full px-3 py-2 bg-[#090a0f] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white outline-none resize-none"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-400 block mb-1">
                      Notification Category
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {(['alert', 'bonus', 'bid'] as const).map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => setNotifType(t)}
                          className={`py-1.5 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
                            notifType === t
                              ? 'bg-orange-500 text-black font-black'
                              : 'bg-[#090a0f] text-slate-400 border border-zinc-800'
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    type="button"
                    disabled={isSendingNotif}
                    onClick={handleSendBroadcastNotification}
                    className="w-full py-2.5 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-black font-black text-xs rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-1.5 transition-all active:scale-95 disabled:opacity-50"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isSendingNotif ? 'Broadcasting...' : 'Broadcast to All Players'}</span>
                  </button>
                </div>

                <div className="p-3 bg-[#11131c] rounded-2xl border border-zinc-800 text-[11px] text-slate-400 space-y-1">
                  <div className="font-bold text-slate-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Real-time Sync Active</span>
                  </div>
                  <p>
                    All broadcast alerts trigger instant Supabase Postgres Realtime event notifications, updating the bell icon badge and Notification Center immediately.
                  </p>
                </div>
              </div>
            )}

            {/* TAB 3: MARKET CONTROLS */}
            {activeTab === 'markets' && (
              <div className="flex-1 p-4 overflow-y-auto space-y-3">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-bold text-slate-300">
                    Live Market Operating Status ({markets.length})
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowAddMarket(!showAddMarket)}
                    className="px-2.5 py-1 bg-orange-500/20 hover:bg-orange-500/30 text-orange-400 border border-orange-500/40 rounded-xl text-[11px] font-bold cursor-pointer transition-all flex items-center gap-1"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>{showAddMarket ? 'Cancel' : 'Add Market'}</span>
                  </button>
                </div>

                {/* Add Market Form */}
                {showAddMarket && (
                  <div className="bg-[#141624] p-3.5 rounded-2xl border border-orange-500/30 space-y-3 animate-in fade-in">
                    <div className="text-xs font-black text-orange-300 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Create New Firestore Market</span>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-400 block mb-1">
                        Market Name
                      </label>
                      <input
                        type="text"
                        value={newMarketName}
                        onChange={(e) => setNewMarketName(e.target.value)}
                        placeholder="e.g. RAJDHANI DAY"
                        className="w-full px-3 py-2 bg-[#090a0f] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white uppercase outline-none font-bold"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-400 block mb-1">
                        Document ID Format
                      </label>
                      <div className="grid grid-cols-3 gap-1.5 text-[10px]">
                        <button
                          type="button"
                          onClick={() => setNewMarketIdType('mkt_prefix')}
                          className={`py-1.5 px-2 rounded-lg border font-mono font-bold cursor-pointer transition-all ${
                            newMarketIdType === 'mkt_prefix'
                              ? 'bg-orange-500 text-black border-orange-400 font-black'
                              : 'bg-[#090a0f] text-slate-400 border-zinc-800'
                          }`}
                        >
                          mkt-slug
                        </button>
                        <button
                          type="button"
                          onClick={() => setNewMarketIdType('slug')}
                          className={`py-1.5 px-2 rounded-lg border font-mono font-bold cursor-pointer transition-all ${
                            newMarketIdType === 'slug'
                              ? 'bg-orange-500 text-black border-orange-400 font-black'
                              : 'bg-[#090a0f] text-slate-400 border-zinc-800'
                          }`}
                        >
                          clean_slug
                        </button>
                        <button
                          type="button"
                          onClick={() => setNewMarketIdType('auto')}
                          className={`py-1.5 px-2 rounded-lg border font-mono font-bold cursor-pointer transition-all ${
                            newMarketIdType === 'auto'
                              ? 'bg-orange-500 text-black border-orange-400 font-black'
                              : 'bg-[#090a0f] text-slate-400 border-zinc-800'
                          }`}
                        >
                          auto_id
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 block mb-1">
                          Open Time
                        </label>
                        <input
                          type="text"
                          value={newMarketOpenTime}
                          onChange={(e) => setNewMarketOpenTime(e.target.value)}
                          placeholder="11:00 AM"
                          className="w-full px-2.5 py-1.5 bg-[#090a0f] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white outline-none font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 block mb-1">
                          Close Time
                        </label>
                        <input
                          type="text"
                          value={newMarketCloseTime}
                          onChange={(e) => setNewMarketCloseTime(e.target.value)}
                          placeholder="01:00 PM"
                          className="w-full px-2.5 py-1.5 bg-[#090a0f] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white outline-none font-mono"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-400 block mb-1">
                        Initial lastResult (e.g. 140-59-360 or ***-**-***)
                      </label>
                      <input
                        type="text"
                        value={newMarketLastResult}
                        onChange={(e) => setNewMarketLastResult(e.target.value)}
                        placeholder="***-**-***"
                        className="w-full px-2.5 py-1.5 bg-[#090a0f] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white outline-none font-mono"
                      />
                    </div>

                    <button
                      type="button"
                      disabled={isCreatingMarket}
                      onClick={handleCreateMarket}
                      className="w-full py-2 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-black font-black text-xs rounded-xl shadow-md cursor-pointer transition-all active:scale-95 disabled:opacity-50"
                    >
                      {isCreatingMarket ? 'Saving to Firestore...' : 'Create & Sync to Firestore'}
                    </button>
                  </div>
                )}

                {/* Markets List */}
                <div className="space-y-2">
                  {markets.map((m) => (
                    <div
                      key={m.id}
                      className="bg-[#11131c] p-3 rounded-2xl border border-zinc-800 flex items-center justify-between"
                    >
                      <div className="min-w-0 pr-2">
                        <div className="text-xs font-bold text-white flex items-center gap-1.5">
                          <span className="truncate">{m.name}</span>
                          <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-zinc-800 text-zinc-400">
                            {m.id}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                          {m.openTime} - {m.closeTime} &bull; {m.lastResult || `${m.openPana}-${m.jodi}-${m.closePana}`}
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleToggleMarketStatus(m)}
                        className={`text-[10px] px-2.5 py-1.5 rounded-xl font-bold font-mono cursor-pointer transition-all shrink-0 ${
                          m.isOpen
                            ? 'bg-emerald-950/60 hover:bg-emerald-900/60 text-emerald-400 border border-emerald-500/30'
                            : 'bg-rose-950/60 hover:bg-rose-900/60 text-rose-400 border border-rose-500/30'
                        }`}
                        title="Click to toggle status in Firestore"
                      >
                        {m.isOpen ? 'ACTIVE (Click to Close)' : 'CLOSED (Click to Open)'}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
