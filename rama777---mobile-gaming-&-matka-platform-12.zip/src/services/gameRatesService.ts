/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Supabase-backed Game Rates and Winning Payout Calculation Service for RAMA777.
 * Fetches game rates dynamically from Supabase 'game_rates' table,
 * computes estimated returns, and handles real-time winning payouts.
 */

import { supabase } from '../supabase';
import { getDigitFromPana } from '../utils/marketEngine';
import { GameBid, Transaction, UserProfile } from '../types';
import {
  STORAGE_KEYS,
  getStoredJson,
  setStoredJson,
  emitChangeEvent,
  toSupabaseUuid,
  resolveMarketNameFromId,
} from './firestoreSyncService';

export interface GameRateItem {
  id?: string | number;
  name: string;
  ratio: string; // e.g. "1 ka 10", "1 ka 160", "1 ka 100"
  multiplier: number; // e.g. 10, 160, 100, 300, 900, 1000, 10000
  icon: string;
  category: string; // 'RAMA777' | 'BOMBAY STARLINE' | 'BOMBAY JACKPOT'
}

export interface GameRateSection {
  category: string;
  sectionKey: 'RAMA777' | 'BOMBAY STARLINE' | 'BOMBAY JACKPOT';
  items: GameRateItem[];
}

export const DEFAULT_GAME_RATES: GameRateSection[] = [
  {
    category: 'RAMA777 Game Win Ratio',
    sectionKey: 'RAMA777',
    items: [
      { name: 'Single Digit', ratio: '1 ka 10', multiplier: 10, icon: 'dice-1', category: 'RAMA777' },
      { name: 'Single Pana', ratio: '1 ka 160', multiplier: 160, icon: 'spade', category: 'RAMA777' },
      { name: 'Jodi Digit', ratio: '1 ka 100', multiplier: 100, icon: 'dice-2', category: 'RAMA777' },
      { name: 'Double Pana', ratio: '1 ka 300', multiplier: 300, icon: 'spade-pair', category: 'RAMA777' },
      { name: 'Red Brackets', ratio: '1 ka 100', multiplier: 100, icon: 'brackets', category: 'RAMA777' },
      { name: 'Triple Pana', ratio: '1 ka 900', multiplier: 900, icon: 'cards-3', category: 'RAMA777' },
      { name: 'Half Sangam A', ratio: '1 ka 1000', multiplier: 1000, icon: 'coin-a', category: 'RAMA777' },
      { name: 'Half Sangam B', ratio: '1 ka 1000', multiplier: 1000, icon: 'coin-b', category: 'RAMA777' },
      { name: 'Full Sangam Digits', ratio: '1 ka 10000', multiplier: 10000, icon: 'coin-gold', category: 'RAMA777' },
    ],
  },
  {
    category: 'Bombay Starline Game Win Ratio',
    sectionKey: 'BOMBAY STARLINE',
    items: [
      { name: 'Single Digit', ratio: '1 ka 10', multiplier: 10, icon: 'dice-1', category: 'BOMBAY STARLINE' },
      { name: 'Single Pana', ratio: '1 ka 160', multiplier: 160, icon: 'spade', category: 'BOMBAY STARLINE' },
      { name: 'Double Pana', ratio: '1 ka 320', multiplier: 320, icon: 'spade-pair', category: 'BOMBAY STARLINE' },
      { name: 'Triple Pana', ratio: '1 ka 1000', multiplier: 1000, icon: 'cards-3', category: 'BOMBAY STARLINE' },
    ],
  },
  {
    category: 'Bombay Jackpot Game Win Ratio',
    sectionKey: 'BOMBAY JACKPOT',
    items: [
      { name: 'Jackpot', ratio: '1 ka 10', multiplier: 10, icon: 'spade', category: 'BOMBAY JACKPOT' },
    ],
  },
];

// In-memory cache of parsed rates for synchronous multiplier queries during fast bid typing
const cachedRatesMap: Record<string, number> = {
  // RAMA777 standard mappings
  'single_digit': 10,
  'single digit': 10,
  'single_digit_bulk': 10,
  'single digit bulk': 10,
  'odd_even': 10,
  'odd even': 10,
  'jodi_digit': 100,
  'jodi digit': 100,
  'jodi digits': 100,
  'jodi_digit_bulk': 100,
  'jodi bulk': 100,
  'group_jodi': 100,
  'group jodi': 100,
  'red_brackets': 100,
  'red brackets': 100,
  'single_pana': 160,
  'single pana': 160,
  'single_pana_bulk': 160,
  'single pana bulk': 160,
  'sp_motor': 160,
  'sp motor': 160,
  'double_pana': 300,
  'double pana': 300,
  'double_pana_bulk': 300,
  'double pana bulk': 300,
  'dp_motor': 300,
  'dp motor': 300,
  'triple_pana': 900,
  'triple pana': 900,
  'triple_pana_bulk': 900,
  'triple pana bulk': 900,
  'half_sangam': 1000,
  'half sangam': 1000,
  'half sangam a': 1000,
  'half sangam b': 1000,
  'full_sangam': 10000,
  'full sangam': 10000,
  'full sangam digits': 10000,
  // Starline mappings
  'starline_single_digit': 10,
  'starline_single_pana': 160,
  'starline_double_pana': 320,
  'starline_triple_pana': 1000,
  // Jackpot mappings
  'jackpot': 10,
  'bombay_jackpot': 10,
};

/**
 * Extracts a numeric multiplier from ratio string like "1 ka 10", "1:100", or raw number
 */
export function parseRatioMultiplier(ratioStr: string | number | undefined, defaultMult: number = 10): number {
  if (typeof ratioStr === 'number' && !isNaN(ratioStr)) {
    return ratioStr;
  }
  if (!ratioStr) return defaultMult;

  const str = String(ratioStr).trim();
  const match = str.match(/(?:1\s*(?:ka|:|\/)\s*)?(\d+)/i);
  if (match && match[1]) {
    const val = parseInt(match[1], 10);
    return isNaN(val) ? defaultMult : val;
  }
  return defaultMult;
}

function normalizeSectionKey(catName: string = ''): 'RAMA777' | 'BOMBAY STARLINE' | 'BOMBAY JACKPOT' {
  const lower = catName.toLowerCase();
  if (lower.includes('jackpot')) return 'BOMBAY JACKPOT';
  if (lower.includes('starline')) return 'BOMBAY STARLINE';
  return 'RAMA777';
}

async function seedDefaultGameRatesToSupabase(): Promise<void> {
  try {
    const flatRows: any[] = [];
    for (const section of DEFAULT_GAME_RATES) {
      for (const item of section.items) {
        flatRows.push({
          game_name: item.name,
          category: section.sectionKey,
          win_ratio: item.ratio,
          ratio: item.ratio,
          multiplier: item.multiplier,
          icon: item.icon,
          updated_at: new Date().toISOString(),
        });
      }
    }
    await supabase.from('game_rates').upsert(flatRows, { onConflict: 'game_name,category' });
  } catch (err) {
    console.warn('Game rates auto-seed note:', err);
  }
}

/**
 * Fetches game rates directly from Supabase 'game_rates' table.
 * Dynamically categorizes them into RAMA777, BOMBAY STARLINE, and BOMBAY JACKPOT sections.
 */
export async function fetchGameRatesFromSupabase(): Promise<GameRateSection[]> {
  try {
    const { data, error } = await supabase
      .from('game_rates')
      .select('*')
      .order('id', { ascending: true });

    if (error) {
      console.warn('[Supabase Error] Query game_rates failed, using cached defaults:', error.message);
      return DEFAULT_GAME_RATES;
    }

    if (!data || data.length === 0) {
      seedDefaultGameRatesToSupabase();
      return DEFAULT_GAME_RATES;
    }

    const ramaItems: GameRateItem[] = [];
    const starlineItems: GameRateItem[] = [];
    const jackpotItems: GameRateItem[] = [];

    for (const row of data) {
      const name = row.game_name || row.name || 'Game';
      const categoryRaw = row.category || row.game_category || row.section || '';
      const sectionKey = normalizeSectionKey(categoryRaw);
      const ratioStr = row.win_ratio || row.ratio || '1 ka 10';
      const multiplier = row.multiplier ? Number(row.multiplier) : parseRatioMultiplier(ratioStr);
      const icon = row.icon || 'dice-1';

      const item: GameRateItem = {
        id: row.id,
        name,
        ratio: ratioStr,
        multiplier,
        icon,
        category: sectionKey,
      };

      const key = name.toLowerCase().trim();
      cachedRatesMap[key] = multiplier;
      cachedRatesMap[key.replace(/\s+/g, '_')] = multiplier;

      if (sectionKey === 'BOMBAY STARLINE') {
        starlineItems.push(item);
      } else if (sectionKey === 'BOMBAY JACKPOT') {
        jackpotItems.push(item);
      } else {
        ramaItems.push(item);
      }
    }

    const sections: GameRateSection[] = [
      {
        category: 'RAMA777 Game Win Ratio',
        sectionKey: 'RAMA777',
        items: ramaItems.length > 0 ? ramaItems : DEFAULT_GAME_RATES[0].items,
      },
      {
        category: 'Bombay Starline Game Win Ratio',
        sectionKey: 'BOMBAY STARLINE',
        items: starlineItems.length > 0 ? starlineItems : DEFAULT_GAME_RATES[1].items,
      },
      {
        category: 'Bombay Jackpot Game Win Ratio',
        sectionKey: 'BOMBAY JACKPOT',
        items: jackpotItems.length > 0 ? jackpotItems : DEFAULT_GAME_RATES[2].items,
      },
    ];

    return sections;
  } catch (err) {
    console.error('Network failure fetching game rates:', err);
    return DEFAULT_GAME_RATES;
  }
}

/**
 * Subscribes to real-time updates from Supabase 'game_rates' table
 */
export function subscribeToGameRates(
  onUpdate: (sections: GameRateSection[]) => void
): () => void {
  let isMounted = true;

  fetchGameRatesFromSupabase().then((sections) => {
    if (isMounted) onUpdate(sections);
  });

  const channel = supabase
    .channel('public:game_rates:realtime')
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'game_rates' },
      () => {
        if (!isMounted) return;
        fetchGameRatesFromSupabase().then((sections) => {
          if (isMounted) onUpdate(sections);
        });
      }
    )
    .subscribe();

  return () => {
    isMounted = false;
    supabase.removeChannel(channel);
  };
}

/**
 * Get dynamic multiplier for any game type or game ID
 */
export function getGameMultiplier(
  gameIdentifier: string,
  category: 'RAMA777' | 'BOMBAY STARLINE' | 'BOMBAY JACKPOT' = 'RAMA777'
): number {
  if (!gameIdentifier) return 10;
  const clean = gameIdentifier.toLowerCase().trim();

  // Starline specific checks
  if (category === 'BOMBAY STARLINE' || clean.includes('starline')) {
    if (clean.includes('triple')) return cachedRatesMap['starline_triple_pana'] || 1000;
    if (clean.includes('double')) return cachedRatesMap['starline_double_pana'] || 320;
    if (clean.includes('pana')) return cachedRatesMap['starline_single_pana'] || 160;
    return cachedRatesMap['starline_single_digit'] || 10;
  }

  // Jackpot specific check
  if (category === 'BOMBAY JACKPOT' || clean.includes('jackpot')) {
    return cachedRatesMap['jackpot'] || 10;
  }

  if (cachedRatesMap[clean]) return cachedRatesMap[clean];
  const underscored = clean.replace(/\s+/g, '_');
  if (cachedRatesMap[underscored]) return cachedRatesMap[underscored];

  // Pattern matching
  if (clean.includes('full sangam') || clean === 'full_sangam') return 10000;
  if (clean.includes('half sangam') || clean === 'half_sangam') return 1000;
  if (clean.includes('triple') || clean.includes('tripple')) return 900;
  if (clean.includes('double') || clean.includes('dp_motor')) return 300;
  if (clean.includes('single pana') || clean.includes('sp_motor')) return 160;
  if (clean.includes('jodi') || clean.includes('bracket')) return 100;
  if (clean.includes('single') || clean.includes('odd') || clean.includes('even')) return 10;

  return 10;
}

/**
 * Calculate dynamic estimated winning returns on placing bids
 */
export function calculateEstimatedPayout(
  gameIdentifier: string,
  points: number,
  category: 'RAMA777' | 'BOMBAY STARLINE' | 'BOMBAY JACKPOT' = 'RAMA777'
): { multiplier: number; estimatedWin: number; ratioDisplay: string } {
  const multiplier = getGameMultiplier(gameIdentifier, category);
  const safePoints = Math.max(0, points || 0);
  const estimatedWin = safePoints * multiplier;
  const ratioDisplay = `1 ka ${multiplier}`;

  return { multiplier, estimatedWin, ratioDisplay };
}

/**
 * Real-time listener for winning bets & wallet credits from Supabase.
 * Triggers a callback whenever a player's bid is marked WON or a winning credit transaction arrives.
 */
export function listenToWinningCredits(
  userId: string,
  userPhone: string,
  onWinCredit: (winData: {
    bidId: string;
    marketName: string;
    gameType: string;
    amount: number;
    digits: string;
    multiplier: number;
  }) => void
): () => void {
  let isMounted = true;
  const cleanPhone = (userPhone || '').replace(/\D/g, '');

  // 1. Subscribe to Supabase 'bids' table for status = 'WON'
  const bidsChannel = supabase
    .channel(`public:bids:winning:${cleanPhone || userId || 'all'}`)
    .on(
      'postgres_changes',
      { event: 'UPDATE', schema: 'public', table: 'bids' },
      (payload) => {
        if (!isMounted) return;
        const newRecord = payload.new;
        if (!newRecord) return;

        const isUserMatch =
          newRecord.user_id === userId ||
          !newRecord.user_id ||
          (newRecord.phone && newRecord.phone.includes(cleanPhone)) ||
          (newRecord.mobile && newRecord.mobile.includes(cleanPhone));

        if (isUserMatch && String(newRecord.status).toUpperCase() === 'WON') {
          const gameType = newRecord.game_type || 'Single Digit';
          const points = Number(newRecord.points) || 10;
          const mult = getGameMultiplier(gameType);
          const winAmount = Number(newRecord.win_amount) || points * mult;

          onWinCredit({
            bidId: newRecord.id || `win-${Date.now()}`,
            marketName: newRecord.market_name || 'Market',
            gameType,
            amount: winAmount,
            digits: String(newRecord.digits || ''),
            multiplier: mult,
          });
        }
      }
    )
    .subscribe();

  // 2. Also subscribe to Supabase 'transactions' table for WINNING credits
  const txChannel = supabase
    .channel(`public:transactions:win:${cleanPhone || userId || 'all'}`)
    .on(
      'postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'transactions' },
      (payload) => {
        if (!isMounted) return;
        const tx = payload.new;
        if (!tx) return;

        const isUserMatch =
          tx.user_id === userId ||
          !tx.user_id ||
          tx.user_id?.includes(cleanPhone);

        const typeStr = String(tx.type || '').toUpperCase();
        const isWin =
          typeStr.includes('WIN') ||
          typeStr.includes('PRIZE') ||
          (typeStr.includes('CREDIT') && Number(tx.amount) > 0 && String(tx.payment_gateway || '').includes('WIN'));

        if (isUserMatch && isWin) {
          onWinCredit({
            bidId: tx.id || `tx-win-${Date.now()}`,
            marketName: tx.title || 'Market Winner',
            gameType: 'Winning Payout',
            amount: Number(tx.amount) || 0,
            digits: '',
            multiplier: 10,
          });
        }
      }
    )
    .subscribe();

  return () => {
    isMounted = false;
    supabase.removeChannel(bidsChannel);
    supabase.removeChannel(txChannel);
  };
}

/**
 * Evaluates pending bids against declared results and calculates winning payouts
 * using active rates from the Supabase game_rates table (Single Digit = 10x, Single Pana = 160x, Jodi = 100x, etc.).
 * Credits the user's wallet instantly, logs the transaction in the passbook,
 * and updates the bid status to 'WIN'/'Won' with the exact winning amount displayed in history.
 */
export async function evaluateAndSettleBidsForMarket(params: {
  marketId: string;
  marketName: string;
  openPana: string;
  jodi: string;
  closePana: string;
  currentUserPhone?: string;
  currentUserId?: string;
  onWinSettled?: (summary: {
    wonBidsCount: number;
    totalWonPayout: number;
    winningBids: {
      bidId: string;
      marketName: string;
      gameType: string;
      points: number;
      multiplier: number;
      winAmount: number;
      digitOrPana: string;
    }[];
  }) => void;
}): Promise<{
  wonBidsCount: number;
  totalWonPayout: number;
  winningBids: any[];
}> {
  const { marketId, marketName, openPana, jodi, closePana, currentUserPhone, currentUserId, onWinSettled } = params;

  // Ensure active rates from Supabase game_rates table are freshly synced
  await fetchGameRatesFromSupabase();

  const isOpenValid = /^\d{3}$/.test(openPana);
  const isCloseValid = /^\d{3}$/.test(closePana);
  const openDigit = isOpenValid ? String(getDigitFromPana(openPana)) : '';
  const closeDigit = isCloseValid ? String(getDigitFromPana(closePana)) : '';
  const isMarketFullyDeclared = isOpenValid && isCloseValid;

  let wonBidsCount = 0;
  let totalWonPayout = 0;
  const winningBids: any[] = [];

  // Helper to test if a bid matches this market
  const isTargetMarket = (bidMarketName?: string, bidMarketId?: string) => {
    const cleanBM = String(bidMarketName || '').toLowerCase().trim();
    const cleanBId = String(bidMarketId || '').toLowerCase().trim();
    const targetMName = String(marketName || '').toLowerCase().trim();
    const targetMId = String(marketId || '').toLowerCase().trim();

    return (
      cleanBM === targetMName ||
      cleanBId === targetMId ||
      cleanBM.includes(targetMName) ||
      targetMName.includes(cleanBM) ||
      cleanBId.includes(targetMId) ||
      toSupabaseUuid(cleanBM) === targetMId ||
      toSupabaseUuid(cleanBId) === targetMId
    );
  };

  // 1. Fetch & evaluate local storage bids
  try {
    const localBids = getStoredJson<GameBid[]>(STORAGE_KEYS.BIDS, []);
    let updatedLocal = false;
    let totalCreditForCurrentUser = 0;

    for (const b of localBids) {
      if (b.status !== 'Placed' && b.status !== 'PENDING' && (b as any).status !== 'pending') {
        continue;
      }
      if (!isTargetMarket(b.marketName, b.marketId)) {
        continue;
      }

      const gType = String(b.gameType || '').toLowerCase();
      const digitOrPana = String(b.digitOrPana || '').trim();
      const session = b.session || 'Open';
      let isWon = false;

      // Rate multiplier lookup (Single Digit = 10x, Single Pana = 160x, Jodi = 100x, Double Pana = 300x, etc.)
      const mult = getGameMultiplier(b.gameType);

      if (gType.includes('single digit') || gType.includes('odd even')) {
        if (session === 'Open' && isOpenValid && digitOrPana === openDigit) isWon = true;
        if (session === 'Close' && isCloseValid && digitOrPana === closeDigit) isWon = true;
        if (gType.includes('odd') && session === 'Open' && isOpenValid && Number(openDigit) % 2 !== 0) isWon = true;
        if (gType.includes('even') && session === 'Open' && isOpenValid && Number(openDigit) % 2 === 0) isWon = true;
      } else if (gType.includes('jodi') || gType.includes('bracket')) {
        if (isOpenValid && isCloseValid && (digitOrPana === jodi || digitOrPana === `${openDigit}${closeDigit}`)) {
          isWon = true;
        }
      } else if (gType.includes('single pana') || gType.includes('single patti') || gType.includes('sp motor')) {
        if (session === 'Open' && isOpenValid && digitOrPana === openPana) isWon = true;
        if (session === 'Close' && isCloseValid && digitOrPana === closePana) isWon = true;
      } else if (gType.includes('double pana') || gType.includes('double patti') || gType.includes('dp motor')) {
        if (session === 'Open' && isOpenValid && digitOrPana === openPana) isWon = true;
        if (session === 'Close' && isCloseValid && digitOrPana === closePana) isWon = true;
      } else if (gType.includes('triple pana') || gType.includes('triple patti')) {
        if (session === 'Open' && isOpenValid && digitOrPana === openPana) isWon = true;
        if (session === 'Close' && isCloseValid && digitOrPana === closePana) isWon = true;
      } else if (gType.includes('half sangam')) {
        if (isOpenValid && isCloseValid) {
          if (digitOrPana.includes(openPana) && digitOrPana.includes(closeDigit)) isWon = true;
          if (digitOrPana.includes(closePana) && digitOrPana.includes(openDigit)) isWon = true;
        }
      } else if (gType.includes('full sangam')) {
        if (isOpenValid && isCloseValid && digitOrPana.includes(openPana) && digitOrPana.includes(closePana)) {
          isWon = true;
        }
      }

      if (isWon) {
        // Calculate exact winnings: bet_points * rate_multiplier
        const winPayout = (Number(b.points) || 10) * mult;
        b.status = 'Won';
        b.winAmount = winPayout;
        (b as any).settledAt = new Date().toISOString();

        wonBidsCount++;
        totalWonPayout += winPayout;
        totalCreditForCurrentUser += winPayout;
        updatedLocal = true;

        winningBids.push({
          bidId: b.id,
          marketName: b.marketName,
          gameType: b.gameType,
          points: b.points,
          multiplier: mult,
          winAmount: winPayout,
          digitOrPana: b.digitOrPana,
        });

        // 1. Update Supabase bids table status to 'WIN'
        if (b.id) {
          supabase
            .from('bids')
            .update({ status: 'WIN' })
            .eq('id', b.id)
            .then(() => {}, () => {});
        }

        // 2. Log winning transaction in passbook
        const now = new Date();
        const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
          .toString()
          .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
        })}`;

        const winTx: Transaction = {
          id: `tx-win-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          title: `${b.marketName} Win | ₹${winPayout}`,
          referenceId: `WIN-${Math.random().toString(36).substring(2, 9).toUpperCase()}`,
          description: `Winning payout for ${b.gameType} #${b.digitOrPana} (${mult}x Rate) | Points: ₹${b.points}`,
          amount: winPayout,
          type: 'credit',
          status: 'SUCCESS',
          date: dateStr,
          previousBalance: 0,
          currentBalance: winPayout,
        };

        const existingTxs = getStoredJson<Transaction[]>(STORAGE_KEYS.TRANSACTIONS, []);
        if (!existingTxs.some((t) => t.referenceId === winTx.referenceId || t.description.includes(b.id))) {
          setStoredJson(STORAGE_KEYS.TRANSACTIONS, [winTx, ...existingTxs]);
          emitChangeEvent(STORAGE_KEYS.TRANSACTIONS);
        }

        // Insert into Supabase transactions table
        const userUuid = toSupabaseUuid((b as any).userId || currentUserId || currentUserPhone || '00000000-0000-0000-0000-000000000000');
        supabase
          .from('transactions')
          .insert({
            user_id: userUuid,
            amount: winPayout,
            type: 'WINNING_PAYOUT',
            status: 'SUCCESS',
            payment_gateway: 'RAMA_WALLET_WIN',
          })
          .then(() => {}, () => {});
      } else if (isMarketFullyDeclared) {
        // If session is closed and bet did not win, mark as Lost
        b.status = 'Lost';
        updatedLocal = true;

        if (b.id) {
          supabase
            .from('bids')
            .update({ status: 'LOST' })
            .eq('id', b.id)
            .then(() => {}, () => {});
        }
      }
    }

    if (updatedLocal) {
      setStoredJson(STORAGE_KEYS.BIDS, localBids);
      emitChangeEvent(STORAGE_KEYS.BIDS);

      // Instant Wallet Credit in local storage users registry
      if (totalCreditForCurrentUser > 0) {
        const allUsers = getStoredJson<Record<string, Partial<UserProfile>>>(STORAGE_KEYS.USERS, {});
        const targetKey = currentUserId || currentUserPhone || 'default';

        if (allUsers[targetKey]) {
          const currentBal = Number(allUsers[targetKey].walletBalance) || 0;
          allUsers[targetKey].walletBalance = currentBal + totalCreditForCurrentUser;
          setStoredJson(STORAGE_KEYS.USERS, allUsers);
          emitChangeEvent(STORAGE_KEYS.USERS);
        }

        // Also update active session in local storage
        try {
          const rawSession = localStorage.getItem('rama777_active_user');
          if (rawSession) {
            const activeUser = JSON.parse(rawSession);
            activeUser.walletBalance = (Number(activeUser.walletBalance) || 0) + totalCreditForCurrentUser;
            localStorage.setItem('rama777_active_user', JSON.stringify(activeUser));
          }
        } catch (e) {
          console.warn('Active user wallet credit note:', e);
        }
      }
    }
  } catch (err) {
    console.warn('Local bid evaluation notice:', err);
  }

  // 2. Query and settle Supabase 'bids' table rows directly
  try {
    const { data: dbBids } = await supabase
      .from('bids')
      .select('*')
      .in('status', ['PENDING', 'Placed', 'pending']);

    if (dbBids && dbBids.length > 0) {
      for (const row of dbBids) {
        const bMarket = String(row.market_name || row.market_id || '').toLowerCase();
        if (!isTargetMarket(row.market_name, row.market_id)) {
          continue;
        }

        const gType = String(row.game_type || '').toLowerCase();
        const digits = String(row.digits || '').trim();
        const mult = getGameMultiplier(row.game_type);
        let isWon = false;

        if (gType.includes('single digit') || gType.includes('odd even')) {
          if (isOpenValid && digits === openDigit) isWon = true;
          if (isCloseValid && digits === closeDigit) isWon = true;
        } else if (gType.includes('jodi') || gType.includes('bracket')) {
          if (isOpenValid && isCloseValid && (digits === jodi || digits === `${openDigit}${closeDigit}`)) isWon = true;
        } else if (gType.includes('single pana') || gType.includes('double pana') || gType.includes('triple pana')) {
          if (isOpenValid && digits === openPana) isWon = true;
          if (isCloseValid && digits === closePana) isWon = true;
        }

        if (isWon) {
          const winAmount = (Number(row.points) || 10) * mult;

          // Update Supabase bids to 'WIN'
          await supabase
            .from('bids')
            .update({ status: 'WIN' })
            .eq('id', row.id);

          // Credit wallet in Supabase users table
          try {
            const { data: uData } = await supabase
              .from('users')
              .select('main_wallet, winning_wallet, mobile')
              .eq('id', row.user_id)
              .limit(1);

            const curMain = uData && uData.length > 0 ? Number(uData[0].main_wallet || 0) : 0;
            const curWin = uData && uData.length > 0 ? Number(uData[0].winning_wallet || 0) : 0;
            const uMobile = uData && uData.length > 0 ? uData[0].mobile : (currentUserPhone || '');

            await supabase
              .from('users')
              .update({
                main_wallet: curMain + winAmount,
                winning_wallet: curWin + winAmount,
              })
              .eq('id', row.user_id);

            // Record in Supabase passbook table
            await supabase.from('passbook').insert({
              user_id: row.user_id,
              mobile: uMobile,
              type: 'credit',
              amount: winAmount,
              description: `Winning Payout: ${params.marketName || 'Market'} (${row.game_type || 'Game'} @ ${mult}x)`,
              status: 'SUCCESS',
            });
          } catch (e) {
            console.warn('Supabase user wallet credit notice:', e);
          }

          // Insert winning credit transaction into Supabase transactions
          await supabase.from('transactions').insert({
            user_id: row.user_id,
            amount: winAmount,
            type: 'WINNING_PAYOUT',
            status: 'SUCCESS',
            payment_gateway: 'RAMA_WALLET_WIN',
          });
        } else if (isMarketFullyDeclared) {
          await supabase
            .from('bids')
            .update({ status: 'LOST' })
            .eq('id', row.id);
        }
      }
    }
  } catch (err) {
    console.warn('Supabase DB settlement notice:', err);
  }

  if (onWinSettled && winningBids.length > 0) {
    onWinSettled({
      wonBidsCount,
      totalWonPayout,
      winningBids,
    });
  }

  return { wonBidsCount, totalWonPayout, winningBids };
}
