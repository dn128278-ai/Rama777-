/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Supabase Plain CRUD Data Service for RAMA777.
 * Handles plain direct CRUD operations on 'markets', 'bids', and 'transactions'
 * without enforcing user authentication checks.
 *
 * Resilience & Guarantees:
 * - Executes direct queries on Supabase tables.
 * - Catches any errors with descriptive console.error logging.
 * - Always falls back to local optimistic state if network or Supabase queries fail.
 * - Realtime channel subscriptions broadcast live updates immediately.
 */

import { supabase } from '../supabase';
import {
  UserProfile,
  Transaction,
  FundHistoryItem,
  BankAccount,
  GameBid,
  AppNotification,
  MarketItem,
} from '../types';
import { secureStorage } from '../utils/security';
import {
  sanitizeText,
  sanitizeAmount,
  sanitizeUtr,
  sanitizeIfsc,
  sanitizeBankAccount,
} from '../utils/sanitizer';
import { formatRemainingDuration, parseTimeString, formatMarketResult, getDigitFromPana } from '../utils/marketEngine';
import { INITIAL_MARKETS } from '../data/initialData';
import { getGameMultiplier } from './gameRatesService';

export interface ManualUpiConfig {
  enabled: boolean;
  upiId: string;
  merchantName: string;
  qrCodeUrl: string;
  requireScreenshot?: boolean;
  instructions?: string;
}

export interface PaymentGatewayConfig {
  merchantVpa: string;
  merchantName: string;
  status: 'active' | 'maintenance';
  minDeposit: number;
  maxDeposit?: number;
  minWithdrawal: number;
  welcomeBonusEnabled: boolean;
  bonusAmount: number;
  activeGateway?: string;
  manualUpi?: ManualUpiConfig;
  phonepe?: {
    enabled?: boolean;
    merchantId?: string;
  };
  paytm?: {
    enabled?: boolean;
    mid?: string;
  };
  razorpay?: {
    enabled?: boolean;
    keyId?: string;
  };
  updatedAt?: string;
}

export const DEFAULT_GATEWAY_CONFIG: PaymentGatewayConfig = {
  merchantVpa: '0793748A0296660.bqr@kotak',
  merchantName: 'RAMA77 GAMING ENTERPRISES',
  status: 'active',
  minDeposit: 100,
  maxDeposit: 100000,
  minWithdrawal: 300,
  welcomeBonusEnabled: true,
  bonusAmount: 100,
  activeGateway: 'manual_upi',
  manualUpi: {
    enabled: true,
    upiId: '0793748A0296660.bqr@kotak',
    merchantName: 'RAMA77 GAMING ENTERPRISES',
    qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=upi://pay?pa=0793748A0296660.bqr@kotak&pn=RAMA77%20GAMING&cu=INR',
    requireScreenshot: true,
    instructions: 'Scan QR code or copy UPI ID. Pay using any UPI app and enter the 12-digit UTR/Ref No.',
  },
};

export interface UserAuthScope {
  uid: string;
  phone: string;
}

// Local Encrypted Cache Keys for Optimistic Fallback
const STORAGE_KEYS = {
  USERS: 'rama777_users_data',
  WITHDRAWALS: 'rama777_withdrawals_data',
  DEPOSITS: 'rama777_deposits_data',
  TRANSACTIONS: 'rama777_transactions_data',
  BIDS: 'rama777_bids_data',
  BANKS: 'rama777_banks_data',
  NOTIFICATIONS: 'rama777_notifications_data',
  GATEWAY: 'rama777_gateway_data',
  MARKETS: 'rama777_markets_data',
};

// Event bus for real-time reactivity across components
type EventCallback = () => void;
const eventListeners: Record<string, Set<EventCallback>> = {};

function emitChangeEvent(key: string) {
  if (eventListeners[key]) {
    eventListeners[key].forEach((cb) => {
      try {
        cb();
      } catch (e) {
        console.warn('Listener notification warning:', e);
      }
    });
  }
}

function addStorageListener(key: string, callback: EventCallback): () => void {
  if (!eventListeners[key]) {
    eventListeners[key] = new Set();
  }
  eventListeners[key].add(callback);
  return () => {
    eventListeners[key]?.delete(callback);
  };
}

function getStoredJson<T>(key: string, defaultValue: T): T {
  return secureStorage.getItem<T>(key, defaultValue);
}

function setStoredJson<T>(key: string, value: T): void {
  try {
    secureStorage.setItem(key, value);
    emitChangeEvent(key);
  } catch (e) {
    console.warn('SecureStorage save notice:', e);
  }
}

export function resolveUserAuthScope(userParam?: Partial<UserProfile> | string | null): UserAuthScope {
  let uid = '';
  let phone = '';

  if (typeof userParam === 'string') {
    const digits = userParam.replace(/\D/g, '');
    if (digits.length === 10) phone = digits;
    if (!uid) uid = userParam.trim();
  } else if (userParam && typeof userParam === 'object') {
    if (userParam.uid) uid = String(userParam.uid).trim();
    else if (userParam.id) uid = String(userParam.id).trim();
    if (userParam.phone) {
      const digits = String(userParam.phone).replace(/\D/g, '');
      if (digits) phone = digits;
    }
  }

  if (!uid && typeof window !== 'undefined') {
    const storedUid = localStorage.getItem('rama777_user_uid');
    if (storedUid) uid = storedUid.trim();
  }

  if (!phone && typeof window !== 'undefined') {
    const storedPhone = localStorage.getItem('rama777_user_phone');
    if (storedPhone) phone = storedPhone.replace(/\D/g, '');
  }

  if (!uid && phone) {
    uid = phone;
  }

  return { uid, phone };
}

export function getUserIdentifier(userOrPhone?: Partial<UserProfile> | string | null): string {
  const scope = resolveUserAuthScope(userOrPhone);
  return scope.uid || scope.phone;
}

import { toSupabaseUuid, isMatchingUser } from '../utils/userScope';
export { toSupabaseUuid, isMatchingUser };

// ==========================================
// 1. User Profile & Live Wallet Sync
// ==========================================
export function subscribeToUserWallet(
  userParam: string | Partial<UserProfile>,
  onUpdate: (userData: Partial<UserProfile>) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);
  const targetId = scope.uid || scope.phone || 'default';
  const cleanPhone = (scope.phone || '').replace(/\D/g, '');
  const phoneUuid = toSupabaseUuid(cleanPhone);
  const uidUuid = toSupabaseUuid(scope.uid);

  let isMounted = true;

  // 1. Optimistic read from local storage immediately
  const allUsers = getStoredJson<Record<string, Partial<UserProfile>>>(STORAGE_KEYS.USERS, {});
  const stored = allUsers[targetId] || allUsers[cleanPhone] || {};
  if (stored && typeof stored.walletBalance === 'number') {
    onUpdate({
      uid: targetId,
      id: targetId,
      ...stored,
    });
  }

  // 2. Fetch live wallet balance from Supabase 'users' table
  const fetchSupabaseUser = async () => {
    try {
      let query = supabase.from('users').select('*');
      if (cleanPhone) {
        query = query.or(`id.eq.${phoneUuid},id.eq.${uidUuid},mobile.eq.${cleanPhone}`);
      } else {
        query = query.or(`id.eq.${uidUuid}`);
      }

      const { data, error } = await query.limit(1).maybeSingle();
      if (error) {
        console.warn('[Supabase Note] Query user wallet notice:', error.message);
        return;
      }

      if (data && isMounted) {
        const mainBal = Number(data.main_wallet ?? data.wallet_balance ?? data.balance ?? 0);
        const winBal = Number(data.winning_wallet ?? 0);
        const gamingBal = Number(data.gaming_wallet ?? 0);
        const totalBal = Math.max(0, mainBal + winBal);

        const updatedPartial: Partial<UserProfile> = {
          walletBalance: totalBal,
          mainWallet: mainBal,
          winningWallet: winBal,
          gamingWallet: gamingBal,
        };

        const latest = getStoredJson<Record<string, Partial<UserProfile>>>(STORAGE_KEYS.USERS, {});
        latest[targetId] = { ...(latest[targetId] || {}), ...updatedPartial };
        if (cleanPhone) latest[cleanPhone] = latest[targetId];
        setStoredJson(STORAGE_KEYS.USERS, latest);

        onUpdate(updatedPartial);
      }
    } catch (err) {
      console.warn('Network sync for user wallet:', err);
    }
  };

  fetchSupabaseUser();

  // 3. Realtime Subscription on Supabase 'users' table for instant balance updates
  const userChannel = supabase
    .channel(`public:users:sync:${cleanPhone || targetId || 'all'}`)
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'users' },
      (payload) => {
        if (!isMounted) return;
        const row = payload.new as any;
        if (row && isMatchingUser(row.id, { uid: scope.uid, id: targetId, phone: cleanPhone }, row.mobile || row.phone)) {
          const mainBal = Number(row.main_wallet ?? row.wallet_balance ?? row.balance ?? 0);
          const winBal = Number(row.winning_wallet ?? 0);
          const gamingBal = Number(row.gaming_wallet ?? 0);
          const totalBal = Math.max(0, mainBal + winBal);

          const updatedPartial: Partial<UserProfile> = {
            walletBalance: totalBal,
            mainWallet: mainBal,
            winningWallet: winBal,
            gamingWallet: gamingBal,
          };

          const latest = getStoredJson<Record<string, Partial<UserProfile>>>(STORAGE_KEYS.USERS, {});
          latest[targetId] = { ...(latest[targetId] || {}), ...updatedPartial };
          if (cleanPhone) latest[cleanPhone] = latest[targetId];
          setStoredJson(STORAGE_KEYS.USERS, latest);

          onUpdate(updatedPartial);
        }
      }
    )
    .subscribe();

  // 4. Listen to local storage changes
  const unsubStorage = addStorageListener(STORAGE_KEYS.USERS, () => {
    if (!isMounted) return;
    const latest = getStoredJson<Record<string, Partial<UserProfile>>>(STORAGE_KEYS.USERS, {});
    const cur = latest[targetId] || latest[cleanPhone] || {};
    if (cur && typeof cur.walletBalance === 'number') {
      onUpdate({
        uid: targetId,
        id: targetId,
        ...cur,
      });
    }
  });

  return () => {
    isMounted = false;
    unsubStorage();
    supabase.removeChannel(userChannel);
  };
}

export async function syncUserToFirestore(user: UserProfile): Promise<void> {
  const scope = resolveUserAuthScope(user);
  const uid = scope.uid || scope.phone || 'default';
  const cleanPhone = (scope.phone || '').replace(/\D/g, '');
  const allUsers = getStoredJson<Record<string, Partial<UserProfile>>>(STORAGE_KEYS.USERS, {});
  allUsers[uid] = { ...allUsers[uid], ...user, uid, id: uid };
  if (cleanPhone) allUsers[cleanPhone] = allUsers[uid];
  setStoredJson(STORAGE_KEYS.USERS, allUsers);

  // Sync to Supabase users table
  try {
    const userUuid = toSupabaseUuid(cleanPhone || uid);
    const updatePayload: Record<string, any> = {
      name: user.name,
      wallet_balance: user.walletBalance,
    };
    if (user.mainWallet !== undefined) updatePayload.main_wallet = user.mainWallet;
    if (user.winningWallet !== undefined) updatePayload.winning_wallet = user.winningWallet;
    if (user.gamingWallet !== undefined) updatePayload.gaming_wallet = user.gamingWallet;

    await supabase
      .from('users')
      .update(updatePayload)
      .or(`id.eq.${userUuid},mobile.eq.${cleanPhone}`);
  } catch (err) {
    // Non-blocking fallback
  }
}

// ==========================================
// 2. Withdrawal Requests Sync ('withdrawals')
// ==========================================

export function normalizeWithdrawalStatus(rawStatus?: string | null): 'Success' | 'Failure' | 'Pending' {
  if (!rawStatus) return 'Pending';
  const s = String(rawStatus).trim().toLowerCase();
  if (s === 'approved' || s === 'success' || s === 'paid' || s === 'completed') {
    return 'Success';
  }
  if (s === 'rejected' || s === 'failure' || s === 'failed' || s === 'cancelled') {
    return 'Failure';
  }
  return 'Pending';
}

export function subscribeToWithdrawals(
  userParam: string | Partial<UserProfile>,
  onUpdate: (withdrawals: FundHistoryItem[], hasData: boolean) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);
  let isMounted = true;
  const cleanPhone = (scope.phone || '').replace(/\D/g, '');
  const phoneUuid = toSupabaseUuid(cleanPhone);
  const uidUuid = toSupabaseUuid(scope.uid);

  const emitLocal = () => {
    const all = getStoredJson<FundHistoryItem[]>(STORAGE_KEYS.WITHDRAWALS, []);
    const filtered = all.filter((item) => {
      if (!scope.phone && !scope.uid) return true;
      const itemPhone = (item as any).userPhone || (item as any).phone || '';
      const itemUid = (item as any).userId || (item as any).uid || '';
      return (
        (scope.phone && itemPhone.includes(scope.phone)) ||
        (scope.uid && itemUid === scope.uid) ||
        (!itemPhone && !itemUid)
      );
    });
    if (isMounted) onUpdate(filtered, filtered.length > 0);
  };

  emitLocal();
  const unsubStorage = addStorageListener(STORAGE_KEYS.WITHDRAWALS, emitLocal);

  // Direct query Supabase 'withdrawals' table
  const queryDirectWithdrawals = async () => {
    try {
      let query = supabase.from('withdrawals').select('*').order('created_at', { ascending: false });
      if (cleanPhone) {
        query = query.or(`mobile.eq.${cleanPhone},user_id.eq.${uidUuid},user_id.eq.${phoneUuid}`);
      } else if (scope.uid) {
        query = query.or(`user_id.eq.${uidUuid}`);
      }
      const { data, error } = await query.limit(50);
      if (error) {
        console.warn('[Supabase Note] Query withdrawals:', error.message);
        return;
      }
      if (data && isMounted) {
        const items: FundHistoryItem[] = data.map((row) => {
          let bName = 'Bank Transfer';
          let accNum = '';
          let ifsc = '';
          try {
            if (row.bank_details) {
              const parsed = typeof row.bank_details === 'string' ? JSON.parse(row.bank_details) : row.bank_details;
              bName = parsed.bankName || bName;
              accNum = parsed.accountNumber || '';
              ifsc = parsed.ifsc || '';
            }
          } catch {}
          return {
            id: row.id,
            requestType: 'Withdrawal',
            depositMode: 'Bank Transfer',
            orderId: row.order_id || `WTH-${String(row.id).slice(-6).toUpperCase()}`,
            amount: Number(row.amount) || 0,
            status: normalizeWithdrawalStatus(row.status),
            date: row.created_at ? new Date(row.created_at).toLocaleString() : new Date().toLocaleString(),
            bankName: bName,
            accountNumber: accNum,
            ifscCode: ifsc,
            userId: row.user_id,
            userPhone: row.mobile,
          };
        });

        // Supabase is authoritative source of truth for withdrawal status
        const currentLocal = getStoredJson<FundHistoryItem[]>(STORAGE_KEYS.WITHDRAWALS, []);
        const remoteIds = new Set(items.map((r) => r.id));
        const nonRemoteLocals = currentLocal.filter((loc) => !remoteIds.has(loc.id));
        const merged = [...items, ...nonRemoteLocals];
        setStoredJson(STORAGE_KEYS.WITHDRAWALS, merged);
        onUpdate(items.length > 0 ? items : merged, true);
      }
    } catch (err) {
      console.warn('Network sync for withdrawals:', err);
    }
  };

  queryDirectWithdrawals();

  // 1. Realtime subscription on Supabase 'withdrawals' table
  const realtimeChannelName = `withdrawals-live-${cleanPhone || scope.uid || 'all'}-${Date.now()}`;
  const withChannel = supabase
    .channel(realtimeChannelName)
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'withdrawals' },
      (payload) => {
        if (!isMounted) return;
        console.log('[Supabase Realtime] Withdrawal status changed in database:', payload);
        queryDirectWithdrawals();
      }
    )
    .subscribe((status) => {
      console.log('[Supabase Realtime] withdrawal subscription status:', status);
    });

  // 2. In-app custom event listener for instant status reflection from Admin Panel
  const handleInAppWithdrawalUpdate = () => {
    if (!isMounted) return;
    queryDirectWithdrawals();
  };
  if (typeof window !== 'undefined') {
    window.addEventListener('rama777:withdrawal_updated', handleInAppWithdrawalUpdate);
  }

  // 3. Fallback active polling every 3 seconds to guarantee instant status sync without reload
  const pollTimer = setInterval(() => {
    if (isMounted) {
      queryDirectWithdrawals();
    }
  }, 3000);

  return () => {
    isMounted = false;
    clearInterval(pollTimer);
    if (typeof window !== 'undefined') {
      window.removeEventListener('rama777:withdrawal_updated', handleInAppWithdrawalUpdate);
    }
    unsubStorage();
    supabase.removeChannel(withChannel);
  };
}

export async function createWithdrawalInFirestore(
  item: FundHistoryItem,
  user: UserProfile
): Promise<void> {
  const scope = resolveUserAuthScope(user);
  const cleanPhone = (scope.phone || '').replace(/\D/g, '');
  const cleanAmountResult = sanitizeAmount(item.amount, 100, 100000);
  const safeAmount = cleanAmountResult.isValid ? cleanAmountResult.amount : item.amount;
  const safeBankName = sanitizeText(item.bankName || '', 50);
  const safeAccount = sanitizeBankAccount(item.accountNumber || '').accountNumber || item.accountNumber || '';
  const safeIfsc = sanitizeIfsc(item.ifscCode || '').ifsc || item.ifscCode || '';
  const userUuid = toSupabaseUuid(cleanPhone || scope.uid || '');
  const withUuid = toSupabaseUuid(item.id || `with-${Date.now()}`);

  // 1. Optimistic Local Update immediately
  const all = getStoredJson<FundHistoryItem[]>(STORAGE_KEYS.WITHDRAWALS, []);
  const newItem = {
    ...item,
    amount: safeAmount,
    bankName: safeBankName,
    accountNumber: safeAccount,
    ifscCode: safeIfsc,
    userId: scope.uid,
    userPhone: scope.phone,
    userName: sanitizeText(user.name, 50),
  };
  setStoredJson(STORAGE_KEYS.WITHDRAWALS, [newItem, ...all.filter((w) => w.id !== item.id)]);

  // 2. Direct write into Supabase 'withdrawals' table
  try {
    const { error: wErr } = await supabase.from('withdrawals').insert({
      id: withUuid,
      user_id: userUuid,
      mobile: cleanPhone,
      amount: safeAmount,
      status: 'Pending',
      bank_details: JSON.stringify({
        bankName: safeBankName,
        accountNumber: safeAccount,
        ifsc: safeIfsc,
      }),
    });
    if (wErr) console.warn('[Supabase Error] Direct withdrawals insert failed:', wErr.message);

    // 3. Direct write into Supabase 'transactions' table
    await supabase.from('transactions').insert({
      user_id: userUuid,
      amount: safeAmount,
      type: 'WITHDRAWAL',
      status: 'PENDING',
      payment_gateway: 'Bank Transfer',
    });

    // 4. Direct write into Supabase 'passbook' table
    await supabase.from('passbook').insert({
      user_id: userUuid,
      mobile: cleanPhone,
      type: 'debit',
      amount: safeAmount,
      description: `Withdrawal Request to ${safeBankName} (A/C: ${safeAccount.slice(-4)})`,
      status: 'Pending',
    });
  } catch (err) {
    console.warn('[Supabase Network Failure] Withdrawal insert fell back to local state:', err);
  }
}

// ==========================================
// 3. Deposits Sync ('deposits')
// ==========================================
export function subscribeToDeposits(
  userParam: string | Partial<UserProfile>,
  onUpdate: (deposits: FundHistoryItem[], hasData: boolean) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);
  let isMounted = true;
  const cleanPhone = (scope.phone || '').replace(/\D/g, '');
  const phoneUuid = toSupabaseUuid(cleanPhone);
  const uidUuid = toSupabaseUuid(scope.uid);

  const emitLocal = () => {
    const all = getStoredJson<FundHistoryItem[]>(STORAGE_KEYS.DEPOSITS, []);
    const filtered = all.filter((item) => {
      if (!scope.phone && !scope.uid) return true;
      const itemPhone = (item as any).userPhone || (item as any).phone || '';
      const itemUid = (item as any).userId || (item as any).uid || '';
      return (
        (scope.phone && itemPhone.includes(scope.phone)) ||
        (scope.uid && itemUid === scope.uid) ||
        (!itemPhone && !itemUid)
      );
    });
    if (isMounted) onUpdate(filtered, filtered.length > 0);
  };

  emitLocal();
  const unsubStorage = addStorageListener(STORAGE_KEYS.DEPOSITS, emitLocal);

  // Direct query Supabase 'deposits' table
  const queryDirectDeposits = async () => {
    try {
      let query = supabase.from('deposits').select('*').order('created_at', { ascending: false });
      if (cleanPhone) {
        query = query.or(`mobile.eq.${cleanPhone},user_id.eq.${uidUuid},user_id.eq.${phoneUuid}`);
      } else if (scope.uid) {
        query = query.or(`user_id.eq.${uidUuid}`);
      }
      const { data, error } = await query.limit(50);
      if (error) {
        console.warn('[Supabase Note] Query deposits:', error.message);
        return;
      }
      if (data && isMounted) {
        const items: FundHistoryItem[] = data.map((row) => ({
          id: row.id,
          requestType: 'Add Fund',
          depositMode: 'UPI Instant',
          orderId: `DEP-${String(row.id).slice(-6).toUpperCase()}`,
          utrOrReference: row.utr || '',
          amount: Number(row.amount) || 0,
          status: row.status === 'Success' ? 'Success' : row.status === 'Failure' ? 'Failure' : 'Pending',
          date: row.created_at ? new Date(row.created_at).toLocaleString() : new Date().toLocaleString(),
          userId: row.user_id,
          userPhone: row.mobile,
        }));

        const currentLocal = getStoredJson<FundHistoryItem[]>(STORAGE_KEYS.DEPOSITS, []);
        const merged = [...items];
        for (const loc of currentLocal) {
          if (!merged.some((m) => m.id === loc.id)) {
            merged.push(loc);
          }
        }
        setStoredJson(STORAGE_KEYS.DEPOSITS, merged);
        onUpdate(merged, true);
      }
    } catch (err) {
      console.warn('Network sync for deposits:', err);
    }
  };

  queryDirectDeposits();

  // Realtime subscription on 'deposits' table
  const depChannel = supabase
    .channel(`public:deposits:sync:${cleanPhone || scope.uid || 'all'}`)
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'deposits' },
      () => {
        if (!isMounted) return;
        queryDirectDeposits();
      }
    )
    .subscribe();

  return () => {
    isMounted = false;
    unsubStorage();
    supabase.removeChannel(depChannel);
  };
}

export async function createDepositInFirestore(
  item: FundHistoryItem,
  user: UserProfile,
  bonus: number = 0
): Promise<void> {
  const scope = resolveUserAuthScope(user);
  const cleanPhone = (scope.phone || '').replace(/\D/g, '');
  const cleanAmountResult = sanitizeAmount(item.amount, 1, 500000);
  const safeAmount = cleanAmountResult.isValid ? cleanAmountResult.amount : item.amount;
  const safeBonusResult = sanitizeAmount(bonus, 0, 50000);
  const safeBonus = safeBonusResult.isValid ? safeBonusResult.amount : bonus;
  const safeUtr = item.utrOrReference ? sanitizeUtr(item.utrOrReference).utr : '';
  const totalAmount = safeAmount + safeBonus;
  const userUuid = toSupabaseUuid(cleanPhone || scope.uid || '');
  const depUuid = toSupabaseUuid(item.id || `dep-${Date.now()}`);

  // 1. Optimistic Local Update immediately
  const all = getStoredJson<FundHistoryItem[]>(STORAGE_KEYS.DEPOSITS, []);
  const newItem = {
    ...item,
    amount: safeAmount,
    bonus: safeBonus,
    utrOrReference: safeUtr || item.utrOrReference,
    userId: scope.uid,
    userPhone: scope.phone,
    userName: sanitizeText(user.name, 50),
  };
  setStoredJson(STORAGE_KEYS.DEPOSITS, [newItem, ...all.filter((d) => d.id !== item.id)]);

  // 2. Direct write into Supabase 'deposits' table
  try {
    const { error: dErr } = await supabase.from('deposits').insert({
      id: depUuid,
      user_id: userUuid,
      mobile: cleanPhone,
      amount: totalAmount,
      status: item.status === 'Pending' ? 'Pending' : 'Success',
      utr: safeUtr || item.utrOrReference || `RAMA-${Date.now()}`,
    });
    if (dErr) console.warn('[Supabase Error] Direct deposits insert failed:', dErr.message);

    // 3. Direct write into Supabase 'transactions' table
    await supabase.from('transactions').insert({
      user_id: userUuid,
      amount: totalAmount,
      type: 'DEPOSIT',
      status: item.status === 'Pending' ? 'PENDING' : 'SUCCESS',
      payment_gateway: item.depositMode || 'UPI',
    });

    // 4. Direct write into Supabase 'passbook' table
    await supabase.from('passbook').insert({
      user_id: userUuid,
      mobile: cleanPhone,
      type: 'credit',
      amount: totalAmount,
      description: `Instant Wallet Topup via ${item.depositMode || 'UPI'} | UTR: ${safeUtr || item.utrOrReference || 'N/A'}`,
      status: item.status === 'Pending' ? 'Pending' : 'SUCCESS',
    });
  } catch (err) {
    console.warn('[Supabase Network Failure] Deposit insert fell back to local state:', err);
  }
}

// ==========================================
// 4. Passbook Transactions Sync with Plain Direct CRUD & Realtime
// ==========================================
export function subscribeToTransactions(
  userParam: string | Partial<UserProfile>,
  onUpdate: (transactions: Transaction[], hasData: boolean) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);
  let isMounted = true;

  // 1. Optimistic Local State Fetch
  const emitLocal = () => {
    const all = getStoredJson<Transaction[]>(STORAGE_KEYS.TRANSACTIONS, []);
    const filtered = all.filter((tx) => {
      if (!scope.phone && !scope.uid) return true;
      const txUid = (tx as any).userId || (tx as any).uid || '';
      const txPhone = (tx as any).userPhone || (tx as any).phone || '';
      return (
        (scope.phone && txPhone.includes(scope.phone)) ||
        (scope.uid && txUid === scope.uid) ||
        (!txUid && !txPhone)
      );
    });
    if (isMounted) {
      onUpdate(filtered, filtered.length > 0);
    }
  };

  emitLocal();
  const unsubStorage = addStorageListener(STORAGE_KEYS.TRANSACTIONS, emitLocal);

  // 2. Direct plain query on Supabase 'transactions' and 'passbook' tables without auth checks
  const queryDirectTransactions = async () => {
    try {
      const [{ data: txData, error: txError }, { data: pbData }] = await Promise.all([
        supabase
          .from('transactions')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(50),
        supabase
          .from('passbook')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(50),
      ]);

      if (txError && !pbData) {
        console.error('[Supabase Error] Query transactions failed:', txError.message);
        return;
      }

      const items: Transaction[] = [];

      // Process passbook entries
      if (pbData && isMounted) {
        for (const row of pbData) {
          if (!row.user_id || row.user_id === '00000000-0000-0000-0000-000000000000' || isMatchingUser(row.user_id, scope, row.mobile)) {
            const isDebit = String(row.type).toLowerCase() === 'debit';
            items.push({
              id: row.id || `pb-${Date.now()}`,
              referenceId: row.id ? `PB-${String(row.id).slice(-8).toUpperCase()}` : `PB-${Date.now()}`,
              title: isDebit ? 'Debit | ' + (row.description || 'Transaction') : 'Credit | ' + (row.description || 'Deposit / Win'),
              description: row.description || (isDebit ? 'Debited from wallet' : 'Credited to wallet'),
              amount: Number(row.amount) || 0,
              type: isDebit ? 'debit' : 'credit',
              status: row.status === 'SUCCESS' ? 'SUCCESS' : row.status === 'FAILED' ? 'FAILED' : 'PENDING',
              date: row.created_at ? new Date(row.created_at).toLocaleString() : new Date().toLocaleString(),
              previousBalance: 0,
              currentBalance: Number(row.amount) || 0,
            });
          }
        }
      }

      // Process transaction entries
      if (txData && isMounted) {
        for (const row of txData) {
          if (!row.user_id || row.user_id === '00000000-0000-0000-0000-000000000000' || isMatchingUser(row.user_id, scope)) {
            const isDebit =
              String(row.type).toUpperCase().includes('WITHDRAW') ||
              String(row.type).toUpperCase().includes('DEBIT') ||
              String(row.type).toUpperCase().includes('BET');
            // Deduplicate if already present
            if (!items.some((i) => i.id === row.id)) {
              items.push({
                id: row.id || `tx-${Date.now()}`,
                referenceId: row.id ? `TXN-${String(row.id).slice(-8).toUpperCase()}` : `TXN-${Date.now()}`,
                title: `${row.type || 'Transaction'} | ₹${row.amount}`,
                description: `Gateway: ${row.payment_gateway || 'UPI'} - Status: ${row.status || 'SUCCESS'}`,
                amount: Number(row.amount) || 0,
                type: isDebit ? 'debit' : 'credit',
                status: row.status === 'SUCCESS' ? 'SUCCESS' : row.status === 'FAILED' ? 'FAILED' : 'PENDING',
                date: row.created_at ? new Date(row.created_at).toLocaleString() : new Date().toLocaleString(),
                previousBalance: 0,
                currentBalance: Number(row.amount) || 0,
              });
            }
          }
        }
      }

      if (items.length > 0 && isMounted) {
        const currentLocal = getStoredJson<Transaction[]>(STORAGE_KEYS.TRANSACTIONS, []);
        const merged = [...items];
        for (const loc of currentLocal) {
          if (!merged.some((m) => m.id === loc.id)) {
            merged.push(loc);
          }
        }
        setStoredJson(STORAGE_KEYS.TRANSACTIONS, merged);
        onUpdate(merged, true);
      }
    } catch (err) {
      console.error('[Supabase Network Failure] Failed fetching transactions/passbook:', err);
    }
  };

  queryDirectTransactions();

  // 3. Realtime Subscription on both 'transactions' and 'passbook' tables
  const channel = supabase
    .channel('public:transactions_passbook:realtime')
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'transactions' },
      () => {
        if (!isMounted) return;
        queryDirectTransactions();
      }
    )
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'passbook' },
      () => {
        if (!isMounted) return;
        queryDirectTransactions();
      }
    )
    .subscribe();

  return () => {
    isMounted = false;
    unsubStorage();
    supabase.removeChannel(channel);
  };
}

export async function recordTransactionInFirestore(
  tx: Transaction,
  userParam: string | Partial<UserProfile>
): Promise<void> {
  const scope = resolveUserAuthScope(userParam);
  const txId = tx.referenceId || tx.id;

  // 1. Optimistic Local Update immediately
  const all = getStoredJson<Transaction[]>(STORAGE_KEYS.TRANSACTIONS, []);
  const newTx = { ...tx, userId: scope.uid, userPhone: scope.phone };
  setStoredJson(STORAGE_KEYS.TRANSACTIONS, [newTx, ...all.filter((t) => t.id !== tx.id)]);

  // 2. Direct plain insert into Supabase 'transactions' table without auth checks
  try {
    const userUuid = toSupabaseUuid(scope.uid || scope.phone || '00000000-0000-0000-0000-000000000000');
    const { error } = await supabase.from('transactions').insert({
      user_id: userUuid,
      amount: tx.amount,
      type: tx.type === 'debit' ? 'BET_OR_WITHDRAWAL' : 'DEPOSIT',
      status: tx.status === 'SUCCESS' ? 'SUCCESS' : tx.status === 'FAILED' ? 'FAILED' : 'PENDING',
      payment_gateway: 'RAMA_WALLET',
    });
    if (error) {
      console.error('[Supabase Error] Direct recordTransaction failed:', error.message, error.details);
    }
  } catch (err) {
    console.error('[Supabase Network Failure] Transaction record fell back to local state:', err);
  }
}

// ==========================================
// 5. Game Bids & Win History with Plain Direct CRUD & Realtime
// ==========================================
export function subscribeToBids(
  userParam: string | Partial<UserProfile>,
  onUpdate: (bids: GameBid[], hasData: boolean) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);
  let isMounted = true;

  // 1. Optimistic Local State Fetch
  const emitLocal = () => {
    const all = getStoredJson<GameBid[]>(STORAGE_KEYS.BIDS, []);
    const filtered = all.filter((bid) => {
      if (!scope.phone && !scope.uid) return true;
      const bidUid = (bid as any).userId || (bid as any).uid || '';
      const bidPhone = (bid as any).userPhone || (bid as any).phone || '';
      return (
        (scope.phone && bidPhone.includes(scope.phone)) ||
        (scope.uid && bidUid === scope.uid) ||
        (!bidUid && !bidPhone)
      );
    });
    if (isMounted) {
      onUpdate(filtered, filtered.length > 0);
    }
  };

  emitLocal();
  const unsubStorage = addStorageListener(STORAGE_KEYS.BIDS, emitLocal);

  // 2. Direct plain query on Supabase 'bids' table and 'markets' table without auth checks
  const queryDirectBids = async () => {
    try {
      const [{ data: bidsData, error: bidsError }, { data: marketsData }] = await Promise.all([
        supabase
          .from('bids')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(100),
        supabase
          .from('markets')
          .select('id, name'),
      ]);

      if (bidsError) {
        console.error('[Supabase Error] Direct query bids failed:', bidsError.message, bidsError.details);
        return; // Retains optimistic local state
      }

      if (bidsData && isMounted) {
        // Build comprehensive ID-to-Market-Name lookup map
        const marketNameMap = new Map<string, string>();

        // 1. Static Initial markets mapping
        for (const m of INITIAL_MARKETS) {
          if (m.id && m.name) {
            marketNameMap.set(m.id.toLowerCase(), m.name);
            marketNameMap.set(toSupabaseUuid(m.id), m.name);
            marketNameMap.set(toSupabaseUuid(m.name), m.name);
            marketNameMap.set(toSupabaseUuid(m.name.toLowerCase()), m.name);
          }
        }

        // 2. Dynamic Supabase markets mapping
        if (marketsData) {
          for (const m of marketsData) {
            if (m.id && m.name) {
              marketNameMap.set(m.id, m.name);
              marketNameMap.set(m.id.toLowerCase(), m.name);
              marketNameMap.set(toSupabaseUuid(m.id), m.name);
              marketNameMap.set(toSupabaseUuid(m.name), m.name);
              marketNameMap.set(toSupabaseUuid(m.name.toLowerCase()), m.name);
            }
          }
        }

        // 3. Local stored markets fallback
        const localMarkets = getStoredJson<MarketItem[]>(STORAGE_KEYS.MARKETS, []);
        for (const m of localMarkets) {
          if (m.id && m.name) {
            marketNameMap.set(m.id, m.name);
            marketNameMap.set(toSupabaseUuid(m.id), m.name);
          }
        }

        const resolveMarketName = (marketId: string | undefined, localFallback?: string): string => {
          if (!marketId && localFallback && localFallback !== 'Matka Market') return localFallback;
          if (!marketId) return localFallback || 'Kalyan';

          if (marketNameMap.has(marketId)) return marketNameMap.get(marketId)!;
          if (marketNameMap.has(marketId.toLowerCase())) return marketNameMap.get(marketId.toLowerCase())!;

          // Match by UUID hash
          for (const [key, val] of marketNameMap.entries()) {
            if (key === marketId || toSupabaseUuid(key) === marketId) {
              return val;
            }
          }

          if (localFallback && localFallback !== 'Matka Market') return localFallback;
          return 'Kalyan';
        };

        const localBids = getStoredJson<GameBid[]>(STORAGE_KEYS.BIDS, []);
        const localBidMap = new Map<string, GameBid>();
        for (const lb of localBids) {
          if (lb.id) localBidMap.set(lb.id, lb);
        }

        const items: GameBid[] = bidsData
          .filter((row) => !row.user_id || row.user_id === '00000000-0000-0000-0000-000000000000' || isMatchingUser(row.user_id, scope))
          .map((row) => {
            const local = localBidMap.get(row.id);
            const mName = resolveMarketName(row.market_id, local?.marketName);
            const gType = row.game_type || local?.gameType || 'Single Digit';
            const mult = getGameMultiplier(gType);
            const rawStatus = String(row.status || '').toUpperCase();
            const isWon = rawStatus === 'WON' || rawStatus === 'WIN' || local?.status === 'Won';
            const isLost = rawStatus === 'LOST' || local?.status === 'Lost';
            const status: 'Placed' | 'Won' | 'Lost' = isWon ? 'Won' : isLost ? 'Lost' : 'Placed';
            const points = Number(row.points) || local?.points || 0;
            const winAmount = isWon ? (local?.winAmount || points * mult) : undefined;

            return {
              id: row.id,
              marketId: row.market_id,
              marketName: mName,
              gameType: gType,
              session: (local?.session as any) || 'Open',
              digitOrPana: String(row.digits ?? local?.digitOrPana ?? ''),
              points,
              date: row.created_at ? new Date(row.created_at).toLocaleString() : local?.date || 'Recent',
              status,
              winAmount,
            };
          });

        if (items.length > 0) {
          const currentLocal = getStoredJson<GameBid[]>(STORAGE_KEYS.BIDS, []);
          const merged = [...items];
          for (const loc of currentLocal) {
            if (!merged.some((m) => m.id === loc.id)) {
              merged.push(loc);
            }
          }
          setStoredJson(STORAGE_KEYS.BIDS, merged);
          onUpdate(merged, true);
        }
      }
    } catch (err) {
      console.error('[Supabase Network Failure] Direct bids query error:', err);
    }
  };

  queryDirectBids();

  // 3. Realtime Subscription on 'bids' table
  const channel = supabase
    .channel('public:bids:realtime')
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'bids' },
      (payload) => {
        if (!isMounted) return;
        console.log('[Supabase Realtime] Bids table event:', payload.eventType);
        queryDirectBids();
      }
    )
    .subscribe();

  return () => {
    isMounted = false;
    unsubStorage();
    supabase.removeChannel(channel);
  };
}

export async function placeBidInFirestore(
  bid: Omit<GameBid, 'id' | 'date' | 'status'>,
  user: UserProfile
): Promise<string> {
  const scope = resolveUserAuthScope(user);
  const now = new Date();
  const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
    .toString()
    .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  })}`;
  const bidId = `bid-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const cleanPointsResult = sanitizeAmount(bid.points, 1, 100000);
  const safePoints = cleanPointsResult.isValid ? cleanPointsResult.amount : bid.points;

  // 1. Optimistic Local Update immediately
  const newBid: GameBid = {
    ...bid,
    marketName: sanitizeText(bid.marketName, 50),
    gameType: sanitizeText(bid.gameType, 50),
    digitOrPana: sanitizeText(bid.digitOrPana, 10),
    points: safePoints,
    id: bidId,
    date: dateStr,
    status: 'Placed',
    userId: scope.uid,
    userPhone: scope.phone,
    userName: sanitizeText(user.name, 50),
  } as any;

  const all = getStoredJson<GameBid[]>(STORAGE_KEYS.BIDS, []);
  setStoredJson(STORAGE_KEYS.BIDS, [newBid, ...all]);

  // Keep backward-compatible settlement cache updated
  try {
    const rawV2 = localStorage.getItem('rama777_game_bids_v2');
    const listV2 = rawV2 ? JSON.parse(rawV2) : [];
    localStorage.setItem('rama777_game_bids_v2', JSON.stringify([newBid, ...listV2]));
  } catch (e) {
    // ignore
  }

  // 2. Direct plain insert into Supabase 'bids' table without auth checks
  try {
    const userUuid = toSupabaseUuid(scope.uid || scope.phone || '00000000-0000-0000-0000-000000000000');
    let targetMarketId = (bid as any).marketId;
    let marketUuid = '00000000-0000-0000-0000-000000000000';
    if (targetMarketId && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(targetMarketId)) {
      marketUuid = targetMarketId;
    } else {
      marketUuid = toSupabaseUuid(targetMarketId || bid.marketName || 'kalyan');
    }

    const { error } = await supabase.from('bids').insert({
      user_id: userUuid,
      market_id: marketUuid,
      game_type: sanitizeText(bid.gameType, 50),
      digits: sanitizeText(bid.digitOrPana, 10),
      points: safePoints,
      status: 'PENDING',
    });

    if (error) {
      console.error('[Supabase Error] Direct placeBid failed:', error.message, error.details);
    }
  } catch (err) {
    console.error('[Supabase Network Failure] Place bid fell back to optimistic local state:', err);
  }

  return bidId;
}

// ==========================================
// 6. Payment Gateway Config
// ==========================================
export function subscribeToPaymentGateway(
  onUpdate: (config: PaymentGatewayConfig) => void
): () => void {
  const readData = () => {
    const cfg = getStoredJson<PaymentGatewayConfig>(STORAGE_KEYS.GATEWAY, DEFAULT_GATEWAY_CONFIG);
    onUpdate(cfg);
  };
  readData();
  return addStorageListener(STORAGE_KEYS.GATEWAY, readData);
}

export async function updatePaymentGatewayConfig(
  config: Partial<PaymentGatewayConfig>
): Promise<void> {
  const current = getStoredJson<PaymentGatewayConfig>(STORAGE_KEYS.GATEWAY, DEFAULT_GATEWAY_CONFIG);
  const updated = { ...current, ...config, updatedAt: new Date().toISOString() };
  setStoredJson(STORAGE_KEYS.GATEWAY, updated);
}

// ==========================================
// 7. Bank Accounts
// ==========================================
export function subscribeToBankAccounts(
  userParam: string | Partial<UserProfile>,
  onUpdate: (banks: BankAccount[], hasData: boolean) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);
  const readData = () => {
    const all = getStoredJson<BankAccount[]>(STORAGE_KEYS.BANKS, []);
    const filtered = all.filter((b) => {
      if (!scope.phone && !scope.uid) return true;
      const bUid = (b as any).userId || (b as any).uid || '';
      const bPhone = (b as any).userPhone || (b as any).phone || '';
      return (
        (scope.phone && bPhone.includes(scope.phone)) ||
        (scope.uid && bUid === scope.uid) ||
        (!bUid && !bPhone)
      );
    });
    onUpdate(filtered, filtered.length > 0);
  };
  readData();
  return addStorageListener(STORAGE_KEYS.BANKS, readData);
}

export async function addBankAccountToFirestore(
  bank: Omit<BankAccount, 'id' | 'updatedAt'>,
  user: UserProfile
): Promise<void> {
  const scope = resolveUserAuthScope(user);
  const now = new Date();
  const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
    .toString()
    .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  })}`;
  const lockDate = new Date();
  lockDate.setDate(lockDate.getDate() + 30);
  const lockDateStr = `${lockDate.getDate().toString().padStart(2, '0')}/${(lockDate.getMonth() + 1)
    .toString()
    .padStart(2, '0')}/${lockDate.getFullYear()}`;

  const cleanAccount = sanitizeBankAccount(bank.accountNumber).accountNumber || bank.accountNumber;
  const cleanIfsc = sanitizeIfsc(bank.ifscCode).ifsc || bank.ifscCode;
  const cleanHolder = sanitizeText(bank.accountHolder, 60);
  const cleanBankName = sanitizeText(bank.bankName, 60);

  const newBank: BankAccount = {
    ...bank,
    accountHolder: cleanHolder,
    bankName: cleanBankName,
    accountNumber: cleanAccount,
    ifscCode: cleanIfsc,
    id: `bank-${Date.now()}`,
    updatedAt: dateStr,
    lockUntil: lockDateStr,
    status: bank.status || 'Success',
    userId: scope.uid,
    userPhone: scope.phone,
  } as any;

  const all = getStoredJson<BankAccount[]>(STORAGE_KEYS.BANKS, []);
  setStoredJson(STORAGE_KEYS.BANKS, [newBank, ...all]);
}

// ==========================================
// 8. Notifications with Supabase Real-Time Channel & Tables
// ==========================================
export function subscribeToNotifications(
  userParam: string | Partial<UserProfile>,
  onUpdate: (notifications: AppNotification[], hasData: boolean) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);
  let isMounted = true;

  // 1. Initial Local Cache Load
  const emitLocal = () => {
    const all = getStoredJson<AppNotification[]>(STORAGE_KEYS.NOTIFICATIONS, [
      {
        id: 'n-1',
        title: 'Welcome to RAMA777!',
        message: 'Fast & secure mobile Matka platform powered by Supabase. Enjoy instant withdrawals and 24/7 support.',
        time: 'Just now',
        read: false,
        type: 'bonus',
      },
      {
        id: 'n-2',
        title: 'Kalyan Market Bids Open',
        message: 'Kalyan Day is running for Open bids until 04:15 PM. Place your lucky digit bids now!',
        time: '1h ago',
        read: false,
        type: 'bid',
      },
    ]);
    const filtered = all.filter((n) => {
      const target = (n as any).targetPhone;
      if (!target || target === 'all') return true;
      return scope.phone && target.includes(scope.phone);
    });
    if (isMounted) {
      onUpdate(filtered, filtered.length > 0);
    }
  };

  emitLocal();
  const unsubStorage = addStorageListener(STORAGE_KEYS.NOTIFICATIONS, emitLocal);

  // 2. Direct Query Supabase 'notifications' table if available
  const querySupabaseNotifications = async () => {
    try {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (!error && data && data.length > 0 && isMounted) {
        const remoteItems: AppNotification[] = data.map((row) => ({
          id: String(row.id || `notif-${Date.now()}`),
          title: String(row.title || 'Notice'),
          message: String(row.message || row.description || ''),
          time: row.created_at ? new Date(row.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Just now',
          read: Boolean(row.read || false),
          type: (row.type || 'alert') as any,
          targetPhone: row.target_phone || row.targetPhone || 'all',
        } as any));

        const currentLocal = getStoredJson<AppNotification[]>(STORAGE_KEYS.NOTIFICATIONS, []);
        const merged = [...remoteItems];
        for (const loc of currentLocal) {
          if (!merged.some((m) => m.id === loc.id)) {
            merged.push(loc);
          }
        }
        setStoredJson(STORAGE_KEYS.NOTIFICATIONS, merged);
      }
    } catch (err) {
      // Table doesn't exist yet or offline; fallback to realtime broadcast channel
    }
  };

  querySupabaseNotifications();

  // 3. Realtime Supabase Channel listening to both postgres_changes and live broadcast events
  const channel = supabase
    .channel('public:notifications')
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'notifications' },
      async (payload) => {
        if (!isMounted) return;
        console.log('[Supabase Realtime] notifications table event:', payload.eventType);
        querySupabaseNotifications();
      }
    )
    .on('broadcast', { event: 'admin_notification' }, (payload) => {
      if (!isMounted || !payload?.payload) return;
      console.log('[Supabase Realtime] Received live admin broadcast notification:', payload.payload);
      const incoming = payload.payload;
      const newNotif: AppNotification = {
        id: incoming.id || `notif-${Date.now()}`,
        title: incoming.title || 'Admin Announcement',
        message: incoming.message || '',
        time: 'Just now',
        read: false,
        type: incoming.type || 'alert',
        targetPhone: incoming.targetPhone || 'all',
      } as any;

      const current = getStoredJson<AppNotification[]>(STORAGE_KEYS.NOTIFICATIONS, []);
      if (!current.some((n) => n.id === newNotif.id)) {
        const updated = [newNotif, ...current];
        setStoredJson(STORAGE_KEYS.NOTIFICATIONS, updated);
      }
    })
    .subscribe((status) => {
      console.log('[Supabase Realtime] notifications channel status:', status);
    });

  return () => {
    isMounted = false;
    unsubStorage();
    supabase.removeChannel(channel);
  };
}

export async function broadcastNotificationInFirestore(
  notif: Omit<AppNotification, 'id'> & { id?: string; targetPhone?: string }
): Promise<void> {
  const notifId = notif.id || `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
  const newNotif: AppNotification = {
    ...notif,
    id: notifId,
    read: false,
  };

  // 1. Optimistic Local Cache Update
  const all = getStoredJson<AppNotification[]>(STORAGE_KEYS.NOTIFICATIONS, []);
  setStoredJson(STORAGE_KEYS.NOTIFICATIONS, [newNotif, ...all]);

  // 2. Direct Insert into Supabase 'notifications' table (if table exists)
  try {
    await supabase.from('notifications').insert({
      id: notifId,
      title: notif.title,
      message: notif.message,
      type: notif.type || 'alert',
      target_phone: notif.targetPhone || 'all',
      read: false,
      created_at: new Date().toISOString(),
    });
  } catch (err) {
    // Continue to broadcast channel
  }

  // 3. Broadcast dynamically through Supabase Realtime channel so all connected players see it immediately
  try {
    const channel = supabase.channel('public:notifications');
    await channel.send({
      type: 'broadcast',
      event: 'admin_notification',
      payload: newNotif,
    });
  } catch (err) {
    console.error('[Supabase Error] Broadcast notification error:', err);
  }
}

export async function seedInitialDataToFirestore(): Promise<void> {
  // Pure local storage operation - no-op
}

// ==========================================
// 9. Admin Direct Supabase Management Functions
// ==========================================

export async function fetchAdminUsers(): Promise<any[]> {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) {
      console.warn('[Supabase Error] fetchAdminUsers failed:', error.message);
      return [];
    }
    return data || [];
  } catch (e) {
    return [];
  }
}

export async function updateUserWalletInSupabase(
  userId: string,
  mobile: string,
  newBalance: number,
  delta: number,
  reason: string = 'Admin Adjustment'
): Promise<boolean> {
  try {
    const cleanPhone = (mobile || '').replace(/\D/g, '');
    const userUuid = toSupabaseUuid(cleanPhone || userId);

    // 1. Update users table
    const { error: uErr } = await supabase
      .from('users')
      .update({
        main_wallet: newBalance,
        gaming_wallet: newBalance,
      })
      .or(`id.eq.${userUuid},mobile.eq.${cleanPhone}`);
    if (uErr) console.warn('[Supabase Note] updateUserWallet error:', uErr.message);

    // 2. Insert into transactions table
    await supabase.from('transactions').insert({
      user_id: userUuid,
      amount: Math.abs(delta),
      type: delta >= 0 ? 'ADMIN_CREDIT' : 'ADMIN_DEBIT',
      status: 'SUCCESS',
      payment_gateway: 'ADMIN',
    });

    // 3. Insert into passbook table
    await supabase.from('passbook').insert({
      user_id: userUuid,
      mobile: cleanPhone,
      type: delta >= 0 ? 'credit' : 'debit',
      amount: Math.abs(delta),
      description: `${reason} | Balance set to ₹${newBalance}`,
      status: 'SUCCESS',
    });

    return true;
  } catch (e) {
    return false;
  }
}

export async function fetchAdminDeposits(): Promise<any[]> {
  try {
    const { data, error } = await supabase
      .from('deposits')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100);
    if (error) {
      console.warn('[Supabase Error] fetchAdminDeposits failed:', error.message);
      return [];
    }
    return data || [];
  } catch (e) {
    return [];
  }
}

export async function updateDepositStatusInSupabase(
  depositId: string,
  status: 'Success' | 'Failure',
  mobile: string,
  amount: number
): Promise<boolean> {
  try {
    const cleanPhone = (mobile || '').replace(/\D/g, '');
    const userUuid = toSupabaseUuid(cleanPhone);

    // 1. Update deposits table
    await supabase
      .from('deposits')
      .update({ status })
      .eq('id', depositId);

    // 2. If approved, credit user's main wallet in users table
    if (status === 'Success' && cleanPhone) {
      const { data: userRow } = await supabase
        .from('users')
        .select('main_wallet')
        .or(`id.eq.${userUuid},mobile.eq.${cleanPhone}`)
        .maybeSingle();

      const currentMain = Number(userRow?.main_wallet || 0);
      const newBal = currentMain + amount;

      await supabase
        .from('users')
        .update({
          main_wallet: newBal,
          gaming_wallet: newBal,
        })
        .or(`id.eq.${userUuid},mobile.eq.${cleanPhone}`);

      // 3. Log in passbook
      await supabase.from('passbook').insert({
        user_id: userUuid,
        mobile: cleanPhone,
        type: 'credit',
        amount: amount,
        description: `Deposit Approved by Admin (ID: ${depositId.slice(0, 8)})`,
        status: 'SUCCESS',
      });

      // 4. Update transaction
      await supabase.from('transactions').insert({
        user_id: userUuid,
        amount: amount,
        type: 'DEPOSIT',
        status: 'SUCCESS',
        payment_gateway: 'ADMIN_APPROVED',
      });
    }

    return true;
  } catch (e) {
    return false;
  }
}

export async function fetchAdminWithdrawals(): Promise<any[]> {
  try {
    const { data, error } = await supabase
      .from('withdrawals')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100);
    if (error) {
      console.warn('[Supabase Error] fetchAdminWithdrawals failed:', error.message);
      return [];
    }
    return data || [];
  } catch (e) {
    return [];
  }
}

export async function updateWithdrawalStatusInSupabase(
  withdrawalId: string,
  status: 'Success' | 'Failure' | 'Approved' | 'Rejected',
  mobile: string,
  amount: number
): Promise<boolean> {
  try {
    const cleanPhone = (mobile || '').replace(/\D/g, '');
    const userUuid = toSupabaseUuid(cleanPhone);
    const isApproved =
      status === 'Success' || status === 'Approved' || String(status).toLowerCase() === 'approved';
    const dbStatus = isApproved ? 'APPROVED' : 'REJECTED';
    const normalizedStatus: 'Success' | 'Failure' = isApproved ? 'Success' : 'Failure';

    console.log(`[Admin Panel] Updating withdrawal ID ${withdrawalId} to ${dbStatus} (${normalizedStatus})`);

    // 1. Direct update to Supabase 'withdrawals' table
    const { error: updErr } = await supabase
      .from('withdrawals')
      .update({
        status: dbStatus,
      })
      .eq('id', withdrawalId);

    if (updErr) {
      console.warn('[Supabase Error] update withdrawal failed:', updErr.message);
      // Fallback matching
      await supabase
        .from('withdrawals')
        .update({ status: dbStatus })
        .match({ id: withdrawalId });
    }

    // 2. Immediately update local storage cache for instant reflection
    if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
      const currentWithdrawals = getStoredJson<FundHistoryItem[]>(STORAGE_KEYS.WITHDRAWALS, []);
      const updatedWithdrawals = currentWithdrawals.map((w) => {
        if (w.id === withdrawalId || (w.orderId && withdrawalId.includes(w.orderId.replace(/\D/g, '')))) {
          return {
            ...w,
            status: normalizedStatus,
          };
        }
        return w;
      });
      setStoredJson(STORAGE_KEYS.WITHDRAWALS, updatedWithdrawals);

      // 3. Dispatch in-app custom event and storage event for zero-delay cross-component update
      window.dispatchEvent(
        new CustomEvent('rama777:withdrawal_updated', {
          detail: { withdrawalId, status: normalizedStatus, dbStatus, mobile, amount },
        })
      );
      window.dispatchEvent(new StorageEvent('storage', { key: STORAGE_KEYS.WITHDRAWALS }));
    }

    // 4. Update transactions table in Supabase if exists
    try {
      await supabase
        .from('transactions')
        .update({ status: isApproved ? 'SUCCESS' : 'FAILED' })
        .eq('user_id', userUuid)
        .eq('amount', amount)
        .eq('status', 'PENDING');
    } catch {}

    // 5. If rejected, refund user's wallet
    if (!isApproved && cleanPhone) {
      const { data: userRow } = await supabase
        .from('users')
        .select('main_wallet')
        .or(`id.eq.${userUuid},mobile.eq.${cleanPhone}`)
        .maybeSingle();

      const currentMain = Number(userRow?.main_wallet || 0);
      const newBal = currentMain + amount;

      await supabase
        .from('users')
        .update({
          main_wallet: newBal,
          gaming_wallet: newBal,
        })
        .or(`id.eq.${userUuid},mobile.eq.${cleanPhone}`);

      // Log refund
      await supabase.from('passbook').insert({
        user_id: userUuid,
        mobile: cleanPhone,
        type: 'credit',
        amount: amount,
        description: `Withdrawal Rejected - Refund to Wallet (ID: ${withdrawalId.slice(0, 8)})`,
        status: 'SUCCESS',
      });
    } else if (isApproved) {
      // Log paid in passbook
      await supabase.from('passbook').insert({
        user_id: userUuid,
        mobile: cleanPhone,
        type: 'debit',
        amount: amount,
        description: `Withdrawal Processed & Paid (ID: ${withdrawalId.slice(0, 8)})`,
        status: 'SUCCESS',
      });
    }

    return true;
  } catch (e) {
    console.error('Failed to update withdrawal status:', e);
    return false;
  }
}

export async function fetchAdminAgents(): Promise<any[]> {
  try {
    const { data, error } = await supabase
      .from('agents')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) {
      console.warn('[Supabase Error] fetchAdminAgents failed:', error.message);
      return [];
    }
    return data || [];
  } catch (e) {
    return [];
  }
}

export async function createAgentInSupabase(agent: {
  name: string;
  mobile: string;
  commission_rate: number;
  status?: string;
}): Promise<boolean> {
  try {
    const { error } = await supabase.from('agents').insert({
      name: agent.name,
      mobile: agent.mobile,
      commission_rate: agent.commission_rate,
      status: agent.status || 'Active',
    });
    if (error) throw error;
    return true;
  } catch (e) {
    return false;
  }
}

export async function updateAgentInSupabase(
  agentId: string,
  updates: Partial<{ commission_rate: number; status: string; name: string }>
): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('agents')
      .update(updates)
      .eq('id', agentId);
    if (error) throw error;
    return true;
  } catch (e) {
    return false;
  }
}
