import React, { useState } from 'react';
import { Menu, Bell, Wallet, Crown, ShieldCheck } from 'lucide-react';
import { MainTab, UserRole } from '../types';

interface HeaderProps {
  currentTab: MainTab;
  walletBalance: number;
  unreadNotificationsCount: number;
  userRole?: UserRole;
  onOpenDrawer: () => void;
  onOpenNotifications: () => void;
  onNavigateToFunds: () => void;
  onOpenAdminHub?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  walletBalance,
  unreadNotificationsCount,
  userRole,
  onOpenDrawer,
  onOpenNotifications,
  onNavigateToFunds,
  onOpenAdminHub,
}) => {
  const getTabTitle = () => {
    switch (currentTab) {
      case 'history':
        return 'History';
      case 'passbook':
        return 'Passbook';
      case 'funds':
        return 'Funds';
      case 'support':
        return 'Support';
      default:
        return null;
    }
  };

  const title = getTabTitle();

  return (
    <header
      style={{ flexShrink: 0 }}
      className="shrink-0 z-30 bg-[#0c0d14] border-b border-zinc-800/80 px-4 py-3 flex items-center justify-between text-white transition-colors shadow-md shadow-black/40"
    >
      {/* Left: Hamburger Menu and Title or Logo */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenDrawer}
          className="w-10 h-10 rounded-xl flex items-center justify-center text-zinc-200 hover:bg-zinc-800/80 active:scale-95 transition-all cursor-pointer"
          aria-label="Open menu"
        >
          <Menu className="w-6 h-6" />
        </button>

        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#E65100] to-[#FF7700] flex items-center justify-center shadow-md shadow-orange-600/30">
            <span className="text-white font-extrabold text-base tracking-tighter">R</span>
          </div>
          <div>
            <span className="text-lg font-black tracking-tight text-[#FF7700] block leading-none">
              RAMA777
            </span>
            {title && (
              <span className="text-[10px] font-bold text-amber-400/90 block leading-none mt-0.5 uppercase tracking-wider">
                {title}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Right: Admin Shortcut (if admin), Wallet Balance Pill & Bell Notification Icon */}
      <div className="flex items-center gap-2">
        {userRole === 'admin' && onOpenAdminHub && (
          <button
            onClick={onOpenAdminHub}
            className="bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 border border-amber-500/50 rounded-full px-2.5 py-1 flex items-center gap-1 transition-all cursor-pointer active:scale-95 shadow-xs"
            title="Open Admin Control Hub"
          >
            <Crown className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[10px] font-black uppercase tracking-wider font-mono">
              ADMIN
            </span>
          </button>
        )}

        <button
          onClick={onNavigateToFunds}
          className="bg-[#151722] hover:bg-[#1c1f2e] border border-orange-500/30 hover:border-orange-500/60 rounded-full px-3 py-1 flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-xs"
          title="View Wallet Funds (Protected with 256-Bit Encrypted Storage & Signed Token)"
        >
          <div className="flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-emerald-400 shrink-0" />
            <Wallet className="w-3.5 h-3.5 text-[#FF7700] shrink-0" />
          </div>
          <span className="text-xs font-black text-amber-300 font-mono tracking-tight">
            ₹{Number(walletBalance || 0).toFixed(2)}
          </span>
        </button>

        <button
          onClick={onOpenNotifications}
          className="relative w-10 h-10 rounded-xl flex items-center justify-center text-zinc-200 hover:bg-zinc-800/80 active:scale-95 transition-all cursor-pointer"
          aria-label="Notifications"
        >
          <Bell className="w-5 h-5" />
          {unreadNotificationsCount > 0 && (
            <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-[#FF7700] ring-2 ring-[#0c0d14]" />
          )}
        </button>
      </div>
    </header>
  );
};
