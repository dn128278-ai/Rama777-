import React, { useState, useEffect, useRef } from 'react';
import { LoginScreen } from './components/LoginScreen';
import { RegisterScreen } from './components/RegisterScreen';
import { Header } from './components/Header';
import { BottomNavBar } from './components/BottomNavBar';
import { SideDrawer } from './components/SideDrawer';
import { HomeTab } from './components/HomeTab';
import { HistoryTab } from './components/HistoryTab';
import { PassbookTab } from './components/PassbookTab';
import { FundsTab } from './components/FundsTab';
import { SupportTab } from './components/SupportTab';
import { GamePlayView } from './components/GamePlayView';
import { ChartsView } from './components/ChartsView';
import { ChangeMpinModal } from './components/ChangeMpinModal';
import { GameRatesModal } from './components/GameRatesModal';
import { StarlineJackpotModal } from './components/StarlineJackpotModal';
import { ResultManagementModal } from './components/ResultManagementModal';
import { AdminPanelModal } from './components/AdminPanelModal';
import { getActiveSession, clearSession, persistSession } from './services/authService';
import {
  NotificationsModal,
  HowToPlayModal,
  SubmitIdeasModal,
  SettingsModal,
  LanguageModal,
} from './components/SecondaryModals';
import {
  INITIAL_USER,
  INITIAL_MARKETS,
  INITIAL_TRANSACTIONS,
  INITIAL_ADD_FUNDS_HISTORY,
  INITIAL_WITHDRAW_FUNDS_HISTORY,
  INITIAL_BANK_ACCOUNTS,
  INITIAL_STARLINE_RESULTS,
  INITIAL_NOTIFICATIONS,
} from './data/initialData';
import {
  evaluateMarkets,
  evaluateStarlineSlots,
  convertSlotsToStarlineResults,
} from './utils/marketEngine';
import {
  subscribeToRealtimeMarkets,
  evaluateSingleMarket,
  mergeMarketResultsIntoMarkets,
  transformSupabaseRowToMarket,
} from './services/marketService';
import {
  subscribeToUserWallet,
  syncUserToFirestore,
  subscribeToWithdrawals,
  createWithdrawalInFirestore,
  subscribeToDeposits,
  createDepositInFirestore,
  subscribeToBids,
  placeBidInFirestore,
  subscribeToTransactions,
  recordTransactionInFirestore,
  subscribeToBankAccounts,
  addBankAccountToFirestore,
  subscribeToPaymentGateway,
  subscribeToNotifications,
  broadcastNotificationInFirestore,
  seedInitialDataToFirestore,
  PaymentGatewayConfig,
  DEFAULT_GATEWAY_CONFIG,
} from './services/firestoreSyncService';
import { subscribeToMarketResults } from './services/marketResultService';
import {
  MainTab,
  MarketItem,
  UserProfile,
  Transaction,
  FundHistoryItem,
  BankAccount,
  StarlineResult,
  GameBid,
  AppNotification,
  MarketResultRecord,
} from './types';
import { Smartphone, Monitor, ShieldCheck, ShieldAlert, X } from 'lucide-react';
import { initSessionWatchdog } from './services/sessionManager';
import { checkRateLimit, recordActionAttempt } from './services/rateLimiter';
import { sanitizeAmount, sanitizeText } from './utils/sanitizer';
import { supabase } from './supabase';

export default function App() {
  // App authentication state - authenticated by default so Home screen renders properly in preview
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('rama777_auth_session') !== 'false';
  });
  const [isAuthChecking, setIsAuthChecking] = useState<boolean>(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [user, setUser] = useState<UserProfile>(() => {
    const active = getActiveSession();
    return active || INITIAL_USER;
  });
  const [currentTab, setCurrentTab] = useState<MainTab>('home');

  // Dark Mode state - default enabled for authentic deep dark/black theme
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);
  const [securityNotice, setSecurityNotice] = useState<{ message: string; isError?: boolean } | null>(null);

  // Initialize secure session watchdog (15-min idle timeout & storage tamper defense)
  useEffect(() => {
    const unsubWatchdog = initSessionWatchdog((reason) => {
      setSecurityNotice({ message: reason, isError: true });
      clearSession();
      setIsAuthenticated(false);
      setAuthMode('login');
      setActiveOverlay(null);
      setCurrentTab('home');
    });
    return () => unsubWatchdog();
  }, []);

  // Auth state listener: checks persistent session and role on launch
  useEffect(() => {
    let isMounted = true;
    const storedSession = localStorage.getItem('rama777_auth_session');

    // Check stored active session first
    const activeSession = getActiveSession();
    if (activeSession) {
      setUser(activeSession);
      setIsAuthenticated(true);
    } else {
      // Check stored user profile info
      const storedUserUid = localStorage.getItem('rama777_user_uid');
      const storedUserPhone = localStorage.getItem('rama777_user_phone');
      const storedUserName = localStorage.getItem('rama777_user_name');
      const storedRole = localStorage.getItem('rama777_user_role') as any;

      if (storedUserPhone || storedUserUid) {
        setUser((prev) => ({
          ...prev,
          uid: storedUserUid || prev.uid,
          id: storedUserUid || prev.id,
          phone: storedUserPhone || prev.phone,
          name: storedUserName || prev.name,
          role: storedRole || prev.role || 'user',
        }));
      }
    }

    const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
      if (!isMounted) return;
      if (session?.user) {
        setIsAuthenticated(true);
        localStorage.setItem('rama777_auth_session', 'true');
        localStorage.setItem('rama777_user_uid', session.user.id);
        if (session.user.phone) {
          localStorage.setItem('rama777_user_phone', session.user.phone);
        }
        setUser((prev) => ({
          ...prev,
          uid: session.user.id,
          id: session.user.id,
          email: session.user.email || prev.email,
          phone: session.user.phone || prev.phone,
        }));
      } else {
        if (storedSession !== 'false') {
          setIsAuthenticated(true);
        } else {
          setIsAuthenticated(false);
        }
      }
      setIsAuthChecking(false);
    });

    return () => {
      isMounted = false;
      authListener?.subscription?.unsubscribe();
    };
  }, []);
  const [viewDeviceMode, setViewDeviceMode] = useState<'mobile-frame' | 'responsive'>('mobile-frame');

  // Dynamic Clock & Market Time Engine
  const [timeOffsetMs, setTimeOffsetMs] = useState<number>(0);
  const [currentTime, setCurrentTime] = useState<Date>(() => new Date());

  // Data states directly populated from live Firestore collections without mock fallback
  const [markets, setMarkets] = useState<MarketItem[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [addFundsHistory, setAddFundsHistory] = useState<FundHistoryItem[]>([]);
  const [withdrawFundsHistory, setWithdrawFundsHistory] = useState<FundHistoryItem[]>([]);
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([]);
  const [starlineResults, setStarlineResults] = useState<StarlineResult[]>(() => {
    const slots = evaluateStarlineSlots(new Date());
    const now = new Date();
    const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
      .toString()
      .padStart(2, '0')}/${now.getFullYear()}`;
    return convertSlotsToStarlineResults(slots, dateStr);
  });
  const [bids, setBids] = useState<GameBid[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>(INITIAL_NOTIFICATIONS);
  const [historicalResults, setHistoricalResults] = useState<MarketResultRecord[]>([]);
  const historicalResultsRef = useRef<MarketResultRecord[]>([]);

  // Real-time payment gateway configuration from Firestore settings collection
  const [gatewayConfig, setGatewayConfig] = useState<PaymentGatewayConfig>(DEFAULT_GATEWAY_CONFIG);

  // Reference holding the latest raw market definitions from Firestore (or fallback)
  const latestRawMarketsRef = useRef<MarketItem[]>([]);

  // Real-time user session identifier for dynamic Firestore isolation
  const activeUserScope = user.uid || user.phone || 'anonymous';

  // 1. Real-time User & Wallet sync via onSnapshot
  useEffect(() => {
    if (!user.uid && !user.phone) return;
    const unsub = subscribeToUserWallet(user, (userData) => {
      setUser((prev) => ({
        ...prev,
        ...userData,
      }));
    });
    return () => unsub();
  }, [user.uid, user.phone]);

  // 2. Real-time Withdrawals sync via onSnapshot
  useEffect(() => {
    if (!user.uid && !user.phone) {
      setWithdrawFundsHistory([]);
      return;
    }
    const unsub = subscribeToWithdrawals(user, (withdrawals) => {
      setWithdrawFundsHistory(withdrawals);
    });
    return () => unsub();
  }, [user.uid, user.phone]);

  // 3. Real-time Deposits sync via onSnapshot
  useEffect(() => {
    if (!user.uid && !user.phone) {
      setAddFundsHistory([]);
      return;
    }
    const unsub = subscribeToDeposits(user, (deposits) => {
      setAddFundsHistory(deposits);
    });
    return () => unsub();
  }, [user.uid, user.phone]);

  // 4. Real-time Game Bids & Win History sync via onSnapshot
  useEffect(() => {
    if (!user.uid && !user.phone) {
      setBids([]);
      return;
    }
    const unsub = subscribeToBids(user, (syncedBids) => {
      setBids(syncedBids);
    });
    return () => unsub();
  }, [user.uid, user.phone]);

  // 5. Real-time Transactions (Passbook) sync via onSnapshot
  useEffect(() => {
    if (!user.uid && !user.phone) {
      setTransactions([]);
      return;
    }
    const unsub = subscribeToTransactions(user, (txs) => {
      setTransactions(txs);
    });
    return () => unsub();
  }, [user.uid, user.phone]);

  // 6. Real-time Bank Accounts sync via onSnapshot
  useEffect(() => {
    if (!user.uid && !user.phone) {
      setBankAccounts([]);
      return;
    }
    const unsub = subscribeToBankAccounts(user, (banks) => {
      setBankAccounts(banks);
    });
    return () => unsub();
  }, [user.uid, user.phone]);

  // 8. Real-time Payment Gateway Status & Config sync via onSnapshot
  useEffect(() => {
    const unsub = subscribeToPaymentGateway((cfg) => {
      setGatewayConfig(cfg);
    });
    return () => unsub();
  }, []);

  // 9. Real-time Notifications & Broadcasts sync via onSnapshot from 'notifications' collection
  useEffect(() => {
    const unsub = subscribeToNotifications(user.phone, (syncedNotifs, hasData) => {
      if (hasData) {
        setNotifications(syncedNotifs);
      }
    });
    return () => unsub();
  }, [user.phone]);

  // 10. Real-time Market Results & Chart History sync via onSnapshot from 'market_results' collection
  useEffect(() => {
    const unsub = subscribeToMarketResults((results) => {
      historicalResultsRef.current = results;
      setHistoricalResults(results);
      const now = new Date(Date.now() + timeOffsetMs);
      const base = latestRawMarketsRef.current;
      const evaluated = mergeMarketResultsIntoMarkets(base, results, now);
      setMarkets(evaluated);
    });
    return () => unsub();
  }, [timeOffsetMs]);

  // Initial Direct Load and Realtime Subscription directly from Supabase tables ('markets')
  useEffect(() => {
    let isMounted = true;

    // Direct plain CRUD query on mount using supabase.from('markets').select('*')
    const loadInitialMarkets = async () => {
      try {
        const { data, error } = await supabase
          .from('markets')
          .select('*')
          .order('name', { ascending: true });

        if (!isMounted) return;
        if (error) {
          console.error('[Supabase Error] Initial load markets failed:', error.message);
          return;
        }

        if (data && data.length > 0) {
          const now = new Date(Date.now() + timeOffsetMs);
          const rawItems = data.map((row) => transformSupabaseRowToMarket(row, now));
          latestRawMarketsRef.current = rawItems;
          const evaluated = mergeMarketResultsIntoMarkets(rawItems, historicalResultsRef.current, now);
          setMarkets(evaluated);
        }
      } catch (err) {
        console.error('[Supabase Network Failure] Initial markets load error:', err);
      }
    };

    loadInitialMarkets();

    // Subscribe directly to supabase.channel('public:markets').on('postgres_changes', ...)
    const channel = supabase
      .channel('public:markets')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'markets' },
        async (payload) => {
          if (!isMounted) return;
          console.log('[Supabase Realtime] Direct public:markets event:', payload.eventType);
          try {
            const { data, error } = await supabase
              .from('markets')
              .select('*')
              .order('name', { ascending: true });

            if (!isMounted) return;
            if (error) {
              console.error('[Supabase Error] Realtime markets select failed:', error.message);
              return;
            }
            if (data) {
              const now = new Date(Date.now() + timeOffsetMs);
              const rawItems = data.map((row) => transformSupabaseRowToMarket(row, now));
              latestRawMarketsRef.current = rawItems;
              const evaluated = mergeMarketResultsIntoMarkets(rawItems, historicalResultsRef.current, now);
              setMarkets(evaluated);
            }
          } catch (e) {
            console.error('[Supabase Network Failure] Realtime markets update error:', e);
          }
        }
      )
      .subscribe((status) => {
        console.log('[Supabase Realtime] public:markets direct status:', status);
      });

    return () => {
      isMounted = false;
      supabase.removeChannel(channel);
    };
  }, [timeOffsetMs]);

  // Real-time ticking engine: evaluates markets, countdowns, and results every 1 second
  useEffect(() => {
    const tick = () => {
      const now = new Date(Date.now() + timeOffsetMs);
      setCurrentTime(now);

      // Evaluate active markets directly from live Firestore collection without mock fallback
      const base = latestRawMarketsRef.current;
      const evaluated = mergeMarketResultsIntoMarkets(base, historicalResultsRef.current, now);
      setMarkets(evaluated);

      const slots = evaluateStarlineSlots(now);
      const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
        .toString()
        .padStart(2, '0')}/${now.getFullYear()}`;
      setStarlineResults(convertSlotsToStarlineResults(slots, dateStr));
    };

    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [timeOffsetMs]);

  const handleSetSimulatedTime = (hour: number, minute: number, addDays: number = 0) => {
    const nowReal = new Date();
    const target = new Date(
      nowReal.getFullYear(),
      nowReal.getMonth(),
      nowReal.getDate() + addDays,
      hour,
      minute,
      0
    );
    setTimeOffsetMs(target.getTime() - nowReal.getTime());
  };

  const handleResetRealTime = () => {
    setTimeOffsetMs(0);
  };

  // Active overlay view (e.g. gameplay, charts, rates, settings, change MPIN)
  const [activeOverlay, setActiveOverlay] = useState<string | null>(null);
  const [selectedMarketForPlay, setSelectedMarketForPlay] = useState<MarketItem | null>(null);
  const [selectedMarketForChart, setSelectedMarketForChart] = useState<string | null>(null);
  const [language, setLanguage] = useState<string>('English');

  // Reference for nested back handlers (e.g. sub-game mode in GamePlayView or specific chart in ChartsView)
  const subScreenBackHandlerRef = useRef<(() => boolean) | null>(null);
  const lastBackPressTimeRef = useRef<number>(0);
  const [showExitToast, setShowExitToast] = useState<boolean>(false);
  const exitToastTimerRef = useRef<any>(null);

  // Keep refs for event listeners so they never refer to stale closures
  const activeOverlayRef = useRef(activeOverlay);
  const currentTabRef = useRef(currentTab);
  const isDrawerOpenRef = useRef(isDrawerOpen);

  useEffect(() => {
    activeOverlayRef.current = activeOverlay;
  }, [activeOverlay]);

  useEffect(() => {
    currentTabRef.current = currentTab;
  }, [currentTab]);

  useEffect(() => {
    isDrawerOpenRef.current = isDrawerOpen;
  }, [isDrawerOpen]);

  // Unified history navigation handlers
  const openOverlay = (
    overlay: string,
    meta?: { marketForPlay?: MarketItem | null; marketForChart?: string | null }
  ) => {
    if (meta?.marketForPlay !== undefined) setSelectedMarketForPlay(meta.marketForPlay);
    if (meta?.marketForChart !== undefined) setSelectedMarketForChart(meta.marketForChart);
    setActiveOverlay(overlay);
  };

  const closeOverlay = () => {
    setActiveOverlay(null);
    setSelectedMarketForPlay(null);
    setSelectedMarketForChart(null);
    subScreenBackHandlerRef.current = null;
  };

  const handleTabChange = (tab: MainTab) => {
    if (tab !== currentTab) {
      setCurrentTab(tab);
      setActiveOverlay(null);
      subScreenBackHandlerRef.current = null;
    }
  };

  const handleOpenDrawer = () => {
    setIsDrawerOpen(true);
  };

  const handleCloseDrawer = () => {
    setIsDrawerOpen(false);
  };

  // Centralized hardware back button dispatcher for Android APK, WebView, and browser
  const handleHardwareBackPress = () => {
    // 1. Priority 1: If side drawer is open, close it cleanly
    if (isDrawerOpenRef.current) {
      setIsDrawerOpen(false);
      return;
    }

    // 2. Priority 2: If a sub-screen has its own active nested back handler (e.g. sub-game betting mode in GamePlayView, or specific chart in ChartsView)
    if (subScreenBackHandlerRef.current) {
      try {
        const handled = subScreenBackHandlerRef.current();
        if (handled) return;
      } catch (e) {
        console.warn('Error in subScreenBackHandler:', e);
      }
    }

    // 3. Priority 3: If an overlay/sub-screen is active (GamePlayView, Charts, Rates, Settings, etc.), return cleanly to Home dashboard
    if (activeOverlayRef.current) {
      setActiveOverlay(null);
      setSelectedMarketForPlay(null);
      setSelectedMarketForChart(null);
      subScreenBackHandlerRef.current = null;
      return;
    }

    // 4. Priority 4: If on any sub-tab (funds/wallet, passbook, history, support), cleanly navigate back to Home dashboard
    if (currentTabRef.current !== 'home') {
      setCurrentTab('home');
      return;
    }

    // 5. Priority 5: User is on the root Home screen.
    // Intercept and prompt before exiting the app (double-press back within 2 seconds to exit)
    const now = Date.now();
    if (now - lastBackPressTimeRef.current < 2000) {
      try {
        (window as any)?.Capacitor?.Plugins?.App?.exitApp?.();
      } catch (e) {
        (navigator as any)?.app?.exitApp?.();
      }
    } else {
      lastBackPressTimeRef.current = now;
      setShowExitToast(true);
      if (exitToastTimerRef.current) {
        clearTimeout(exitToastTimerRef.current);
      }
      exitToastTimerRef.current = setTimeout(() => {
        setShowExitToast(false);
      }, 2000);
    }
  };

  // Hardware back button lifecycle & event listener integration
  useEffect(() => {
    // 1. Maintain a history entry so Android WebView never exits due to an empty back stack
    try {
      window.history.pushState({ screen: 'app-root' }, '');
    } catch (e) {
      // Ignore
    }

    // 2. Android Capacitor hardware back button integration
    let capacitorListener: any = null;
    try {
      const capApp = (window as any)?.Capacitor?.Plugins?.App;
      if (capApp?.addListener) {
        capApp.addListener('backButton', () => {
          handleHardwareBackPress();
        }).then((handle: any) => {
          capacitorListener = handle;
        }).catch((err: any) => {
          console.warn('CapacitorApp backButton setup notice:', err);
        });
      }
    } catch (err) {
      console.warn('CapacitorApp backButton not available:', err);
    }

    // 3. Cordova / PhoneGap / Android WebView backbutton event
    const handleCordovaBackButton = (e: Event) => {
      e.preventDefault();
      handleHardwareBackPress();
    };
    document.addEventListener('backbutton', handleCordovaBackButton, false);

    // 4. Browser / WebView popstate listener
    const handlePopState = (e: PopStateEvent) => {
      e.preventDefault();
      handleHardwareBackPress();
      // Repush dummy state so the browser/webview history stack never empties
      try {
        window.history.pushState({ screen: 'app-root' }, '');
      } catch (err) {
        // Ignore
      }
    };
    window.addEventListener('popstate', handlePopState);

    return () => {
      if (capacitorListener?.remove) {
        capacitorListener.remove();
      }
      document.removeEventListener('backbutton', handleCordovaBackButton);
      window.removeEventListener('popstate', handlePopState);
      if (exitToastTimerRef.current) {
        clearTimeout(exitToastTimerRef.current);
      }
    };
  }, []);

  // Sync dark mode class on document element
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const handleUpdateMpin = (newMpin: string) => {
    const updatedUser = {
      ...user,
      mpin: newMpin,
    };
    setUser(updatedUser);
    syncUserToFirestore(updatedUser);
  };

  const handleLoginSuccess = (loginData?: UserProfile | string) => {
    let updatedUser: UserProfile;

    if (loginData && typeof loginData === 'object' && 'name' in loginData) {
      updatedUser = loginData as UserProfile;
    } else {
      const effectivePhone = (typeof loginData === 'string' ? loginData : user.phone) || user.phone;
      const cleanPhone = effectivePhone.replace(/\D/g, '');
      const userUid = user.uid || (cleanPhone ? `user_${cleanPhone}` : '');
      updatedUser = {
        ...user,
        phone: effectivePhone,
        uid: userUid,
        id: userUid,
      };
    }

    persistSession(updatedUser);
    setUser(updatedUser);
    setIsAuthenticated(true);
    setCurrentTab('home');
    setActiveOverlay(null);
  };

  const handleGoogleLoginSuccess = (supabaseUser: any) => {
    const updatedUser: UserProfile = {
      ...user,
      uid: supabaseUser.id || supabaseUser.uid,
      id: supabaseUser.id || supabaseUser.uid,
      name: supabaseUser.user_metadata?.full_name || supabaseUser.displayName || user.name || 'RAMA Player',
      email: supabaseUser.email || user.email,
      phone: supabaseUser.phone || user.phone || '',
      walletBalance: user.walletBalance || 0,
      role: 'user',
    };
    persistSession(updatedUser);
    setUser(updatedUser);
    setIsAuthenticated(true);
    setAuthMode('login');
    setCurrentTab('home');
    setActiveOverlay(null);
    syncUserToFirestore(updatedUser);
  };

  const handleLogout = async () => {
    setIsDrawerOpen(false);
    clearSession();
    try {
      await supabase.auth.signOut();
    } catch (err) {
      console.warn('Signout notice:', err);
    }
    setUser(INITIAL_USER);
    setTransactions([]);
    setAddFundsHistory([]);
    setWithdrawFundsHistory([]);
    setBankAccounts([]);
    setBids([]);
    setIsAuthenticated(false);
    setAuthMode('login');
    setActiveOverlay(null);
    setCurrentTab('home');
  };

  const handleRegisterSuccess = (newUser: UserProfile) => {
    const cleanUid = newUser.uid || `user_${newUser.phone.replace(/\D/g, '')}`;
    const cleanUser: UserProfile = {
      ...newUser,
      uid: cleanUid,
      id: cleanUid,
      walletBalance: newUser.walletBalance || 500, // ₹500 Welcome Bonus
      role: newUser.role || 'user',
    };

    persistSession(cleanUser);
    setUser(cleanUser);
    setTransactions([]);
    setAddFundsHistory([]);
    setWithdrawFundsHistory([]);
    setBankAccounts([]);
    setBids([]);

    setIsAuthenticated(true);
    setAuthMode('login');
    setCurrentTab('home');
    setActiveOverlay(null);

    // Sync user profile to Firestore
    syncUserToFirestore(cleanUser);

    // Add welcome notification
    const welcomeNotif: AppNotification = {
      id: `notif-${Date.now()}`,
      title: `Welcome, ${cleanUser.name}!`,
      message: 'Your RAMA777 account is active. 4-digit MPIN and Biometric security successfully configured.',
      time: 'Just now',
      read: false,
      type: 'alert',
    };

    setNotifications((prev) => [welcomeNotif, ...prev]);
    broadcastNotificationInFirestore({
      ...welcomeNotif,
      targetPhone: cleanUser.phone,
    });
  };

  const handlePlaceBid = (
    bidData: Omit<GameBid, 'id' | 'date' | 'status'> | Omit<GameBid, 'id' | 'date' | 'status'>[]
  ): boolean => {
    const bidsArray = Array.isArray(bidData) ? bidData : [bidData];
    if (bidsArray.length === 0) {
      return false;
    }

    // Rate Limiting on bid submissions
    const userScopeKey = user.uid || user.phone || 'guest';
    const rateCheck = checkRateLimit('game:place_bid', userScopeKey);
    if (!rateCheck.allowed) {
      setSecurityNotice({ message: rateCheck.errorMessage || 'Please wait before placing more bids.', isError: true });
      return false;
    }

    // Calculate the complete accumulated sum of all points in the active bid slip with sanitization
    const totalPoints = bidsArray.reduce((sum, b) => {
      const cleanPts = sanitizeAmount(b.points, 1, 100000);
      return sum + (cleanPts.isValid ? cleanPts.amount : 0);
    }, 0);

    if (totalPoints <= 0 || user.walletBalance < totalPoints) {
      return false;
    }

    recordActionAttempt('game:place_bid', userScopeKey, true);

    const prevBal = user.walletBalance;
    const newBal = prevBal - totalPoints;
    const now = new Date();
    const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
      .toString()
      .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    })}`;

    const newBids: GameBid[] = bidsArray.map((bidItem, idx) => ({
      ...bidItem,
      points: sanitizeAmount(bidItem.points, 1, 100000).amount || Number(bidItem.points),
      marketName: sanitizeText(bidItem.marketName, 50),
      gameType: sanitizeText(bidItem.gameType, 50),
      digitOrPana: sanitizeText(bidItem.digitOrPana, 10),
      id: `bid-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 7)}`,
      date: dateStr,
      status: 'Placed',
    }));

    const firstBid = bidsArray[0];
    const marketName = firstBid.marketName;
    const digitsSample = bidsArray.map((b) => b.digitOrPana).slice(0, 4).join(', ');
    const description =
      bidsArray.length === 1
        ? `${firstBid.gameType} (${firstBid.session}) #${firstBid.digitOrPana}`
        : `${firstBid.gameType} (${firstBid.session}) • ${bidsArray.length} Bids (#${digitsSample}${
            bidsArray.length > 4 ? '...' : ''
          })`;

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      title: `${marketName} Bid | ₹${totalPoints}`,
      referenceId: `BID-${Math.random().toString(36).substring(2, 9).toUpperCase()}`,
      description,
      amount: totalPoints,
      type: 'debit',
      status: 'SUCCESS',
      date: dateStr,
      previousBalance: prevBal,
      currentBalance: newBal,
    };

    const updatedUser = { ...user, walletBalance: newBal };
    setUser(updatedUser);
    setBids((prev) => [...newBids, ...prev]);
    setTransactions((prev) => [newTx, ...prev]);

    // Real-time Firestore sync
    for (const bidItem of bidsArray) {
      placeBidInFirestore(bidItem, user);
    }
    recordTransactionInFirestore(newTx, user);
    syncUserToFirestore(updatedUser);

    return true;
  };

  const handleAddFunds = (
    amount: number,
    bonus: number = 0,
    depositMode: string = 'Kotak Merchant UPI',
    utrOrOrderId?: string,
    status: 'Success' | 'Pending' = 'Success'
  ) => {
    // Rate Limiting check on Add Fund requests
    const userScopeKey = user.uid || user.phone || 'guest';
    const rateCheck = checkRateLimit('funds:deposit', userScopeKey);
    if (!rateCheck.allowed) {
      setSecurityNotice({ message: rateCheck.errorMessage || 'Please wait before submitting deposit requests.', isError: true });
      return;
    }
    recordActionAttempt('funds:deposit', userScopeKey, true);

    const safeAmountResult = sanitizeAmount(amount, 1, 500000);
    const safeAmount = safeAmountResult.isValid ? safeAmountResult.amount : Math.max(1, amount);
    const safeBonusResult = sanitizeAmount(bonus, 0, 50000);
    const safeBonus = safeBonusResult.isValid ? safeBonusResult.amount : 0;
    const safeDepositMode = sanitizeText(depositMode, 40);

    const totalAdded = safeAmount + safeBonus;
    const prevBal = user.walletBalance;
    const isSuccess = status === 'Success';
    const newBal = isSuccess ? prevBal + totalAdded : prevBal;
    const now = new Date();
    const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
      .toString()
      .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    const orderId = utrOrOrderId && utrOrOrderId.startsWith('KTK-') ? utrOrOrderId : `KTK-${Math.random().toString(36).substring(2, 10).toUpperCase()}`;

    const newHistory: FundHistoryItem = {
      id: `afh-${Date.now()}`,
      orderId,
      date: dateStr,
      amount: totalAdded,
      status: status,
      requestType: 'Credit',
      depositMode: safeDepositMode,
      utrOrReference: utrOrOrderId ? sanitizeText(utrOrOrderId, 24) : undefined,
    };

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      title: isSuccess
        ? (safeBonus > 0 ? `Welcome Bonus Added | ₹${totalAdded}` : `Kotak UPI Topup SUCCESS | ₹${safeAmount}`)
        : `UPI Deposit (Pending Verification) | ₹${safeAmount}`,
      referenceId: orderId,
      description: `${safeDepositMode} | ${utrOrOrderId ? `UTR: ${utrOrOrderId}` : 'Awaiting confirmation'}`,
      amount: totalAdded,
      type: 'credit',
      status: isSuccess ? 'SUCCESS' : 'PENDING',
      date: dateStr,
      previousBalance: prevBal,
      currentBalance: newBal,
    };

    if (isSuccess) {
      const updatedUser = { ...user, walletBalance: newBal };
      setUser(updatedUser);
      syncUserToFirestore(updatedUser);
    }

    setAddFundsHistory((prev) => [newHistory, ...prev]);
    setTransactions((prev) => [newTx, ...prev]);

    // Real-time Firestore sync (dual-writes to deposits & deposit_requests)
    createDepositInFirestore(newHistory, user, safeBonus);
    recordTransactionInFirestore(newTx, user);
  };

  const handleAddFundsFailure = (
    orderId: string,
    amount: number,
    depositMode: string = 'Kotak Merchant UPI',
    reason: string = 'Payment Failed'
  ) => {
    const now = new Date();
    const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
      .toString()
      .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    const failedHistory: FundHistoryItem = {
      id: `afh-fail-${Date.now()}`,
      orderId,
      date: dateStr,
      amount,
      status: 'Failure',
      requestType: 'Credit',
      depositMode,
    };

    const failedTx: Transaction = {
      id: `tx-fail-${Date.now()}`,
      title: `Add Fund FAILED | ₹${amount}`,
      referenceId: orderId,
      description: `${reason} | ${depositMode}`,
      amount,
      type: 'credit',
      status: 'FAILED',
      date: dateStr,
      previousBalance: user.walletBalance,
      currentBalance: user.walletBalance, // Wallet points are NOT credited on failure!
    };

    // User wallet balance is strictly protected and remains unchanged
    setAddFundsHistory((prev) => [failedHistory, ...prev]);
    setTransactions((prev) => [failedTx, ...prev]);

    // Real-time Firestore sync of failure record
    createDepositInFirestore(failedHistory, user, 0);
    recordTransactionInFirestore(failedTx, user);
  };

  const handleWithdrawFunds = (amount: number, bankId: string): boolean => {
    // Rate Limiting check on Withdrawal requests
    const userScopeKey = user.uid || user.phone || 'guest';
    const rateCheck = checkRateLimit('funds:withdraw', userScopeKey);
    if (!rateCheck.allowed) {
      setSecurityNotice({ message: rateCheck.errorMessage || 'Please wait before submitting withdrawal requests.', isError: true });
      return false;
    }

    const safeAmountResult = sanitizeAmount(amount, 100, 100000);
    const safeAmount = safeAmountResult.isValid ? safeAmountResult.amount : amount;

    if (user.walletBalance < safeAmount) {
      setSecurityNotice({ message: 'Insufficient wallet balance for withdrawal.', isError: true });
      return false;
    }

    recordActionAttempt('funds:withdraw', userScopeKey, true);

    const bank = bankAccounts.find((b) => b.id === bankId) || bankAccounts[0];
    const prevBal = user.walletBalance;
    const newBal = prevBal - safeAmount;
    const now = new Date();
    const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
      .toString()
      .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    const orderId = `TNX${Date.now()}`;
    const newHistory: FundHistoryItem = {
      id: `wfh-${Date.now()}`,
      orderId,
      date: dateStr,
      amount: safeAmount,
      status: 'Pending',
      requestType: 'Debit',
      depositMode: 'Bank Transfer',
      bankName: bank?.bankName || 'Bank Account',
      accountNumber: bank?.accountNumber || '',
      ifscCode: bank?.ifscCode || '',
    };

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      title: `Withdrawal Request PENDING | ₹${amount}`,
      referenceId: orderId,
      description: `Bank Transfer to ${bank?.bankName || 'Linked Bank'}`,
      amount,
      type: 'debit',
      status: 'PENDING',
      date: dateStr,
      previousBalance: prevBal,
      currentBalance: newBal,
    };

    const updatedUser = { ...user, walletBalance: newBal };
    setUser(updatedUser);
    setWithdrawFundsHistory((prev) => [newHistory, ...prev]);
    setTransactions((prev) => [newTx, ...prev]);

    // Real-time Firestore sync
    createWithdrawalInFirestore(newHistory, user);
    recordTransactionInFirestore(newTx, user);
    syncUserToFirestore(updatedUser);

    return true;
  };

  const handleAddBank = (bankData: Omit<BankAccount, 'id' | 'updatedAt'>) => {
    const now = new Date();
    const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
      .toString()
      .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    const lockDate = new Date();
    lockDate.setDate(lockDate.getDate() + 30);
    const lockDateStr = `${lockDate.getDate().toString().padStart(2, '0')}/${(lockDate.getMonth() + 1)
      .toString()
      .padStart(2, '0')}/${lockDate.getFullYear()}`;

    const newBank: BankAccount = {
      ...bankData,
      id: `bank-${Date.now()}`,
      updatedAt: dateStr,
      status: bankData.status || 'Success',
      lockUntil: lockDateStr,
    };

    setBankAccounts((prev) => [newBank, ...prev]);

    // Real-time Firestore sync
    addBankAccountToFirestore(bankData, user);
  };

  const handleSelectDrawerOption = (optionId: string) => {
    switch (optionId) {
      case 'home':
        setCurrentTab('home');
        closeOverlay();
        break;
      case 'admin_panel':
        openOverlay('admin_panel');
        break;
      case 'result_management':
        openOverlay('admin_panel');
        break;
      case 'charts':
        openOverlay('charts');
        break;
      case 'change_mpin':
        openOverlay('change_mpin');
        break;
      case 'notifications':
        openOverlay('notifications');
        break;
      case 'how_to_play':
        openOverlay('how_to_play');
        break;
      case 'submit_ideas':
        openOverlay('submit_ideas');
        break;
      case 'game_rates':
        openOverlay('game_rates');
        break;
      case 'terms':
        openOverlay('terms');
        break;
      case 'settings':
        openOverlay('settings');
        break;
      case 'language':
        openOverlay('language');
        break;
      default:
        break;
    }
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  if (isAuthChecking) {
    return (
      <div
        className="w-full bg-[#050608] flex items-center justify-center select-none"
        style={{
          height: '100vh',
          maxHeight: '100vh',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        <div
          className="w-full max-w-md mx-auto bg-[#0a0b10] text-slate-100 flex flex-col items-center justify-center p-8 text-center"
          style={{
            height: '100vh',
            maxHeight: '100vh',
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-[#E65100] to-[#FF7700] flex items-center justify-center shadow-lg shadow-orange-500/30 mb-5 animate-pulse">
            <span className="text-white font-extrabold text-4xl tracking-tighter">R</span>
          </div>
          <h1 className="text-2xl font-black tracking-tight text-[#FF7700] mb-2">RAMA777</h1>
          <p className="text-xs text-slate-400 font-medium mb-6">
            Checking authentication...
          </p>
          <div className="w-8 h-8 border-3 border-[#FF7700] border-t-transparent rounded-full animate-spin" />
        </div>
      </div>
    );
  }

  return (
    <div
      className="w-full bg-[#050608] flex items-center justify-center select-none"
      style={{
        height: '100vh',
        maxHeight: '100vh',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      {/* Root/Main Container of the App with height: 100vh; overflow: hidden; display: flex; flex-direction: column; */}
      <div
        className="w-full max-w-md mx-auto bg-[#0a0b10] text-slate-100 relative shadow-2xl border-x border-zinc-900/60"
        style={{
          height: '100vh',
          maxHeight: '100vh',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        {!isAuthenticated ? (
          <div
            className="w-full"
            style={{ flex: 1, minHeight: 0, overflowY: 'auto' }}
          >
            {authMode === 'register' ? (
              /* New Registration Screen */
              <RegisterScreen
                onRegisterSuccess={handleRegisterSuccess}
                onNavigateToLogin={() => setAuthMode('login')}
              />
            ) : (
              /* MPIN & Password Login Flow */
              <LoginScreen
                onLoginSuccess={handleLoginSuccess}
                savedMpin={user.mpin}
                onUpdateMpin={handleUpdateMpin}
                phone={user.phone}
                onNavigateToRegister={() => setAuthMode('register')}
              />
            )}
          </div>
        ) : (
          <>
            {/* Top Fixed Header with flex-shrink: 0 */}
            {!activeOverlay && (
              <div style={{ flexShrink: 0 }} className="shrink-0">
                <Header
                  currentTab={currentTab}
                  walletBalance={user.walletBalance}
                  unreadNotificationsCount={unreadCount}
                  userRole={user.role}
                  onOpenDrawer={handleOpenDrawer}
                  onOpenNotifications={() => openOverlay('notifications')}
                  onNavigateToFunds={() => handleTabChange('funds')}
                  onOpenAdminHub={() => openOverlay('admin_panel')}
                />
              </div>
            )}

            {/* Side Drawer Menu */}
            <SideDrawer
              isOpen={isDrawerOpen}
              onClose={handleCloseDrawer}
              user={user}
              isDarkMode={isDarkMode}
              onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
              onSelectOption={handleSelectDrawerOption}
              onLogout={handleLogout}
            />

            {/* Middle Content Area - flex: 1, column layout with nested independent scroll for Home */}
            <main
              className="bg-[#0a0b10] text-slate-100 overscroll-contain flex-1 flex flex-col min-h-0"
              style={{
                flex: 1,
                minHeight: 0,
                display: 'flex',
                flexDirection: 'column',
                overflowY: currentTab === 'home' && !activeOverlay ? 'hidden' : 'auto',
                overflowX: 'hidden',
                WebkitOverflowScrolling: 'touch',
              }}
            >
                {activeOverlay === 'gameplay' && selectedMarketForPlay ? (
                  <GamePlayView
                    market={markets.find((m) => m.id === selectedMarketForPlay.id) || selectedMarketForPlay}
                    walletBalance={user.walletBalance}
                    onBack={closeOverlay}
                    onPlaceBid={handlePlaceBid}
                    onRegisterBackHandler={(fn) => { subScreenBackHandlerRef.current = fn; }}
                  />
                ) : activeOverlay === 'charts' ? (
                  <ChartsView
                    markets={markets}
                    initialMarket={selectedMarketForChart}
                    historicalResults={historicalResults}
                    currentTime={currentTime}
                    onBack={closeOverlay}
                    onRegisterBackHandler={(fn) => { subScreenBackHandlerRef.current = fn; }}
                  />
                ) : activeOverlay === 'admin_panel' || activeOverlay === 'result_management' ? (
                  <AdminPanelModal
                    currentUser={user}
                    markets={markets}
                    currentTime={currentTime}
                    onClose={closeOverlay}
                    onSwitchUser={(newUser) => {
                      persistSession(newUser);
                      setUser(newUser);
                    }}
                  />
                ) : activeOverlay === 'change_mpin' ? (
                  <ChangeMpinModal
                    currentMpin={user.mpin}
                    onUpdateMpin={handleUpdateMpin}
                    onClose={closeOverlay}
                  />
                ) : activeOverlay === 'game_rates' ? (
                  <GameRatesModal onClose={closeOverlay} />
                ) : activeOverlay === 'starline' ? (
                  <StarlineJackpotModal
                    type="starline"
                    walletBalance={user.walletBalance}
                    starlineResults={starlineResults}
                    currentTime={currentTime}
                    onBack={closeOverlay}
                    onPlaceBid={handlePlaceBid}
                  />
                ) : activeOverlay === 'jackpot' ? (
                  <StarlineJackpotModal
                    type="jackpot"
                    walletBalance={user.walletBalance}
                    starlineResults={starlineResults}
                    currentTime={currentTime}
                    onBack={closeOverlay}
                    onPlaceBid={handlePlaceBid}
                  />
                ) : activeOverlay === 'notifications' ? (
                  <NotificationsModal
                    notifications={notifications}
                    onClose={closeOverlay}
                    onClear={() => setNotifications([])}
                  />
                ) : activeOverlay === 'how_to_play' ? (
                  <HowToPlayModal onClose={closeOverlay} />
                ) : activeOverlay === 'submit_ideas' ? (
                  <SubmitIdeasModal onClose={closeOverlay} />
                ) : activeOverlay === 'settings' ? (
                  <SettingsModal
                    biometric={user.biometricEnabled}
                    onToggleBiometric={() =>
                      setUser((p) => ({ ...p, biometricEnabled: !p.biometricEnabled }))
                    }
                    language={language}
                    onChangeLanguage={setLanguage}
                    onClose={closeOverlay}
                  />
                ) : activeOverlay === 'language' ? (
                  <LanguageModal
                    currentLanguage={language}
                    onSelectLanguage={setLanguage}
                    onClose={closeOverlay}
                  />
                ) : activeOverlay === 'terms' ? (
                  <div className="pb-6 pt-2 px-4 space-y-4">
                    <div className="flex items-center gap-2.5 mb-4">
                      <button
                        onClick={closeOverlay}
                        className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
                      >
                        ←
                      </button>
                      <h2 className="text-base font-extrabold text-[#FF7700]">Terms & Conditions</h2>
                    </div>
                    <div className="bg-[#11131c] rounded-3xl p-5 border border-zinc-800 text-xs text-slate-300 leading-relaxed space-y-3 shadow-lg">
                      <p className="font-bold text-white">1. Eligibility</p>
                      <p>Users must be 18 years of age or older to register and place bids on RAMA777.</p>
                      <p className="font-bold text-white">2. Fair Play & Results</p>
                      <p>All market results are official and verified in accordance with national market timings.</p>
                      <p className="font-bold text-white">3. Fast Withdrawals</p>
                      <p>Withdrawals are processed to the user&apos;s verified bank account within 24 hours.</p>
                    </div>
                  </div>
                ) : (
                  /* Standard 5 Tab Navigation */
                  <>
                    {currentTab === 'home' && (
                      <HomeTab
                        markets={markets}
                        currentTime={currentTime}
                        isSimulated={timeOffsetMs !== 0}
                        onSetSimulatedTime={handleSetSimulatedTime}
                        onResetRealTime={handleResetRealTime}
                        onPlayMarket={(m) => {
                          openOverlay('gameplay', { marketForPlay: m });
                        }}
                        onOpenChart={(marketName) => {
                          openOverlay('charts', { marketForChart: `${marketName} Panel Chart` });
                        }}
                        onOpenStarline={() => openOverlay('starline')}
                        onOpenJackpot={() => openOverlay('jackpot')}
                      />
                    )}

                    {currentTab === 'history' && (
                      <HistoryTab bids={bids} starlineResults={starlineResults} />
                    )}

                    {currentTab === 'passbook' && (
                      <PassbookTab transactions={transactions} />
                    )}

                    {currentTab === 'funds' && (
                      <FundsTab
                        user={user}
                        addFundsHistory={addFundsHistory}
                        withdrawFundsHistory={withdrawFundsHistory}
                        bankAccounts={bankAccounts}
                        onAddFunds={handleAddFunds}
                        onAddFundsFailure={handleAddFundsFailure}
                        onWithdrawFunds={handleWithdrawFunds}
                        onAddBank={handleAddBank}
                        gatewayConfig={gatewayConfig}
                      />
                    )}

                    {currentTab === 'support' && <SupportTab />}
                  </>
                )}
              </main>

              {/* Fixed Bottom Navigation Bar with flex-shrink: 0 */}
              {!activeOverlay && (
                <div style={{ flexShrink: 0 }} className="shrink-0">
                  <BottomNavBar currentTab={currentTab} onTabChange={handleTabChange} />
                </div>
              )}

              {/* Security Shield & Rate Limit Notification Banner */}
              {securityNotice && (
                <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-[#12141f]/95 backdrop-blur-md text-white border border-amber-500/50 px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2.5 animate-in fade-in slide-in-from-top-3 max-w-sm w-[92%] mx-auto">
                  {securityNotice.isError ? (
                    <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0" />
                  ) : (
                    <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                  )}
                  <span className="text-xs font-semibold leading-tight flex-1 text-slate-100">{securityNotice.message}</span>
                  <button
                    onClick={() => setSecurityNotice(null)}
                    className="text-zinc-400 hover:text-white p-1 rounded-lg cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* Native-style Android Back Press Exit Toast */}
              {showExitToast && (
                <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-[#1E232A]/95 backdrop-blur-md text-white border border-slate-700/80 px-4 py-2.5 rounded-full shadow-2xl flex items-center gap-2.5 animate-in fade-in slide-in-from-bottom-3 duration-200 pointer-events-none">
                  <div className="w-2 h-2 rounded-full bg-[#FF7700] animate-pulse" />
                  <span className="text-xs font-bold tracking-wide">Press back again to exit RAMA777</span>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    );
  }
