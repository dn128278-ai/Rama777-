import React, { useState, useEffect, useRef, useMemo } from 'react';
import { ArrowLeft, ArrowUp, ArrowDown, Activity, Sparkles } from 'lucide-react';
import { MarketItem, MarketResultRecord, WeekdayKey } from '../types';
import { buildMarketChartRows } from '../services/marketResultService';

interface ChartsViewProps {
  markets: MarketItem[];
  initialMarket?: string | null;
  historicalResults?: MarketResultRecord[];
  currentTime?: Date;
  onBack: () => void;
  onRegisterBackHandler?: (handler: (() => boolean) | null) => void;
  onPushSubScreen?: (name: string) => void;
}

const WEEKDAYS: WeekdayKey[] = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];

export const ChartsView: React.FC<ChartsViewProps> = ({
  markets,
  initialMarket,
  historicalResults = [],
  currentTime = new Date(),
  onBack,
  onRegisterBackHandler,
  onPushSubScreen,
}) => {
  const [selectedMarketName, setSelectedMarketName] = useState<string | null>(
    initialMarket ? initialMarket.replace(/ (Jodi|Panel) Chart/g, '') : null
  );
  const [chartMode, setChartMode] = useState<'panel' | 'jodi'>(
    initialMarket && initialMarket.includes('Jodi') ? 'jodi' : 'panel'
  );

  const selectedMarketNameRef = useRef<string | null>(selectedMarketName);
  useEffect(() => {
    selectedMarketNameRef.current = selectedMarketName;
  }, [selectedMarketName]);

  const handleSelectChart = (name: string, mode: 'panel' | 'jodi') => {
    setSelectedMarketName(name);
    setChartMode(mode);
    onPushSubScreen?.(`chart:${name}:${mode}`);
  };

  useEffect(() => {
    if (onRegisterBackHandler) {
      if (selectedMarketName) {
        onRegisterBackHandler(() => {
          setSelectedMarketName(null);
          return true;
        });
      } else {
        onRegisterBackHandler(null);
      }
    }
  }, [selectedMarketName, onRegisterBackHandler]);

  useEffect(() => {
    return () => {
      onRegisterBackHandler?.(null);
    };
  }, [onRegisterBackHandler]);

  const handleDetailBack = () => {
    if (selectedMarketName) {
      setSelectedMarketName(null);
    } else {
      onBack();
    }
  };

  const currentMarketItem = markets.find(
    (m) => m.name.toLowerCase() === selectedMarketName?.toLowerCase()
  );

  // Dynamic Chart Rows generated using real-time synchronization engine
  const chartRows = useMemo(() => {
    if (!selectedMarketName) return [];
    const marketId = currentMarketItem?.id || selectedMarketName.toLowerCase().replace(/\s+/g, '_');
    return buildMarketChartRows(
      marketId,
      selectedMarketName,
      currentMarketItem,
      historicalResults,
      currentTime,
      14
    );
  }, [selectedMarketName, currentMarketItem, historicalResults, currentTime]);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToBottom = () => {
    window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
  };


  return (
    <div className="pb-24 pt-2 px-4 transition-colors">
      {!selectedMarketName ? (
        /* Market Charts Directory matching f_010.jpg */
        <div className="space-y-4">
          <div className="flex items-center gap-2.5">
            <button
              onClick={onBack}
              className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <h2 className="text-base font-extrabold text-[#FF7700]">Charts</h2>
          </div>

          {/* Matka Chart Title Strip */}
          <div className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white text-center font-extrabold text-sm shadow-xs">
            Matka Chart
          </div>

          {/* Markets List with Jodi & Panel Buttons */}
          <div className="space-y-2.5">
            {markets.map((m) => (
              <div
                key={m.id}
                className="bg-white dark:bg-slate-900 rounded-2xl p-3 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between shadow-xs"
              >
                <span className="font-extrabold text-xs uppercase text-slate-900 dark:text-slate-100 pr-2">
                  {m.name}
                </span>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => handleSelectChart(m.name, 'jodi')}
                    className="px-5 py-1.5 rounded-full bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-bold text-xs shadow-xs active:scale-95 transition-all cursor-pointer"
                  >
                    Jodi
                  </button>
                  <button
                    onClick={() => handleSelectChart(m.name, 'panel')}
                    className="px-5 py-1.5 rounded-full bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-bold text-xs shadow-xs active:scale-95 transition-all cursor-pointer"
                  >
                    Panel
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Detailed Sub-view: Either Jodi Chart or Panel Chart */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={handleDetailBack}
                className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div>
                <h2 className="text-sm font-extrabold text-[#FF7700] truncate">
                  {selectedMarketName} {chartMode === 'jodi' ? 'Jodi Chart' : 'Panel Chart'}
                </h2>
                <p className="text-[10px] text-slate-400">Official verified historical records</p>
              </div>
            </div>

            {/* Segmented Mode Switcher */}
            <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
              <button
                onClick={() => setChartMode('jodi')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  chartMode === 'jodi'
                    ? 'bg-[#FF7700] text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                Jodi
              </button>
              <button
                onClick={() => setChartMode('panel')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  chartMode === 'panel'
                    ? 'bg-[#FF7700] text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                Panel
              </button>
            </div>
          </div>

          {/* Quick Scroll Buttons matching video */}
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={scrollToTop}
              className="h-11 rounded-2xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs active:scale-95 cursor-pointer"
            >
              <ArrowUp className="w-4 h-4" />
              <span>Go To Top</span>
            </button>
            <button
              onClick={scrollToBottom}
              className="h-11 rounded-2xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs active:scale-95 cursor-pointer"
            >
              <ArrowDown className="w-4 h-4" />
              <span>Go To Bottom</span>
            </button>
          </div>

          {/* Chart Table */}
          {chartMode === 'jodi' ? (
            /* Detailed Jodi Table (Pure 2-Digit Jodi with Red highlights) */
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-amber-200 dark:border-amber-900/60 overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-center border-collapse text-xs">
                  <thead>
                    <tr className="bg-[#FFE5D0] dark:bg-orange-950/50 text-[#8B3A00] dark:text-orange-300 font-extrabold border-b border-amber-200 dark:border-amber-900/60">
                      <th className="py-3 px-2 border-r border-amber-200 dark:border-amber-900/60 text-[11px]">Date Range</th>
                      <th className="py-3 px-2 border-r border-amber-200 dark:border-amber-900/60">Mon</th>
                      <th className="py-3 px-2 border-r border-amber-200 dark:border-amber-900/60">Tue</th>
                      <th className="py-3 px-2 border-r border-amber-200 dark:border-amber-900/60">Wed</th>
                      <th className="py-3 px-2 border-r border-amber-200 dark:border-amber-900/60">Thu</th>
                      <th className="py-3 px-2 border-r border-amber-200 dark:border-amber-900/60">Fri</th>
                      <th className="py-3 px-2 border-r border-amber-200 dark:border-amber-900/60">Sat</th>
                      <th className="py-3 px-2">Sun</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-amber-200/60 dark:divide-amber-900/40 font-mono">
                    {chartRows.map((row, idx) => (
                      <tr key={idx} className={`hover:bg-orange-50/30 dark:hover:bg-slate-800/40 ${row.isCurrentWeek ? 'bg-orange-50/20 dark:bg-orange-950/10' : ''}`}>
                        <td className="py-2.5 px-2 border-r border-amber-200/60 dark:border-amber-900/40 font-bold whitespace-pre-line text-[10px] text-slate-600 dark:text-slate-400">
                          {row.range}
                        </td>
                        {WEEKDAYS.map((wKey) => {
                          const cell = row.days[wKey];
                          return (
                            <td
                              key={wKey}
                              className={`py-2.5 px-2 border-r last:border-r-0 border-amber-200/60 dark:border-amber-900/40 text-sm font-black relative ${
                                cell.isRedJodi
                                  ? 'text-red-600 bg-red-50/50 dark:bg-red-950/25'
                                  : 'text-slate-900 dark:text-slate-100'
                              } ${cell.isToday ? 'bg-orange-100/40 dark:bg-orange-900/25 ring-1 ring-inset ring-orange-400/50' : ''}`}
                            >
                              <div className="flex flex-col items-center justify-center">
                                <span>{cell.jodi}</span>
                                {cell.isToday && (
                                  <span className="text-[8px] font-bold text-[#FF7700] uppercase tracking-tighter leading-none mt-0.5">
                                    Today
                                  </span>
                                )}
                              </div>
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            /* Detailed Panel Table (Open Pana / Jodi / Close Pana matching authentic Matka panel cards) */
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-amber-200 dark:border-amber-900/60 overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-center border-collapse text-[10px]">
                  <thead>
                    <tr className="bg-[#FFE5D0] dark:bg-orange-950/50 text-[#8B3A00] dark:text-orange-300 font-extrabold border-b border-amber-200 dark:border-amber-900/60">
                      <th className="py-2.5 px-2 border-r border-amber-200 dark:border-amber-900/60">Date</th>
                      <th className="py-2.5 px-1.5 border-r border-amber-200 dark:border-amber-900/60">Mon</th>
                      <th className="py-2.5 px-1.5 border-r border-amber-200 dark:border-amber-900/60">Tue</th>
                      <th className="py-2.5 px-1.5 border-r border-amber-200 dark:border-amber-900/60">Wed</th>
                      <th className="py-2.5 px-1.5 border-r border-amber-200 dark:border-amber-900/60">Thu</th>
                      <th className="py-2.5 px-1.5 border-r border-amber-200 dark:border-amber-900/60">Fri</th>
                      <th className="py-2.5 px-1.5 border-r border-amber-200 dark:border-amber-900/60">Sat</th>
                      <th className="py-2.5 px-1.5">Sun</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-amber-200/60 dark:divide-amber-900/40 font-mono">
                    {chartRows.map((row, idx) => (
                      <tr key={idx} className={`hover:bg-orange-50/30 dark:hover:bg-slate-800/40 ${row.isCurrentWeek ? 'bg-orange-50/20 dark:bg-orange-950/10' : ''}`}>
                        <td className="py-2 px-1 border-r border-amber-200/60 dark:border-amber-900/40 font-bold whitespace-pre-line text-slate-600 dark:text-slate-400">
                          {row.range}
                        </td>
                        {WEEKDAYS.map((wKey) => {
                          const cell = row.days[wKey];
                          return (
                            <td
                              key={wKey}
                              className={`py-2 px-1 border-r last:border-r-0 border-amber-200/60 dark:border-amber-900/40 leading-tight ${
                                cell.isRedJodi
                                  ? 'text-red-600 font-black'
                                  : 'text-slate-900 dark:text-slate-100 font-bold'
                              } ${cell.isToday ? 'bg-orange-100/40 dark:bg-orange-900/25 ring-1 ring-inset ring-orange-400/50' : ''}`}
                            >
                              <div className="text-[9px] text-slate-400 dark:text-slate-500">{cell.openPana}</div>
                              <div className="text-xs font-black my-0.5">{cell.jodi}</div>
                              <div className="text-[9px] text-slate-400 dark:text-slate-500">{cell.closePana}</div>
                              {cell.isToday && (
                                <div className="text-[7px] font-black text-[#FF7700] uppercase tracking-tighter">
                                  Live
                                </div>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
