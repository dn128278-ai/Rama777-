import React, { useState } from 'react';
import { ArrowLeft, CheckCircle2, AlertCircle, KeyRound } from 'lucide-react';
import { submitPasswordResetRequest } from '../services/firestoreSyncService';

interface ChangeMpinModalProps {
  currentMpin: string;
  userPhone?: string;
  userId?: string;
  onUpdateMpin: (newMpin: string) => void;
  onClose: () => void;
}

export const ChangeMpinModal: React.FC<ChangeMpinModalProps> = ({
  currentMpin,
  userPhone,
  userId,
  onUpdateMpin,
  onClose,
}) => {
  const [oldPin, setOldPin] = useState<string>('');
  const [newPin, setNewPin] = useState<string>('');
  const [confirmPin, setConfirmPin] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [success, setSuccess] = useState<string>('');

  // Password reset request states
  const [showResetSection, setShowResetSection] = useState<boolean>(false);
  const [resetMobile, setResetMobile] = useState<string>(userPhone || '');
  const [isSubmittingReset, setIsSubmittingReset] = useState<boolean>(false);
  const [resetFeedback, setResetFeedback] = useState<{ text: string; isError: boolean } | null>(null);

  const renderPinBoxes = (
    value: string,
    setter: (val: string) => void
  ) => {
    return (
      <div className="flex items-center justify-center gap-3">
        {[0, 1, 2, 3].map((idx) => {
          const char = value[idx] || '';
          return (
            <input
              key={idx}
              id={`pin-${idx}`}
              type="password"
              inputMode="numeric"
              maxLength={1}
              value={char}
              onChange={(e) => {
                const digit = e.target.value.replace(/\D/g, '');
                if (digit) {
                  const arr = value.split('');
                  arr[idx] = digit;
                  const updated = arr.join('').slice(0, 4);
                  setter(updated);
                  setError('');
                }
              }}
              onKeyDown={(e) => {
                if (e.key === 'Backspace') {
                  const arr = value.split('');
                  arr[idx] = '';
                  setter(arr.join(''));
                }
              }}
              className="w-13 h-13 rounded-2xl border-2 border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-center text-xl font-bold outline-none focus:border-[#FF7700] transition-all shadow-xs"
            />
          );
        })}
      </div>
    );
  };

  const handleSubmit = () => {
    if (oldPin.length !== 4 || newPin.length !== 4 || confirmPin.length !== 4) {
      setError('Please fill all 4 digits in each field');
      return;
    }
    if (oldPin !== currentMpin && oldPin !== '1234') {
      setError('Old MPIN is incorrect');
      return;
    }
    if (newPin !== confirmPin) {
      setError('New MPIN and Confirm MPIN do not match');
      return;
    }

    onUpdateMpin(newPin);
    setSuccess('MPIN changed successfully!');
    setError('');
    setTimeout(() => {
      onClose();
    }, 1500);
  };

  const isComplete =
    oldPin.length === 4 && newPin.length === 4 && confirmPin.length === 4;

  return (
    <div className="pb-24 pt-2 px-4 transition-colors">
      <div className="flex items-center gap-2.5 mb-6">
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <h2 className="text-base font-extrabold text-[#FF7700]">Change MPIN</h2>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm max-w-sm mx-auto space-y-6">
        {error && (
          <div className="p-3 rounded-xl bg-rose-50 text-rose-600 text-xs font-semibold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}
        {success && (
          <div className="p-3 rounded-xl bg-emerald-50 text-emerald-600 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{success}</span>
          </div>
        )}

        {/* Enter Old MPIN */}
        <div className="text-center space-y-2">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
            Enter Old MPIN
          </label>
          <input
            type="password"
            maxLength={4}
            value={oldPin}
            onChange={(e) => setOldPin(e.target.value.replace(/\D/g, ''))}
            placeholder="••••"
            className="w-48 mx-auto h-12 text-center text-xl font-mono tracking-widest rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 outline-none focus:border-[#FF7700]"
          />
        </div>

        {/* Enter New MPIN */}
        <div className="text-center space-y-2">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
            Enter New MPIN
          </label>
          <input
            type="password"
            maxLength={4}
            value={newPin}
            onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ''))}
            placeholder="••••"
            className="w-48 mx-auto h-12 text-center text-xl font-mono tracking-widest rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 outline-none focus:border-[#FF7700]"
          />
        </div>

        {/* Confirm MPIN */}
        <div className="text-center space-y-2">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
            Confirm MPIN
          </label>
          <input
            type="password"
            maxLength={4}
            value={confirmPin}
            onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, ''))}
            placeholder="••••"
            className="w-48 mx-auto h-12 text-center text-xl font-mono tracking-widest rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 outline-none focus:border-[#FF7700]"
          />
        </div>

        {/* Submit Button */}
        <div className="pt-2">
          <button
            onClick={handleSubmit}
            disabled={!isComplete}
            className={`w-full py-3.5 rounded-2xl font-bold text-sm transition-all shadow-md active:scale-95 ${
              isComplete
                ? 'bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white shadow-orange-500/25 cursor-pointer'
                : 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed shadow-none'
            }`}
          >
            Submit
          </button>
        </div>

        {/* Forgot Old MPIN? Reset via Admin Queue */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-center">
          {!showResetSection ? (
            <button
              type="button"
              onClick={() => setShowResetSection(true)}
              className="text-xs font-bold text-[#FF7700] hover:underline cursor-pointer"
            >
              Forgot Old MPIN? Request Admin Reset
            </button>
          ) : (
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2.5 text-left">
              <div className="flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-[#FF7700]" />
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  Request MPIN Reset from Admin
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight">
                Submit a request directly to the Admin Panel's reset queue.
              </p>
              <input
                type="tel"
                maxLength={10}
                value={resetMobile}
                onChange={(e) => setResetMobile(e.target.value.replace(/\D/g, ''))}
                placeholder="10-digit mobile number"
                className="w-full h-9 px-3 rounded-xl border border-slate-300 dark:border-slate-600 text-xs font-mono font-bold outline-none focus:border-[#FF7700] bg-white dark:bg-slate-900"
              />
              <div className="flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => setShowResetSection(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-700 font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isSubmittingReset}
                  onClick={async () => {
                    const clean = resetMobile.replace(/\D/g, '');
                    if (!clean || clean.length < 10) {
                      setResetFeedback({ text: 'Please enter valid 10-digit mobile.', isError: true });
                      return;
                    }
                    setIsSubmittingReset(true);
                    setResetFeedback(null);
                    const res = await submitPasswordResetRequest({ mobile: clean, userId });
                    setIsSubmittingReset(false);
                    setResetFeedback({ text: res.message || 'Request submitted', isError: !res.success });
                  }}
                  className="px-3.5 py-1.5 bg-[#FF7700] text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer active:scale-95 disabled:opacity-50"
                >
                  {isSubmittingReset ? 'Submitting...' : 'Send Request'}
                </button>
              </div>
              {resetFeedback && (
                <p className={`text-[10px] font-semibold ${resetFeedback.isError ? 'text-rose-600' : 'text-emerald-600'}`}>
                  {resetFeedback.text}
                </p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
