/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  UserProfile,
  FundHistoryItem,
  Transaction,
  BankAccount,
  GameBid,
  AppNotification,
} from '../types';
import { supabase } from '../supabase';
import { toSupabaseUuid } from '../utils/userScope';

export { toSupabaseUuid };

export interface PaymentGatewayConfig {
  merchantVpa: string;
  merchantName: string;
  status: 'active' | 'maintenance' | 'disabled';
  minDeposit: number;
  maxDeposit: number;
  minWithdrawal: number;
  welcomeBonusEnabled: boolean;
  bonusAmount: number;
}

export const DEFAULT_GATEWAY_CONFIG: PaymentGatewayConfig = {
  merchantVpa: '6377972674@kotak',
  merchantName: 'RAMA 777 Official Services',
  status: 'active',
  minDeposit: 100,
  maxDeposit: 100000,
  minWithdrawal: 300,
  welcomeBonusEnabled: true,
  bonusAmount: 100,
};

const KEYS = {
  deposits: 'rama777_deposits',
  withdrawals: 'rama777_withdrawals',
  bids: 'rama777_bids',
  transactions: 'rama777_transactions',
  banks: 'rama777_banks',
  notifications: 'rama777_notifications',
  gateway: 'rama777_gateway_config',
  agents: 'rama777_agents',
};

function getLocal<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function setLocal<T>(key: string, val: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(val));
  } catch {}
}

// ---------------- USER WALLET SYNC (Supabase 'users') ----------------
export function subscribeToUserWallet(
  user: UserProfile,
  callback: (userData: any) => void
): () => void {
  if (!user.phone && !user.uid) return () => {};

  const cleanPhone = (user.phone || '').replace(/\D/g, '');

  const fetchWallet = async () => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .or(`mobile.eq.${cleanPhone},id.eq.${user.uid || user.id}`)
        .maybeSingle();

      if (!error && data) {
        callback({
          walletBalance: Number(data.main_wallet ?? data.wallet_balance ?? user.walletBalance ?? 0),
          mainWallet: Number(data.main_wallet ?? data.wallet_balance ?? user.walletBalance ?? 0),
          winningWallet: Number(data.winning_wallet ?? user.winningWallet ?? 0),
          gamingWallet: Number(data.gaming_wallet ?? data.wallet_balance ?? user.walletBalance ?? 0),
        });
      }
    } catch {}
  };

  fetchWallet();

  const onUserUpdated = (e: Event) => {
    const custom = e as CustomEvent;
    if (custom?.detail) {
      const row = custom.detail;
      if (row.mobile === cleanPhone || row.id === user.uid || row.id === user.id) {
        callback({
          walletBalance: Number(row.main_wallet ?? row.wallet_balance ?? 0),
          mainWallet: Number(row.main_wallet ?? row.wallet_balance ?? 0),
          winningWallet: Number(row.winning_wallet ?? 0),
          gamingWallet: Number(row.gaming_wallet ?? 0),
        });
        return;
      }
    }
    fetchWallet();
  };

  window.addEventListener('rama777:user_updated', onUserUpdated);

  return () => {
    window.removeEventListener('rama777:user_updated', onUserUpdated);
  };
}

export async function syncUserToFirestore(user: UserProfile): Promise<void> {
  const cleanPhone = (user.phone || '').replace(/\D/g, '');
  try {
    const userId = toSupabaseUuid(user.id || user.uid || cleanPhone);
    await supabase.from('users').upsert({
      id: userId,
      name: user.name || 'RAMA Player',
      mobile: cleanPhone,
      mpin: user.mpin || '1234',
      main_wallet: Number(user.walletBalance || user.mainWallet || 0),
      winning_wallet: Number(user.winningWallet || 0),
      gaming_wallet: Number(user.gamingWallet ?? user.walletBalance ?? 0),
      role: user.role || 'user',
      status: 'active',
    });
  } catch (e) {
    console.warn('Sync user to Supabase error:', e);
  }
}

// ---------------- WITHDRAWALS SYNC (Supabase 'withdrawals') ----------------
export function subscribeToWithdrawals(
  user: UserProfile,
  callback: (withdrawals: FundHistoryItem[]) => void
): () => void {
  const local = getLocal<FundHistoryItem[]>(KEYS.withdrawals, []);
  callback(local);

  const cleanPhone = (user.phone || '').replace(/\D/g, '');
  const userId = toSupabaseUuid(user.uid || user.id || cleanPhone);

  const fetchRemoteWithdrawals = async () => {
    try {
      let query = supabase
        .from('withdrawals')
        .select('*')
        .order('created_at', { ascending: false });

      if (cleanPhone && userId) {
        query = query.or(`mobile.eq.${cleanPhone},user_id.eq.${userId}`);
      } else if (cleanPhone) {
        query = query.eq('mobile', cleanPhone);
      } else if (userId) {
        query = query.eq('user_id', userId);
      }

      const { data, error } = await query;

      if (!error && data) {
        const mapped: FundHistoryItem[] = data.map((d: any) => {
          let bankName = 'Bank Account';
          let accountNumber = '';
          let ifscCode = '';
          let orderId = `TNX${(d.id || '').slice(0, 8)}`;

          if (d.bank_details) {
            try {
              const parsed = typeof d.bank_details === 'string' ? JSON.parse(d.bank_details) : d.bank_details;
              bankName = parsed.bankName || parsed.bank || bankName;
              accountNumber = parsed.accountNumber || parsed.account || accountNumber;
              ifscCode = parsed.ifscCode || parsed.ifsc || ifscCode;
              if (parsed.orderId) orderId = parsed.orderId;
            } catch {
              bankName = String(d.bank_details);
            }
          }

          const rawStatus = String(d.status || '').toUpperCase();
          const status =
            rawStatus === 'SUCCESS' || rawStatus === 'APPROVED'
              ? 'Success'
              : rawStatus === 'FAILURE' || rawStatus === 'REJECTED'
              ? 'Failure'
              : 'Pending';

          return {
            id: d.id,
            orderId,
            date: d.created_at ? new Date(d.created_at).toLocaleDateString() : 'Recent',
            amount: Number(d.amount),
            status,
            requestType: 'Debit',
            depositMode: 'Bank Transfer (IMPS)',
            bankName,
            accountNumber,
            ifscCode,
          };
        });
        setLocal(KEYS.withdrawals, mapped);
        callback(mapped);
      }
    } catch {}
  };

  fetchRemoteWithdrawals();

  const channelTopic = `public:user_withdrawals_${cleanPhone || userId || 'anon'}`;
  for (const ch of supabase.getChannels()) {
    if (ch.topic === `realtime:${channelTopic}`) {
      supabase.removeChannel(ch);
    }
  }

  const channel = supabase
    .channel(channelTopic)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'withdrawals' }, () => {
      fetchRemoteWithdrawals();
    })
    .subscribe();

  const onLocal = () => callback(getLocal<FundHistoryItem[]>(KEYS.withdrawals, []));
  window.addEventListener('rama777:withdrawal_updated', onLocal);

  return () => {
    window.removeEventListener('rama777:withdrawal_updated', onLocal);
    supabase.removeChannel(channel);
  };
}

export async function createWithdrawalInFirestore(
  item: FundHistoryItem,
  user: UserProfile
): Promise<void> {
  const local = getLocal<FundHistoryItem[]>(KEYS.withdrawals, []);
  setLocal(KEYS.withdrawals, [item, ...local]);

  const cleanPhone = (user.phone || '').replace(/\D/g, '');
  const withdrawalId = toSupabaseUuid(item.id || item.orderId || `wth_${cleanPhone}_${Date.now()}`);
  const userId = toSupabaseUuid(user.uid || user.id || cleanPhone);
  const bankDetailsStr = JSON.stringify({
    bankName: item.bankName || 'Bank Account',
    accountNumber: item.accountNumber || '',
    ifscCode: item.ifscCode || '',
    orderId: item.orderId || `TNX${withdrawalId.slice(0, 8)}`,
  });

  try {
    const { error } = await supabase.from('withdrawals').insert({
      id: withdrawalId,
      user_id: userId,
      mobile: cleanPhone,
      amount: Number(item.amount),
      status: 'PENDING',
      bank_details: bankDetailsStr,
      created_at: new Date().toISOString(),
    });
    if (error) console.error('[Supabase Withdrawal] Insert error:', error.message);
  } catch (e) {
    console.warn('Create withdrawal in Supabase error:', e);
  }
}

// ---------------- DEPOSITS SYNC (Supabase 'deposits') ----------------
export function subscribeToDeposits(
  user: UserProfile,
  callback: (deposits: FundHistoryItem[]) => void
): () => void {
  const local = getLocal<FundHistoryItem[]>(KEYS.deposits, []);
  callback(local);

  const cleanPhone = (user.phone || '').replace(/\D/g, '');
  const userId = toSupabaseUuid(user.uid || user.id || cleanPhone);

  const fetchRemoteDeposits = async () => {
    try {
      let query = supabase
        .from('deposits')
        .select('*')
        .order('created_at', { ascending: false });

      if (cleanPhone && userId) {
        query = query.or(`mobile.eq.${cleanPhone},user_id.eq.${userId}`);
      } else if (cleanPhone) {
        query = query.eq('mobile', cleanPhone);
      } else if (userId) {
        query = query.eq('user_id', userId);
      }

      const { data, error } = await query;

      if (!error && data) {
        const mapped: FundHistoryItem[] = data.map((d: any) => {
          const rawStatus = String(d.status || '').toUpperCase();
          const status =
            rawStatus === 'SUCCESS' || rawStatus === 'APPROVED'
              ? 'Success'
              : rawStatus === 'FAILURE' || rawStatus === 'REJECTED'
              ? 'Failure'
              : 'Pending';

          return {
            id: d.id,
            orderId: d.utr ? String(d.utr) : `ORD-${(d.id || '').slice(0, 8).toUpperCase()}`,
            date: d.created_at ? new Date(d.created_at).toLocaleDateString() : 'Recent',
            amount: Number(d.amount),
            status,
            requestType: 'Credit',
            depositMode: 'UPI Intent Checkout',
            utrOrReference: d.utr || undefined,
          };
        });
        setLocal(KEYS.deposits, mapped);
        callback(mapped);
      }
    } catch {}
  };

  fetchRemoteDeposits();

  const channelTopic = `public:user_deposits_${cleanPhone || userId || 'anon'}`;
  for (const ch of supabase.getChannels()) {
    if (ch.topic === `realtime:${channelTopic}`) {
      supabase.removeChannel(ch);
    }
  }

  const channel = supabase
    .channel(channelTopic)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'deposits' }, () => {
      fetchRemoteDeposits();
    })
    .subscribe();

  const onLocal = () => callback(getLocal<FundHistoryItem[]>(KEYS.deposits, []));
  window.addEventListener('rama777:deposit_updated', onLocal);

  return () => {
    window.removeEventListener('rama777:deposit_updated', onLocal);
    supabase.removeChannel(channel);
  };
}

export async function createDepositInFirestore(
  item: FundHistoryItem,
  user: UserProfile,
  _bonus: number = 0
): Promise<string> {
  const local = getLocal<FundHistoryItem[]>(KEYS.deposits, []);
  const deduped = [item, ...local.filter((d) => d.id !== item.id && d.orderId !== item.orderId)];
  setLocal(KEYS.deposits, deduped);

  const cleanPhone = (user.phone || '').replace(/\D/g, '');
  const depositId = toSupabaseUuid(item.id || item.orderId || `dep_${cleanPhone}_${Date.now()}`);
  const userId = toSupabaseUuid(user.uid || user.id || cleanPhone);
  const normalizedStatus =
    item.status === 'Pending'
      ? 'PENDING'
      : item.status === 'Success'
      ? 'SUCCESS'
      : item.status === 'Failure'
      ? 'REJECTED'
      : String(item.status || 'PENDING').toUpperCase();

  try {
    const { error } = await supabase.from('deposits').upsert(
      {
        id: depositId,
        user_id: userId,
        mobile: cleanPhone,
        amount: Number(item.amount),
        status: normalizedStatus,
        utr: item.utrOrReference || item.orderId || '',
        created_at: new Date().toISOString(),
      },
      { onConflict: 'id' }
    );
    if (error) console.error('[Supabase Deposit] Insert error:', error.message);
  } catch (e) {
    console.warn('Create deposit in Supabase error:', e);
  }
  return depositId;
}

export async function updateDepositUtrInSupabase(
  depositIdOrOrderId: string,
  utr: string
): Promise<{ success: boolean; message?: string }> {
  const depositId = toSupabaseUuid(depositIdOrOrderId);
  const cleanUtr = utr.trim();
  if (!cleanUtr) return { success: false, message: 'Please enter a valid UTR / Reference ID.' };

  try {
    const { error } = await supabase
      .from('deposits')
      .update({ utr: cleanUtr })
      .eq('id', depositId);
    if (error) {
      console.error('[Supabase Deposit] UTR update error:', error.message);
      return { success: false, message: error.message };
    }
    return { success: true };
  } catch (e: any) {
    return { success: false, message: e?.message || 'Network error updating UTR.' };
  }
}

// ---------------- BIDS SYNC (Supabase 'bids') ----------------
export function subscribeToBids(
  _user: UserProfile,
  callback: (bids: GameBid[]) => void
): () => void {
  const local = getLocal<GameBid[]>(KEYS.bids, []);
  callback(local);

  const cleanPhone = (_user?.phone || '').replace(/\D/g, '');
  const userUuid =
    _user?.uid || _user?.id || cleanPhone ? toSupabaseUuid(_user?.uid || _user?.id || cleanPhone) : '';

  const fetchRemoteBids = async () => {
    try {
      // Plain direct CRUD query on 'bids' table filtered by user UUID when not admin
      let query = supabase
        .from('bids')
        .select('*')
        .order('created_at', { ascending: false });

      if (userUuid && _user?.role !== 'admin') {
        query = query.eq('user_id', userUuid);
      }

      const { data, error } = await query;

      if (error) {
        console.error('[Supabase Data Service] Direct select on bids failed:', error.message || error);
        callback(getLocal<GameBid[]>(KEYS.bids, []));
        return;
      }

      if (data) {
        const cachedMarkets = getLocal<any[]>('rama777_local_markets', []);
        const mapped: GameBid[] = data.map((b: any) => {
          const matchedMarket = cachedMarkets.find(
            (m: any) => m.id === b.market_id || toSupabaseUuid(m.id || m.name) === b.market_id
          );
          return {
            id: b.id,
            marketId: b.market_id,
            marketName: b.market_name || matchedMarket?.name || 'Matka Market',
            gameType: b.game_type,
            session: b.session || 'Open',
            digitOrPana: b.digits,
            points: Number(b.points),
            status:
              b.status === 'WON' || b.status === 'Won'
                ? 'Won'
                : b.status === 'LOST' || b.status === 'Lost'
                ? 'Lost'
                : 'Placed',
            winAmount: b.win_amount ? Number(b.win_amount) : undefined,
            date: b.created_at ? new Date(b.created_at).toLocaleDateString() : 'Recent',
          };
        });
        setLocal(KEYS.bids, mapped);
        callback(mapped);
      }
    } catch (err: any) {
      console.error('[Supabase Data Service] Network failure reading bids, falling back to local state:', err?.message || err);
      callback(getLocal<GameBid[]>(KEYS.bids, []));
    }
  };

  fetchRemoteBids();

  const onLocal = () => {
    callback(getLocal<GameBid[]>(KEYS.bids, []));
    fetchRemoteBids();
  };
  window.addEventListener('rama777:bids_updated', onLocal);

  return () => {
    window.removeEventListener('rama777:bids_updated', onLocal);
  };
}

export async function placeBidInFirestore(
  bid: Omit<GameBid, 'id' | 'date' | 'status'>,
  user: UserProfile
): Promise<void> {
  const now = new Date();
  const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
    .toString()
    .padStart(2, '0')}/${now.getFullYear()}`;

  const newBid: GameBid = {
    ...bid,
    id: `bid_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    date: dateStr,
    status: 'Placed',
  };

  // Optimistic local state update
  const local = getLocal<GameBid[]>(KEYS.bids, []);
  setLocal(KEYS.bids, [newBid, ...local]);
  window.dispatchEvent(new CustomEvent('rama777:bids_updated'));

  // Direct insertion into Supabase 'bids' table with user_id, market_id, game_type, digits, and points
  // for instant real-time synchronization with Admin Panel's Bet Analytics
  try {
    const payload = {
      user_id: toSupabaseUuid(user?.uid || user?.id || user?.phone || '00000000-0000-0000-0000-000000000000'),
      market_id: toSupabaseUuid(bid.marketId || bid.marketName),
      game_type: bid.gameType,
      digits: String(bid.digitOrPana || ''),
      points: Number(bid.points),
      status: 'PENDING',
    };

    const { data, error } = await supabase.from('bids').insert(payload).select();
    if (error) {
      console.error('[Supabase Betting Service] Direct insert into bids table failed:', error.message || error);
    } else {
      console.log('[Supabase Betting Service] Bet directly inserted into bids table:', data);
    }
  } catch (err: any) {
    console.error('[Supabase Betting Service] Network failure during bid insert, retaining local state:', err?.message || err);
  }
}

// ---------------- PASSBOOK / TRANSACTIONS SYNC (Supabase 'transactions' & 'passbook') ----------------
export function subscribeToTransactions(
  user: UserProfile,
  callback: (txs: Transaction[]) => void
): () => void {
  const local = getLocal<Transaction[]>(KEYS.transactions, []);
  callback(local);

  const cleanPhone = (user?.phone || '').replace(/\D/g, '');
  const rawUid = user?.uid || user?.id;
  const userId = rawUid ? toSupabaseUuid(rawUid) : cleanPhone ? toSupabaseUuid(`usr_${cleanPhone}`) : '';

  const fetchRemoteTransactions = async () => {
    try {
      // Fetch from both 'passbook' and 'transactions' directly in parallel
      const passbookQuery = supabase
        .from('passbook')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      const txQuery = supabase
        .from('transactions')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (cleanPhone && userId) {
        passbookQuery.or(`mobile.eq.${cleanPhone},user_id.eq.${userId}`);
        txQuery.eq('user_id', userId);
      } else if (userId) {
        passbookQuery.eq('user_id', userId);
        txQuery.eq('user_id', userId);
      } else if (cleanPhone) {
        passbookQuery.eq('mobile', cleanPhone);
      }

      const [passbookRes, txRes] = await Promise.all([passbookQuery, txQuery]);

      if (passbookRes.error && txRes.error) {
        console.error(
          '[Supabase Data Service] Direct select on passbook/transactions failed:',
          passbookRes.error.message || txRes.error.message
        );
        callback(getLocal<Transaction[]>(KEYS.transactions, []));
        return;
      }

      const mergedMap = new Map<string, { raw: any; source: 'passbook' | 'transactions' }>();

      if (!txRes.error && txRes.data) {
        for (const t of txRes.data) {
          mergedMap.set(String(t.id), { raw: t, source: 'transactions' });
        }
      }

      // Passbook rows take precedence for richer description & mobile metadata
      if (!passbookRes.error && passbookRes.data) {
        for (const p of passbookRes.data) {
          mergedMap.set(String(p.id), { raw: p, source: 'passbook' });
        }
      }

      const sortedEntries = Array.from(mergedMap.values()).sort((a, b) => {
        const ta = a.raw.created_at ? new Date(a.raw.created_at).getTime() : 0;
        const tb = b.raw.created_at ? new Date(b.raw.created_at).getTime() : 0;
        return tb - ta;
      });

      // Walk backwards from current wallet balance when DB rows lack stored balance columns
      let runningBal = Number(user?.walletBalance ?? 0);

      const mapped: Transaction[] = sortedEntries.map(({ raw: t }) => {
        const rawType = String(t.type || 'debit').toLowerCase();
        const isCredit =
          rawType === 'credit' ||
          rawType === 'deposit' ||
          rawType === 'win' ||
          rawType === 'refund' ||
          rawType === 'bonus';

        const amt = Number(t.amount || 0);
        const rawStatus = String(t.status || 'SUCCESS').toUpperCase();
        const status: 'SUCCESS' | 'PENDING' | 'FAILED' =
          rawStatus === 'FAILED' || rawStatus === 'FAILURE' || rawStatus === 'REJECTED'
            ? 'FAILED'
            : rawStatus === 'PENDING'
            ? 'PENDING'
            : 'SUCCESS';

        const curBal =
          t.current_balance !== undefined && t.current_balance !== null
            ? Number(t.current_balance)
            : runningBal;
        const prevBal =
          t.previous_balance !== undefined && t.previous_balance !== null
            ? Number(t.previous_balance)
            : status === 'SUCCESS'
            ? Math.max(0, isCredit ? curBal - amt : curBal + amt)
            : curBal;

        if (status === 'SUCCESS' && (t.previous_balance === undefined || t.previous_balance === null)) {
          runningBal = prevBal;
        }

        const descText = String(t.description || '').trim();
        const [splitTitle, ...restDesc] = descText.includes(' | ')
          ? descText.split(' | ')
          : [descText];

        const fallbackTitle = isCredit
          ? t.payment_gateway === 'WELCOME_BONUS'
            ? 'Welcome Bonus Credited'
            : t.payment_gateway === 'WIN_PAYOUT'
            ? 'Winning Payout Credited'
            : 'Wallet Credit'
          : rawType.includes('withdrawal')
          ? 'Withdrawal Request'
          : 'Wallet Debit';

        return {
          id: t.id,
          title: t.title || splitTitle || fallbackTitle,
          referenceId: t.reference_id || `TX-${String(t.id || '').slice(0, 8).toUpperCase()}`,
          description:
            restDesc.length > 0 ? restDesc.join(' | ') : descText || t.payment_gateway || '',
          amount: amt,
          type: isCredit ? 'credit' : 'debit',
          status,
          date: t.created_at ? new Date(t.created_at).toLocaleString() : 'Recent',
          previousBalance: prevBal,
          currentBalance: curBal,
          userId: t.user_id,
        };
      });

      setLocal(KEYS.transactions, mapped);
      callback(mapped);
    } catch (err: any) {
      console.error(
        '[Supabase Data Service] Network failure reading passbook/transactions, falling back to local state:',
        err?.message || err
      );
      callback(getLocal<Transaction[]>(KEYS.transactions, []));
    }
  };

  fetchRemoteTransactions();

  // Real-time subscriptions to both 'passbook' and 'transactions'
  const topicSuffix = cleanPhone || userId || 'all';
  const passbookTopic = `public:passbook_${topicSuffix}`;
  const txTopic = `public:transactions_${topicSuffix}`;

  for (const ch of supabase.getChannels()) {
    if (ch.topic === `realtime:${passbookTopic}` || ch.topic === `realtime:${txTopic}`) {
      supabase.removeChannel(ch);
    }
  }

  const passbookChannel = supabase
    .channel(passbookTopic)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'passbook' }, () => {
      fetchRemoteTransactions();
    })
    .subscribe();

  const txChannel = supabase
    .channel(txTopic)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'transactions' }, () => {
      fetchRemoteTransactions();
    })
    .subscribe();

  const onLocal = () => {
    callback(getLocal<Transaction[]>(KEYS.transactions, []));
    fetchRemoteTransactions();
  };
  window.addEventListener('rama777:transactions_updated', onLocal);

  return () => {
    window.removeEventListener('rama777:transactions_updated', onLocal);
    supabase.removeChannel(passbookChannel);
    supabase.removeChannel(txChannel);
  };
}

export async function recordTransactionInFirestore(
  tx: Transaction,
  user: UserProfile,
  paymentGateway: string = 'RAMA_WALLET'
): Promise<void> {
  const local = getLocal<Transaction[]>(KEYS.transactions, []);
  const dedupedLocal = [tx, ...local.filter((item) => item.id !== tx.id)];
  setLocal(KEYS.transactions, dedupedLocal);
  window.dispatchEvent(new CustomEvent('rama777:transactions_updated'));

  const cleanPhone = (user?.phone || '').replace(/\D/g, '');
  const txId = toSupabaseUuid(tx.id || tx.referenceId);
  const userId = toSupabaseUuid(user?.uid || user?.id || user?.phone || '00000000-0000-0000-0000-000000000000');
  const nowIso = new Date().toISOString();

  const normalizedType =
    tx.type === 'credit'
      ? 'DEPOSIT'
      : (tx.title || '').toLowerCase().includes('withdrawal')
      ? 'WITHDRAWAL'
      : 'BET_OR_WITHDRAWAL';

  // Direct upsert into 'transactions' table with exact columns supported by table schema
  try {
    const txRow = {
      id: txId,
      user_id: userId,
      amount: Number(tx.amount),
      type: normalizedType,
      status: tx.status || 'SUCCESS',
      payment_gateway: paymentGateway,
      created_at: nowIso,
    };
    const { error } = await supabase.from('transactions').upsert(txRow, { onConflict: 'id' });
    if (error) {
      console.error('[Supabase Data Service] Direct upsert into transactions failed:', error.message || error);
    }
  } catch (e: any) {
    console.error('[Supabase Data Service] Network failure recording transaction:', e?.message || e);
  }

  // Direct upsert into 'passbook' table
  try {
    const passbookDesc = tx.description
      ? `${tx.title} | ${tx.description}`
      : tx.title || 'Wallet Transaction';
    const passbookRow = {
      id: txId,
      user_id: userId,
      mobile: cleanPhone,
      type: tx.type,
      amount: Number(tx.amount),
      description: passbookDesc,
      status: tx.status || 'SUCCESS',
      created_at: nowIso,
    };
    const { error } = await supabase.from('passbook').upsert(passbookRow, { onConflict: 'id' });
    if (error) {
      console.error('[Supabase Data Service] Direct upsert into passbook failed:', error.message || error);
    }
  } catch (e: any) {
    console.error('[Supabase Data Service] Network failure recording passbook:', e?.message || e);
  }
}

// ---------------- BANK ACCOUNTS SYNC ----------------
export function subscribeToBankAccounts(
  _user: UserProfile,
  callback: (banks: BankAccount[]) => void
): () => void {
  const local = getLocal<BankAccount[]>(KEYS.banks, []);
  callback(local);

  const onLocal = () => callback(getLocal<BankAccount[]>(KEYS.banks, []));
  window.addEventListener('rama777:banks_updated', onLocal);

  return () => {
    window.removeEventListener('rama777:banks_updated', onLocal);
  };
}

export async function addBankAccountToFirestore(
  bankData: Omit<BankAccount, 'id' | 'updatedAt'>,
  _user: UserProfile
): Promise<void> {
  const newBank: BankAccount = {
    ...bankData,
    id: `bank_${Date.now()}`,
    updatedAt: new Date().toLocaleDateString('en-GB'),
  };
  const local = getLocal<BankAccount[]>(KEYS.banks, []);
  setLocal(KEYS.banks, [newBank, ...local]);
  window.dispatchEvent(new CustomEvent('rama777:banks_updated'));
}

// ---------------- PAYMENT GATEWAY & NOTIFICATIONS (Supabase 'payment_settings') ----------------
export async function fetchPaymentSettingsFromSupabase(): Promise<PaymentGatewayConfig> {
  const cached = getLocal<PaymentGatewayConfig>(KEYS.gateway, DEFAULT_GATEWAY_CONFIG);
  try {
    const { data, error } = await supabase
      .from('payment_settings')
      .select('*')
      .order('updated_at', { ascending: false });

    if (!error && data && data.length > 0) {
      const activeRow = data.find((r: any) => r.is_active === true) || data[0];
      const nextCfg: PaymentGatewayConfig = {
        ...cached,
        merchantVpa: String(activeRow.merchant_upi_id || cached.merchantVpa || DEFAULT_GATEWAY_CONFIG.merchantVpa).trim(),
        merchantName: String(activeRow.merchant_name || cached.merchantName || DEFAULT_GATEWAY_CONFIG.merchantName).trim(),
        status: activeRow.is_active === false ? 'disabled' : 'active',
      };
      setLocal(KEYS.gateway, nextCfg);
      return nextCfg;
    }
  } catch (e) {
    console.warn('[Supabase Payment Settings] Fetch note:', e);
  }
  return cached;
}

export async function updatePaymentSettingsInSupabase(params: {
  merchantUpiId: string;
  merchantName: string;
  isActive?: boolean;
}): Promise<{ success: boolean; message?: string }> {
  try {
    const nowIso = new Date().toISOString();
    const { data: existing } = await supabase.from('payment_settings').select('id').limit(1);
    if (existing && existing.length > 0) {
      const { error } = await supabase
        .from('payment_settings')
        .update({
          merchant_upi_id: params.merchantUpiId.trim(),
          merchant_name: params.merchantName.trim(),
          is_active: params.isActive !== false,
          updated_at: nowIso,
        })
        .eq('id', existing[0].id);
      if (error) return { success: false, message: error.message };
    } else {
      const { error } = await supabase.from('payment_settings').insert({
        merchant_upi_id: params.merchantUpiId.trim(),
        merchant_name: params.merchantName.trim(),
        is_active: params.isActive !== false,
        updated_at: nowIso,
      });
      if (error) return { success: false, message: error.message };
    }

    const updatedCfg: PaymentGatewayConfig = {
      ...getLocal<PaymentGatewayConfig>(KEYS.gateway, DEFAULT_GATEWAY_CONFIG),
      merchantVpa: params.merchantUpiId.trim(),
      merchantName: params.merchantName.trim(),
      status: params.isActive === false ? 'disabled' : 'active',
    };
    setLocal(KEYS.gateway, updatedCfg);
    window.dispatchEvent(new CustomEvent('rama777:payment_settings_updated', { detail: updatedCfg }));
    return { success: true };
  } catch (e: any) {
    return { success: false, message: e?.message || 'Failed to update payment settings' };
  }
}

export function subscribeToPaymentGateway(
  callback: (config: PaymentGatewayConfig) => void
): () => void {
  const cfg = getLocal<PaymentGatewayConfig>(KEYS.gateway, DEFAULT_GATEWAY_CONFIG);
  callback(cfg);

  const syncLive = () => {
    fetchPaymentSettingsFromSupabase().then((live) => {
      callback(live);
    });
  };

  syncLive();

  const channelTopic = 'public:payment_settings';
  for (const ch of supabase.getChannels()) {
    if (ch.topic === `realtime:${channelTopic}`) {
      supabase.removeChannel(ch);
    }
  }

  const channel = supabase
    .channel(channelTopic)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'payment_settings' }, () => {
      syncLive();
    })
    .subscribe();

  const onLocalUpdated = (e: Event) => {
    const custom = e as CustomEvent<PaymentGatewayConfig>;
    if (custom?.detail) callback(custom.detail);
    else syncLive();
  };
  window.addEventListener('rama777:payment_settings_updated', onLocalUpdated);

  return () => {
    window.removeEventListener('rama777:payment_settings_updated', onLocalUpdated);
    supabase.removeChannel(channel);
  };
}

const READ_NOTIFS_KEY = 'rama777_read_notifs';
const CLEARED_NOTIFS_KEY = 'rama777_cleared_notifs';
const ZERO_UUID = '00000000-0000-0000-0000-000000000000';

export function markAllNotificationsRead(notifIds: string[]): void {
  const existing = new Set(getLocal<string[]>(READ_NOTIFS_KEY, []));
  notifIds.forEach((id) => existing.add(id));
  setLocal(READ_NOTIFS_KEY, Array.from(existing));
  const current = getLocal<AppNotification[]>(KEYS.notifications, []);
  const updated = current.map((n) => ({ ...n, read: true }));
  setLocal(KEYS.notifications, updated);
  window.dispatchEvent(new CustomEvent('rama777:notifications_updated'));
}

export function clearAllNotifications(notifIds: string[]): void {
  const existing = new Set(getLocal<string[]>(CLEARED_NOTIFS_KEY, []));
  notifIds.forEach((id) => existing.add(id));
  setLocal(CLEARED_NOTIFS_KEY, Array.from(existing));
  setLocal(KEYS.notifications, []);
  window.dispatchEvent(new CustomEvent('rama777:notifications_updated'));
}

export function subscribeToNotifications(
  userPhoneOrId: string | undefined,
  callback: (notifs: AppNotification[], hasData: boolean) => void
): () => void {
  const notifs = getLocal<AppNotification[]>(KEYS.notifications, []);
  callback(notifs, true);

  const cleanPhone = (userPhoneOrId || '').replace(/\D/g, '');
  const currentUserId = cleanPhone ? toSupabaseUuid(`usr_${cleanPhone}`) : userPhoneOrId ? toSupabaseUuid(userPhoneOrId) : '';

  const isRelevantNotif = (n: any): boolean => {
    if (!n) return false;
    if (!n.user_id || n.user_id === ZERO_UUID) return true;
    if (currentUserId && n.user_id === currentUserId) return true;
    if (userPhoneOrId && n.user_id === userPhoneOrId) return true;
    return false;
  };

  const fetchRemoteNotifs = async () => {
    try {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (!error && data) {
        const readSet = new Set(getLocal<string[]>(READ_NOTIFS_KEY, []));
        const clearedSet = new Set(getLocal<string[]>(CLEARED_NOTIFS_KEY, []));

        const mapped: AppNotification[] = data
          .filter((n: any) => isRelevantNotif(n) && !clearedSet.has(String(n.id)))
          .map((n: any) => ({
            id: n.id,
            title: n.title || 'Admin Alert',
            message: n.message || '',
            time: n.created_at
              ? new Date(n.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
              : 'Just now',
            read: readSet.has(String(n.id)),
            type: n.type || 'alert',
          }));

        setLocal(KEYS.notifications, mapped);
        callback(mapped, true);
      }
    } catch (e) {
      console.warn('Notifications fetch notice:', e);
    }
  };

  fetchRemoteNotifs();

  const channelTopic = 'public:notifications_feed';
  for (const ch of supabase.getChannels()) {
    if (ch.topic === `realtime:${channelTopic}`) {
      supabase.removeChannel(ch);
    }
  }

  const channel = supabase
    .channel(channelTopic)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'notifications' }, (payload: any) => {
      if (payload?.eventType === 'INSERT' && payload?.new && isRelevantNotif(payload.new)) {
        window.dispatchEvent(
          new CustomEvent('rama777:admin_alert', {
            detail: {
              id: payload.new.id,
              title: payload.new.title || 'Admin Alert',
              message: payload.new.message || '',
              type: payload.new.type || 'alert',
            },
          })
        );
      }
      fetchRemoteNotifs();
    })
    .subscribe();

  const onLocal = () => {
    const fresh = getLocal<AppNotification[]>(KEYS.notifications, []);
    callback(fresh, true);
  };
  window.addEventListener('rama777:notifications_updated', onLocal);

  return () => {
    window.removeEventListener('rama777:notifications_updated', onLocal);
    supabase.removeChannel(channel);
  };
}

export async function broadcastNotificationInFirestore(notif: any): Promise<void> {
  const newNotif: AppNotification = {
    id: `notif_${Date.now()}`,
    title: notif.title,
    message: notif.message,
    time: notif.time || 'Just now',
    read: false,
    type: notif.type || 'alert',
  };
  const current = getLocal<AppNotification[]>(KEYS.notifications, []);
  setLocal(KEYS.notifications, [newNotif, ...current]);
  window.dispatchEvent(new CustomEvent('rama777:notifications_updated'));

  try {
    await supabase.from('notifications').insert({
      id: toSupabaseUuid(newNotif.id),
      user_id: toSupabaseUuid('00000000-0000-0000-0000-000000000000'),
      title: notif.title || 'Notification',
      message: notif.message || '',
      type: notif.type || 'alert',
      created_at: new Date().toISOString(),
    });
  } catch (e) {
    console.warn('Supabase notification broadcast notice:', e);
  }
}

// ---------------- PASSWORD RESET REQUESTS (Supabase 'password_reset_requests') ----------------
export async function submitPasswordResetRequest(params: {
  mobile: string;
  userId?: string;
  name?: string;
  reason?: string;
}): Promise<{ success: boolean; message?: string }> {
  const cleanPhone = params.mobile.replace(/\D/g, '');
  if (!cleanPhone || cleanPhone.length < 10) {
    return { success: false, message: 'Please provide a valid 10-digit mobile number.' };
  }

  const userId = toSupabaseUuid(params.userId || cleanPhone);
  const reqId = toSupabaseUuid(`reset_${cleanPhone}_${Date.now()}`);

  try {
    const reqPayload = {
      id: reqId,
      user_id: userId,
      mobile: cleanPhone,
      status: 'PENDING',
      created_at: new Date().toISOString(),
    };
    const { error } = await supabase.from('password_reset_requests').insert(reqPayload);
    if (error) {
      console.error('[Supabase Reset Service] Reset request failed:', error.message || error);
      return { success: false, message: error.message };
    }
    return { success: true, message: 'MPIN reset request submitted directly to Admin queue!' };
  } catch (e: any) {
    console.error('[Supabase Reset Service] Reset request exception:', e?.message || e);
    return { success: false, message: e?.message || 'Failed to submit reset request.' };
  }
}

export async function seedInitialDataToFirestore(): Promise<void> {}

// ---------------- ADMIN PANEL SUPABASE OPERATIONS ----------------
export async function fetchAdminUsers(): Promise<any[]> {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .order('created_at', { ascending: false });
    if (!error && data) return data;
  } catch {}
  return [];
}

export async function updateUserWalletInSupabase(
  userId: string,
  mobile: string,
  newBalance: number,
  delta: number
): Promise<void> {
  const safeUserId = toSupabaseUuid(userId || mobile);
  try {
    await supabase
      .from('users')
      .update({
        main_wallet: newBalance,
        gaming_wallet: newBalance,
      })
      .or(`id.eq.${safeUserId},mobile.eq.${mobile}`);

    const isCredit = delta >= 0;
    const now = new Date();
    const txId = toSupabaseUuid(`admin_adj_${mobile}_${Date.now()}`);
    await supabase.from('passbook').insert({
      id: txId,
      user_id: safeUserId,
      mobile: mobile,
      type: isCredit ? 'credit' : 'debit',
      amount: Math.abs(delta),
      description: `Operator balance adjustment: ${isCredit ? '+' : ''}₹${delta}`,
      status: 'SUCCESS',
      created_at: now.toISOString(),
    });
    await supabase.from('transactions').insert({
      id: txId,
      user_id: safeUserId,
      amount: Math.abs(delta),
      type: isCredit ? 'DEPOSIT' : 'WITHDRAWAL',
      status: 'SUCCESS',
      payment_gateway: 'ADMIN_ADJUSTMENT',
      created_at: now.toISOString(),
    });
  } catch (e) {
    console.warn('Update user wallet error:', e);
  }
}

export async function fetchAdminDeposits(): Promise<any[]> {
  try {
    const { data, error } = await supabase
      .from('deposits')
      .select('*')
      .order('created_at', { ascending: false });
    if (!error && data) return data;
  } catch {}
  return getLocal<any[]>(KEYS.deposits, []);
}

export async function updateDepositStatusInSupabase(
  id: string,
  status: 'Success' | 'Failure',
  mobile: string,
  amount: number
): Promise<void> {
  try {
    await supabase.from('deposits').update({ status }).eq('id', id);

    if (status === 'Success' && mobile && amount > 0) {
      const { data: userRow } = await supabase.from('users').select('*').eq('mobile', mobile).maybeSingle();
      if (userRow) {
        const curBal = Number(userRow.main_wallet ?? 0);
        const newBal = curBal + amount;
        await supabase
          .from('users')
          .update({ main_wallet: newBal, gaming_wallet: newBal })
          .eq('id', userRow.id);

        const now = new Date();
        const txId = toSupabaseUuid(`dep_approved_${id}`);
        await supabase.from('passbook').insert({
          id: txId,
          user_id: userRow.id,
          mobile,
          type: 'credit',
          amount,
          description: `Approved deposit of ₹${amount}`,
          status: 'SUCCESS',
          created_at: now.toISOString(),
        });
        await supabase.from('transactions').insert({
          id: txId,
          user_id: userRow.id,
          amount,
          type: 'DEPOSIT',
          status: 'SUCCESS',
          payment_gateway: 'UPI_GATEWAY',
          created_at: now.toISOString(),
        });
      }
    }
  } catch {}

  const deposits = getLocal<any[]>(KEYS.deposits, []);
  const match = deposits.find((d) => d.id === id);
  if (match) {
    match.status = status;
    setLocal(KEYS.deposits, deposits);
    window.dispatchEvent(new CustomEvent('rama777:deposit_updated'));
  }
}

export async function fetchAdminWithdrawals(): Promise<any[]> {
  try {
    const { data, error } = await supabase
      .from('withdrawals')
      .select('*')
      .order('created_at', { ascending: false });
    if (!error && data) return data;
  } catch {}
  return getLocal<any[]>(KEYS.withdrawals, []);
}

export async function updateWithdrawalStatusInSupabase(
  id: string,
  status: 'Success' | 'Failure',
  _mobile: string,
  _amount: number
): Promise<void> {
  try {
    await supabase.from('withdrawals').update({ status }).eq('id', id);

    if (status === 'Failure' && _mobile && _amount > 0) {
      const { data: userRow } = await supabase.from('users').select('*').eq('mobile', _mobile).maybeSingle();
      if (userRow) {
        const curBal = Number(userRow.main_wallet ?? 0);
        const newBal = curBal + _amount;
        await supabase
          .from('users')
          .update({ main_wallet: newBal, gaming_wallet: newBal })
          .eq('id', userRow.id);

        const now = new Date();
        const txId = toSupabaseUuid(`wth_refund_${id}`);
        await supabase.from('passbook').insert({
          id: txId,
          user_id: userRow.id,
          mobile: _mobile,
          type: 'credit',
          amount: _amount,
          description: `Refund for rejected withdrawal ₹${_amount}`,
          status: 'SUCCESS',
          created_at: now.toISOString(),
        });
        await supabase.from('transactions').insert({
          id: txId,
          user_id: userRow.id,
          amount: _amount,
          type: 'DEPOSIT',
          status: 'SUCCESS',
          payment_gateway: 'REFUND',
          created_at: now.toISOString(),
        });
      }
    }
  } catch {}

  const withdrawals = getLocal<any[]>(KEYS.withdrawals, []);
  const match = withdrawals.find((w) => w.id === id);
  if (match) {
    match.status = status;
    setLocal(KEYS.withdrawals, withdrawals);
    window.dispatchEvent(new CustomEvent('rama777:withdrawal_updated'));
  }
}

export async function fetchAdminAgents(): Promise<any[]> {
  try {
    const { data, error } = await supabase.from('agents').select('*');
    if (!error && data) return data;
  } catch {}
  return [];
}

export async function createAgentInSupabase(agentData: any): Promise<void> {
  const current = getLocal<any[]>(KEYS.agents, []);
  setLocal(KEYS.agents, [{ ...agentData, id: `ag_${Date.now()}` }, ...current]);
  try {
    await supabase.from('agents').insert(agentData);
  } catch {}
}

export async function updateAgentInSupabase(id: string, agentData: any): Promise<void> {
  const current = getLocal<any[]>(KEYS.agents, []);
  const match = current.find((a) => a.id === id);
  if (match) {
    Object.assign(match, agentData);
    setLocal(KEYS.agents, current);
  }
  try {
    await supabase.from('agents').update(agentData).eq('id', id);
  } catch {}
}
