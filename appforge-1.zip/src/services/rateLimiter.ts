/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

interface RateLimitEntry {
  timestamps: number[];
}

const rateLimitStore = new Map<string, RateLimitEntry>();

const LIMITS: Record<string, { max: number; windowMs: number; label: string }> = {
  'game:place_bid': { max: 30, windowMs: 10000, label: 'Bids' },
  'funds:deposit': { max: 10, windowMs: 60000, label: 'Deposits' },
  'funds:withdraw': { max: 5, windowMs: 60000, label: 'Withdrawals' },
};

export function checkRateLimit(
  action: string,
  userKey: string
): { allowed: boolean; errorMessage?: string } {
  const config = LIMITS[action];
  if (!config) return { allowed: true };

  const key = `${action}:${userKey}`;
  const now = Date.now();
  const entry = rateLimitStore.get(key) || { timestamps: [] };

  // Remove timestamps outside window
  entry.timestamps = entry.timestamps.filter((t) => now - t < config.windowMs);
  rateLimitStore.set(key, entry);

  if (entry.timestamps.length >= config.max) {
    return {
      allowed: false,
      errorMessage: `Too many ${config.label} requests. Please slow down and try again in a few moments.`,
    };
  }

  return { allowed: true };
}

export function recordActionAttempt(
  action: string,
  userKey: string,
  _success: boolean = true
): void {
  const key = `${action}:${userKey}`;
  const now = Date.now();
  const entry = rateLimitStore.get(key) || { timestamps: [] };
  entry.timestamps.push(now);
  rateLimitStore.set(key, entry);
}
