/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { supabase } from '../supabase';

export interface GameRateItem {
  id?: string;
  name: string;
  ratio: string;
  multiplier: number;
  icon: string;
}

export interface GameRateSection {
  sectionKey: string;
  category: string;
  items: GameRateItem[];
}

export const DEFAULT_GAME_RATES: GameRateSection[] = [
  {
    sectionKey: 'RAMA777',
    category: 'RAMA777 Live Game Rates',
    items: [
      { id: 'gr_1', name: 'Single Digit', ratio: '1 : 10', multiplier: 10, icon: 'dice-1' },
      { id: 'gr_2', name: 'Jodi Digits', ratio: '1 : 100', multiplier: 100, icon: 'dice-2' },
      { id: 'gr_3', name: 'Single Pana', ratio: '1 : 160', multiplier: 160, icon: 'spade' },
      { id: 'gr_4', name: 'Double Pana', ratio: '1 : 320', multiplier: 320, icon: 'spade-pair' },
      { id: 'gr_5', name: 'Triple Pana', ratio: '1 : 1000', multiplier: 1000, icon: 'cards-3' },
      { id: 'gr_6', name: 'Half Sangam', ratio: '1 : 1000', multiplier: 1000, icon: 'coin-a' },
      { id: 'gr_7', name: 'Full Sangam', ratio: '1 : 10000', multiplier: 10000, icon: 'coin-gold' },
      { id: 'gr_8', name: 'Red Brackets', ratio: '1 : 100', multiplier: 100, icon: 'brackets' },
    ],
  },
  {
    sectionKey: 'BOMBAY STARLINE',
    category: 'BOMBAY STARLINE Rates',
    items: [
      { id: 'bs_1', name: 'Starline Single Digit', ratio: '1 : 10', multiplier: 10, icon: 'dice-1' },
      { id: 'bs_2', name: 'Starline Single Pana', ratio: '1 : 160', multiplier: 160, icon: 'spade' },
      { id: 'bs_3', name: 'Starline Double Pana', ratio: '1 : 320', multiplier: 320, icon: 'spade-pair' },
      { id: 'bs_4', name: 'Starline Triple Pana', ratio: '1 : 1000', multiplier: 1000, icon: 'cards-3' },
    ],
  },
  {
    sectionKey: 'BOMBAY JACKPOT',
    category: 'BOMBAY JACKPOT Rates',
    items: [
      { id: 'bj_1', name: 'Jackpot Jodi', ratio: '1 : 100', multiplier: 100, icon: 'dice-2' },
    ],
  },
];

// Live multiplier cache populated from Supabase 'game_rates' table
let liveGameRateSections: GameRateSection[] = DEFAULT_GAME_RATES;
const liveMultiplierMap: Record<string, number> = {};

function normalizeRateKey(raw: string = ''): string {
  return raw.toLowerCase().replace(/[^a-z0-9]/g, '');
}

function seedDefaultMultiplierMap() {
  for (const sec of DEFAULT_GAME_RATES) {
    for (const item of sec.items) {
      liveMultiplierMap[normalizeRateKey(item.name)] = item.multiplier;
    }
  }
}
seedDefaultMultiplierMap();

export function getLiveGameRateSections(): GameRateSection[] {
  return liveGameRateSections;
}

export function getGameMultiplier(gameTypeStr: string = ''): number {
  const norm = normalizeRateKey(gameTypeStr);
  if (!norm) return 10;

  // 1. Direct match in live Supabase rates cache
  if (liveMultiplierMap[norm] !== undefined) {
    return liveMultiplierMap[norm];
  }

  // 2. Alias / partial match against live Supabase rates cache
  const aliasCandidates: Array<[string, string[]]> = [
    ['fullsangam', ['fullsangam']],
    ['halfsangam', ['halfsangam']],
    ['triplepana', ['triplepana', 'starlinetriplepana']],
    ['doublepana', ['doublepana', 'starlinedoublepana']],
    ['singlepana', ['singlepana', 'starlinesinglepana', 'spmotor', 'dpmotor']],
    ['redbrackets', ['redbrackets', 'bracket']],
    ['jackpotjodi', ['jackpotjodi']],
    ['jodidigits', ['jodidigit', 'jodidigits', 'jodi']],
    ['singledigit', ['singledigit', 'oddeven', 'starlinesingledigit', 'starline']],
  ];

  for (const [canonicalKey, patterns] of aliasCandidates) {
    if (patterns.some((p) => norm.includes(p))) {
      // Check specific match in liveMultiplierMap first (e.g. starlinesinglepana vs singlepana)
      for (const pat of patterns) {
        if (liveMultiplierMap[pat] !== undefined) {
          return liveMultiplierMap[pat];
        }
      }
      if (liveMultiplierMap[canonicalKey] !== undefined) {
        return liveMultiplierMap[canonicalKey];
      }
    }
  }

  // 3. Standard fallback defaults
  if (norm.includes('fullsangam')) return 10000;
  if (norm.includes('halfsangam')) return 1000;
  if (norm.includes('triplepana')) return 1000;
  if (norm.includes('doublepana')) return 320;
  if (norm.includes('singlepana') || norm.includes('spmotor') || norm.includes('dpmotor')) return 160;
  if (norm.includes('jodi') || norm.includes('redbracket') || norm.includes('jackpot')) return 100;
  if (norm.includes('singledigit') || norm.includes('oddeven') || norm.includes('starline')) return 10;
  return 10;
}

export function calculateEstimatedPayout(points: number, gameType: string): number {
  return points * getGameMultiplier(gameType);
}

function parseMultiplierValue(row: any, fallbackName: string): number {
  const candidates = [row.multiplier, row.rate, row.win_multiplier, row.payout, row.value];
  for (const c of candidates) {
    const num = Number(c);
    if (!Number.isNaN(num) && num > 0) return num;
  }
  if (typeof row.ratio === 'string' && row.ratio.includes(':')) {
    const parts = row.ratio.split(':');
    const rhs = Number(parts[1]?.trim());
    if (!Number.isNaN(rhs) && rhs > 0) return rhs;
  }
  return getGameMultiplier(fallbackName);
}

export async function fetchGameRatesFromSupabase(): Promise<GameRateSection[]> {
  try {
    const { data, error } = await supabase.from('game_rates').select('*');
    if (!error && data && data.length > 0) {
      // Support either multi-row (one row per game type) OR single-row config object
      const isSingleConfigRow =
        data.length === 1 &&
        !data[0].game_type &&
        !data[0].name &&
        (data[0].single_digit !== undefined || data[0].jodi !== undefined || data[0].single_pana !== undefined);

      if (isSingleConfigRow) {
        const cfg = data[0];
        const fieldMap: Array<[string, string, string]> = [
          ['single_digit', 'Single Digit', 'dice-1'],
          ['jodi', 'Jodi Digits', 'dice-2'],
          ['jodi_digit', 'Jodi Digits', 'dice-2'],
          ['single_pana', 'Single Pana', 'spade'],
          ['double_pana', 'Double Pana', 'spade-pair'],
          ['triple_pana', 'Triple Pana', 'cards-3'],
          ['half_sangam', 'Half Sangam', 'coin-a'],
          ['full_sangam', 'Full Sangam', 'coin-gold'],
          ['red_brackets', 'Red Brackets', 'brackets'],
        ];
        for (const [col, label] of fieldMap) {
          const val = Number(cfg[col]);
          if (!Number.isNaN(val) && val > 0) {
            liveMultiplierMap[normalizeRateKey(label)] = val;
          }
        }
      } else {
        for (const r of data) {
          const name = String(r.game_type || r.name || r.title || '').trim();
          if (!name) continue;
          const mult = parseMultiplierValue(r, name);
          liveMultiplierMap[normalizeRateKey(name)] = mult;
        }
      }

      // Rebuild categorized sections with live multipliers merged in
      const updatedSections: GameRateSection[] = DEFAULT_GAME_RATES.map((sec) => ({
        ...sec,
        items: sec.items.map((item) => {
          const liveMult = liveMultiplierMap[normalizeRateKey(item.name)];
          if (liveMult && liveMult > 0) {
            return {
              ...item,
              multiplier: liveMult,
              ratio: `1 : ${liveMult}`,
            };
          }
          return item;
        }),
      }));

      // Include any extra custom game types defined in Supabase game_rates
      if (!isSingleConfigRow) {
        const knownKeys = new Set(
          updatedSections.flatMap((s) => s.items.map((i) => normalizeRateKey(i.name)))
        );
        const extraItems: GameRateItem[] = [];
        for (let idx = 0; idx < data.length; idx++) {
          const r = data[idx];
          const name = String(r.game_type || r.name || r.title || '').trim();
          if (name && !knownKeys.has(normalizeRateKey(name))) {
            const mult = parseMultiplierValue(r, name);
            extraItems.push({
              id: r.id || `gr_custom_${idx}`,
              name,
              ratio: r.ratio || `1 : ${mult}`,
              multiplier: mult,
              icon: r.icon || 'dice-1',
            });
          }
        }
        if (extraItems.length > 0) {
          updatedSections[0] = {
            ...updatedSections[0],
            items: [...updatedSections[0].items, ...extraItems],
          };
        }
      }

      liveGameRateSections = updatedSections;
      window.dispatchEvent(new CustomEvent('rama777:game_rates_updated', { detail: updatedSections }));
      return updatedSections;
    }
  } catch (e) {
    console.warn('fetchGameRates note:', e);
  }
  return liveGameRateSections;
}

export function subscribeToGameRates(callback: (rates: GameRateSection[]) => void): () => void {
  // Emit current cached rates immediately, then fetch fresh from Supabase
  callback(liveGameRateSections);
  fetchGameRatesFromSupabase().then(callback);

  const channelTopic = 'public:game_rates';
  for (const ch of supabase.getChannels()) {
    if (ch.topic === `realtime:${channelTopic}`) {
      supabase.removeChannel(ch);
    }
  }

  const channel = supabase
    .channel(channelTopic)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'game_rates' }, () => {
      fetchGameRatesFromSupabase().then(callback);
    })
    .subscribe();

  const onUpdated = (e: Event) => {
    const custom = e as CustomEvent<GameRateSection[]>;
    if (custom?.detail) {
      callback(custom.detail);
    } else {
      callback(liveGameRateSections);
    }
  };
  window.addEventListener('rama777:game_rates_updated', onUpdated);

  return () => {
    window.removeEventListener('rama777:game_rates_updated', onUpdated);
    supabase.removeChannel(channel);
  };
}

export function listenToWinningCredits(
  _userId: string,
  _userPhone: string,
  _callback: (winData: any) => void
): () => void {
  // Hook for Supabase realtime payouts if needed
  return () => {};
}

/**
 * When a result is declared in admin or simulation, evaluate all placed bids for that market
 * and settle winnings via local events & Supabase updates.
 */
export async function evaluateAndSettleBidsForMarket(params: {
  marketId?: string;
  marketName: string;
  openPana?: string;
  jodi?: string;
  closePana?: string;
}): Promise<void> {
  const openDigit = params.openPana
    ? (parseInt(params.openPana[0], 10) + parseInt(params.openPana[1], 10) + parseInt(params.openPana[2], 10)) % 10
    : null;

  const closeDigit = params.closePana
    ? (parseInt(params.closePana[0], 10) + parseInt(params.closePana[1], 10) + parseInt(params.closePana[2], 10)) % 10
    : null;

  const expectedJodi =
    params.jodi || (openDigit !== null && closeDigit !== null ? `${openDigit}${closeDigit}` : null);

  // Read bids from local storage
  const storedBidsRaw = localStorage.getItem('rama777_bids');
  if (storedBidsRaw) {
    try {
      const bids = JSON.parse(storedBidsRaw);
      let updated = false;

      for (const b of bids) {
        if (
          b.status === 'Placed' &&
          (b.marketName.toLowerCase() === params.marketName.toLowerCase() ||
            (params.marketId && b.marketId === params.marketId))
        ) {
          let isWon = false;
          const num = String(b.digitOrPana || '').trim();
          const gType = (b.gameType || '').toLowerCase();

          if (gType.includes('single digit') || gType.includes('odd even')) {
            if (b.session === 'Open' && openDigit !== null && num === String(openDigit)) {
              isWon = true;
            } else if (b.session === 'Close' && closeDigit !== null && num === String(closeDigit)) {
              isWon = true;
            }
          } else if (gType.includes('jodi') || gType.includes('red brackets')) {
            if (expectedJodi && num === expectedJodi) {
              isWon = true;
            }
          } else if (gType.includes('single pana') || gType.includes('double pana') || gType.includes('triple pana')) {
            if (b.session === 'Open' && params.openPana && num === params.openPana) {
              isWon = true;
            } else if (b.session === 'Close' && params.closePana && num === params.closePana) {
              isWon = true;
            }
          }

          if (isWon) {
            b.status = 'Won';
            const mult = getGameMultiplier(b.gameType);
            const winAmount = Number(b.points) * mult;
            b.winAmount = winAmount;
            updated = true;

            // Dispatch global event for App.tsx listener
            window.dispatchEvent(
              new CustomEvent('rama777:bet_won', {
                detail: {
                  bidId: b.id,
                  marketName: b.marketName,
                  gameType: b.gameType,
                  amount: winAmount,
                  digits: b.digitOrPana,
                  multiplier: mult,
                },
              })
            );
          } else if (openDigit !== null && closeDigit !== null) {
            b.status = 'Lost';
            updated = true;
          }
        }
      }

      if (updated) {
        localStorage.setItem('rama777_bids', JSON.stringify(bids));
      }
    } catch (e) {
      console.warn('Bid evaluation error:', e);
    }
  }
}
