/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Initializes a session watchdog that tracks user activity (15-min idle timeout)
 * and verifies local storage validity.
 */
export function initSessionWatchdog(
  onSessionExpired: (reason: string) => void
): () => void {
  const IDLE_TIMEOUT_MS = 15 * 60 * 1000; // 15 minutes
  let lastActivity = Date.now();

  const resetTimer = () => {
    lastActivity = Date.now();
  };

  const activityEvents = ['mousedown', 'keydown', 'touchstart', 'scroll'];
  activityEvents.forEach((ev) => window.addEventListener(ev, resetTimer, { passive: true }));

  const interval = setInterval(() => {
    const elapsed = Date.now() - lastActivity;
    if (elapsed > IDLE_TIMEOUT_MS) {
      const hasAuth = localStorage.getItem('rama777_auth_session') === 'true';
      if (hasAuth) {
        onSessionExpired('Session timed out due to 15 minutes of inactivity. Please log in again.');
      }
    }
  }, 30000);

  return () => {
    clearInterval(interval);
    activityEvents.forEach((ev) => window.removeEventListener(ev, resetTimer));
  };
}
