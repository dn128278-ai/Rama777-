/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Clean localStorage-based Biometric Authentication Service.
 * Uses a local biometric toggle and simulated native device biometric prompt check
 * so mobile browsers, WebViews, and embedded previews work reliably with zero errors.
 */

const BIO_PROMPTED_KEY = 'rama777_biometrics_prompted';
const BIO_ENABLED_KEY = 'rama777_biometrics_enabled';
const BIO_PROFILE_KEY = 'rama777_biometric_profile';

export interface StoredBiometricProfile {
  userId: string;
  userName: string;
  phone: string;
  enabledAt: string;
  lastVerifiedAt?: string;
}

export interface BiometricAuthResult {
  success: boolean;
  phone?: string;
  userId?: string;
  cancelled?: boolean;
  error?: string;
}

export function hasBeenPromptedForBiometrics(): boolean {
  try {
    return localStorage.getItem(BIO_PROMPTED_KEY) === 'true';
  } catch {
    return false;
  }
}

export function markBiometricsPrompted(): void {
  try {
    localStorage.setItem(BIO_PROMPTED_KEY, 'true');
  } catch {
    // ignore storage errors
  }
}

export function isBiometricEnabled(): boolean {
  try {
    const val = localStorage.getItem(BIO_ENABLED_KEY);
    if (val === null) return true; // Default enabled
    return val === 'true';
  } catch {
    return true;
  }
}

export function setBiometricEnabled(enabled: boolean): void {
  try {
    localStorage.setItem(BIO_ENABLED_KEY, enabled ? 'true' : 'false');
  } catch {
    // ignore storage errors
  }
}

export function getStoredBiometricProfile(): StoredBiometricProfile | null {
  try {
    const raw = localStorage.getItem(BIO_PROFILE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object') {
      return parsed as StoredBiometricProfile;
    }
    return null;
  } catch {
    return null;
  }
}

export function saveStoredBiometricProfile(profile: StoredBiometricProfile): void {
  try {
    localStorage.setItem(BIO_PROFILE_KEY, JSON.stringify(profile));
  } catch {
    // ignore storage errors
  }
}

export function hasStoredBiometricCredential(phone?: string): boolean {
  const cleanPhone = (phone || '').replace(/\D/g, '');
  const profile = getStoredBiometricProfile();
  if (profile?.phone) {
    if (!cleanPhone) return true;
    return profile.phone === cleanPhone;
  }
  try {
    return Boolean(
      cleanPhone ||
        localStorage.getItem('rama777_active_mobile') ||
        localStorage.getItem('rama777_user_phone') ||
        localStorage.getItem('rama777_last_registered_phone')
    );
  } catch {
    return Boolean(cleanPhone);
  }
}

/**
 * Biometric quick-login is always available via local toggle + native-style prompt.
 */
export async function isBiometricSupported(): Promise<boolean> {
  return true;
}

/**
 * Enrolls the user's biometric quick-login toggle and profile metadata in localStorage.
 */
export async function registerBiometricCredential(
  userId: string,
  userName: string,
  phone?: string
): Promise<BiometricAuthResult> {
  const cleanPhone = (phone || '').replace(/\D/g, '');
  saveStoredBiometricProfile({
    userId: userId || cleanPhone || 'user',
    userName: userName || 'RAMA Player',
    phone: cleanPhone,
    enabledAt: new Date().toISOString(),
  });
  setBiometricEnabled(true);
  markBiometricsPrompted();

  return {
    success: true,
    phone: cleanPhone,
    userId: userId || cleanPhone || 'user',
  };
}

/**
 * Runs a smooth simulated native biometric verification check using the localStorage
 * biometric state and returns the linked phone/userId for instant session login.
 */
export async function triggerNativeBiometricAuth(options?: {
  targetedPhone?: string;
  simulatedDelayMs?: number;
}): Promise<BiometricAuthResult> {
  if (!isBiometricEnabled()) {
    return {
      success: false,
      cancelled: true,
      error: 'Biometric login is turned off — enter your 4-digit MPIN.',
    };
  }

  const delay = options?.simulatedDelayMs ?? 650;
  await new Promise((resolve) => setTimeout(resolve, delay));

  const storedProfile = getStoredBiometricProfile();
  const cleanOptionPhone = (options?.targetedPhone || '').replace(/\D/g, '');

  let fallbackStoragePhone = '';
  try {
    fallbackStoragePhone = (
      localStorage.getItem('rama777_active_mobile') ||
      localStorage.getItem('rama777_user_phone') ||
      localStorage.getItem('rama777_last_registered_phone') ||
      ''
    ).replace(/\D/g, '');
  } catch {
    // ignore storage errors
  }

  const resolvedPhone =
    cleanOptionPhone || storedProfile?.phone || fallbackStoragePhone;

  if (storedProfile) {
    saveStoredBiometricProfile({
      ...storedProfile,
      phone: resolvedPhone || storedProfile.phone,
      lastVerifiedAt: new Date().toISOString(),
    });
  }

  return {
    success: true,
    phone: resolvedPhone,
    userId: storedProfile?.userId,
  };
}
