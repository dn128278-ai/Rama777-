/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { MarketItem, MarketResultRecord } from '../types';
import { evaluateMarkets } from '../utils/marketEngine';
import { supabase } from '../supabase';
import { INITIAL_MARKETS } from '../data/initialData';
import { toSupabaseUuid } from '../utils/userScope';

const RESET_INFO_KEY = 'rama777_last_market_reset';
const MARKETS_CACHE_KEY = 'rama777_local_markets';

export function getLastMarketResetInfo(): {
  lastResetDate: string | null;
  lastResetTimestamp: string | null;
} {
  try {
    const raw = localStorage.getItem(RESET_INFO_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return { lastResetDate: null, lastResetTimestamp: null };
}

export function evaluateSingleMarket(market: MarketItem, currentTime: Date): MarketItem {
  return evaluateMarkets(currentTime, [market])[0];
}

export function mergeMarketResultsIntoMarkets(
  markets: MarketItem[],
  results: MarketResultRecord[],
  currentTime: Date
): MarketItem[] {
  const evaluated = evaluateMarkets(currentTime, markets);
  const nowKey = `${currentTime.getFullYear()}-${String(currentTime.getMonth() + 1).padStart(2, '0')}-${String(currentTime.getDate()).padStart(2, '0')}`;

  return evaluated.map((m) => {
    const declaredToday = results.find(
      (r) => r.marketId === m.id && r.dateKey === nowKey && r.status !== 'pending'
    );
    if (declaredToday) {
      return {
        ...m,
        openPana: declaredToday.openPana,
        jodi: declaredToday.jodi,
        closePana: declaredToday.closePana,
        lastResult: `${declaredToday.openPana}-${declaredToday.jodi}-${declaredToday.closePana}`,
      };
    }
    return m;
  });
}

export function transformSupabaseRowToMarket(row: any, currentTime: Date): MarketItem {
  const raw: MarketItem = {
    id: row.id || row.name?.toLowerCase().replace(/\s+/g, '_'),
    name: row.name || 'Matka Market',
    openPana: row.open_pana || '***',
    jodi: row.jodi || '**',
    closePana: row.close_pana || '***',
    openTime: row.open_time || '11:00 AM',
    closeTime: row.close_time || '01:00 PM',
    status: row.status === 'ACTIVE' ? 'Running for Open' : row.status || 'Running for Open',
    isOpen: row.status !== 'CLOSED',
    lastResult: row.last_result || `${row.open_pana || '***'}-${row.jodi || '**'}-${row.close_pana || '***'}`,
  };
  return evaluateSingleMarket(raw, currentTime);
}

export async function fetchRealtimeMarkets(currentTime: Date): Promise<MarketItem[]> {
  try {
    const { data, error } = await supabase.from('markets').select('*').order('name');
    if (!error && data && data.length > 0) {
      const items = data.map((r) => transformSupabaseRowToMarket(r, currentTime));
      localStorage.setItem(MARKETS_CACHE_KEY, JSON.stringify(items));
      return items;
    }
    // If Supabase markets table is currently empty, seed default open markets into Supabase
    if (!error && data && data.length === 0) {
      const rows = INITIAL_MARKETS.map((m) => ({
        id: toSupabaseUuid(m.id),
        name: m.name,
        open_time: m.openTime,
        close_time: m.closeTime,
        status: 'ACTIVE',
        open_pana: m.openPana,
        jodi: m.jodi,
        close_pana: m.closePana,
      }));
      (async () => {
        try {
          await supabase.from('markets').upsert(rows);
        } catch {}
      })();
      return evaluateMarkets(currentTime, INITIAL_MARKETS);
    }
  } catch (err) {
    console.warn('fetchRealtimeMarkets Supabase error:', err);
  }
  return evaluateMarkets(currentTime, INITIAL_MARKETS);
}

export function subscribeToRealtimeMarkets(
  currentTime: Date,
  callback: (markets: MarketItem[]) => void
): () => void {
  fetchRealtimeMarkets(currentTime).then(callback);

  const onMarketUpdated = async () => {
    const fresh = await fetchRealtimeMarkets(currentTime);
    callback(fresh);
  };

  window.addEventListener('rama777:market-result-declared', onMarketUpdated);
  window.addEventListener('rama777:markets_updated', onMarketUpdated);

  return () => {
    window.removeEventListener('rama777:market-result-declared', onMarketUpdated);
    window.removeEventListener('rama777:markets_updated', onMarketUpdated);
  };
}

export async function executeDailyMarketReset(currentTime: Date): Promise<{
  success: boolean;
  dateKey: string;
  timestamp: string;
  resetCount: number;
  archivedBidsCount: number;
}> {
  const dateKey = `${currentTime.getFullYear()}-${String(currentTime.getMonth() + 1).padStart(2, '0')}-${String(currentTime.getDate()).padStart(2, '0')}`;
  const timestamp = currentTime.toISOString();

  let resetCount = 0;
  let archivedBidsCount = 0;

  try {
    // Reset markets directly in Supabase
    const { data: updatedMarkets } = await supabase
      .from('markets')
      .update({
        open_pana: '***',
        jodi: '**',
        close_pana: '***',
        status: 'ACTIVE',
        updated_at: timestamp,
      })
      .neq('status', 'ARCHIVED')
      .select();

    resetCount = updatedMarkets?.length || 0;
  } catch (err) {
    console.warn('Supabase reset markets error:', err);
  }

  // Save reset info
  localStorage.setItem(
    RESET_INFO_KEY,
    JSON.stringify({ lastResetDate: dateKey, lastResetTimestamp: timestamp })
  );

  window.dispatchEvent(new CustomEvent('rama777:market-daily-reset', { detail: { dateKey } }));

  return {
    success: true,
    dateKey,
    timestamp,
    resetCount,
    archivedBidsCount,
  };
}

export async function checkAndTriggerDailyMarketReset(currentTime: Date): Promise<boolean> {
  const dateKey = `${currentTime.getFullYear()}-${String(currentTime.getMonth() + 1).padStart(2, '0')}-${String(currentTime.getDate()).padStart(2, '0')}`;
  const info = getLastMarketResetInfo();

  if (info.lastResetDate !== dateKey) {
    await executeDailyMarketReset(currentTime);
    return true;
  }
  return false;
}
