/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { UserProfile, UserAccount, UserRole } from '../types';

const SESSION_KEY = 'rama777_user';
const ACCOUNTS_KEY = 'rama777_registered_accounts';

export function getActiveSession(): UserProfile | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function persistSession(user: UserProfile): void {
  try {
    localStorage.setItem(SESSION_KEY, JSON.stringify(user));
    localStorage.setItem('rama777_auth_session', 'true');
    if (user.phone) {
      localStorage.setItem('rama777_active_mobile', user.phone);
      localStorage.setItem('rama777_user_phone', user.phone);
    }
    // Also save in accounts list
    saveAccountToRegistry(user);
  } catch (e) {
    console.warn('Persist session notice:', e);
  }
}

export function clearSession(): void {
  try {
    localStorage.removeItem(SESSION_KEY);
    localStorage.removeItem('rama777_auth_session');
    localStorage.removeItem('rama777_user_uid');
  } catch (e) {
    console.warn('Clear session notice:', e);
  }
}

export function getRegisteredAccounts(): UserAccount[] {
  try {
    const raw = localStorage.getItem(ACCOUNTS_KEY);
    const list: UserAccount[] = raw ? JSON.parse(raw) : [];

    // Ensure Admin account exists for demo
    if (!list.some((a) => a.role === 'admin')) {
      list.push({
        id: 'usr_admin_777',
        name: 'RATAN Admin',
        phone: '9999999999',
        walletBalance: 1000000,
        mpin: '9999',
        role: 'admin',
        status: 'active',
      });
    }

    return list;
  } catch {
    return [];
  }
}

function saveAccountToRegistry(user: UserProfile): void {
  try {
    const list = getRegisteredAccounts();
    const existingIdx = list.findIndex(
      (a) => a.phone === user.phone || a.id === user.id || a.id === user.uid
    );
    const newEntry: UserAccount = {
      id: user.id || user.uid || `usr_${user.phone}`,
      name: user.name,
      phone: user.phone,
      walletBalance: user.walletBalance,
      mpin: user.mpin,
      role: user.role,
      status: 'active',
    };
    if (existingIdx >= 0) {
      list[existingIdx] = { ...list[existingIdx], ...newEntry };
    } else {
      list.push(newEntry);
    }
    localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(list));
  } catch (e) {
    console.warn('Save registry notice:', e);
  }
}

export function adjustUserBalance(phoneOrId: string, newBalance: number): void {
  try {
    const list = getRegisteredAccounts();
    const target = list.find((a) => a.phone === phoneOrId || a.id === phoneOrId);
    if (target) {
      target.walletBalance = newBalance;
      localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(list));
    }

    const current = getActiveSession();
    if (current && (current.phone === phoneOrId || current.id === phoneOrId || current.uid === phoneOrId)) {
      current.walletBalance = newBalance;
      persistSession(current);
    }
  } catch (e) {
    console.warn('Adjust user balance notice:', e);
  }
}

export function switchUserRole(phoneOrId: string, role: UserRole): UserProfile | null {
  try {
    const current = getActiveSession();
    if (current) {
      const updated = { ...current, role };
      persistSession(updated);
      return updated;
    }
    const accounts = getRegisteredAccounts();
    const match = accounts.find((a) => a.phone === phoneOrId || a.id === phoneOrId);
    if (match) {
      match.role = role;
      localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
      const newProf: UserProfile = {
        ...match,
        appVersion: '1.0.2',
        biometricEnabled: true,
      };
      persistSession(newProf);
      return newProf;
    }
    return null;
  } catch {
    return null;
  }
}
