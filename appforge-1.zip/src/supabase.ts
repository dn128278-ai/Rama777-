/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { createClient } from '@supabase/supabase-js';

export const HARDCODED_SUPABASE_URL = 'https://ekngcegflrtmlblxulyt.supabase.co';
export const HARDCODED_SUPABASE_ANON_KEY = 'sb_publishable_h1WzUpjPRT57tQEQPsFKWg_5sbEILhB';

function sanitizeUrl(raw: any): string {
  if (!raw || typeof raw !== 'string') {
    return HARDCODED_SUPABASE_URL;
  }
  let str = raw.trim();
  // Extract URL from markdown link format like [text](https://...)
  const mdMatch = str.match(/\((https?:\/\/[^\s\)]+)\)/);
  if (mdMatch) {
    str = mdMatch[1];
  } else {
    // Strip leading/trailing brackets, quotes, angle brackets
    str = str.replace(/^[\[<"'\s]+|[\]>"'\s]+$/g, '');
    const httpMatch = str.match(/(https?:\/\/[^\s\]"'\)]+)/);
    if (httpMatch) {
      str = httpMatch[1];
    }
  }
  if (!/^https?:\/\//i.test(str) || str.includes('ekngcegftrtmlbxkulyt')) {
    return HARDCODED_SUPABASE_URL;
  }
  return str.replace(/\/+$/, '');
}

function sanitizeKey(raw: any): string {
  if (!raw || typeof raw !== 'string') {
    return HARDCODED_SUPABASE_ANON_KEY;
  }
  const clean = raw.trim().replace(/^["']|["']$/g, '');
  return clean || HARDCODED_SUPABASE_ANON_KEY;
}

const supabaseUrl = sanitizeUrl(import.meta.env?.VITE_SUPABASE_URL);
const supabaseAnonKey = sanitizeKey(import.meta.env?.VITE_SUPABASE_ANON_KEY);

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
  realtime: {
    params: {
      eventsPerSecond: 10,
    },
  },
});
