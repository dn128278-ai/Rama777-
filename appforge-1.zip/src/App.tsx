import React, { useState, useEffect, useRef } from 'react';
import { SplashScreen } from './components/SplashScreen';
import { LoginScreen } from './components/LoginScreen';
import { RegisterScreen } from './components/RegisterScreen';
import { Header } from './components/Header';
import { BottomNavBar } from './components/BottomNavBar';
import { SideDrawer } from './components/SideDrawer';
import { HomeTab } from './components/HomeTab';
import { HistoryTab } from './components/HistoryTab';
import { PassbookTab } from './components/PassbookTab';
import { FundsTab } from './components/FundsTab';
import { SupportTab } from './components/SupportTab';
import { GamePlayView } from './components/GamePlayView';
import { ChartsView } from './components/ChartsView';
import { ChangeMpinModal } from './components/ChangeMpinModal';
import { GameRatesModal } from './components/GameRatesModal';
import { StarlineJackpotModal } from './components/StarlineJackpotModal';
import { ResultManagementModal } from './components/ResultManagementModal';
import { AdminPanelModal } from './components/AdminPanelModal';
import { getActiveSession, clearSession, persistSession } from './services/authService';
import {
  setBiometricEnabled,
  hasStoredBiometricCredential,
  registerBiometricCredential,
} from './services/webAuthnService';
import {
  listenToWinningCredits,
  evaluateAndSettleBidsForMarket,
  subscribeToGameRates,
} from './services/gameRatesService';
import {
  NotificationsModal,
  HowToPlayModal,
  SubmitIdeasModal,
  SettingsModal,
  LanguageModal,
} from './components/SecondaryModals';
import { INITIAL_MARKETS } from './data/initialData';
import {
  evaluateMarkets,
  evaluateStarlineSlots,
  convertSlotsToStarlineResults,
} from './utils/marketEngine';
import {
  subscribeToRealtimeMarkets,
  evaluateSingleMarket,
  mergeMarketResultsIntoMarkets,
  transformSupabaseRowToMarket,
  checkAndTriggerDailyMarketReset,
  executeDailyMarketReset,
  fetchRealtimeMarkets,
} from './services/marketService';
import {
  subscribeToUserWallet,
  syncUserToFirestore,
  subscribeToWithdrawals,
  createWithdrawalInFirestore,
  subscribeToDeposits,
  createDepositInFirestore,
  subscribeToBids,
  placeBidInFirestore,
  subscribeToTransactions,
  recordTransactionInFirestore,
  subscribeToBankAccounts,
  addBankAccountToFirestore,
  subscribeToPaymentGateway,
  subscribeToNotifications,
  markAllNotificationsRead,
  clearAllNotifications,
  broadcastNotificationInFirestore,
  seedInitialDataToFirestore,
  PaymentGatewayConfig,
  DEFAULT_GATEWAY_CONFIG,
  toSupabaseUuid,
} from './services/firestoreSyncService';
import { subscribeToMarketResults } from './services/marketResultService';
import {
  MainTab,
  MarketItem,
  UserProfile,
  Transaction,
  FundHistoryItem,
  BankAccount,
  StarlineResult,
  GameBid,
  AppNotification,
  MarketResultRecord,
} from './types';
import { Smartphone, Monitor, ShieldCheck, ShieldAlert, X } from 'lucide-react';
import { initSessionWatchdog } from './services/sessionManager';
import { checkRateLimit, recordActionAttempt } from './services/rateLimiter';
import { sanitizeAmount, sanitizeText } from './utils/sanitizer';
import { supabase } from './supabase';

export default function App() {
  // App authentication state - strict unauthenticated default state on fresh installation
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    const hasAuthSession = localStorage.getItem('rama777_auth_session') === 'true';
    const hasStoredUser = !!localStorage.getItem('rama777_user') || !!localStorage.getItem('rama777_user_uid');
    const active = getActiveSession();
    // Only true if an active authenticated session explicitly exists in storage!
    return !!(hasAuthSession && (hasStoredUser || active));
  });
  const [isAuthChecking, setIsAuthChecking] = useState<boolean>(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [user, setUser] = useState<UserProfile>(() => {
    const active = getActiveSession();
    if (active) return active;
    try {
      const stored = localStorage.getItem('rama777_user');
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {}
    return {
      name: 'Player',
      phone: '',
      walletBalance: 0,
      mainWallet: 0,
      winningWallet: 0,
      gamingWallet: 0,
      mpin: '',
      biometricEnabled: true,
      appVersion: '1.0.2',
      role: 'user',
    };
  });
  const [currentTab, setCurrentTab] = useState<MainTab>('home');

  // Clean light mode default theme
  const [isDarkMode, setIsDarkMode] = useState<boolean>(false);
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);
  const [securityNotice, setSecurityNotice] = useState<{ message: string; isError?: boolean } | null>(null);

  // Splash screen presentation timer on initial app launch
  useEffect(() => {
    const splashTimer = setTimeout(() => {
      setShowSplash(false);
    }, 1200);
    return () => clearTimeout(splashTimer);
  }, []);

  // Initialize secure session watchdog (15-min idle timeout & storage tamper defense)
  useEffect(() => {
    const unsubWatchdog = initSessionWatchdog((reason) => {
      setSecurityNotice({ message: reason, isError: true });
      clearSession();
      setIsAuthenticated(false);
      setAuthMode('login');
      setActiveOverlay(null);
      setCurrentTab('home');
    });
    return () => unsubWatchdog();
  }, []);

  // Auth state listener: strict check on application launch
  useEffect(() => {
    let isMounted = true;
    const hasAuthSession = localStorage.getItem('rama777_auth_session') === 'true';
    const storedUserRaw = localStorage.getItem('rama777_user');
    const activeSession = getActiveSession();

    let resolvedUser: UserProfile | null = activeSession;
    if (!resolvedUser && storedUserRaw) {
      try {
        resolvedUser = JSON.parse(storedUserRaw);
      } catch {}
    }

    if (hasAuthSession && resolvedUser) {
      setUser(resolvedUser);
      setIsAuthenticated(true);
    } else {
      // Unauthenticated fresh installation or missing session: strictly route to login screen
      setIsAuthenticated(false);
      setAuthMode('login');
      setActiveOverlay(null);
    }

    const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
      if (!isMounted) return;
      if (session?.user) {
        setIsAuthenticated(true);
        localStorage.setItem('rama777_auth_session', 'true');
        localStorage.setItem('rama777_user_uid', session.user.id);
        if (session.user.phone) {
          localStorage.setItem('rama777_user_phone', session.user.phone);
        }
        setUser((prev) => ({
          ...prev,
          uid: session.user.id,
          id: session.user.id,
          email: session.user.email || prev.email,
          phone: session.user.phone || prev.phone,
        }));
      } else {
        // If no active Supabase session and no valid local session, enforce login
        const currentAuth = localStorage.getItem('rama777_auth_session') === 'true';
        const currentUser = !!localStorage.getItem('rama777_user') || !!getActiveSession();
        if (currentAuth && currentUser) {
          setIsAuthenticated(true);
        } else {
          setIsAuthenticated(false);
          setAuthMode('login');
        }
      }
      setIsAuthChecking(false);
    });

    return () => {
      isMounted = false;
      authListener?.subscription?.unsubscribe();
    };
  }, []);
  const [viewDeviceMode, setViewDeviceMode] = useState<'mobile-frame' | 'responsive'>('mobile-frame');

  // Dynamic Clock & Market Time Engine
  const [timeOffsetMs, setTimeOffsetMs] = useState<number>(0);
  const [currentTime, setCurrentTime] = useState<Date>(() => new Date());

  // Data states directly populated from live Supabase tables
  const [markets, setMarkets] = useState<MarketItem[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [addFundsHistory, setAddFundsHistory] = useState<FundHistoryItem[]>([]);
  const [withdrawFundsHistory, setWithdrawFundsHistory] = useState<FundHistoryItem[]>([]);
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([]);
  const [starlineResults, setStarlineResults] = useState<StarlineResult[]>(() => {
    const slots = evaluateStarlineSlots(new Date());
    const now = new Date();
    const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
      .toString()
      .padStart(2, '0')}/${now.getFullYear()}`;
    return convertSlotsToStarlineResults(slots, dateStr);
  });
  const [bids, setBids] = useState<GameBid[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [historicalResults, setHistoricalResults] = useState<MarketResultRecord[]>([]);
  const historicalResultsRef = useRef<MarketResultRecord[]>([]);
  const processedWinsRef = useRef<Set<string>>(new Set());
  const creditedDepositsRef = useRef<Set<string>>(new Set());

  // Real-time payment gateway configuration
  const [gatewayConfig, setGatewayConfig] = useState<PaymentGatewayConfig>(DEFAULT_GATEWAY_CONFIG);

  // Reference holding the latest raw market definitions from live Supabase
  const latestRawMarketsRef = useRef<MarketItem[]>([]);
  const lastCalendarDateKeyRef = useRef<string>('');

  // Reference holding the latest user profile for persistent real-time WebSocket callbacks
  const userRef = useRef<UserProfile>(user);
  useEffect(() => {
    userRef.current = user;
  }, [user]);

  // Real-time user session identifier for dynamic Firestore isolation
  const activeUserScope = user.uid || user.phone || 'anonymous';

  // 1. Real-time User & Wallet sync via onSnapshot
  useEffect(() => {
    if (!user.uid && !user.phone) return;
    const unsub = subscribeToUserWallet(user, (userData) => {
      setUser((prev) => {
        const updated = {
          ...prev,
          ...userData,
        };
        persistSession(updated);
        return updated;
      });
    });
    return () => unsub();
  }, [user.uid, user.phone]);

  // 1b. Real-time Winning Credits & Bet Payout listener from Supabase & Local Settlement
  useEffect(() => {
    if (!user.uid && !user.phone) return;

    const handleWinPayout = (winData: {
      bidId: string;
      marketName: string;
      gameType: string;
      amount: number;
      digits: string;
      multiplier: number;
    }) => {
      // Deduplicate payout events
      const winKey = winData.bidId
        ? String(winData.bidId)
        : `${winData.marketName}-${winData.gameType}-${winData.amount}-${winData.digits}`;
      if (processedWinsRef.current.has(winKey)) {
        return;
      }
      processedWinsRef.current.add(winKey);

      let prevBalSnap = 0;
      let newBalSnap = 0;

      // 1. Credit wallet balance (updating both total walletBalance & winningWallet)
      setUser((prev) => {
        const currentBal = Number(prev.walletBalance) || 0;
        const currentWinBal = Number(prev.winningWallet) || 0;
        const currentMain = prev.mainWallet ?? currentBal;
        prevBalSnap = currentBal;
        newBalSnap = currentBal + winData.amount;

        const updated = {
          ...prev,
          walletBalance: newBalSnap,
          winningWallet: currentWinBal + winData.amount,
          mainWallet: currentMain,
        };
        persistSession(updated);
        return updated;
      });

      // 2. Mark matching placed bid as Won
      setBids((prev) =>
        prev.map((b) => {
          if (b.id === winData.bidId || (b.marketName === winData.marketName && b.status === 'Placed')) {
            return { ...b, status: 'Won', winAmount: winData.amount };
          }
          return b;
        })
      );

      // 3. Add winning credit transaction to passbook & Supabase
      const winTx: Transaction = {
        id: `tx-win-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        title: `${winData.marketName} Win Payout`,
        referenceId: winData.bidId || `WIN-${Date.now()}`,
        description: `Won ${winData.gameType} ${winData.digits ? '(' + winData.digits + ')' : ''} at 1 ka ${winData.multiplier} ratio!`,
        amount: winData.amount,
        type: 'credit',
        status: 'SUCCESS',
        date: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        previousBalance: prevBalSnap,
        currentBalance: newBalSnap,
      };
      setTransactions((prev) => [winTx, ...prev]);

      const winUserSnap: UserProfile = {
        ...userRef.current,
        walletBalance: newBalSnap,
        winningWallet: (Number(userRef.current.winningWallet) || 0) + winData.amount,
      };
      recordTransactionInFirestore(winTx, winUserSnap, 'WIN_PAYOUT');
      syncUserToFirestore(winUserSnap);

      // 4. Alert user with celebratory notice
      setSecurityNotice({
        message: `🎉 Bet Won! You received ₹${winData.amount} for ${winData.marketName} (${winData.gameType} 1 ka ${winData.multiplier})! Credited to your wallet.`,
        isError: false,
      });

      // 5. In-app notification
      const winNotif: AppNotification = {
        id: `notif-win-${Date.now()}`,
        title: `🏆 Winning Payout: ₹${winData.amount}`,
        message: `Congratulations! Your bet on ${winData.marketName} (${winData.gameType}) won ₹${winData.amount} at 1 ka ${winData.multiplier} ratio. Credited instantly to your wallet.`,
        time: 'Just now',
        read: false,
        type: 'bonus',
      };
      setNotifications((prev) => [winNotif, ...prev]);
    };

    const unsubRemote = listenToWinningCredits(user.uid || user.id || '', user.phone || '', handleWinPayout);

    const onLocalWin = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail) {
        handleWinPayout(customEvent.detail);
      }
    };
    window.addEventListener('rama777:bet_won', onLocalWin);

    return () => {
      unsubRemote();
      window.removeEventListener('rama777:bet_won', onLocalWin);
    };
  }, [user.uid, user.id, user.phone]);

  // 2. Real-time Withdrawals sync via onSnapshot
  useEffect(() => {
    if (!user.uid && !user.phone) {
      setWithdrawFundsHistory([]);
      return;
    }
    const unsub = subscribeToWithdrawals(user, (withdrawals) => {
      setWithdrawFundsHistory(withdrawals);
      window.dispatchEvent(new CustomEvent('rama777:user_updated'));
    });
    return () => unsub();
  }, [user.uid, user.phone]);

  // 3. Real-time Deposits sync via onSnapshot
  useEffect(() => {
    if (!user.uid && !user.phone) {
      setAddFundsHistory([]);
      return;
    }
    const unsub = subscribeToDeposits(user, (deposits) => {
      setAddFundsHistory(deposits);
      window.dispatchEvent(new CustomEvent('rama777:user_updated'));
    });
    return () => unsub();
  }, [user.uid, user.phone]);

  // 4. Real-time Game Bids sync from Supabase without enforcing user authentication checks
  useEffect(() => {
    const unsub = subscribeToBids(user, (syncedBids) => {
      setBids(syncedBids);
    });
    return () => unsub();
  }, [user.uid, user.phone]);

  // 5. Real-time Transactions (Passbook) sync from Supabase without enforcing user authentication checks
  useEffect(() => {
    const unsub = subscribeToTransactions(user, (txs) => {
      setTransactions(txs);
    });
    return () => unsub();
  }, [user.uid, user.phone]);

  // 6. Real-time Bank Accounts sync via onSnapshot
  useEffect(() => {
    if (!user.uid && !user.phone) {
      setBankAccounts([]);
      return;
    }
    const unsub = subscribeToBankAccounts(user, (banks) => {
      setBankAccounts(banks);
    });
    return () => unsub();
  }, [user.uid, user.phone]);

  // 8. Real-time Payment Gateway Status & Config sync via onSnapshot
  useEffect(() => {
    const unsub = subscribeToPaymentGateway((cfg) => {
      setGatewayConfig(cfg);
    });
    return () => unsub();
  }, []);

  // 8b. Real-time Game Rates sync from Supabase 'game_rates' table
  useEffect(() => {
    const unsub = subscribeToGameRates(() => {
      // Keeps liveMultiplierMap & custom events synchronized globally
    });
    return () => unsub();
  }, []);

  // 9. Real-time Notifications & Broadcasts sync from Supabase 'notifications' table
  useEffect(() => {
    const unsub = subscribeToNotifications(user.phone || user.uid || user.id, (syncedNotifs, hasData) => {
      if (hasData) {
        setNotifications(syncedNotifs);
      }
    });

    const onAdminAlert = (e: Event) => {
      const custom = e as CustomEvent<{ title?: string; message?: string; type?: string }>;
      if (custom?.detail) {
        setSecurityNotice({
          message: `🔔 ${custom.detail.title || 'Admin Alert'}: ${custom.detail.message || ''}`,
          isError: false,
        });
      }
    };
    window.addEventListener('rama777:admin_alert', onAdminAlert);

    return () => {
      unsub();
      window.removeEventListener('rama777:admin_alert', onAdminAlert);
    };
  }, [user.phone, user.uid, user.id]);

  // 10. Real-time Market Results & Chart History sync via onSnapshot from 'market_results' collection
  useEffect(() => {
    const unsub = subscribeToMarketResults((results) => {
      historicalResultsRef.current = results;
      setHistoricalResults(results);
      const now = new Date(Date.now() + timeOffsetMs);
      const base = latestRawMarketsRef.current;
      const evaluated = mergeMarketResultsIntoMarkets(base, results, now);
      setMarkets(evaluated);
    });
    return () => unsub();
  }, [timeOffsetMs]);

  // Initial Direct Load and Realtime Subscription directly from Supabase tables ('markets')
  useEffect(() => {
    let isMounted = true;
    let seeded = false;

    // Helper to render default open markets instantly and seed them into Supabase
    const seedFallback = () => {
      if (seeded || !isMounted) return;
      seeded = true;
      const now = new Date(Date.now() + timeOffsetMs);
      latestRawMarketsRef.current = INITIAL_MARKETS;
      setMarkets(evaluateMarkets(now, INITIAL_MARKETS));

      // Asynchronously seed default open markets into Supabase so table is populated
      (async () => {
        try {
          const rowsToInsert = INITIAL_MARKETS.map((m) => ({
            id: toSupabaseUuid(m.id),
            name: m.name,
            open_time: m.openTime,
            close_time: m.closeTime,
            status: 'ACTIVE',
            open_pana: m.openPana,
            jodi: m.jodi,
            close_pana: m.closePana,
          }));
          await supabase.from('markets').upsert(rowsToInsert);
        } catch (err) {
          console.warn('[Supabase Seed Notice]', err);
        }
      })();
    };

    // Fallback timeout: If Supabase connection takes more than 1200ms or table is slow/empty,
    // immediately render default open markets so the user is never stuck on loading screen
    const fallbackTimer = setTimeout(() => {
      if (latestRawMarketsRef.current.length === 0) {
        seedFallback();
      }
    }, 1200);

    // Direct plain CRUD query on mount using supabase.from('markets').select('*')
    // Direct plain CRUD queries on component mount without enforcing user authentication checks
    const loadInitialData = async () => {
      // 1. Direct query on 'markets' table: supabase.from('markets').select('*')
      try {
        const { data: marketsData, error: marketsError } = await supabase
          .from('markets')
          .select('*')
          .order('name', { ascending: true });

        if (!isMounted) return;

        if (marketsError) {
          console.error('[Supabase Error] Direct select on markets failed:', marketsError.message || marketsError);
          seedFallback();
        } else if (marketsData && marketsData.length > 0) {
          clearTimeout(fallbackTimer);
          seeded = true;
          const now = new Date(Date.now() + timeOffsetMs);
          const rawItems = marketsData.map((row) => transformSupabaseRowToMarket(row, now));
          latestRawMarketsRef.current = rawItems;
          const evaluated = mergeMarketResultsIntoMarkets(rawItems, historicalResultsRef.current, now);
          setMarkets(evaluated);
        } else {
          console.warn('[Supabase Markets Live Notice] Markets table empty, seeding default open markets');
          seedFallback();
        }
      } catch (err: any) {
        console.error('[Supabase Error] Network error during markets fetch, falling back to local state:', err?.message || err);
        seedFallback();
      }

      // 2. Direct query on 'bids' table: supabase.from('bids').select('*')
      try {
        const curUser = userRef.current;
        const cleanPhone = (curUser.phone || '').replace(/\D/g, '');
        const userUuid =
          curUser.uid || curUser.id || cleanPhone
            ? toSupabaseUuid(curUser.uid || curUser.id || cleanPhone)
            : '';

        let bidsQuery = supabase
          .from('bids')
          .select('*')
          .order('created_at', { ascending: false });

        if (userUuid && curUser.role !== 'admin') {
          bidsQuery = bidsQuery.eq('user_id', userUuid);
        }

        const { data: bidsData, error: bidsError } = await bidsQuery;

        if (!isMounted) return;

        if (bidsError) {
          console.error('[Supabase Error] Direct select on bids failed:', bidsError.message || bidsError);
        } else if (bidsData) {
          const mappedBids: GameBid[] = bidsData.map((b: any) => {
            const matchedMarket = latestRawMarketsRef.current.find(
              (m) => m.id === b.market_id || toSupabaseUuid(m.id || m.name) === b.market_id
            );
            return {
              id: b.id,
              marketId: b.market_id,
              marketName: b.market_name || matchedMarket?.name || 'Matka Market',
              gameType: b.game_type,
              session: b.session || 'Open',
              digitOrPana: b.digits,
              points: Number(b.points),
              status:
                b.status === 'WON' || b.status === 'Won'
                  ? 'Won'
                  : b.status === 'LOST' || b.status === 'Lost'
                  ? 'Lost'
                  : 'Placed',
              winAmount: b.win_amount ? Number(b.win_amount) : undefined,
              date: b.created_at ? new Date(b.created_at).toLocaleDateString() : 'Recent',
            };
          });
          setBids(mappedBids);
        }
      } catch (err: any) {
        console.error('[Supabase Error] Network error during bids fetch, falling back to local state:', err?.message || err);
      }
    };

    loadInitialData();

    // Real-time Supabase channels actively listening to postgres_changes:
    // 1. supabase.channel('public:markets') - updates markets & settles declared results
    // 2. supabase.channel('public:bids') - updates bets & win statuses immediately
    // 3. supabase.channel('public:users') - updates wallet balance & profiles live
    // 4. supabase.channel('public:deposits') - updates deposit approvals & rejections
    // 5. supabase.channel('public:withdrawals') - updates withdrawal approvals & rejections

    // Ensure any previously registered channel instances on these topics are cleanly removed first
    for (const ch of supabase.getChannels()) {
      if (
        ch.topic === 'realtime:public:markets' ||
        ch.topic === 'realtime:public:bids' ||
        ch.topic === 'realtime:public:users' ||
        ch.topic === 'realtime:public:deposits' ||
        ch.topic === 'realtime:public:withdrawals'
      ) {
        supabase.removeChannel(ch);
      }
    }

    // 1. Channel: public:markets
    const marketsChannel = supabase
      .channel('public:markets')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'markets' },
        async (payload: any) => {
          if (!isMounted) return;
          console.log('[Supabase Realtime] public:markets event:', payload.eventType, payload.new || payload.old);

          const now = new Date(Date.now() + timeOffsetMs);

          // Instant update from payload so any market created or result declared appears immediately
          if (payload.new && (payload.eventType === 'INSERT' || payload.eventType === 'UPDATE')) {
            const updatedItem = transformSupabaseRowToMarket(payload.new, now);
            const exists = latestRawMarketsRef.current.some(
              (m) => m.id === updatedItem.id || m.name.toUpperCase() === updatedItem.name.toUpperCase()
            );
            latestRawMarketsRef.current = exists
              ? latestRawMarketsRef.current.map((m) =>
                  m.id === updatedItem.id || m.name.toUpperCase() === updatedItem.name.toUpperCase()
                    ? updatedItem
                    : m
                )
              : [...latestRawMarketsRef.current, updatedItem];

            const evaluated = mergeMarketResultsIntoMarkets(
              latestRawMarketsRef.current,
              historicalResultsRef.current,
              now
            );
            setMarkets(evaluated);

            // If an admin declared a result in RATAN567 Admin Panel, settle active bets immediately
            if (
              (payload.new.open_pana && payload.new.open_pana !== '***') ||
              (payload.new.close_pana && payload.new.close_pana !== '***') ||
              (payload.new.jodi && payload.new.jodi !== '**')
            ) {
              evaluateAndSettleBidsForMarket({
                marketId: payload.new.id,
                marketName: payload.new.name,
                openPana: payload.new.open_pana,
                jodi: payload.new.jodi,
                closePana: payload.new.close_pana,
              }).catch((e) => console.warn('[Supabase Realtime] Automatic bet evaluation notice:', e));
            }
          } else if (payload.old && payload.eventType === 'DELETE') {
            const delId = payload.old.id;
            latestRawMarketsRef.current = latestRawMarketsRef.current.filter((m) => m.id !== delId);
            const evaluated = mergeMarketResultsIntoMarkets(
              latestRawMarketsRef.current,
              historicalResultsRef.current,
              now
            );
            setMarkets(evaluated);
          }

          // Full background synchronization of markets
          try {
            const { data, error } = await supabase
              .from('markets')
              .select('*')
              .order('name', { ascending: true });

            if (!isMounted || error || !data || data.length === 0) return;
            const rawItems = data.map((row) => transformSupabaseRowToMarket(row, now));
            latestRawMarketsRef.current = rawItems;
            const evaluated = mergeMarketResultsIntoMarkets(rawItems, historicalResultsRef.current, now);
            setMarkets(evaluated);
            window.dispatchEvent(new CustomEvent('rama777:markets_updated', { detail: payload }));
          } catch (e) {
            console.warn('[Supabase Realtime] Markets refetch notice:', e);
          }
        }
      )
      .subscribe((status) => {
        console.log('[Supabase Realtime] public:markets status:', status);
      });

    // 2. Channel: public:bids
    const bidsChannel = supabase
      .channel('public:bids')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'bids' },
        async (payload: any) => {
          if (!isMounted) return;
          console.log('[Supabase Realtime] public:bids event:', payload.eventType, payload.new || payload.old);
          const currentUser = userRef.current;
          const cleanPhone = (currentUser.phone || '').replace(/\D/g, '');
          const userUuid =
            currentUser.uid || currentUser.id || cleanPhone
              ? toSupabaseUuid(currentUser.uid || currentUser.id || cleanPhone)
              : '';

          if (payload.new && (payload.eventType === 'INSERT' || payload.eventType === 'UPDATE')) {
            const row = payload.new;
            const isMatch =
              (userUuid && row.user_id === userUuid) ||
              (currentUser.uid && row.user_id === currentUser.uid) ||
              (currentUser.id && row.user_id === currentUser.id) ||
              currentUser.role === 'admin';

            if (isMatch) {
              const matchedMarket = latestRawMarketsRef.current.find(
                (m) => m.id === row.market_id || toSupabaseUuid(m.id || m.name) === row.market_id
              );
              const resolvedMarketName = row.market_name || matchedMarket?.name || 'Matka Market';
              const mappedBid: GameBid = {
                id: row.id,
                marketId: row.market_id,
                marketName: resolvedMarketName,
                gameType: row.game_type,
                session: row.session || 'Open',
                digitOrPana: row.digits,
                points: Number(row.points),
                status:
                  row.status === 'WON' || row.status === 'Won'
                    ? 'Won'
                    : row.status === 'LOST' || row.status === 'Lost'
                    ? 'Lost'
                    : 'Placed',
                winAmount: row.win_amount ? Number(row.win_amount) : undefined,
                date: row.created_at ? new Date(row.created_at).toLocaleDateString() : 'Recent',
              };

              setBids((prev) => {
                const idx = prev.findIndex((b) => b.id === mappedBid.id);
                if (idx >= 0) {
                  const updated = [...prev];
                  updated[idx] = mappedBid;
                  return updated;
                }
                return [mappedBid, ...prev];
              });

              if ((row.status === 'WON' || row.status === 'Won') && row.win_amount) {
                const winAmt = Number(row.win_amount);
                setSecurityNotice({
                  message: `🎉 Bet Won! You won ₹${winAmt} on ${resolvedMarketName} (${row.game_type})! Credited to your wallet.`,
                  isError: false,
                });
              }
            }
          }

          // Full background sync for current user bids (filter by valid user_id UUID, never nonexistent mobile column)
          if (userUuid) {
            try {
              const { data, error } = await supabase
                .from('bids')
                .select('*')
                .eq('user_id', userUuid)
                .order('created_at', { ascending: false });

              if (!error && data && isMounted) {
                const mapped: GameBid[] = data.map((b: any) => {
                  const matchedMarket = latestRawMarketsRef.current.find(
                    (m) => m.id === b.market_id || toSupabaseUuid(m.id || m.name) === b.market_id
                  );
                  return {
                    id: b.id,
                    marketId: b.market_id,
                    marketName: b.market_name || matchedMarket?.name || 'Matka Market',
                    gameType: b.game_type,
                    session: b.session || 'Open',
                    digitOrPana: b.digits,
                    points: Number(b.points),
                    status:
                      b.status === 'WON' || b.status === 'Won'
                        ? 'Won'
                        : b.status === 'LOST' || b.status === 'Lost'
                        ? 'Lost'
                        : 'Placed',
                    winAmount: b.win_amount ? Number(b.win_amount) : undefined,
                    date: b.created_at ? new Date(b.created_at).toLocaleDateString() : 'Recent',
                  };
                });
                setBids(mapped);
              }
            } catch (e) {
              console.warn('[Supabase Realtime] Bids refetch notice:', e);
            }
          }
          window.dispatchEvent(new CustomEvent('rama777:bids_updated', { detail: payload }));
        }
      )
      .subscribe((status) => {
        console.log('[Supabase Realtime] public:bids status:', status);
      });

    // 3. Channel: public:users
    const usersChannel = supabase
      .channel('public:users')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'users' },
        (payload: any) => {
          if (!isMounted) return;
          console.log('[Supabase Realtime] public:users event:', payload.eventType, payload.new);
          const currentUser = userRef.current;
          const cleanPhone = (currentUser.phone || '').replace(/\D/g, '');
          const row = payload.new;
          if (!row) return;

          const isMatch =
            (cleanPhone && row.mobile && row.mobile.replace(/\D/g, '') === cleanPhone) ||
            (currentUser.uid && (row.id === currentUser.uid || row.user_id === currentUser.uid)) ||
            (currentUser.id && (row.id === currentUser.id || row.user_id === currentUser.id));

          if (isMatch) {
            const newMain = Number(row.main_wallet ?? row.wallet_balance ?? currentUser.walletBalance ?? 0);
            const newWinning = Number(row.winning_wallet ?? currentUser.winningWallet ?? 0);
            const newGaming = Number(row.gaming_wallet ?? newMain);

            setUser((prev) => {
              const updated = {
                ...prev,
                walletBalance: newMain,
                mainWallet: newMain,
                winningWallet: newWinning,
                gamingWallet: newGaming,
                role: row.role || prev.role,
                status: row.status || prev.status,
              };
              persistSession(updated);
              return updated;
            });
            window.dispatchEvent(new CustomEvent('rama777:user_updated', { detail: row }));
          }
        }
      )
      .subscribe((status) => {
        console.log('[Supabase Realtime] public:users status:', status);
      });

    // 4. Channel: public:deposits (Real-time admin deposit approvals/rejections)
    const depositsChannel = supabase
      .channel('public:deposits')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'deposits' },
        async (payload: any) => {
          if (!isMounted) return;
          console.log('[Supabase Realtime] public:deposits event:', payload.eventType, payload.new || payload.old);
          const currentUser = userRef.current;
          const cleanPhone = (currentUser.phone || '').replace(/\D/g, '');
          const row = payload.new;
          if (!row) return;

          const isMatch =
            (cleanPhone && row.mobile && row.mobile.replace(/\D/g, '') === cleanPhone) ||
            (currentUser.uid && row.user_id === currentUser.uid) ||
            (currentUser.id && row.user_id === currentUser.id) ||
            (cleanPhone && row.user_id === toSupabaseUuid(cleanPhone));

          if (isMatch) {
            const rawStatus = String(row.status || '').toUpperCase();
            const prevStatus = String(payload.old?.status || '').toUpperCase();
            const amt = Number(row.amount || 0);
            const isApproved = rawStatus === 'SUCCESS' || rawStatus === 'APPROVED';
            const wasApproved = prevStatus === 'SUCCESS' || prevStatus === 'APPROVED';

            let resolvedMainBalance = Number(currentUser.mainWallet ?? currentUser.walletBalance ?? 0);

            // Re-fetch user wallet directly from 'users' table
            try {
              const userUuid = toSupabaseUuid(currentUser.uid || currentUser.id || cleanPhone);
              let userQuery = supabase.from('users').select('*');
              if (cleanPhone && userUuid) {
                userQuery = userQuery.or(`mobile.eq.${cleanPhone},id.eq.${userUuid}`);
              } else if (cleanPhone) {
                userQuery = userQuery.eq('mobile', cleanPhone);
              } else {
                userQuery = userQuery.eq('id', userUuid);
              }
              const { data: userRow } = await userQuery.maybeSingle();

              if (userRow) {
                let newMain = Number(userRow.main_wallet ?? userRow.wallet_balance ?? currentUser.walletBalance ?? 0);
                const newWinning = Number(userRow.winning_wallet ?? 0);
                let newGaming = Number(userRow.gaming_wallet ?? newMain);

                // Auto-credit main_wallet if status became approved/SUCCESS via webhook or auto-verification
                // (checking dep_approved_<id> idempotency key so Admin Panel approvals never double-credit)
                if (isApproved && !wasApproved && amt > 0 && !creditedDepositsRef.current.has(String(row.id))) {
                  creditedDepositsRef.current.add(String(row.id));
                  const approvalTxId = toSupabaseUuid(`dep_approved_${row.id}`);

                  const { data: existingPassbook } = await supabase
                    .from('passbook')
                    .select('id')
                    .eq('id', approvalTxId)
                    .maybeSingle();

                  if (!existingPassbook) {
                    newMain = newMain + amt;
                    newGaming = newGaming + amt;
                    const targetUserId = userRow.id || userUuid;
                    const nowIso = new Date().toISOString();

                    await supabase
                      .from('users')
                      .update({ main_wallet: newMain, gaming_wallet: newGaming })
                      .eq('id', targetUserId);

                    await supabase.from('passbook').upsert(
                      {
                        id: approvalTxId,
                        user_id: targetUserId,
                        mobile: cleanPhone || row.mobile || '',
                        type: 'credit',
                        amount: amt,
                        description: `UPI Deposit Approved (${row.utr || 'Auto-Verified'}) | +₹${amt}`,
                        status: 'SUCCESS',
                        created_at: nowIso,
                      },
                      { onConflict: 'id' }
                    );

                    await supabase.from('transactions').upsert(
                      {
                        id: approvalTxId,
                        user_id: targetUserId,
                        amount: amt,
                        type: 'DEPOSIT',
                        status: 'SUCCESS',
                        payment_gateway: 'UPI_WEBHOOK_AUTOCREDIT',
                        created_at: nowIso,
                      },
                      { onConflict: 'id' }
                    );
                  }
                }

                resolvedMainBalance = newMain;
                setUser((prev) => {
                  const updated = {
                    ...prev,
                    walletBalance: newMain,
                    mainWallet: newMain,
                    gamingWallet: newGaming,
                    winningWallet: newWinning,
                  };
                  persistSession(updated);
                  return updated;
                });
              }
            } catch (err) {
              console.warn('[Supabase Realtime] User wallet refetch/auto-credit on deposit notice:', err);
            }

            if (isApproved) {
              setSecurityNotice({
                message: `🎉 Deposit Approved! ₹${amt.toLocaleString('en-IN')} has been credited to your Main Wallet.`,
                isError: false,
              });
              window.dispatchEvent(
                new CustomEvent('rama777:deposit_approved', {
                  detail: {
                    depositId: row.id,
                    orderId: row.utr,
                    amount: amt,
                    newBalance: resolvedMainBalance,
                  },
                })
              );
            } else if (rawStatus === 'FAILURE' || rawStatus === 'REJECTED') {
              setSecurityNotice({
                message: `❌ Deposit of ₹${amt.toLocaleString('en-IN')} was rejected or declined.`,
                isError: true,
              });
            }

            window.dispatchEvent(new CustomEvent('rama777:deposit_updated'));
            window.dispatchEvent(new CustomEvent('rama777:transactions_updated'));
          }
        }
      )
      .subscribe((status) => {
        console.log('[Supabase Realtime] public:deposits status:', status);
      });

    // 5. Channel: public:withdrawals (Real-time admin withdrawal approvals/rejections)
    const withdrawalsChannel = supabase
      .channel('public:withdrawals')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'withdrawals' },
        async (payload: any) => {
          if (!isMounted) return;
          console.log('[Supabase Realtime] public:withdrawals event:', payload.eventType, payload.new || payload.old);
          const currentUser = userRef.current;
          const cleanPhone = (currentUser.phone || '').replace(/\D/g, '');
          const row = payload.new;
          if (!row) return;

          const isMatch =
            (cleanPhone && row.mobile && row.mobile.replace(/\D/g, '') === cleanPhone) ||
            (currentUser.uid && row.user_id === currentUser.uid) ||
            (currentUser.id && row.user_id === currentUser.id);

          if (isMatch) {
            const rawStatus = String(row.status || '').toUpperCase();
            const amt = Number(row.amount || 0);

            // Re-fetch authoritative user wallet from 'users' table (admin approval/rejection already updates/refunds users table)
            try {
              const userUuid = toSupabaseUuid(currentUser.uid || currentUser.id || cleanPhone);
              let userQuery = supabase.from('users').select('*');
              if (cleanPhone && userUuid) {
                userQuery = userQuery.or(`mobile.eq.${cleanPhone},id.eq.${userUuid}`);
              } else if (cleanPhone) {
                userQuery = userQuery.eq('mobile', cleanPhone);
              } else {
                userQuery = userQuery.eq('id', userUuid);
              }
              const { data: userRow } = await userQuery.maybeSingle();

              if (userRow) {
                const newMain = Number(userRow.main_wallet ?? userRow.wallet_balance ?? currentUser.walletBalance ?? 0);
                const newWinning = Number(userRow.winning_wallet ?? currentUser.winningWallet ?? 0);
                const newGaming = Number(userRow.gaming_wallet ?? newMain);

                setUser((prev) => {
                  const updated = {
                    ...prev,
                    walletBalance: newMain,
                    mainWallet: newMain,
                    winningWallet: newWinning,
                    gamingWallet: newGaming,
                  };
                  persistSession(updated);
                  return updated;
                });
              }
            } catch (err) {
              console.warn('[Supabase Realtime] User wallet refetch on withdrawal notice:', err);
            }

            if (rawStatus === 'FAILURE' || rawStatus === 'REJECTED') {
              setSecurityNotice({
                message: `ℹ️ Withdrawal of ₹${amt} was rejected by Admin. ₹${amt} has been refunded to your wallet.`,
                isError: false,
              });
            } else if (rawStatus === 'SUCCESS' || rawStatus === 'APPROVED') {
              setSecurityNotice({
                message: `✅ Payout Approved! Withdrawal of ₹${amt} has been approved and transferred.`,
                isError: false,
              });
            }

            window.dispatchEvent(new CustomEvent('rama777:withdrawal_updated'));
            window.dispatchEvent(new CustomEvent('rama777:transactions_updated'));
          }
        }
      )
      .subscribe((status) => {
        console.log('[Supabase Realtime] public:withdrawals status:', status);
      });

    return () => {
      isMounted = false;
      clearTimeout(fallbackTimer);
      supabase.removeChannel(marketsChannel);
      supabase.removeChannel(bidsChannel);
      supabase.removeChannel(usersChannel);
      supabase.removeChannel(depositsChannel);
      supabase.removeChannel(withdrawalsChannel);
    };
  }, [timeOffsetMs]);

  // Automatic Daily Market Reset check on initial boot and window focus / visibility change
  useEffect(() => {
    const checkReset = () => {
      const now = new Date(Date.now() + timeOffsetMs);
      checkAndTriggerDailyMarketReset(now).catch((err) => {
        console.warn('[RAMA777] Daily market reset check notice:', err);
      });
    };

    // 1. Initial check on mount
    checkReset();

    // 2. Window focus & visibility change listener (mobile unlock, tab focus)
    const handleVisibilityOrFocus = () => {
      if (typeof document !== 'undefined' && document.visibilityState === 'visible') {
        checkReset();
      }
    };

    // 3. Listener for daily reset custom event to refresh UI state immediately
    const handleDailyResetEvent = () => {
      const now = new Date(Date.now() + timeOffsetMs);
      fetchRealtimeMarkets(now)
        .then((freshMarkets) => {
          if (freshMarkets && freshMarkets.length > 0) {
            latestRawMarketsRef.current = freshMarkets;
            setMarkets(freshMarkets);
          }
        })
        .catch(() => {});
    };

    window.addEventListener('visibilitychange', handleVisibilityOrFocus);
    window.addEventListener('focus', handleVisibilityOrFocus);
    window.addEventListener('rama777:market-daily-reset', handleDailyResetEvent);

    return () => {
      window.removeEventListener('visibilitychange', handleVisibilityOrFocus);
      window.removeEventListener('focus', handleVisibilityOrFocus);
      window.removeEventListener('rama777:market-daily-reset', handleDailyResetEvent);
    };
  }, [timeOffsetMs]);

  // Real-time ticking engine: evaluates markets, countdowns, and results every 1 second
  useEffect(() => {
    const tick = () => {
      const now = new Date(Date.now() + timeOffsetMs);
      setCurrentTime(now);

      const currentDateKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;

      // Daily date-check routine: Detect calendar day rollover
      if (lastCalendarDateKeyRef.current && lastCalendarDateKeyRef.current !== currentDateKey) {
        console.log(`[RAMA777 Date Engine] Calendar day rollover detected: ${lastCalendarDateKeyRef.current} -> ${currentDateKey}. Refreshing markets.`);

        // Trigger persistent Supabase & LocalStorage Daily Reset and bet archiving
        executeDailyMarketReset(now).catch((e) => {
          console.warn('[RAMA777] Midnight auto-reset notice:', e);
        });

        // 1. Reset latestRawMarketsRef: Clear out yesterday's declared numbers and reset session states
        latestRawMarketsRef.current = latestRawMarketsRef.current.map((market) => {
          let previousLastResult = market.lastResult;
          if (market.openPana && market.openPana !== '***' && market.closePana && market.closePana !== '***') {
            previousLastResult = `${market.openPana}-${market.jodi}-${market.closePana}`;
          }
          return {
            ...market,
            openPana: '***',
            jodi: '**',
            closePana: '***',
            lastResult: previousLastResult || market.lastResult,
            marketDate: currentDateKey,
            status: 'Running for Open',
            isOpen: true,
            allowedSession: 'all',
          };
        });

        // 2. Clear out in-memory processed win cache so new day's bids settle freshly
        processedWinsRef.current.clear();
      }

      lastCalendarDateKeyRef.current = currentDateKey;

      // Evaluate active markets directly from live Firestore collection without mock fallback
      const base = latestRawMarketsRef.current;
      const evaluated = mergeMarketResultsIntoMarkets(base, historicalResultsRef.current, now);
      setMarkets(evaluated);

      // Keep selected market for play updated if active overlay is open
      setSelectedMarketForPlay((prev) => {
        if (!prev) return null;
        const matching = evaluated.find((m) => m.id === prev.id);
        return matching || prev;
      });

      const slots = evaluateStarlineSlots(now);
      const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
        .toString()
        .padStart(2, '0')}/${now.getFullYear()}`;
      setStarlineResults(convertSlotsToStarlineResults(slots, dateStr));
    };

    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [timeOffsetMs]);

  const handleSetSimulatedTime = (hour: number, minute: number, addDays: number = 0) => {
    const nowReal = new Date();
    const target = new Date(
      nowReal.getFullYear(),
      nowReal.getMonth(),
      nowReal.getDate() + addDays,
      hour,
      minute,
      0
    );
    setTimeOffsetMs(target.getTime() - nowReal.getTime());
  };

  const handleResetRealTime = () => {
    setTimeOffsetMs(0);
  };

  // Active overlay view (e.g. gameplay, charts, rates, settings, change MPIN)
  const [activeOverlay, setActiveOverlay] = useState<string | null>(null);
  const [selectedMarketForPlay, setSelectedMarketForPlay] = useState<MarketItem | null>(null);
  const [selectedMarketForChart, setSelectedMarketForChart] = useState<string | null>(null);
  const [language, setLanguage] = useState<string>('English');

  // Reference for nested back handlers (e.g. sub-game mode in GamePlayView or specific chart in ChartsView)
  const subScreenBackHandlerRef = useRef<(() => boolean) | null>(null);
  const lastBackPressTimeRef = useRef<number>(0);
  const [showExitToast, setShowExitToast] = useState<boolean>(false);
  const exitToastTimerRef = useRef<any>(null);

  // Navigation stack depth & tracking refs
  const navDepthRef = useRef<number>(0);
  const activeOverlayRef = useRef(activeOverlay);
  const currentTabRef = useRef(currentTab);
  const isDrawerOpenRef = useRef(isDrawerOpen);
  const isAuthenticatedRef = useRef(isAuthenticated);
  const authModeRef = useRef(authMode);

  useEffect(() => {
    activeOverlayRef.current = activeOverlay;
  }, [activeOverlay]);

  useEffect(() => {
    currentTabRef.current = currentTab;
  }, [currentTab]);

  useEffect(() => {
    isDrawerOpenRef.current = isDrawerOpen;
  }, [isDrawerOpen]);

  useEffect(() => {
    isAuthenticatedRef.current = isAuthenticated;
  }, [isAuthenticated]);

  useEffect(() => {
    authModeRef.current = authMode;
  }, [authMode]);

  const isBackActionInProgressRef = useRef<boolean>(false);

  // Push new navigation state onto browser/webview history
  const pushNavState = (tag: string) => {
    navDepthRef.current += 1;
    try {
      window.history.pushState({ tag, depth: navDepthRef.current }, '');
    } catch {
      // Ignore
    }
  };

  // Unified history navigation handlers
  const openOverlay = (
    overlay: string,
    meta?: { marketForPlay?: MarketItem | null; marketForChart?: string | null }
  ) => {
    if (meta?.marketForPlay !== undefined) setSelectedMarketForPlay(meta.marketForPlay);
    if (meta?.marketForChart !== undefined) setSelectedMarketForChart(meta.marketForChart);
    setActiveOverlay(overlay);
    pushNavState(`overlay:${overlay}`);
  };

  const closeOverlay = () => {
    setActiveOverlay(null);
    setSelectedMarketForPlay(null);
    setSelectedMarketForChart(null);
    subScreenBackHandlerRef.current = null;
    if (navDepthRef.current > 0) {
      isBackActionInProgressRef.current = true;
      try {
        window.history.back();
      } catch {}
      setTimeout(() => {
        isBackActionInProgressRef.current = false;
      }, 150);
    }
  };

  const handleTabChange = (tab: MainTab) => {
    if (tab !== currentTab) {
      if (tab === 'home' && navDepthRef.current > 0) {
        isBackActionInProgressRef.current = true;
        try {
          window.history.back();
        } catch {}
        setTimeout(() => {
          isBackActionInProgressRef.current = false;
        }, 150);
      } else if (tab !== 'home') {
        pushNavState(`tab:${tab}`);
      }
      setCurrentTab(tab);
      setActiveOverlay(null);
      subScreenBackHandlerRef.current = null;
    }
  };

  const handleOpenDrawer = () => {
    setIsDrawerOpen(true);
    pushNavState('drawer');
  };

  const handleCloseDrawer = () => {
    setIsDrawerOpen(false);
  };

  // Trigger Home exit confirmation or close native app on double back
  const handleHomeExit = () => {
    const now = Date.now();
    if (now - lastBackPressTimeRef.current < 2000) {
      try {
        (window as any)?.Capacitor?.Plugins?.App?.exitApp?.();
      } catch (e) {
        (navigator as any)?.app?.exitApp?.();
      }
    } else {
      lastBackPressTimeRef.current = now;
      setShowExitToast(true);
      if (exitToastTimerRef.current) {
        clearTimeout(exitToastTimerRef.current);
      }
      exitToastTimerRef.current = setTimeout(() => {
        setShowExitToast(false);
      }, 2000);

      // Guard the root state so mobile browser doesn't exit on a single accidental back tap
      try {
        window.history.pushState({ screen: 'app-root', depth: 0 }, '');
      } catch {
        // Ignore
      }
    }
  };

  // Centralized hardware back button dispatcher for Android APK, WebView, and mobile browser
  const handleHardwareBackPress = () => {
    // 0. Priority 0: If unauthenticated
    if (!isAuthenticatedRef.current) {
      if (authModeRef.current === 'register') {
        setAuthMode('login');
        return;
      }
      handleHomeExit();
      return;
    }

    // 1. Priority 1: If side drawer is open, close it cleanly
    if (isDrawerOpenRef.current) {
      setIsDrawerOpen(false);
      return;
    }

    // 2. Priority 2: If a sub-screen has its own active nested back handler
    // (e.g. sub-game betting mode in GamePlayView, sub-view in FundsTab, sub-view in HistoryTab, or specific chart in ChartsView)
    if (subScreenBackHandlerRef.current) {
      try {
        const handled = subScreenBackHandlerRef.current();
        if (handled) return;
      } catch (e) {
        console.warn('Error in subScreenBackHandler:', e);
      }
    }

    // 3. Priority 3: If an overlay/sub-screen is active (GamePlayView, Charts, Rates, Settings, etc.), return cleanly to Home dashboard
    if (activeOverlayRef.current) {
      setActiveOverlay(null);
      setSelectedMarketForPlay(null);
      setSelectedMarketForChart(null);
      subScreenBackHandlerRef.current = null;
      return;
    }

    // 4. Priority 4: If on any sub-tab (funds/wallet, passbook, history, support), cleanly navigate back to Home dashboard
    if (currentTabRef.current !== 'home') {
      setCurrentTab('home');
      subScreenBackHandlerRef.current = null;
      return;
    }

    // 5. Priority 5: User is on the root Home screen.
    // Intercept and prompt before exiting the app (double-press back within 2 seconds to exit)
    handleHomeExit();
  };

  // Hardware back button lifecycle & event listener integration
  useEffect(() => {
    // 1. Maintain initial history entries so Android WebView / mobile browser never exits unexpectedly
    try {
      window.history.replaceState({ screen: 'app-root', depth: 0 }, '');
      window.history.pushState({ screen: 'app-root', depth: 0 }, '');
    } catch (e) {
      // Ignore
    }

    // 2. Android Capacitor hardware back button integration
    let capacitorListener: any = null;
    try {
      const capApp = (window as any)?.Capacitor?.Plugins?.App;
      if (capApp?.addListener) {
        capApp.addListener('backButton', () => {
          handleHardwareBackPress();
        }).then((handle: any) => {
          capacitorListener = handle;
        }).catch((err: any) => {
          console.warn('CapacitorApp backButton setup notice:', err);
        });
      }
    } catch (err) {
      console.warn('CapacitorApp backButton not available:', err);
    }

    // 3. Cordova / PhoneGap / Android WebView backbutton event
    const handleCordovaBackButton = (e: Event) => {
      e.preventDefault();
      handleHardwareBackPress();
    };
    document.addEventListener('backbutton', handleCordovaBackButton, false);

    // 4. Browser / WebView popstate listener
    const handlePopState = (e: PopStateEvent) => {
      e.preventDefault();
      if (navDepthRef.current > 0) {
        navDepthRef.current -= 1;
      }
      if (isBackActionInProgressRef.current) {
        isBackActionInProgressRef.current = false;
        return;
      }
      handleHardwareBackPress();
    };
    window.addEventListener('popstate', handlePopState);

    return () => {
      if (capacitorListener?.remove) {
        capacitorListener.remove();
      }
      document.removeEventListener('backbutton', handleCordovaBackButton);
      window.removeEventListener('popstate', handlePopState);
      if (exitToastTimerRef.current) {
        clearTimeout(exitToastTimerRef.current);
      }
    };
  }, []);

  // Sync dark mode class on document element
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const handleUpdateMpin = (newMpin: string) => {
    const updatedUser = {
      ...user,
      mpin: newMpin,
    };
    setUser(updatedUser);
    syncUserToFirestore(updatedUser);
  };

  const handleLoginSuccess = (loginData?: UserProfile | string) => {
    let updatedUser: UserProfile;

    if (loginData && typeof loginData === 'object' && 'name' in loginData) {
      updatedUser = loginData as UserProfile;
    } else {
      const effectivePhone = (typeof loginData === 'string' ? loginData : user.phone) || user.phone;
      const cleanPhone = effectivePhone.replace(/\D/g, '');
      const userUid = user.uid || (cleanPhone ? `user_${cleanPhone}` : '');
      updatedUser = {
        ...user,
        phone: effectivePhone,
        uid: userUid,
        id: userUid,
      };
    }

    persistSession(updatedUser);
    setUser(updatedUser);
    setIsAuthenticated(true);
    setCurrentTab('home');
    setActiveOverlay(null);
  };

  const handleGoogleLoginSuccess = (supabaseUser: any) => {
    const updatedUser: UserProfile = {
      ...user,
      uid: supabaseUser.id || supabaseUser.uid,
      id: supabaseUser.id || supabaseUser.uid,
      name: supabaseUser.user_metadata?.full_name || supabaseUser.displayName || user.name || 'RAMA Player',
      email: supabaseUser.email || user.email,
      phone: supabaseUser.phone || user.phone || '',
      walletBalance: user.walletBalance || 0,
      role: 'user',
    };
    persistSession(updatedUser);
    setUser(updatedUser);
    setIsAuthenticated(true);
    setAuthMode('login');
    setCurrentTab('home');
    setActiveOverlay(null);
    syncUserToFirestore(updatedUser);
  };

  const handleLogout = async () => {
    setIsDrawerOpen(false);
    clearSession();
    try {
      await supabase.auth.signOut();
    } catch (err) {
      console.warn('Signout notice:', err);
    }
    setUser({
      name: 'Player',
      phone: '',
      walletBalance: 0,
      mainWallet: 0,
      winningWallet: 0,
      gamingWallet: 0,
      mpin: '',
      biometricEnabled: true,
      appVersion: '1.0.2',
      role: 'user',
    });
    setTransactions([]);
    setAddFundsHistory([]);
    setWithdrawFundsHistory([]);
    setBankAccounts([]);
    setBids([]);
    setIsAuthenticated(false);
    setAuthMode('login');
    setActiveOverlay(null);
    setCurrentTab('home');
  };

  const handleRegisterSuccess = (newUser: UserProfile) => {
    const cleanUid = newUser.uid || `user_${newUser.phone.replace(/\D/g, '')}`;
    const cleanUser: UserProfile = {
      ...newUser,
      uid: cleanUid,
      id: cleanUid,
      walletBalance: newUser.walletBalance || 500, // ₹500 Welcome Bonus
      role: newUser.role || 'user',
    };

    // Store registered phone for login pre-fill and precise session binding
    if (cleanUser.phone) {
      localStorage.setItem('rama777_active_mobile', cleanUser.phone);
      localStorage.setItem('rama777_user_phone', cleanUser.phone);
      localStorage.setItem('rama777_last_registered_phone', cleanUser.phone);
    }
    localStorage.setItem('rama777_post_register_notice', 'true');
    setUser(cleanUser);

    // Require explicit MPIN login: do not auto-login or open dashboard directly
    setIsAuthenticated(false);
    setAuthMode('login');
    setActiveOverlay(null);

    // Sync user profile to Firestore
    syncUserToFirestore(cleanUser);

    // Add welcome notification
    const welcomeNotif: AppNotification = {
      id: `notif-${Date.now()}`,
      title: `Welcome, ${cleanUser.name}!`,
      message: 'Your RAMA777 account is active. 4-digit MPIN and Biometric security successfully configured.',
      time: 'Just now',
      read: false,
      type: 'alert',
    };

    setNotifications((prev) => [welcomeNotif, ...prev]);
    broadcastNotificationInFirestore({
      ...welcomeNotif,
      targetPhone: cleanUser.phone,
    });
  };

  const handlePlaceBid = (
    bidData: Omit<GameBid, 'id' | 'date' | 'status'> | Omit<GameBid, 'id' | 'date' | 'status'>[]
  ): boolean => {
    const bidsArray = Array.isArray(bidData) ? bidData : [bidData];
    if (bidsArray.length === 0) {
      return false;
    }

    // Rate Limiting on bid submissions
    const userScopeKey = user.uid || user.phone || 'guest';
    const rateCheck = checkRateLimit('game:place_bid', userScopeKey);
    if (!rateCheck.allowed) {
      setSecurityNotice({ message: rateCheck.errorMessage || 'Please wait before placing more bids.', isError: true });
      return false;
    }

    // Calculate the complete accumulated sum of all points in the active bid slip with sanitization
    const totalPoints = bidsArray.reduce((sum, b) => {
      const cleanPts = sanitizeAmount(b.points, 1, 100000);
      return sum + (cleanPts.isValid ? cleanPts.amount : 0);
    }, 0);

    if (totalPoints <= 0 || user.walletBalance < totalPoints) {
      return false;
    }

    recordActionAttempt('game:place_bid', userScopeKey, true);

    const prevBal = user.walletBalance;
    const newBal = prevBal - totalPoints;
    const now = new Date();
    const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
      .toString()
      .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    })}`;

    const newBids: GameBid[] = bidsArray.map((bidItem, idx) => ({
      ...bidItem,
      points: sanitizeAmount(bidItem.points, 1, 100000).amount || Number(bidItem.points),
      marketName: sanitizeText(bidItem.marketName, 50),
      gameType: sanitizeText(bidItem.gameType, 50),
      digitOrPana: sanitizeText(bidItem.digitOrPana, 10),
      id: `bid-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 7)}`,
      date: dateStr,
      status: 'Placed',
    }));

    const firstBid = bidsArray[0];
    const marketName = firstBid.marketName;
    const digitsSample = bidsArray.map((b) => b.digitOrPana).slice(0, 4).join(', ');
    const description =
      bidsArray.length === 1
        ? `${firstBid.gameType} (${firstBid.session}) #${firstBid.digitOrPana}`
        : `${firstBid.gameType} (${firstBid.session}) • ${bidsArray.length} Bids (#${digitsSample}${
            bidsArray.length > 4 ? '...' : ''
          })`;

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      title: `${marketName} Bid | ₹${totalPoints}`,
      referenceId: `BID-${Math.random().toString(36).substring(2, 9).toUpperCase()}`,
      description,
      amount: totalPoints,
      type: 'debit',
      status: 'SUCCESS',
      date: dateStr,
      previousBalance: prevBal,
      currentBalance: newBal,
    };

    const updatedUser = { ...user, walletBalance: newBal };
    setUser(updatedUser);
    setBids((prev) => [...newBids, ...prev]);
    setTransactions((prev) => [newTx, ...prev]);

    // Real-time Firestore sync
    for (const bidItem of bidsArray) {
      placeBidInFirestore(bidItem, user);
    }
    recordTransactionInFirestore(newTx, user);
    syncUserToFirestore(updatedUser);

    return true;
  };

  const handleAddFunds = (
    amount: number,
    bonus: number = 0,
    depositMode: string = 'Kotak Merchant UPI',
    utrOrOrderId?: string,
    status: 'Success' | 'Pending' = 'Success'
  ) => {
    // Rate Limiting check on Add Fund requests
    const userScopeKey = user.uid || user.phone || 'guest';
    const rateCheck = checkRateLimit('funds:deposit', userScopeKey);
    if (!rateCheck.allowed) {
      setSecurityNotice({ message: rateCheck.errorMessage || 'Please wait before submitting deposit requests.', isError: true });
      return;
    }
    recordActionAttempt('funds:deposit', userScopeKey, true);

    const safeAmountResult = sanitizeAmount(amount, 1, 500000);
    const safeAmount = safeAmountResult.isValid ? safeAmountResult.amount : Math.max(1, amount);
    const safeBonusResult = sanitizeAmount(bonus, 0, 50000);
    const safeBonus = safeBonusResult.isValid ? safeBonusResult.amount : 0;
    const safeDepositMode = sanitizeText(depositMode, 40);

    const totalAdded = safeAmount + safeBonus;
    const prevBal = user.walletBalance;
    const isSuccess = status === 'Success';
    const newBal = isSuccess ? prevBal + totalAdded : prevBal;
    const now = new Date();
    const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
      .toString()
      .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    const orderId =
      utrOrOrderId && utrOrOrderId.trim().length > 0
        ? sanitizeText(utrOrOrderId.trim(), 32)
        : `RAMA${Math.floor(100000 + Math.random() * 900000)}`;
    const depositUuid = toSupabaseUuid(orderId);

    const newHistory: FundHistoryItem = {
      id: depositUuid,
      orderId,
      date: dateStr,
      amount: totalAdded,
      status: status,
      requestType: 'Credit',
      depositMode: safeDepositMode,
      utrOrReference: orderId,
    };

    const newTx: Transaction = {
      id: toSupabaseUuid(`tx_${orderId}`),
      title: isSuccess
        ? (safeBonus > 0 ? `Welcome Bonus Added | ₹${totalAdded}` : `UPI Topup SUCCESS | ₹${safeAmount}`)
        : `UPI Deposit (Pending Verification) | ₹${safeAmount}`,
      referenceId: orderId,
      description: `${safeDepositMode} | Order: ${orderId}`,
      amount: totalAdded,
      type: 'credit',
      status: isSuccess ? 'SUCCESS' : 'PENDING',
      date: dateStr,
      previousBalance: prevBal,
      currentBalance: newBal,
    };

    if (isSuccess) {
      const updatedUser = {
        ...user,
        walletBalance: newBal,
        mainWallet: (user.mainWallet ?? user.walletBalance) + totalAdded,
      };
      setUser(updatedUser);
      syncUserToFirestore(updatedUser);
    }

    setAddFundsHistory((prev) => [newHistory, ...prev.filter((d) => d.id !== depositUuid)]);
    setTransactions((prev) => [newTx, ...prev.filter((t) => t.id !== newTx.id)]);

    // Real-time Supabase sync to deposits, transactions & passbook
    createDepositInFirestore(newHistory, user, safeBonus);
    recordTransactionInFirestore(newTx, user, isSuccess ? 'UPI_INSTANT' : 'UPI_INTENT_PENDING');
  };

  const handleAddFundsFailure = (
    orderId: string,
    amount: number,
    depositMode: string = 'Kotak Merchant UPI',
    reason: string = 'Payment Failed'
  ) => {
    const now = new Date();
    const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
      .toString()
      .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    const failedHistory: FundHistoryItem = {
      id: `afh-fail-${Date.now()}`,
      orderId,
      date: dateStr,
      amount,
      status: 'Failure',
      requestType: 'Credit',
      depositMode,
    };

    const failedTx: Transaction = {
      id: `tx-fail-${Date.now()}`,
      title: `Add Fund FAILED | ₹${amount}`,
      referenceId: orderId,
      description: `${reason} | ${depositMode}`,
      amount,
      type: 'credit',
      status: 'FAILED',
      date: dateStr,
      previousBalance: user.walletBalance,
      currentBalance: user.walletBalance, // Wallet points are NOT credited on failure!
    };

    // User wallet balance is strictly protected and remains unchanged
    setAddFundsHistory((prev) => [failedHistory, ...prev]);
    setTransactions((prev) => [failedTx, ...prev]);

    // Real-time Firestore sync of failure record
    createDepositInFirestore(failedHistory, user, 0);
    recordTransactionInFirestore(failedTx, user);
  };

  const handleWithdrawFunds = (amount: number, bankId: string): boolean => {
    // Rate Limiting check on Withdrawal requests
    const userScopeKey = user.uid || user.phone || 'guest';
    const rateCheck = checkRateLimit('funds:withdraw', userScopeKey);
    if (!rateCheck.allowed) {
      setSecurityNotice({ message: rateCheck.errorMessage || 'Please wait before submitting withdrawal requests.', isError: true });
      return false;
    }

    const safeAmountResult = sanitizeAmount(amount, 100, 100000);
    const safeAmount = safeAmountResult.isValid ? safeAmountResult.amount : amount;

    if (user.walletBalance < safeAmount) {
      setSecurityNotice({ message: 'Insufficient wallet balance for withdrawal.', isError: true });
      return false;
    }

    recordActionAttempt('funds:withdraw', userScopeKey, true);

    const bank = bankAccounts.find((b) => b.id === bankId) || bankAccounts[0];
    const prevBal = user.walletBalance;
    const newBal = prevBal - safeAmount;
    const now = new Date();
    const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
      .toString()
      .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    const orderId = `TNX${Date.now()}`;
    const withUuid = toSupabaseUuid(orderId);
    const newHistory: FundHistoryItem = {
      id: withUuid,
      orderId,
      date: dateStr,
      amount: safeAmount,
      status: 'Pending',
      requestType: 'Debit',
      depositMode: 'Bank Transfer',
      bankName: bank?.bankName || 'Bank Account',
      accountNumber: bank?.accountNumber || '',
      ifscCode: bank?.ifscCode || '',
    };

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      title: `Withdrawal Request PENDING | ₹${amount}`,
      referenceId: orderId,
      description: `Bank Transfer to ${bank?.bankName || 'Linked Bank'}`,
      amount,
      type: 'debit',
      status: 'PENDING',
      date: dateStr,
      previousBalance: prevBal,
      currentBalance: newBal,
    };

    const updatedUser = { ...user, walletBalance: newBal };
    setUser(updatedUser);
    setWithdrawFundsHistory((prev) => [newHistory, ...prev]);
    setTransactions((prev) => [newTx, ...prev]);

    // Real-time Firestore sync
    createWithdrawalInFirestore(newHistory, user);
    recordTransactionInFirestore(newTx, user);
    syncUserToFirestore(updatedUser);

    return true;
  };

  const handleAddBank = (bankData: Omit<BankAccount, 'id' | 'updatedAt'>) => {
    const now = new Date();
    const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
      .toString()
      .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    const lockDate = new Date();
    lockDate.setDate(lockDate.getDate() + 30);
    const lockDateStr = `${lockDate.getDate().toString().padStart(2, '0')}/${(lockDate.getMonth() + 1)
      .toString()
      .padStart(2, '0')}/${lockDate.getFullYear()}`;

    const newBank: BankAccount = {
      ...bankData,
      id: `bank-${Date.now()}`,
      updatedAt: dateStr,
      status: bankData.status || 'Success',
      lockUntil: lockDateStr,
    };

    setBankAccounts((prev) => [newBank, ...prev]);

    // Real-time Firestore sync
    addBankAccountToFirestore(bankData, user);
  };

  const handleSelectDrawerOption = (optionId: string) => {
    switch (optionId) {
      case 'home':
        setCurrentTab('home');
        closeOverlay();
        break;
      case 'admin_panel':
        openOverlay('admin_panel');
        break;
      case 'result_management':
        openOverlay('admin_panel');
        break;
      case 'charts':
        openOverlay('charts');
        break;
      case 'change_mpin':
        openOverlay('change_mpin');
        break;
      case 'notifications':
        openOverlay('notifications');
        break;
      case 'how_to_play':
        openOverlay('how_to_play');
        break;
      case 'submit_ideas':
        openOverlay('submit_ideas');
        break;
      case 'game_rates':
        openOverlay('game_rates');
        break;
      case 'terms':
        openOverlay('terms');
        break;
      case 'settings':
        openOverlay('settings');
        break;
      case 'language':
        openOverlay('language');
        break;
      default:
        break;
    }
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  if (isAuthChecking || showSplash) {
    return <SplashScreen />;
  }

  return (
    <div
      className="w-full bg-[#FFFFFF] flex items-center justify-center select-none"
      style={{
        height: '100vh',
        maxHeight: '100vh',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      {/* Root/Main Container of the App with crisp white background */}
      <div
        className="w-full max-w-md mx-auto bg-[#FFFFFF] text-slate-800 relative shadow-2xl border-x border-slate-200"
        style={{
          height: '100vh',
          maxHeight: '100vh',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        {!isAuthenticated ? (
          <div
            className="w-full"
            style={{ flex: 1, minHeight: 0, overflowY: 'auto' }}
          >
            {authMode === 'register' ? (
              /* New Registration Screen */
              <RegisterScreen
                onRegisterSuccess={handleRegisterSuccess}
                onNavigateToLogin={() => setAuthMode('login')}
              />
            ) : (
              /* MPIN & Password Login Flow */
              <LoginScreen
                onLoginSuccess={handleLoginSuccess}
                savedMpin={user.mpin}
                onUpdateMpin={handleUpdateMpin}
                phone={user.phone}
                onNavigateToRegister={() => setAuthMode('register')}
              />
            )}
          </div>
        ) : (
          <>
            {/* Top Fixed Header with flex-shrink: 0 */}
            {!activeOverlay && (
              <div style={{ flexShrink: 0 }} className="shrink-0">
                <Header
                  currentTab={currentTab}
                  walletBalance={user.walletBalance}
                  mainWallet={user.mainWallet}
                  winningWallet={user.winningWallet}
                  unreadNotificationsCount={unreadCount}
                  userRole={user.role}
                  onOpenDrawer={handleOpenDrawer}
                  onOpenNotifications={() => {
                    markAllNotificationsRead(notifications.map((n) => n.id));
                    openOverlay('notifications');
                  }}
                  onNavigateToFunds={() => handleTabChange('funds')}
                  onOpenAdminHub={() => openOverlay('admin_panel')}
                />
              </div>
            )}

            {/* Side Drawer Menu */}
            <SideDrawer
              isOpen={isDrawerOpen}
              onClose={handleCloseDrawer}
              user={user}
              isDarkMode={isDarkMode}
              onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
              onSelectOption={handleSelectDrawerOption}
              onLogout={handleLogout}
            />

            {/* Middle Content Area - flex: 1, column layout with nested independent scroll for Home */}
            <main
              className="bg-[#FFFFFF] text-slate-800 overscroll-contain flex-1 flex flex-col min-h-0"
              style={{
                flex: 1,
                minHeight: 0,
                display: 'flex',
                flexDirection: 'column',
                overflowY: currentTab === 'home' && !activeOverlay ? 'hidden' : 'auto',
                overflowX: 'hidden',
                WebkitOverflowScrolling: 'touch',
              }}
            >
                {activeOverlay === 'gameplay' && selectedMarketForPlay ? (
                  <GamePlayView
                    market={markets.find((m) => m.id === selectedMarketForPlay.id) || selectedMarketForPlay}
                    walletBalance={user.walletBalance}
                    onBack={closeOverlay}
                    onPlaceBid={handlePlaceBid}
                    onRegisterBackHandler={(fn) => { subScreenBackHandlerRef.current = fn; }}
                    onPushSubScreen={pushNavState}
                  />
                ) : activeOverlay === 'charts' ? (
                  <ChartsView
                    markets={markets}
                    initialMarket={selectedMarketForChart}
                    historicalResults={historicalResults}
                    currentTime={currentTime}
                    onBack={closeOverlay}
                    onRegisterBackHandler={(fn) => { subScreenBackHandlerRef.current = fn; }}
                    onPushSubScreen={pushNavState}
                  />
                ) : activeOverlay === 'admin_panel' || activeOverlay === 'result_management' ? (
                  <AdminPanelModal
                    currentUser={user}
                    markets={markets}
                    currentTime={currentTime}
                    onClose={closeOverlay}
                    onSwitchUser={(newUser) => {
                      persistSession(newUser);
                      setUser(newUser);
                    }}
                  />
                ) : activeOverlay === 'change_mpin' ? (
                  <ChangeMpinModal
                    currentMpin={user.mpin}
                    userPhone={user.phone}
                    userId={user.uid || user.id}
                    onUpdateMpin={handleUpdateMpin}
                    onClose={closeOverlay}
                  />
                ) : activeOverlay === 'game_rates' ? (
                  <GameRatesModal onClose={closeOverlay} />
                ) : activeOverlay === 'starline' ? (
                  <StarlineJackpotModal
                    type="starline"
                    walletBalance={user.walletBalance}
                    starlineResults={starlineResults}
                    currentTime={currentTime}
                    onBack={closeOverlay}
                    onPlaceBid={handlePlaceBid}
                  />
                ) : activeOverlay === 'jackpot' ? (
                  <StarlineJackpotModal
                    type="jackpot"
                    walletBalance={user.walletBalance}
                    starlineResults={starlineResults}
                    currentTime={currentTime}
                    onBack={closeOverlay}
                    onPlaceBid={handlePlaceBid}
                  />
                ) : activeOverlay === 'notifications' ? (
                  <NotificationsModal
                    notifications={notifications}
                    onClose={closeOverlay}
                    onClear={() => {
                      clearAllNotifications(notifications.map((n) => n.id));
                      setNotifications([]);
                    }}
                  />
                ) : activeOverlay === 'how_to_play' ? (
                  <HowToPlayModal onClose={closeOverlay} />
                ) : activeOverlay === 'submit_ideas' ? (
                  <SubmitIdeasModal onClose={closeOverlay} />
                ) : activeOverlay === 'settings' ? (
                  <SettingsModal
                    biometric={user.biometricEnabled}
                    onToggleBiometric={async () => {
                      const next = !user.biometricEnabled;
                      if (next && !hasStoredBiometricCredential(user.phone)) {
                        const res = await registerBiometricCredential(
                          user.id || user.uid || 'user',
                          user.name,
                          user.phone
                        );
                        if (!res.success) {
                          setBiometricEnabled(false);
                          setUser((p) => ({ ...p, biometricEnabled: false }));
                          return;
                        }
                      }
                      setBiometricEnabled(next);
                      setUser((p) => ({ ...p, biometricEnabled: next }));
                    }}
                    language={language}
                    onChangeLanguage={setLanguage}
                    onClose={closeOverlay}
                  />
                ) : activeOverlay === 'language' ? (
                  <LanguageModal
                    currentLanguage={language}
                    onSelectLanguage={setLanguage}
                    onClose={closeOverlay}
                  />
                ) : activeOverlay === 'terms' ? (
                  <div className="pb-6 pt-2 px-4 space-y-4">
                    <div className="flex items-center gap-2.5 mb-4">
                      <button
                        onClick={closeOverlay}
                        className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
                      >
                        ←
                      </button>
                      <h2 className="text-base font-extrabold text-[#FF7700]">Terms & Conditions</h2>
                    </div>
                    <div className="bg-white rounded-3xl p-5 border border-slate-200 text-xs text-slate-700 leading-relaxed space-y-3 shadow-md">
                      <p className="font-bold text-slate-900">1. Eligibility</p>
                      <p>Users must be 18 years of age or older to register and place bids on RAMA777.</p>
                      <p className="font-bold text-slate-900">2. Fair Play & Results</p>
                      <p>All market results are official and verified in accordance with national market timings.</p>
                      <p className="font-bold text-slate-900">3. Fast Withdrawals</p>
                      <p>Withdrawals are processed to the user&apos;s verified bank account within 24 hours.</p>
                    </div>
                  </div>
                ) : (
                  /* Standard 5 Tab Navigation */
                  <>
                    {currentTab === 'home' && (
                      <HomeTab
                        markets={markets}
                        currentTime={currentTime}
                        isSimulated={timeOffsetMs !== 0}
                        onSetSimulatedTime={handleSetSimulatedTime}
                        onResetRealTime={handleResetRealTime}
                        onPlayMarket={(m) => {
                          openOverlay('gameplay', { marketForPlay: m });
                        }}
                        onOpenChart={(marketName) => {
                          openOverlay('charts', { marketForChart: `${marketName} Panel Chart` });
                        }}
                        onOpenStarline={() => openOverlay('starline')}
                        onOpenJackpot={() => openOverlay('jackpot')}
                      />
                    )}

                    {currentTab === 'history' && (
                      <HistoryTab
                        bids={bids}
                        starlineResults={starlineResults}
                        markets={markets}
                        onRegisterBackHandler={(fn) => { subScreenBackHandlerRef.current = fn; }}
                        onPushSubScreen={pushNavState}
                      />
                    )}

                    {currentTab === 'passbook' && (
                      <PassbookTab transactions={transactions} />
                    )}

                    {currentTab === 'funds' && (
                      <FundsTab
                        user={user}
                        addFundsHistory={addFundsHistory}
                        withdrawFundsHistory={withdrawFundsHistory}
                        bankAccounts={bankAccounts}
                        onAddFunds={handleAddFunds}
                        onAddFundsFailure={handleAddFundsFailure}
                        onWithdrawFunds={handleWithdrawFunds}
                        onAddBank={handleAddBank}
                        gatewayConfig={gatewayConfig}
                        onRegisterBackHandler={(fn) => { subScreenBackHandlerRef.current = fn; }}
                        onPushSubScreen={pushNavState}
                      />
                    )}

                    {currentTab === 'support' && <SupportTab />}
                  </>
                )}
              </main>

              {/* Fixed Bottom Navigation Bar with flex-shrink: 0 */}
              {!activeOverlay && (
                <div style={{ flexShrink: 0 }} className="shrink-0">
                  <BottomNavBar currentTab={currentTab} onTabChange={handleTabChange} />
                </div>
              )}

              {/* Security Shield & Rate Limit Notification Banner */}
              {securityNotice && (
                <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-white/95 backdrop-blur-md text-slate-800 border border-amber-500/40 px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2.5 animate-in fade-in slide-in-from-top-3 max-w-sm w-[92%] mx-auto">
                  {securityNotice.isError ? (
                    <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0" />
                  ) : (
                    <ShieldCheck className="w-5 h-5 text-emerald-500 shrink-0" />
                  )}
                  <span className="text-xs font-semibold leading-tight flex-1 text-slate-800">{securityNotice.message}</span>
                  <button
                    onClick={() => setSecurityNotice(null)}
                    className="text-slate-400 hover:text-slate-700 p-1 rounded-lg cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* Native-style Android Back Press Exit Toast */}
              {showExitToast && (
                <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-slate-900/95 backdrop-blur-md text-white border border-slate-700 px-4 py-2.5 rounded-full shadow-2xl flex items-center gap-2.5 animate-in fade-in slide-in-from-bottom-3 duration-200 pointer-events-none">
                  <div className="w-2 h-2 rounded-full bg-[#FF7700] animate-pulse" />
                  <span className="text-xs font-bold tracking-wide">Press back again to exit RAMA777</span>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    );
  }
