/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export function sanitizeAmount(
  value: string | number,
  min: number = 1,
  max: number = 1000000
): { isValid: boolean; amount: number; error?: string } {
  const num = typeof value === 'number' ? value : parseFloat(String(value).replace(/[^0-9.]/g, ''));
  if (isNaN(num)) {
    return { isValid: false, amount: 0, error: 'Please enter a valid numeric amount' };
  }
  if (num < min) {
    return { isValid: false, amount: num, error: `Minimum amount is ₹${min.toLocaleString('en-IN')}` };
  }
  if (num > max) {
    return { isValid: false, amount: num, error: `Maximum amount is ₹${max.toLocaleString('en-IN')}` };
  }
  return { isValid: true, amount: Math.floor(num) };
}

export function sanitizeBankAccount(val: string): {
  isValid: boolean;
  accountNumber: string;
  error?: string;
} {
  const clean = String(val || '').replace(/\D/g, '');
  if (clean.length < 9 || clean.length > 18) {
    return {
      isValid: false,
      accountNumber: clean,
      error: 'Bank account number must be between 9 and 18 digits',
    };
  }
  return { isValid: true, accountNumber: clean };
}

export function sanitizeIfsc(val: string): {
  isValid: boolean;
  ifsc: string;
  error?: string;
} {
  const clean = String(val || '').toUpperCase().trim();
  const ifscRegex = /^[A-Z]{4}0[A-Z0-9]{6}$/;
  if (!ifscRegex.test(clean)) {
    return {
      isValid: false,
      ifsc: clean,
      error: 'Invalid IFSC Code (e.g. SBIN0001234 or HDFC0001234)',
    };
  }
  return { isValid: true, ifsc: clean };
}

export function sanitizeText(val: string | undefined | null, maxLength: number = 100): string {
  if (!val) return '';
  return String(val)
    .replace(/[<>'"`;]/g, '')
    .trim()
    .slice(0, maxLength);
}
