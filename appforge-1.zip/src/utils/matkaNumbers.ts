/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export const SINGLE_DIGITS = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

export const ODD_DIGITS = ['1', '3', '5', '7', '9'];

export const EVEN_DIGITS = ['0', '2', '4', '6', '8'];

export const JODI_DIGITS: string[] = Array.from({ length: 100 }, (_, i) =>
  i.toString().padStart(2, '0')
);

// 20 Red Brackets (10 Full-Red + 10 Half-Red)
export const RED_BRACKETS = [
  '00', '11', '22', '33', '44', '55', '66', '77', '88', '99',
  '05', '50', '16', '61', '27', '72', '38', '83', '49', '94',
];

export const QUICK_AMOUNT_CHIPS = [10, 20, 50, 100, 500];

export const TRIPLE_PANAS = [
  '000', '111', '222', '333', '444', '555', '666', '777', '888', '999',
];

// Single Panas: 3 digits sorted strictly ascending (d1 < d2 < d3, with 0 treated as 10 for ordering)
// Total 120 single panas
export const ALL_SINGLE_PANAS: string[] = [];
// Double Panas: exactly 2 identical digits, sorted (d1 <= d2 <= d3)
// Total 90 double panas
export const ALL_DOUBLE_PANAS: string[] = [];

// Helper to calculate sum digit (Matka sum mod 10)
export function getSumDigit(d1: number, d2: number, d3: number): number {
  return (d1 + d2 + d3) % 10;
}

export const SINGLE_PANAS_BY_SUM: Record<number, string[]> = {};
export const DOUBLE_PANAS_BY_SUM: Record<number, string[]> = {};

for (let i = 0; i < 10; i++) {
  SINGLE_PANAS_BY_SUM[i] = [];
  DOUBLE_PANAS_BY_SUM[i] = [];
}

// Order of digits in Matka: 1, 2, 3, 4, 5, 6, 7, 8, 9, 0
const MATKA_DIGITS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0];

for (let i = 0; i < MATKA_DIGITS.length; i++) {
  for (let j = i + 1; j < MATKA_DIGITS.length; j++) {
    for (let k = j + 1; k < MATKA_DIGITS.length; k++) {
      const a = MATKA_DIGITS[i];
      const b = MATKA_DIGITS[j];
      const c = MATKA_DIGITS[k];
      const panaStr = `${a}${b}${c}`;
      ALL_SINGLE_PANAS.push(panaStr);
      const sum = (a + b + c) % 10;
      SINGLE_PANAS_BY_SUM[sum].push(panaStr);
    }
  }
}

// Double Panas: (AAB or ABB)
for (let i = 0; i < MATKA_DIGITS.length; i++) {
  for (let j = 0; j < MATKA_DIGITS.length; j++) {
    if (i === j) continue;
    const a = MATKA_DIGITS[i];
    const b = MATKA_DIGITS[j];
    // a < b
    if (i < j) {
      // AAB
      const p1 = `${a}${a}${b}`;
      ALL_DOUBLE_PANAS.push(p1);
      const sum1 = (a + a + b) % 10;
      DOUBLE_PANAS_BY_SUM[sum1].push(p1);
      // ABB
      const p2 = `${a}${b}${b}`;
      ALL_DOUBLE_PANAS.push(p2);
      const sum2 = (a + b + b) % 10;
      DOUBLE_PANAS_BY_SUM[sum2].push(p2);
    }
  }
}

export function getMatchingSinglePanas(prefix: string): string[] {
  if (!prefix) return [];
  return ALL_SINGLE_PANAS.filter((p) => p.startsWith(prefix)).slice(0, 8);
}

export function getMatchingDoublePanas(prefix: string): string[] {
  if (!prefix) return [];
  return ALL_DOUBLE_PANAS.filter((p) => p.startsWith(prefix)).slice(0, 8);
}

export function getMatchingTriplePanas(prefix: string): string[] {
  if (!prefix) return [];
  return TRIPLE_PANAS.filter((p) => p.startsWith(prefix));
}

// SP Motor Generator: Takes unique digits and generates all 3-digit combinations from those digits
export function generateSpMotor(digitsInput: string): string[] {
  const digits = Array.from(new Set(digitsInput.replace(/\D/g, '').split(''))).map(Number);
  if (digits.length < 3) return [];

  // Sort according to matka order
  digits.sort((a, b) => {
    const valA = a === 0 ? 10 : a;
    const valB = b === 0 ? 10 : b;
    return valA - valB;
  });

  const res: string[] = [];
  for (let i = 0; i < digits.length; i++) {
    for (let j = i + 1; j < digits.length; j++) {
      for (let k = j + 1; k < digits.length; k++) {
        res.push(`${digits[i]}${digits[j]}${digits[k]}`);
      }
    }
  }
  return res;
}

// DP Motor Generator: Takes digits and generates double pana combinations
export function generateDpMotor(digitsInput: string): string[] {
  const digits = Array.from(new Set(digitsInput.replace(/\D/g, '').split(''))).map(Number);
  if (digits.length < 2) return [];

  digits.sort((a, b) => {
    const valA = a === 0 ? 10 : a;
    const valB = b === 0 ? 10 : b;
    return valA - valB;
  });

  const res: string[] = [];
  for (let i = 0; i < digits.length; i++) {
    for (let j = 0; j < digits.length; j++) {
      if (i === j) continue;
      if (i < j) {
        res.push(`${digits[i]}${digits[i]}${digits[j]}`);
        res.push(`${digits[i]}${digits[j]}${digits[j]}`);
      }
    }
  }
  return res;
}

// Group Jodi Generator: Given a 2-digit Jodi (e.g. '12'), generates its family of 8 Jodis (cut digits)
export function generateGroupJodi(jodiInput: string): string[] {
  const clean = jodiInput.replace(/\D/g, '');
  if (clean.length !== 2) return [];

  const a = parseInt(clean[0], 10);
  const b = parseInt(clean[1], 10);
  const cutA = (a + 5) % 10;
  const cutB = (b + 5) % 10;

  const family = new Set<string>([
    `${a}${b}`,
    `${b}${a}`,
    `${a}${cutB}`,
    `${cutB}${a}`,
    `${cutA}${b}`,
    `${b}${cutA}`,
    `${cutA}${cutB}`,
    `${cutB}${cutA}`,
  ]);

  return Array.from(family);
}
