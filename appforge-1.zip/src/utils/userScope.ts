/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Converts any arbitrary string / ID into a valid UUID string format (8-4-4-4-12 hex).
 * Generates a deterministic hash UUID if string is provided.
 */
export function toSupabaseUuid(input: string): string {
  if (!input) {
    return '00000000-0000-4000-8000-000000000000';
  }
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  if (uuidRegex.test(input)) {
    return input.toLowerCase();
  }

  // Simple deterministic hash to 32 hex chars
  let hash1 = 0x811c9dc5;
  let hash2 = 0xcbf29ce4;
  for (let i = 0; i < input.length; i++) {
    const c = input.charCodeAt(i);
    hash1 = Math.imul(hash1 ^ c, 0x01000193);
    hash2 = Math.imul(hash2 ^ c, 0x01000193);
  }

  const h1 = (hash1 >>> 0).toString(16).padStart(8, '0');
  const h2 = (hash2 >>> 0).toString(16).padStart(8, '0');
  const h3 = (Math.imul(hash1, hash2) >>> 0).toString(16).padStart(8, '0');
  const h4 = (Math.imul(hash2, 31) >>> 0).toString(16).padStart(8, '0');

  const combined = (h1 + h2 + h3 + h4).slice(0, 32);
  return `${combined.slice(0, 8)}-${combined.slice(8, 12)}-4${combined.slice(13, 16)}-a${combined.slice(17, 20)}-${combined.slice(20, 32)}`;
}
