/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { MarketItem, StarlineResult } from '../types';

export interface StarlineSlotItem {
  time: string;
  hour: number;
  minute: number;
  status: 'Running for Open' | 'Closed' | 'Scheduled';
  result: string;
  countdownText?: string;
}

export interface JackpotSlotItem {
  time: string;
  hour: number;
  minute: number;
  status: 'Running for Open' | 'Closed' | 'Scheduled';
  result: string;
  countdownText?: string;
}

/**
 * Calculates sum digit from a 3-digit pana (e.g. '140' -> (1+4+0)%10 = 5)
 */
export function getDigitFromPana(pana: string): number | null {
  if (!pana || pana.length !== 3 || !/^\d{3}$/.test(pana)) {
    return null;
  }
  const sum = parseInt(pana[0], 10) + parseInt(pana[1], 10) + parseInt(pana[2], 10);
  return sum % 10;
}

/**
 * Formats a market triplet into a standardized object with derived values
 */
export function formatMarketResult(market: {
  openPana?: string;
  jodi?: string;
  closePana?: string;
}): { openPana: string; jodi: string; closePana: string; formatted: string } {
  const openP = market?.openPana && market.openPana !== '' ? market.openPana : '***';
  const closeP = market?.closePana && market.closePana !== '' ? market.closePana : '***';

  let resolvedJodi = market?.jodi && market.jodi !== '' ? market.jodi : '**';

  // If both panas are present and jodi is '**' or incomplete, compute it
  if (resolvedJodi === '**' || resolvedJodi.includes('*')) {
    const oDigit = getDigitFromPana(openP);
    const cDigit = getDigitFromPana(closeP);
    if (oDigit !== null && cDigit !== null) {
      resolvedJodi = `${oDigit}${cDigit}`;
    } else if (oDigit !== null) {
      resolvedJodi = `${oDigit}*`;
    } else if (cDigit !== null) {
      resolvedJodi = `*${cDigit}`;
    }
  }

  const formatted = `${openP} - ${resolvedJodi} - ${closeP}`;
  return {
    openPana: openP,
    jodi: resolvedJodi,
    closePana: closeP,
    formatted,
  };
}

/**
 * Parses time strings like "11:00 AM", "01:30 PM", "14:00"
 */
function parseTimeString(timeStr: string): { hour: number; minute: number } {
  const match = timeStr.match(/^(\d{1,2}):(\d{2})(?:\s*([AP]M))?$/i);
  if (!match) return { hour: 12, minute: 0 };
  let h = parseInt(match[1], 10);
  const m = parseInt(match[2], 10);
  const meridiem = match[3]?.toUpperCase();
  if (meridiem === 'PM' && h < 12) h += 12;
  if (meridiem === 'AM' && h === 12) h = 0;
  return { hour: h, minute: m };
}

/**
 * Evaluates market status, countdown, and session for current time
 */
export function evaluateMarkets(currentTime: Date, markets: MarketItem[]): MarketItem[] {
  const nowH = currentTime.getHours();
  const nowM = currentTime.getMinutes();
  const nowTotalMinutes = nowH * 60 + nowM;

  return markets.map((m) => {
    const openTimeParsed = parseTimeString(m.openTime);
    const closeTimeParsed = parseTimeString(m.closeTime);

    const openMin = openTimeParsed.hour * 60 + openTimeParsed.minute;
    const closeMin = closeTimeParsed.hour * 60 + closeTimeParsed.minute;

    let status = m.status || 'Running for Open';
    let isOpen = true;
    let allowedSession: 'all' | 'open_only' | 'close_only' = 'all';
    let countdownText = '';

    if (nowTotalMinutes < openMin) {
      status = 'Running for Open';
      isOpen = true;
      allowedSession = 'all';
      const diff = openMin - nowTotalMinutes;
      const hours = Math.floor(diff / 60);
      const mins = diff % 60;
      countdownText = hours > 0 ? `Opens in ${hours}h ${mins}m` : `Opens in ${mins}m`;
    } else if (nowTotalMinutes >= openMin && nowTotalMinutes < closeMin) {
      status = 'Running for Close';
      isOpen = true;
      allowedSession = 'close_only';
      const diff = closeMin - nowTotalMinutes;
      const hours = Math.floor(diff / 60);
      const mins = diff % 60;
      countdownText = hours > 0 ? `Closes in ${hours}h ${mins}m` : `Closes in ${mins}m`;
    } else {
      status = 'Closed for Today';
      isOpen = false;
      allowedSession = 'close_only';
      countdownText = 'Market Closed';
    }

    // Preserve any manually overridden or explicit statuses
    if (m.status === 'CLOSED') {
      isOpen = false;
      status = 'Closed for Today';
    }

    return {
      ...m,
      status,
      isOpen,
      allowedSession,
      countdownText,
      openHour: openTimeParsed.hour,
      openMinute: openTimeParsed.minute,
      closeHour: closeTimeParsed.hour,
      closeMinute: closeTimeParsed.minute,
    };
  });
}

/**
 * Hourly starline slots from 09:00 AM to 09:00 PM
 */
export function evaluateStarlineSlots(currentTime: Date): StarlineSlotItem[] {
  const nowH = currentTime.getHours();
  const slots: StarlineSlotItem[] = [];

  const times = [
    { label: '09:00 AM', hour: 9 },
    { label: '10:00 AM', hour: 10 },
    { label: '11:00 AM', hour: 11 },
    { label: '12:00 PM', hour: 12 },
    { label: '01:00 PM', hour: 13 },
    { label: '02:00 PM', hour: 14 },
    { label: '03:00 PM', hour: 15 },
    { label: '04:00 PM', hour: 16 },
    { label: '05:00 PM', hour: 17 },
    { label: '06:00 PM', hour: 18 },
    { label: '07:00 PM', hour: 19 },
    { label: '08:00 PM', hour: 20 },
    { label: '09:00 PM', hour: 21 },
  ];

  for (const t of times) {
    let status: 'Running for Open' | 'Closed' | 'Scheduled' = 'Scheduled';
    let result = '*** - *';

    if (nowH > t.hour) {
      status = 'Closed';
      // Deterministic pseudo result based on hour
      const seedPana = (140 + t.hour * 17) % 900 + 100;
      const seedDigit = seedPana % 10;
      result = `${seedPana} - ${seedDigit}`;
    } else if (nowH === t.hour) {
      status = 'Running for Open';
      const remainingM = 60 - currentTime.getMinutes();
      result = '*** - *';
    } else {
      status = 'Scheduled';
      result = '*** - *';
    }

    slots.push({
      time: t.label,
      hour: t.hour,
      minute: 0,
      status,
      result,
    });
  }

  return slots;
}

export function convertSlotsToStarlineResults(
  slots: StarlineSlotItem[],
  dateStr: string
): StarlineResult[] {
  return slots.map((s) => ({
    time: s.time,
    result: s.result,
    date: dateStr,
  }));
}

/**
 * Hourly jackpot slots from 10:00 AM to 08:00 PM
 */
export function evaluateJackpotSlots(currentTime: Date): JackpotSlotItem[] {
  const nowH = currentTime.getHours();
  const slots: JackpotSlotItem[] = [];

  const times = [
    { label: '10:00 AM', hour: 10 },
    { label: '11:00 AM', hour: 11 },
    { label: '12:00 PM', hour: 12 },
    { label: '01:00 PM', hour: 13 },
    { label: '02:00 PM', hour: 14 },
    { label: '03:00 PM', hour: 15 },
    { label: '04:00 PM', hour: 16 },
    { label: '05:00 PM', hour: 17 },
    { label: '06:00 PM', hour: 18 },
    { label: '07:00 PM', hour: 19 },
    { label: '08:00 PM', hour: 20 },
  ];

  for (const t of times) {
    let status: 'Running for Open' | 'Closed' | 'Scheduled' = 'Scheduled';
    let result = '**';

    if (nowH > t.hour) {
      status = 'Closed';
      const jodiNum = ((t.hour * 23) % 100).toString().padStart(2, '0');
      result = jodiNum;
    } else if (nowH === t.hour) {
      status = 'Running for Open';
      result = '**';
    } else {
      status = 'Scheduled';
      result = '**';
    }

    slots.push({
      time: t.label,
      hour: t.hour,
      minute: 0,
      status,
      result,
    });
  }

  return slots;
}
