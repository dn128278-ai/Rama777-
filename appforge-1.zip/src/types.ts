/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type MainTab = 'home' | 'history' | 'passbook' | 'funds' | 'support';

export type UserRole = 'user' | 'admin';

export type WeekdayKey = 'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat' | 'sun';

export interface UserProfile {
  id?: string;
  uid?: string;
  name: string;
  phone: string;
  email?: string;
  walletBalance: number;
  mainWallet?: number;
  winningWallet?: number;
  gamingWallet?: number;
  mpin: string;
  biometricEnabled: boolean;
  appVersion: string;
  role: UserRole;
  status?: string;
  createdAt?: string;
}

export interface UserAccount {
  id: string;
  name: string;
  phone: string;
  walletBalance: number;
  mpin: string;
  role: UserRole;
  status?: string;
}

export interface MarketItem {
  id: string;
  name: string;
  openPana: string;
  jodi: string;
  closePana: string;
  openTime: string;
  closeTime: string;
  status: string;
  isOpen: boolean;
  openHour?: number;
  openMinute?: number;
  closeHour?: number;
  closeMinute?: number;
  allowedSession?: 'all' | 'open_only' | 'close_only';
  lastResult?: string;
  marketDate?: string;
  countdownText?: string;
  order?: number;
}

export interface Transaction {
  id: string;
  title: string;
  referenceId: string;
  description: string;
  amount: number;
  type: 'credit' | 'debit';
  status: 'SUCCESS' | 'PENDING' | 'FAILED';
  date: string;
  previousBalance: number;
  currentBalance: number;
  userId?: string;
}

export interface FundHistoryItem {
  id: string;
  orderId: string;
  date: string;
  amount: number;
  status: 'Success' | 'Pending' | 'Failure';
  requestType: 'Credit' | 'Debit';
  depositMode: string;
  utrOrReference?: string;
  bankName?: string;
  accountNumber?: string;
  ifscCode?: string;
}

export interface BankAccount {
  id: string;
  accountHolder: string;
  bankName: string;
  branch: string;
  ifscCode: string;
  accountNumber: string;
  isDefault: boolean;
  status?: 'Verified' | 'Success' | 'Pending' | 'Failure';
  lockUntil?: string;
  updatedAt?: string;
}

export interface StarlineResult {
  time: string;
  result: string;
  date?: string;
}

export interface GameBid {
  id: string;
  marketId?: string;
  marketName: string;
  gameType: string;
  session: 'Open' | 'Close';
  digitOrPana: string;
  points: number;
  status: 'Placed' | 'Won' | 'Lost';
  winAmount?: number;
  date: string;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type?: 'alert' | 'bonus' | 'bid';
  targetPhone?: string;
  createdAt?: string;
}

export interface MarketResultRecord {
  id?: string;
  marketId: string;
  marketName: string;
  date: string;
  dateKey: string;
  dayOfWeek: WeekdayKey;
  openPana: string;
  jodi: string;
  closePana: string;
  status?: string;
  updatedAt?: string;
}

export interface SupportChatMessage {
  id: string;
  sender: 'agent' | 'user';
  text: string;
  timestamp: string;
}
