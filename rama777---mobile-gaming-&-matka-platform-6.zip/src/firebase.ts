import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import {
  getAuth,
  Auth,
  onAuthStateChanged,
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  signInAnonymously,
  User as FirebaseUser,
} from 'firebase/auth';
import rawConfig from '../firebase-applet-config.json';

const apiKey = import.meta.env.VITE_FIREBASE_API_KEY || (rawConfig as any).apiKey || '';

export const firebaseConfig = {
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || rawConfig.projectId || 'rama777-37ef1',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || rawConfig.appId,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || rawConfig.storageBucket || 'rama777-37ef1.firebasestorage.app',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || rawConfig.authDomain || 'rama777-37ef1.firebaseapp.com',
  ...(apiKey ? { apiKey } : {}),
};

export const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
// Connect directly to the Netlify Admin Panel's live Firestore database (default)
export const db = getFirestore(app, import.meta.env.VITE_FIRESTORE_DATABASE_ID || '(default)');

let authInstance: Auth | null = null;
try {
  authInstance = getAuth(app);
} catch (err) {
  console.warn('Firebase Auth initialization notice:', err);
}
export const auth = authInstance;

export {
  onAuthStateChanged,
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  signInAnonymously,
};
export type { FirebaseUser };

// Test connection to Firestore as recommended
export async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}
testConnection();

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid || null,
      email: auth?.currentUser?.email || null,
    },
    operationType,
    path,
  };
  console.warn('Firestore Operation Notice: ', JSON.stringify(errInfo));
}
