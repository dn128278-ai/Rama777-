/**
 * Standard Matka Number Definitions & Helpers
 * Covers Single Digits (0-9), Jodis (00-99), 120 Single Panas,
 * 90 Double Panas, 10 Triple Panas, Red Brackets (20 pairs),
 * Group Jodi families, Odd/Even sets, and Motor generation.
 */

export const SINGLE_DIGITS: string[] = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

// Generate 00 to 99 Jodis
export const JODI_DIGITS: string[] = Array.from({ length: 100 }, (_, i) =>
  i.toString().padStart(2, '0')
);

// Odd and Even digits for 1-tap batch bets
export const ODD_DIGITS: string[] = ['1', '3', '5', '7', '9'];
export const EVEN_DIGITS: string[] = ['0', '2', '4', '6', '8'];

// 20 Red Bracket Pairs (10 Half-Red + 10 Full-Red)
export const RED_BRACKETS: string[] = [
  '00', '11', '22', '33', '44', '55', '66', '77', '88', '99',
  '05', '50', '16', '61', '27', '72', '38', '83', '49', '94',
];

// Quick Amount Chips
export const QUICK_AMOUNT_CHIPS: number[] = [10, 50, 100, 500];

// Digit ordering in Matka: 1 through 9, then 0 (value 10 for sorting in panas)
function sortPanaDigits(arr: number[]): string {
  const sorted = [...arr].sort((a, b) => {
    const valA = a === 0 ? 10 : a;
    const valB = b === 0 ? 10 : b;
    return valA - valB;
  });
  return sorted.join('');
}

// 120 Single Panas (12 per sum digit 0 to 9)
export const SINGLE_PANAS_BY_SUM: Record<number, string[]> = {
  1: ['128', '137', '146', '236', '245', '290', '380', '470', '489', '560', '579', '678'],
  2: ['129', '138', '147', '156', '237', '246', '345', '390', '480', '570', '589', '679'],
  3: ['120', '139', '148', '157', '238', '247', '256', '346', '490', '580', '670', '689'],
  4: ['130', '149', '158', '167', '239', '248', '257', '347', '356', '590', '680', '789'],
  5: ['140', '159', '168', '230', '249', '258', '267', '348', '357', '456', '690', '780'],
  6: ['123', '150', '169', '178', '240', '259', '268', '349', '358', '367', '457', '790'],
  7: ['124', '160', '179', '250', '269', '278', '340', '359', '368', '458', '467', '890'],
  8: ['125', '134', '170', '189', '260', '279', '350', '369', '378', '459', '468', '567'],
  9: ['126', '135', '180', '234', '270', '289', '360', '379', '450', '469', '478', '568'],
  0: ['127', '136', '145', '190', '235', '280', '370', '389', '460', '479', '569', '578'],
};

export const ALL_SINGLE_PANAS: string[] = Object.values(SINGLE_PANAS_BY_SUM).flat();

// 90 Double Panas (9 per sum digit 0 to 9)
export const DOUBLE_PANAS_BY_SUM: Record<number, string[]> = {
  1: ['119', '227', '335', '344', '155', '669', '588', '399', '100'],
  2: ['110', '228', '336', '255', '660', '778', '688', '499', '200'],
  3: ['229', '337', '445', '355', '166', '779', '788', '599', '300'],
  4: ['112', '220', '338', '446', '455', '266', '770', '699', '400'],
  5: ['113', '122', '339', '447', '366', '177', '889', '799', '500'],
  6: ['114', '330', '448', '556', '466', '277', '880', '899', '600'],
  7: ['115', '223', '133', '449', '557', '566', '377', '188', '700'],
  8: ['116', '224', '233', '440', '558', '477', '288', '990', '800'],
  9: ['117', '225', '144', '559', '667', '577', '388', '199', '900'],
  0: ['118', '226', '334', '244', '550', '668', '677', '488', '299'],
};

export const ALL_DOUBLE_PANAS: string[] = Object.values(DOUBLE_PANAS_BY_SUM).flat();

// 10 Triple Panas
export const TRIPLE_PANAS: string[] = [
  '000', '111', '222', '333', '444', '555', '666', '777', '888', '999',
];

// Autocomplete and shortcut helpers
export function getMatchingSinglePanas(prefix: string): string[] {
  if (!prefix) return [];
  return ALL_SINGLE_PANAS.filter((p) => p.startsWith(prefix)).slice(0, 10);
}

export function getMatchingDoublePanas(prefix: string): string[] {
  if (!prefix) return [];
  return ALL_DOUBLE_PANAS.filter((p) => p.startsWith(prefix)).slice(0, 10);
}

export function getMatchingTriplePanas(prefix: string): string[] {
  if (!prefix) return [];
  return TRIPLE_PANAS.filter((p) => p.startsWith(prefix)).slice(0, 10);
}

// SP Motor calculation
export function generateSpMotor(digitsInput: string): string[] {
  const digits = Array.from(new Set(digitsInput.split(''))).map(Number).filter((n) => !isNaN(n));
  if (digits.length < 3) return [];
  const result: string[] = [];
  for (let i = 0; i < digits.length; i++) {
    for (let j = i + 1; j < digits.length; j++) {
      for (let k = j + 1; k < digits.length; k++) {
        const sorted = sortPanaDigits([digits[i], digits[j], digits[k]]);
        if (ALL_SINGLE_PANAS.includes(sorted) && !result.includes(sorted)) {
          result.push(sorted);
        }
      }
    }
  }
  return result;
}

// DP Motor calculation
export function generateDpMotor(digitsInput: string): string[] {
  const digits = Array.from(new Set(digitsInput.split(''))).map(Number).filter((n) => !isNaN(n));
  if (digits.length < 2) return [];
  const result: string[] = [];
  for (let i = 0; i < digits.length; i++) {
    for (let j = 0; j < digits.length; j++) {
      if (i === j) continue;
      const sorted = sortPanaDigits([digits[i], digits[i], digits[j]]);
      if (ALL_DOUBLE_PANAS.includes(sorted) && !result.includes(sorted)) {
        result.push(sorted);
      }
    }
  }
  return result;
}

// Group Jodi (Family Jodi) Generator
export function generateGroupJodi(jodi: string): string[] {
  if (!jodi || jodi.length !== 2) return [];
  const d1 = parseInt(jodi[0], 10);
  const d2 = parseInt(jodi[1], 10);
  if (isNaN(d1) || isNaN(d2)) return [];

  const cut1 = (d1 + 5) % 10;
  const cut2 = (d2 + 5) % 10;

  const set1 = [d1, cut1];
  const set2 = [d2, cut2];

  const results = new Set<string>();
  // Direct combinations
  for (const a of set1) {
    for (const b of set2) {
      results.add(`${a}${b}`);
    }
  }
  // Ulta / reverse combinations
  for (const a of set2) {
    for (const b of set1) {
      results.add(`${a}${b}`);
    }
  }

  return Array.from(results);
}
