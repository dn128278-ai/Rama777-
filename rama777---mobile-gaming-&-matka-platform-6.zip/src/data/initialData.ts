import { MarketItem, UserProfile, Transaction, FundHistoryItem, BankAccount, StarlineResult, AppNotification } from '../types';

export const INITIAL_USER: UserProfile = {
  name: '',
  phone: '',
  walletBalance: 0,
  mpin: '1234',
  biometricEnabled: false,
  appVersion: '2',
};

export const INITIAL_MARKETS: MarketItem[] = [
  {
    id: 'kalyan',
    name: 'KALYAN',
    openPana: '140',
    jodi: '59',
    closePana: '180',
    openTime: '04:15 PM',
    closeTime: '06:15 PM',
    status: 'Running for Open',
    isOpen: true,
  },
  {
    id: 'sridevi',
    name: 'SRIDEVI',
    openPana: '238',
    jodi: '39',
    closePana: '333',
    openTime: '11:40 AM',
    closeTime: '12:40 PM',
    status: 'Running for Open',
    isOpen: true,
  },
  {
    id: 'surya_morning',
    name: 'SURYA MORNING',
    openPana: '389',
    jodi: '02',
    closePana: '237',
    openTime: '10:05 AM',
    closeTime: '11:05 AM',
    status: 'Running for Open',
    isOpen: true,
  },
  {
    id: 'devi_morning',
    name: 'DEVI MORNING',
    openPana: '256',
    jodi: '31',
    closePana: '470',
    openTime: '08:55 AM',
    closeTime: '09:55 AM',
    status: 'Closed for Today',
    isOpen: false,
  },
  {
    id: 'madhur_night',
    name: 'MADHUR NIGHT',
    openPana: '799',
    jodi: '55',
    closePana: '447',
    openTime: '08:30 PM',
    closeTime: '10:30 PM',
    status: 'Running for Open',
    isOpen: true,
  },
  {
    id: 'surya_night',
    name: 'SURYA NIGHT',
    openPana: '158',
    jodi: '40',
    closePana: '118',
    openTime: '09:05 PM',
    closeTime: '11:00 PM',
    status: 'Running for Open',
    isOpen: true,
  },
  {
    id: 'milan_night',
    name: 'MILAN NIGHT',
    openPana: '789',
    jodi: '40',
    closePana: '668',
    openTime: '09:16 PM',
    closeTime: '11:16 PM',
    status: 'Running for Open',
    isOpen: true,
  },
  {
    id: 'rajdhani_night',
    name: 'RAJDHANI NIGHT',
    openPana: '690',
    jodi: '55',
    closePana: '230',
    openTime: '09:30 PM',
    closeTime: '11:45 PM',
    status: 'Running for Open',
    isOpen: true,
  },
  {
    id: 'time_bazar',
    name: 'TIME BAZAR',
    openPana: '160',
    jodi: '78',
    closePana: '567',
    openTime: '01:12 PM',
    closeTime: '02:12 PM',
    status: 'Closed for Today',
    isOpen: false,
  },
  {
    id: 'madhur_day',
    name: 'MADHUR DAY',
    openPana: '125',
    jodi: '89',
    closePana: '234',
    openTime: '01:30 PM',
    closeTime: '02:30 PM',
    status: 'Closed for Today',
    isOpen: false,
  },
];

export const INITIAL_TRANSACTIONS: Transaction[] = [];

export const INITIAL_ADD_FUNDS_HISTORY: FundHistoryItem[] = [];

export const INITIAL_WITHDRAW_FUNDS_HISTORY: FundHistoryItem[] = [];

export const INITIAL_BANK_ACCOUNTS: BankAccount[] = [];

export const INITIAL_STARLINE_RESULTS: StarlineResult[] = [
  { time: '12:30 PM', date: '20/10/2026', result: '457-6' },
  { time: '1:30 PM', date: '20/10/2026', result: '190-0' },
  { time: '2:30 PM', date: '20/10/2026', result: '138-2' },
  { time: '3:30 PM', date: '20/10/2026', result: '***-*' },
  { time: '4:30 PM', date: '20/10/2026', result: '***-*' },
  { time: '5:30 PM', date: '20/10/2026', result: '***-*' },
  { time: '6:30 PM', date: '20/10/2026', result: '***-*' },
  { time: '7:30 PM', date: '20/10/2026', result: '***-*' },
  { time: '8:30 PM', date: '20/10/2026', result: '***-*' },
];

export const GAME_RATES_LIST = [
  {
    category: 'RAMA777 Game Win Ratio',
    items: [
      { name: 'Single Digit', ratio: '1 ka 10', icon: 'dice-1' },
      { name: 'Single Pana', ratio: '1 ka 160', icon: 'spade' },
      { name: 'Jodi Digit', ratio: '1 ka 100', icon: 'dice-2' },
      { name: 'Double Pana', ratio: '1 ka 300', icon: 'spade-pair' },
      { name: 'Red Brackets', ratio: '1 ka 100', icon: 'brackets' },
      { name: 'Triple Pana', ratio: '1 ka 900', icon: 'cards-3' },
      { name: 'Half Sangam A', ratio: '1 ka 1000', icon: 'coin-a' },
      { name: 'Half Sangam B', ratio: '1 ka 1000', icon: 'coin-b' },
      { name: 'Full Sangam Digits', ratio: '1 ka 10000', icon: 'coin-gold' },
    ],
  },
  {
    category: 'Bombay Starline Game Win Ratio',
    items: [
      { name: 'Single Digit', ratio: '1 ka 10', icon: 'dice-1' },
      { name: 'Single Pana', ratio: '1 ka 160', icon: 'spade' },
      { name: 'Double Pana', ratio: '1 ka 320', icon: 'spade-pair' },
      { name: 'Triple Pana', ratio: '1 ka 1000', icon: 'cards-3' },
    ],
  },
  {
    category: 'Bombay Jackpot Game Win Ratio',
    items: [
      { name: 'Jackpot', ratio: '1 ka 10', icon: 'spade' },
    ],
  },
];

export const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'n-1',
    title: 'Welcome to RAMA777!',
    message: 'Deposit min Rs. 300 to claim your special bonus points. Enjoy 24/7 fast withdrawal.',
    time: '10m ago',
    read: false,
    type: 'bonus',
  },
  {
    id: 'n-2',
    title: 'Kalyan Market Bids Open',
    message: 'Kalyan Day is running for Open bids until 04:15 PM. Place your lucky digit bids now!',
    time: '1h ago',
    read: false,
    type: 'bid',
  },
  {
    id: 'n-3',
    title: 'Starline 2:30 PM Result',
    message: 'Starline result declared: 138-2. Check your history for winning credits.',
    time: '2h ago',
    read: true,
    type: 'alert',
  },
];
