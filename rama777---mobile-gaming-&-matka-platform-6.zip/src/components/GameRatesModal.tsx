import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { GAME_RATES_LIST } from '../data/initialData';

interface GameRatesModalProps {
  onClose: () => void;
}

export const GameRatesModal: React.FC<GameRatesModalProps> = ({ onClose }) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'dice-1':
        return '🎲';
      case 'spade':
        return '🂡';
      case 'dice-2':
        return '⚁';
      case 'spade-pair':
        return '🂢';
      case 'brackets':
        return '{ }';
      case 'cards-3':
        return '🎴';
      case 'coin-a':
      case 'coin-b':
        return '🪙';
      case 'coin-gold':
        return '💰';
      default:
        return '🎯';
    }
  };

  return (
    <div className="pb-24 pt-2 px-4 transition-colors">
      <div className="flex items-center gap-2.5 mb-5">
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <h2 className="text-base font-extrabold text-[#FF7700]">Game Rates</h2>
      </div>

      <div className="space-y-6">
        {GAME_RATES_LIST.map((section, sIdx) => (
          <div key={sIdx} className="space-y-2.5">
            <h3 className="text-center font-extrabold text-xs text-slate-800 dark:text-slate-200 tracking-wide uppercase">
              {section.category}
            </h3>

            <div className="space-y-2">
              {section.items.map((item, iIdx) => (
                <div
                  key={iIdx}
                  className="bg-white dark:bg-slate-900 rounded-2xl p-3 px-4 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between shadow-xs"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-orange-500 text-white flex items-center justify-center text-sm font-bold shadow-2xs shrink-0">
                      {getIcon(item.icon)}
                    </div>
                    <span className="font-extrabold text-xs text-slate-900 dark:text-slate-100">
                      {item.name}
                    </span>
                  </div>

                  <span className="font-black text-xs font-mono text-[#FF7700] tracking-tight">
                    {item.ratio}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
