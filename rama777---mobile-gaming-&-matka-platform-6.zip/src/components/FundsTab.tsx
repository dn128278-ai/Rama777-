import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Wallet,
  FileClock,
  Building2,
  ChevronRight,
  ArrowLeft,
  Gift,
  CheckCircle2,
  AlertCircle,
  Plus,
  ShieldAlert,
  Lock,
  Clock,
  XCircle,
  Sparkles,
  Smartphone,
  Info,
  Calendar,
  Check,
  Zap,
  Copy,
  ExternalLink,
  ShieldCheck,
  QrCode,
  ArrowRight,
  Download,
  Share2,
} from 'lucide-react';
import { UserProfile, FundHistoryItem, BankAccount } from '../types';
import {
  subscribeToPaymentGateway,
  createDepositInFirestore,
  PaymentGatewayConfig,
  DEFAULT_GATEWAY_CONFIG,
} from '../services/firestoreSyncService';

interface FundsTabProps {
  user: UserProfile;
  addFundsHistory: FundHistoryItem[];
  withdrawFundsHistory: FundHistoryItem[];
  bankAccounts: BankAccount[];
  onAddFunds: (
    amount: number,
    bonus?: number,
    depositMode?: string,
    utr?: string,
    status?: 'Success' | 'Pending'
  ) => void;
  onAddFundsFailure?: (orderId: string, amount: number, depositMode: string, reason: string) => void;
  onWithdrawFunds: (amount: number, bankId: string) => boolean;
  onAddBank: (bank: Omit<BankAccount, 'id' | 'updatedAt'>) => void;
  gatewayConfig?: PaymentGatewayConfig;
}

export const FundsTab: React.FC<FundsTabProps> = ({
  user,
  addFundsHistory,
  withdrawFundsHistory,
  bankAccounts,
  onAddFunds,
  onAddFundsFailure,
  onWithdrawFunds,
  onAddBank,
  gatewayConfig: initialGatewayConfig,
}) => {
  const [subView, setSubView] = useState<string | null>(null);

  // Dynamic Payment Gateway Configuration synced with Firestore admin panel
  const [liveGatewayConfig, setLiveGatewayConfig] = useState<PaymentGatewayConfig>(
    initialGatewayConfig || DEFAULT_GATEWAY_CONFIG
  );

  useEffect(() => {
    const unsub = subscribeToPaymentGateway((cfg) => {
      setLiveGatewayConfig(cfg);
    });
    return () => unsub();
  }, []);

  const ACTIVE_VPA =
    liveGatewayConfig.manualUpi?.upiId ||
    liveGatewayConfig.merchantVpa ||
    DEFAULT_GATEWAY_CONFIG.merchantVpa;
  const ACTIVE_MERCHANT =
    liveGatewayConfig.manualUpi?.merchantName ||
    liveGatewayConfig.merchantName ||
    DEFAULT_GATEWAY_CONFIG.merchantName;
  const MIN_DEPOSIT = liveGatewayConfig.minDeposit || 100;
  const MAX_DEPOSIT = liveGatewayConfig.maxDeposit || 100000;

  // Legacy fallback alias
  const KOTAK_MERCHANT_VPA = ACTIVE_VPA;
  const MERCHANT_NAME = ACTIVE_MERCHANT;

  // Gateway verification & AppState lifecycle state
  const [gatewayStatus, setGatewayStatus] = useState<'idle' | 'waiting_return' | 'verifying' | 'success' | 'failed'>('idle');
  const [paymentFailureReason, setPaymentFailureReason] = useState<string>('');
  const [activePaymentOrder, setActivePaymentOrder] = useState<{
    amount: number;
    bonus: number;
    method: string;
    orderId: string;
    initiatedAt: number;
  } | null>(null);
  const [copiedVpa, setCopiedVpa] = useState<boolean>(false);

  const pendingPaymentRef = useRef<{
    amount: number;
    bonus: number;
    method: string;
    orderId: string;
    initiatedAt: number;
  } | null>(null);

  // Add Funds state & Manual UPI QR states
  const [depositAmount, setDepositAmount] = useState<string>('500');
  const [utrInput, setUtrInput] = useState<string>('');
  const [utrError, setUtrError] = useState<string>('');
  const [isSubmittingUtr, setIsSubmittingUtr] = useState<boolean>(false);
  const [depositPaymentMode, setDepositPaymentMode] = useState<'qr' | 'apps'>('qr');
  const [showBonusSheet, setShowBonusSheet] = useState<boolean>(false);
  const [showUpiSheet, setShowUpiSheet] = useState<boolean>(false);
  const [activePaymentType, setActivePaymentType] = useState<'normal' | 'bonus'>('normal');
  const [addFundsSuccess, setAddFundsSuccess] = useState<string>('');
  const [addFundsFilter, setAddFundsFilter] = useState<'ALL' | 'Success' | 'Pending' | 'Failure'>('ALL');

  // Withdrawal state
  const [withdrawAmount, setWithdrawAmount] = useState<string>('');
  const [withdrawError, setWithdrawError] = useState<string>('');
  const [withdrawSuccess, setWithdrawSuccess] = useState<string>('');
  const [withdrawFilter, setWithdrawFilter] = useState<'ALL' | 'Success' | 'Pending' | 'Failure'>('ALL');

  // Bank state
  const [accountHolder, setAccountHolder] = useState<string>('');
  const [bankName, setBankName] = useState<string>('');
  const [accountNumber, setAccountNumber] = useState<string>('');
  const [confirmAccountNumber, setConfirmAccountNumber] = useState<string>('');
  const [ifscCode, setIfscCode] = useState<string>('');
  const [bankAgreement, setBankAgreement] = useState<boolean>(false);
  const [bankSuccess, setBankSuccess] = useState<string>('');
  const [bankError, setBankError] = useState<string>('');

  // Selected receipt modal
  const [selectedReceipt, setSelectedReceipt] = useState<FundHistoryItem | null>(null);

  const fundsMenu = [
    { id: 'add_funds', label: 'Add Fund', desc: 'Instant top-up via UPI & Netbanking', icon: 'wallet-up' },
    { id: 'withdraw_funds', label: 'Withdraw Fund', desc: 'Instant withdrawal to bank account', icon: 'wallet-down' },
    { id: 'add_funds_history', label: 'Add Fund History', desc: 'Check deposit status & receipts', icon: 'history' },
    { id: 'withdraw_funds_history', label: 'Withdraw Fund History', desc: 'Check payout status & UTR', icon: 'history' },
    { id: 'bank_details', label: 'Add Bank Details', desc: 'Link your savings or current account', icon: 'bank' },
    { id: 'bank_details_history', label: 'Bank Details History', desc: 'View linked & verified accounts', icon: 'bank-check' },
  ];

  const popularBanks = [
    'State Bank of India',
    'HDFC Bank',
    'ICICI Bank',
    'Kotak Mahindra Bank',
    'Punjab National Bank',
    'Bank of Baroda',
    'Axis Bank',
    'Canara Bank',
  ];

  // Strictly Verified Auto-Credit Callback via Gateway Status
  // Only credits wallet upon verified SUCCESS status from Kotak Gateway
  const pollPaymentGateway = useCallback(
    async (orderId: string, amount: number, bonus: number, method: string) => {
      try {
        const res = await fetch(`/api/payment-status/${orderId}`);
        if (!res.ok) return;
        const data = await res.json();
        if (!data || !data.order) return;

        const order = data.order;
        if (order.status === 'SUCCESS') {
          // WALLET BALANCE ONLY CREDITED HERE UPON STRICTLY VERIFIED SUCCESS FROM GATEWAY
          pendingPaymentRef.current = null;
          onAddFunds(amount, bonus, method, order.utr || orderId);
          setGatewayStatus('success');
          setAddFundsSuccess(
            `Payment verified! ₹${amount + bonus} credited via Kotak Gateway (UTR: ${order.utr || orderId})`
          );
        } else if (order.status === 'FAILED') {
          // TRANSACTION FAILED / INCORRECT PIN / TIMED OUT: ZERO WALLET CREDITING
          pendingPaymentRef.current = null;
          const reason =
            order.reason === 'INCORRECT_PIN'
              ? 'Payment Failed: Incorrect UPI PIN entered. Bank declined the transaction.'
              : order.reason === 'PAYMENT_TIMED_OUT' || order.reason === 'GATEWAY_TIMEOUT'
              ? 'Payment Failed: Gateway confirmation timed out. 0 points credited.'
              : order.reason || 'Payment Failed: Transaction was declined by bank or gateway.';
          setPaymentFailureReason(reason);
          setGatewayStatus('failed');
          onAddFundsFailure?.(orderId, amount + bonus, method, reason);
        } else if (order.status === 'CANCELLED') {
          // CANCELLED BY USER: ZERO WALLET CREDITING
          pendingPaymentRef.current = null;
          const reason = 'Payment Cancelled: Transaction was aborted by the user.';
          setPaymentFailureReason(reason);
          setGatewayStatus('failed');
          onAddFundsFailure?.(orderId, amount + bonus, method, reason);
        }
      } catch {
        // Network retry on next interval tick
      }
    },
    [onAddFunds, onAddFundsFailure]
  );

  // User Payment Cancellation Handler
  const handleCancelPayment = async () => {
    const current = activePaymentOrder;
    if (current) {
      try {
        await fetch('/api/cancel-payment', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ orderId: current.orderId }),
        });
      } catch {}

      pendingPaymentRef.current = null;
      const reason = 'Payment Cancelled: Transaction was aborted by the user.';
      setPaymentFailureReason(reason);
      setGatewayStatus('failed');
      onAddFundsFailure?.(current.orderId, current.amount + current.bonus, current.method, reason);
    } else {
      setGatewayStatus('idle');
      pendingPaymentRef.current = null;
    }
  };

  // Automatic Background Gateway Polling & Lifecycle Listeners
  useEffect(() => {
    if (gatewayStatus !== 'waiting_return' && gatewayStatus !== 'verifying') {
      return;
    }
    const current = activePaymentOrder;
    if (!current?.orderId) {
      return;
    }

    // 1. Immediate status poll
    pollPaymentGateway(current.orderId, current.amount, current.bonus, current.method);

    // 2. Continuous background polling every 2 seconds
    const interval = setInterval(() => {
      pollPaymentGateway(current.orderId, current.amount, current.bonus, current.method);
    }, 2000);

    // 3. Instant status check on app return / visibility change / focus
    const handleReturn = () => {
      if (document.visibilityState === 'visible' || document.hasFocus()) {
        pollPaymentGateway(current.orderId, current.amount, current.bonus, current.method);
      }
    };

    document.addEventListener('visibilitychange', handleReturn);
    window.addEventListener('focus', handleReturn);
    window.addEventListener('pageshow', handleReturn);

    // Hybrid/React Native AppState support if available in WebView wrapper
    const appStateGlobal = (window as any).AppState;
    let sub: any = null;
    if (appStateGlobal && typeof appStateGlobal.addEventListener === 'function') {
      sub = appStateGlobal.addEventListener('change', (state: string) => {
        if (state === 'active') {
          handleReturn();
        }
      });
    }

    // 4. Timeout safety: fail safely if bank confirmation not received within 120s
    const timeout = setTimeout(() => {
      if (gatewayStatus === 'waiting_return' || gatewayStatus === 'verifying') {
        pendingPaymentRef.current = null;
        const reason = 'Payment verification timed out. Bank confirmation not received. Wallet was NOT credited.';
        setPaymentFailureReason(reason);
        setGatewayStatus('failed');
        onAddFundsFailure?.(current.orderId, current.amount + current.bonus, current.method, reason);
      }
    }, 120000);

    return () => {
      clearInterval(interval);
      clearTimeout(timeout);
      document.removeEventListener('visibilitychange', handleReturn);
      window.removeEventListener('focus', handleReturn);
      window.removeEventListener('pageshow', handleReturn);
      if (sub && typeof sub.remove === 'function') sub.remove();
    };
  }, [gatewayStatus, activePaymentOrder, pollPaymentGateway, onAddFundsFailure]);

  // Direct UPI Intent Launch (phonepe://pay and upi://pay) with ZERO intermediate gateway screens
  const handleLaunchKotakUpi = (appScheme: 'upi' | 'phonepe' | 'gpay' | 'paytm', appTitle: string) => {
    const amt = activePaymentType === 'bonus' ? 1 : (parseInt(depositAmount, 10) || 500);
    const bonusAmt = activePaymentType === 'bonus' ? 99 : 0;
    const orderId = `KTK-${Math.floor(100000 + Math.random() * 900000)}`;

    let deepLink = '';
    if (appScheme === 'phonepe') {
      deepLink = `phonepe://pay?pa=${KOTAK_MERCHANT_VPA}&pn=${MERCHANT_NAME}&am=${amt}&tn=Wallet_Topup&cu=INR&mcc=0000&mode=02`;
    } else if (appScheme === 'gpay') {
      deepLink = `tez://upi/pay?pa=${KOTAK_MERCHANT_VPA}&pn=${MERCHANT_NAME}&am=${amt}&tn=Wallet_Topup&cu=INR&mcc=0000&mode=02`;
    } else if (appScheme === 'paytm') {
      deepLink = `paytmmp://pay?pa=${KOTAK_MERCHANT_VPA}&pn=${MERCHANT_NAME}&am=${amt}&tn=Wallet_Topup&cu=INR&mcc=0000&mode=02`;
    } else {
      deepLink = `upi://pay?pa=${KOTAK_MERCHANT_VPA}&pn=${MERCHANT_NAME}&am=${amt}&tn=Wallet_Topup&cu=INR&mcc=0000&mode=02`;
    }

    const orderData = {
      amount: amt,
      bonus: bonusAmt,
      method: appTitle,
      orderId,
      initiatedAt: Date.now(),
    };

    pendingPaymentRef.current = orderData;
    setActivePaymentOrder(orderData);
    setPaymentFailureReason('');
    setShowUpiSheet(false);
    setGatewayStatus('waiting_return');

    // Register pending order with backend registry
    fetch('/api/initiate-payment', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        orderId,
        amount: amt,
        bonus: bonusAmt,
        method: appTitle,
        userPhone: user.phone,
      }),
    }).catch(() => {});

    // Direct Intent trigger without any intermediate screens
    try {
      const link = document.createElement('a');
      link.href = deepLink;
      link.rel = 'noopener noreferrer';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch {
      window.location.href = deepLink;
    }
  };

  const copyKotakVpa = () => {
    navigator.clipboard.writeText(ACTIVE_VPA);
    setCopiedVpa(true);
    setTimeout(() => setCopiedVpa(false), 2000);
  };

  const handleManualUpiDepositSubmit = async () => {
    const amt = parseInt(depositAmount, 10);
    if (isNaN(amt) || amt < MIN_DEPOSIT) {
      setUtrError(`Minimum deposit amount is ₹${MIN_DEPOSIT}`);
      return;
    }
    if (amt > MAX_DEPOSIT) {
      setUtrError(`Maximum deposit amount is ₹${MAX_DEPOSIT}`);
      return;
    }
    const cleanUtr = utrInput.trim().replace(/\s+/g, '');
    if (!cleanUtr || cleanUtr.length < 8) {
      setUtrError('Please enter a valid 12-digit UPI UTR or Reference Number');
      return;
    }

    setIsSubmittingUtr(true);
    setUtrError('');

    const now = new Date();
    const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
      .toString()
      .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    const orderId = `KTK-${Math.floor(100000 + Math.random() * 900000)}`;

    const depositItem: FundHistoryItem = {
      id: `dep-${Date.now()}`,
      orderId,
      date: dateStr,
      amount: amt,
      status: 'Pending',
      requestType: 'Credit',
      depositMode: 'Manual UPI QR',
      utrOrReference: cleanUtr,
    };

    try {
      // 1. Dual-write to deposits and deposit_requests in Firestore for Netlify Admin panel
      await createDepositInFirestore(depositItem, user, 0);

      // 2. Notify parent state so history and transactions update with Pending status
      onAddFunds(amt, 0, 'Manual UPI QR', cleanUtr, 'Pending');

      setAddFundsSuccess(
        `✓ Deposit request of ₹${amt} submitted with UTR: ${cleanUtr}! Admin will verify and credit your wallet shortly.`
      );
      setUtrInput('');
      setIsSubmittingUtr(false);

      setTimeout(() => {
        setAddFundsSuccess('');
        setSubView('add_funds_history');
      }, 2500);
    } catch (err) {
      console.error('Error submitting manual UPI deposit:', err);
      setIsSubmittingUtr(false);
      setUtrError('Failed to submit deposit. Please check your network connection.');
    }
  };

  const handleWithdrawSubmit = () => {
    const amt = parseInt(withdrawAmount, 10);
    if (isNaN(amt) || amt < 300) {
      setWithdrawError('Minimum withdrawal limit is ₹300');
      return;
    }
    if (amt > user.walletBalance) {
      setWithdrawError(`Insufficient balance. Current balance is ₹${user.walletBalance}`);
      return;
    }
    if (bankAccounts.length === 0) {
      setWithdrawError('Please add a verified bank account first');
      return;
    }

    const defaultBank = bankAccounts.find((b) => b.isDefault) || bankAccounts[0];
    const success = onWithdrawFunds(amt, defaultBank.id);
    if (success) {
      setWithdrawError('');
      setWithdrawSuccess(`Withdrawal request of ₹${amt} initiated successfully!`);
      setTimeout(() => {
        setWithdrawSuccess('');
        setSubView('withdraw_funds_history');
      }, 1500);
    }
  };

  const handleAddBankSubmit = () => {
    if (!accountHolder.trim() || !bankName.trim() || !accountNumber.trim() || !ifscCode.trim()) {
      setBankError('Please fill all bank details');
      return;
    }
    if (accountNumber !== confirmAccountNumber) {
      setBankError('Account numbers do not match. Please verify.');
      return;
    }
    if (!bankAgreement) {
      setBankError('Please acknowledge the 30-day update policy checkbox.');
      return;
    }

    onAddBank({
      accountHolder: accountHolder.toUpperCase(),
      bankName: bankName.trim(),
      branch: 'MAIN BRANCH',
      ifscCode: ifscCode.toUpperCase().trim(),
      accountNumber: accountNumber.trim(),
      isDefault: bankAccounts.length === 0,
      status: 'Success',
    });

    setBankSuccess('Bank account added & verified successfully!');
    setBankError('');
    setTimeout(() => {
      setBankSuccess('');
      setSubView('bank_details_history');
    }, 1200);
  };

  const filteredAddFunds = addFundsHistory.filter(
    (item) => addFundsFilter === 'ALL' || item.status === addFundsFilter
  );

  const filteredWithdrawFunds = withdrawFundsHistory.filter(
    (item) => withdrawFilter === 'ALL' || item.status === withdrawFilter
  );

  // Check if bank update is locked under 30 days
  const latestBank = bankAccounts[0];
  const isBankUpdateLocked = !!(latestBank && latestBank.lockUntil);

  return (
    <div className="pb-6 pt-2 px-4 transition-colors">
      {!subView ? (
        /* Funds Menu matching frames2/f_001.jpg */
        <div className="space-y-4">
          {/* Quick Balance Header Card */}
          <div className="bg-gradient-to-r from-orange-500 via-[#FF7700] to-[#E65100] rounded-3xl p-5 text-white shadow-lg shadow-orange-500/20 relative overflow-hidden">
            <div className="absolute -right-6 -bottom-6 w-32 h-32 rounded-full bg-white/10 blur-xl pointer-events-none" />
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs uppercase tracking-wider text-orange-100 font-bold block">
                  Total Wallet Balance
                </span>
                <div className="text-3xl font-black font-mono tracking-tight mt-1">
                  ₹{user.walletBalance.toLocaleString('en-IN')}
                </div>
              </div>
              <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <Wallet className="w-6 h-6 text-white" />
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-white/20 flex items-center justify-between text-xs">
              <span className="text-orange-100">Safe & Instant Deposits/Withdrawals</span>
              <button
                onClick={() => setSubView('add_funds')}
                className="px-3 py-1 rounded-full bg-white text-[#FF7700] font-black text-xs hover:bg-orange-50 active:scale-95 transition-all shadow-xs cursor-pointer"
              >
                + Add Funds
              </button>
            </div>
          </div>

          {/* Menu Options */}
          <div className="space-y-3">
            {fundsMenu.map((item) => (
              <button
                key={item.id}
                onClick={() => setSubView(item.id)}
                className="w-full bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between shadow-xs hover:border-[#FF7700] active:scale-[0.99] transition-all cursor-pointer text-left"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs shrink-0">
                    {item.icon === 'wallet-up' || item.icon === 'wallet-down' ? (
                      <Wallet className="w-5 h-5" />
                    ) : item.icon === 'bank' || item.icon === 'bank-check' ? (
                      <Building2 className="w-5 h-5" />
                    ) : (
                      <FileClock className="w-5 h-5" />
                    )}
                  </div>
                  <div>
                    <span className="font-bold text-slate-900 dark:text-slate-100 text-sm block">
                      {item.label}
                    </span>
                    <span className="text-[11px] text-slate-400 block mt-0.5">
                      {item.desc}
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-400 shrink-0" />
              </button>
            ))}
          </div>
        </div>
      ) : subView === 'add_funds' ? (
        /* Add Funds Flow matching f_015.jpg & reference flow */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setSubView(null)}
                className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <h2 className="text-base font-extrabold text-[#FF7700]">Add Funds</h2>
            </div>
            <div className="bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-full px-3 py-1">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 font-mono">
                ₹{user.walletBalance}
              </span>
            </div>
          </div>

          {/* User Details & Available Balance Card */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-1.5">
                  <h4 className="font-extrabold text-slate-900 dark:text-slate-100 text-sm">
                    {user.name}
                  </h4>
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" title="Active Account" />
                </div>
                <p className="text-xs text-slate-500 font-mono mt-0.5">+91 {user.phone}</p>
              </div>
              <div className="text-right">
                <span className="text-[11px] text-slate-400 block font-medium">Live Wallet Balance</span>
                <span className="font-black text-sm text-[#FF7700] font-mono">
                  ₹{user.walletBalance.toLocaleString('en-IN')}
                </span>
              </div>
            </div>

            {/* Live Gateway Verified Strip */}
            <div className="bg-slate-50 dark:bg-slate-800/60 rounded-2xl p-3 border border-slate-200/70 dark:border-slate-700/60 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2.5 overflow-hidden">
                <div className="w-8 h-8 rounded-xl bg-orange-500/10 text-[#FF7700] flex items-center justify-center font-black text-xs shrink-0">
                  <QrCode className="w-4 h-4 text-[#FF7700]" />
                </div>
                <div className="truncate">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-bold uppercase text-slate-400 leading-none">
                      Manual UPI QR Gateway
                    </span>
                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-[9px] font-bold text-emerald-600 uppercase">Live</span>
                  </div>
                  <div className="font-mono text-xs font-bold text-slate-800 dark:text-slate-200 truncate mt-0.5">
                    {ACTIVE_VPA}
                  </div>
                  <div className="text-[10px] text-slate-400 truncate">
                    {ACTIVE_MERCHANT}
                  </div>
                </div>
              </div>
              <button
                onClick={copyKotakVpa}
                className="px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-[11px] font-bold text-slate-700 dark:text-slate-200 hover:text-[#FF7700] hover:border-[#FF7700] flex items-center gap-1 cursor-pointer shrink-0 ml-2 shadow-2xs active:scale-95 transition-all"
                title="Copy Merchant UPI ID"
              >
                {copiedVpa ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedVpa ? 'Copied!' : 'Copy UPI'}</span>
              </button>
            </div>

            {addFundsSuccess && (
              <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs font-semibold flex items-center gap-2.5 animate-in fade-in border border-emerald-200/80 dark:border-emerald-800/60">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>{addFundsSuccess}</span>
              </div>
            )}

            {/* Select Amount Field */}
            <div className="pt-1 text-center">
              <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 block mb-2">
                Select or Enter Amount (Min. ₹{MIN_DEPOSIT})
              </label>

              {/* Editable Amount Display */}
              <div className="relative inline-flex items-center justify-center mb-3">
                <span className="text-2xl font-black text-[#FF7700] mr-1">₹</span>
                <input
                  type="number"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  placeholder="500"
                  className="w-40 text-center text-3xl font-black text-slate-900 dark:text-slate-100 font-mono tracking-tight bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl py-1.5 px-2 outline-none focus:border-[#FF7700] transition-colors"
                />
              </div>

              {/* Amount Quick Chips */}
              <div className="grid grid-cols-3 gap-2 mb-4">
                {['100', '300', '500', '1000', '2000', '5000'].map((amt) => (
                  <button
                    key={amt}
                    onClick={() => setDepositAmount(amt)}
                    className={`py-2 rounded-xl text-xs font-bold font-mono transition-all cursor-pointer ${
                      depositAmount === amt
                        ? 'bg-[#FF7700] text-white shadow-md shadow-orange-500/30 ring-2 ring-orange-300'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    + ₹{amt}
                  </button>
                ))}
              </div>

              {/* Deposit Mode Toggle: Scan QR vs Direct Apps */}
              <div className="flex bg-slate-100 dark:bg-slate-800/80 p-1 rounded-2xl mb-4 border border-slate-200/70 dark:border-slate-700/60">
                <button
                  type="button"
                  onClick={() => setDepositPaymentMode('qr')}
                  className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    depositPaymentMode === 'qr'
                      ? 'bg-white dark:bg-slate-900 text-[#FF7700] shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  <QrCode className="w-3.5 h-3.5" />
                  <span>Scan QR Code</span>
                </button>
                <button
                  type="button"
                  onClick={() => setDepositPaymentMode('apps')}
                  className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    depositPaymentMode === 'apps'
                      ? 'bg-white dark:bg-slate-900 text-[#FF7700] shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>Pay via UPI App</span>
                </button>
              </div>

              {/* Mode 1: Dynamic Manual UPI QR Screen */}
              {depositPaymentMode === 'qr' && (
                <div className="bg-slate-50 dark:bg-slate-850 p-4 rounded-3xl border border-slate-200/80 dark:border-slate-800 space-y-3.5 mb-4 animate-in fade-in">
                  <div className="text-center">
                    <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 block">
                      Step 1: Scan & Pay with Any UPI App
                    </span>
                    <div className="text-xs text-slate-600 dark:text-slate-300 font-semibold mt-0.5">
                      Payable: <strong className="text-[#FF7700] font-mono text-sm">₹{depositAmount || '0'}</strong>
                    </div>
                  </div>

                  {/* QR Code Container */}
                  <div className="relative mx-auto w-52 h-52 bg-white rounded-2xl p-2.5 shadow-md border-2 border-orange-500/30 flex items-center justify-center">
                    <img
                      src={`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(
                        `upi://pay?pa=${ACTIVE_VPA}&pn=${encodeURIComponent(ACTIVE_MERCHANT)}&am=${depositAmount || '500'}&cu=INR`
                      )}`}
                      alt="Manual UPI QR Code"
                      className="w-full h-full object-contain rounded-lg"
                      loading="eager"
                    />
                    <div className="absolute inset-0 pointer-events-none rounded-2xl border-4 border-dashed border-orange-500/20" />
                  </div>

                  {/* Supported UPI Apps Row */}
                  <div className="flex items-center justify-center gap-2 pt-1 text-[10px] font-bold text-slate-500">
                    <span className="px-2 py-0.5 rounded-md bg-purple-50 text-purple-700 border border-purple-200">PhonePe</span>
                    <span className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200">Google Pay</span>
                    <span className="px-2 py-0.5 rounded-md bg-sky-50 text-sky-700 border border-sky-200">Paytm</span>
                    <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200">BHIM</span>
                  </div>

                  {/* Quick VPA copy bar */}
                  <div className="bg-white dark:bg-slate-900 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
                    <span className="font-mono text-[11px] font-semibold text-slate-700 dark:text-slate-300 truncate">
                      {ACTIVE_VPA}
                    </span>
                    <button
                      onClick={copyKotakVpa}
                      className="text-[#FF7700] hover:underline font-bold text-[11px] shrink-0 ml-2 cursor-pointer flex items-center gap-1"
                    >
                      {copiedVpa ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedVpa ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Mode 2: Direct UPI App Intents */}
              {depositPaymentMode === 'apps' && (
                <div className="space-y-2 mb-4 animate-in fade-in">
                  <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 block mb-1">
                    Step 1: Open Your UPI App to Pay ₹{depositAmount || 0}
                  </span>

                  <button
                    onClick={() => handleLaunchKotakUpi('phonepe', 'PhonePe')}
                    disabled={!depositAmount || parseInt(depositAmount, 10) < MIN_DEPOSIT}
                    className="w-full py-3 rounded-2xl bg-[#5f259f] hover:bg-[#501f87] text-white font-bold text-xs shadow-md shadow-purple-500/20 active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    <span className="w-4 h-4 rounded-full bg-white text-[#5f259f] flex items-center justify-center font-black text-[10px]">
                      पे
                    </span>
                    <span>Pay via PhonePe • ₹{depositAmount || 0}</span>
                  </button>

                  <button
                    onClick={() => handleLaunchKotakUpi('gpay', 'Google Pay')}
                    disabled={!depositAmount || parseInt(depositAmount, 10) < MIN_DEPOSIT}
                    className="w-full py-3 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-500/20 active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    <span className="font-black text-xs">G</span>
                    <span>Pay via Google Pay • ₹{depositAmount || 0}</span>
                  </button>

                  <button
                    onClick={() => handleLaunchKotakUpi('paytm', 'Paytm')}
                    disabled={!depositAmount || parseInt(depositAmount, 10) < MIN_DEPOSIT}
                    className="w-full py-3 rounded-2xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs shadow-md shadow-sky-500/20 active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    <span className="font-black text-xs">P</span>
                    <span>Pay via Paytm • ₹{depositAmount || 0}</span>
                  </button>

                  <button
                    onClick={() => handleLaunchKotakUpi('upi', 'Any UPI App')}
                    disabled={!depositAmount || parseInt(depositAmount, 10) < MIN_DEPOSIT}
                    className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-bold text-xs shadow-md shadow-orange-500/20 active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    <Zap className="w-3.5 h-3.5 fill-white text-white" />
                    <span>Pay via Any Installed UPI App</span>
                  </button>
                </div>
              )}

              {/* Step 2: 12-Digit UTR Submission Card */}
              <div className="bg-orange-50/60 dark:bg-orange-950/20 p-4 rounded-3xl border border-orange-200/80 dark:border-orange-900/40 text-left space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-slate-900 dark:text-slate-100 uppercase tracking-wide flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-[#FF7700]" />
                    <span>Step 2: Enter 12-Digit UTR / Ref No</span>
                  </span>
                  <span className="text-[10px] font-mono text-slate-400 font-bold">
                    {utrInput.trim().length}/12 Digits
                  </span>
                </div>

                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug">
                  After payment is completed in PhonePe/GPay/Paytm, open the receipt, copy the <strong>12-digit UTR/UPI Ref ID</strong>, and enter it below:
                </p>

                <div className="space-y-1.5">
                  <div className="relative">
                    <input
                      type="text"
                      maxLength={18}
                      value={utrInput}
                      onChange={(e) => {
                        setUtrInput(e.target.value.replace(/[^a-zA-Z0-9]/g, ''));
                        if (utrError) setUtrError('');
                      }}
                      placeholder="e.g. 428919028341"
                      className="w-full px-3.5 py-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-mono text-sm font-bold text-slate-900 dark:text-slate-100 placeholder:text-slate-400 outline-none focus:border-[#FF7700] focus:ring-2 focus:ring-orange-500/20 transition-all uppercase"
                    />
                  </div>

                  {utrError && (
                    <div className="flex items-center gap-1.5 text-[11px] font-bold text-red-600 dark:text-red-400 animate-in fade-in">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{utrError}</span>
                    </div>
                  )}
                </div>

                {/* Submit Deposit Request Button */}
                <button
                  type="button"
                  onClick={handleManualUpiDepositSubmit}
                  disabled={isSubmittingUtr || !utrInput.trim() || !depositAmount || parseInt(depositAmount, 10) < MIN_DEPOSIT}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#FF7700] to-[#E65100] hover:from-orange-600 hover:to-orange-700 text-white font-extrabold text-sm shadow-md shadow-orange-500/30 active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmittingUtr ? (
                    <>
                      <Clock className="w-4 h-4 animate-spin" />
                      <span>Submitting Deposit Request...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Submit Deposit Request (₹{depositAmount || 0})</span>
                    </>
                  )}
                </button>
              </div>

              {/* Welcome Bonus Offer Trigger */}
              <button
                onClick={() => setShowBonusSheet(true)}
                className="mt-4 text-xs font-bold text-[#FF7700] hover:underline flex items-center justify-center gap-1.5 mx-auto cursor-pointer"
              >
                <Gift className="w-3.5 h-3.5" />
                <span>Claim ₹100 Welcome Bonus Offer</span>
              </button>
            </div>
          </div>

          {/* Welcome Bonus Bottom Sheet Modal matching f_015.jpg */}
          {showBonusSheet && (
            <div className="absolute inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
              <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-slate-800 text-center animate-in slide-in-from-bottom duration-200 relative">
                <button
                  onClick={() => setShowBonusSheet(false)}
                  className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
                >
                  ✕
                </button>

                {/* Gift Box with Coin Popping Out */}
                <div className="w-20 h-20 mx-auto mb-3 relative flex items-center justify-center">
                  <div className="w-16 h-14 bg-gradient-to-tr from-[#FF7700] to-orange-400 rounded-2xl shadow-md flex items-center justify-center">
                    <Gift className="w-8 h-8 text-white" />
                  </div>
                  <div className="absolute -top-2 w-8 h-8 rounded-full bg-amber-400 border-2 border-white shadow-md flex items-center justify-center text-amber-900 font-black text-xs">
                    ₹
                  </div>
                </div>

                <div className="inline-block px-3 py-1 rounded-full border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 mb-2">
                  Welcome Bonus
                </div>

                <h3 className="text-lg font-black text-slate-900 dark:text-slate-100">
                  Pay ₹1, Get ₹100
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5 mb-5 font-medium">
                  *New Users Only, instant bonus credited to your wallet via Kotak VPA
                </p>

                <div className="space-y-2">
                  <button
                    onClick={() => {
                      setActivePaymentType('bonus');
                      setShowBonusSheet(false);
                      handleLaunchKotakUpi('phonepe', 'PhonePe Welcome Bonus');
                    }}
                    className="w-full py-3.5 rounded-2xl bg-[#5f259f] hover:bg-[#501f87] text-white font-extrabold text-sm shadow-md shadow-purple-500/25 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <span>Pay ₹1 via PhonePe</span>
                  </button>
                  <button
                    onClick={() => {
                      setActivePaymentType('bonus');
                      setShowBonusSheet(false);
                      handleLaunchKotakUpi('upi', 'Kotak UPI Welcome Bonus');
                    }}
                    className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-extrabold text-sm shadow-md shadow-orange-500/25 active:scale-95 transition-all cursor-pointer"
                  >
                    Pay ₹1 via Any UPI
                  </button>
                  <button
                    onClick={() => setShowBonusSheet(false)}
                    className="w-full py-2 text-xs font-bold text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    Skip for now
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Kotak Merchant UPI Gateway Sheet */}
          {showUpiSheet && (
            <div className="absolute inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
              <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in slide-in-from-bottom duration-200 relative">
                <button
                  onClick={() => setShowUpiSheet(false)}
                  className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
                >
                  ✕
                </button>

                <div className="flex items-center gap-2 mb-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[11px] font-bold text-emerald-600 uppercase tracking-wider">
                    Kotak Merchant FastPay Gateway
                  </span>
                </div>

                <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100 mb-0.5">
                  Choose UPI App
                </h3>
                <p className="text-xs text-slate-400 mb-4 font-mono">
                  Payable: <strong className="text-[#FF7700]">₹{activePaymentType === 'bonus' ? '1' : depositAmount}</strong> • Kotak VPA: <span className="font-semibold text-slate-700 dark:text-slate-300">0793748A0296660.bqr@kotak</span>
                </p>

                {/* 6 UPI App Icons with exact deep links */}
                <div className="grid grid-cols-3 gap-3 mb-5">
                  {[
                    { name: 'PhonePe', scheme: 'phonepe' as const, color: 'bg-purple-600', text: 'पे' },
                    { name: 'Google Pay', scheme: 'gpay' as const, color: 'bg-blue-500', text: 'G' },
                    { name: 'Paytm', scheme: 'paytm' as const, color: 'bg-sky-600', text: 'P' },
                    { name: 'BHIM UPI', scheme: 'upi' as const, color: 'bg-emerald-600', text: 'UPI' },
                    { name: 'Cred UPI', scheme: 'upi' as const, color: 'bg-slate-900', text: 'C' },
                    { name: 'Other UPI', scheme: 'upi' as const, color: 'bg-[#FF7700]', text: '₹' },
                  ].map((app) => (
                    <button
                      key={app.name}
                      onClick={() => handleLaunchKotakUpi(app.scheme, app.name)}
                      className="flex flex-col items-center gap-1.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 hover:border-[#FF7700] active:scale-95 transition-all cursor-pointer"
                    >
                      <div
                        className={`w-11 h-11 rounded-2xl ${app.color} text-white flex items-center justify-center font-black text-sm shadow-xs`}
                      >
                        {app.text}
                      </div>
                      <span className="text-[11px] font-semibold text-slate-800 dark:text-slate-200 truncate w-full text-center">
                        {app.name}
                      </span>
                    </button>
                  ))}
                </div>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-center">
                  <span className="text-[10px] text-slate-400">
                    Auto-credit triggers instantly upon app return · No UTR input needed
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Active Background Auto-Credit Modal (AppState / Lifecycle return) */}
          {gatewayStatus !== 'idle' && (
            <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in">
              <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-slate-800 text-center relative">
                {gatewayStatus === 'waiting_return' && (
                  <div className="space-y-4">
                    <div className="w-16 h-16 mx-auto rounded-2xl bg-orange-100 dark:bg-orange-950/60 text-[#FF7700] flex items-center justify-center relative">
                      <Zap className="w-8 h-8 animate-pulse text-[#FF7700]" />
                      <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 animate-ping" />
                    </div>

                    <div>
                      <h3 className="text-base font-black text-slate-900 dark:text-slate-100">
                        Completing Kotak Merchant UPI
                      </h3>
                      <p className="text-xs text-slate-500 mt-1">
                        Please approve payment of <strong className="text-[#FF7700]">₹{activePaymentOrder?.amount || depositAmount}</strong> in your UPI app.
                      </p>
                    </div>

                    <div className="bg-slate-50 dark:bg-slate-800/80 p-3 rounded-2xl border border-slate-200/80 dark:border-slate-700 text-left text-xs font-mono space-y-1">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Order ID:</span>
                        <span className="font-bold">{activePaymentOrder?.orderId || 'KTK-AUTO'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">User:</span>
                        <span>{user.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Phone:</span>
                        <span>+91 {user.phone}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Kotak VPA:</span>
                        <span className="truncate max-w-[170px]">{KOTAK_MERCHANT_VPA}</span>
                      </div>
                    </div>

                    <div className="bg-orange-50 dark:bg-orange-950/40 p-3 rounded-2xl border border-orange-200/80 dark:border-orange-900/60 text-center space-y-1.5">
                      <div className="flex items-center justify-center gap-2 text-xs font-bold text-[#FF7700]">
                        <Clock className="w-4 h-4 animate-spin text-[#FF7700]" />
                        <span>Awaiting Kotak Gateway Confirmation</span>
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight">
                        Auto-checking transaction with Kotak Gateway every 2 seconds. Wallet points will be credited automatically once bank confirms.
                      </p>
                      <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-1.5 overflow-hidden mt-1.5">
                        <div className="bg-gradient-to-r from-[#FF7700] via-emerald-500 to-[#FF7700] h-full rounded-full animate-pulse w-full" />
                      </div>
                    </div>

                    <div className="pt-1">
                      <button
                        onClick={handleCancelPayment}
                        className="w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 font-bold text-xs active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <XCircle className="w-4 h-4 text-slate-400" />
                        <span>Cancel Transaction</span>
                      </button>
                    </div>
                  </div>
                )}

                {gatewayStatus === 'verifying' && (
                  <div className="py-6 space-y-4">
                    <div className="w-16 h-16 mx-auto rounded-full bg-orange-100 dark:bg-orange-950/60 text-[#FF7700] flex items-center justify-center relative">
                      <Clock className="w-8 h-8 animate-spin text-[#FF7700]" />
                    </div>

                    <div>
                      <h3 className="text-base font-black text-slate-900 dark:text-slate-100">
                        Verifying Kotak Merchant Payment...
                      </h3>
                      <p className="text-xs text-slate-400 mt-1">
                        Auto-matching transaction with Kotak Merchant VPA for {user.name} (+91 {user.phone}).
                      </p>
                    </div>

                    <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
                      <div className="bg-[#FF7700] h-full rounded-full animate-pulse w-3/4" />
                    </div>
                  </div>
                )}

                {gatewayStatus === 'success' && (
                  <div className="py-4 space-y-4 animate-in zoom-in-95">
                    <div className="w-16 h-16 mx-auto rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 flex items-center justify-center">
                      <CheckCircle2 className="w-10 h-10 text-emerald-600" />
                    </div>

                    <div>
                      <h3 className="text-lg font-black text-slate-900 dark:text-slate-100">
                        ✓ Instant Auto-Credit Successful!
                      </h3>
                      <p className="text-xs text-emerald-600 font-bold mt-1">
                        + ₹{(activePaymentOrder?.amount || 0) + (activePaymentOrder?.bonus || 0)} points added to your wallet
                      </p>
                    </div>

                    <div className="bg-slate-50 dark:bg-slate-800/80 p-3.5 rounded-2xl border border-slate-200/80 dark:border-slate-700 text-xs font-mono space-y-1.5">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Account:</span>
                        <span className="font-bold">{user.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Order ID:</span>
                        <span className="font-bold text-[#FF7700]">{activePaymentOrder?.orderId || 'KTK-ORDER'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Updated Balance:</span>
                        <span className="font-bold text-emerald-600">₹{user.walletBalance.toLocaleString('en-IN')}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setGatewayStatus('idle');
                        setActivePaymentOrder(null);
                        setSubView(null);
                      }}
                      className="w-full py-3 rounded-2xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-bold text-xs active:scale-95 transition-all cursor-pointer"
                    >
                      Done & Return to Wallet
                    </button>
                  </div>
                )}

                {gatewayStatus === 'failed' && (
                  <div className="py-4 space-y-4 animate-in zoom-in-95">
                    <div className="w-16 h-16 mx-auto rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center">
                      <XCircle className="w-10 h-10 text-rose-600" />
                    </div>

                    <div>
                      <h3 className="text-lg font-black text-slate-900 dark:text-slate-100">
                        Payment Failed
                      </h3>
                      <p className="text-xs text-rose-600 dark:text-rose-400 font-semibold mt-1">
                        {paymentFailureReason || 'Transaction was not successful. Wallet balance was NOT credited.'}
                      </p>
                    </div>

                    <div className="bg-slate-50 dark:bg-slate-800/80 p-3.5 rounded-2xl border border-slate-200/80 dark:border-slate-700 text-xs font-mono space-y-1.5 text-left">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Order ID:</span>
                        <span className="font-bold text-slate-700 dark:text-slate-300">
                          {activePaymentOrder?.orderId || 'KTK-ORDER'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Amount:</span>
                        <span className="font-bold text-slate-700 dark:text-slate-300">
                          ₹{(activePaymentOrder?.amount || 0) + (activePaymentOrder?.bonus || 0)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Status:</span>
                        <span className="font-bold text-rose-600 dark:text-rose-400">FAILED / NOT CREDITED</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Current Balance:</span>
                        <span className="font-bold text-slate-900 dark:text-slate-100">
                          ₹{user.walletBalance.toLocaleString('en-IN')}
                        </span>
                      </div>
                    </div>

                    <div className="space-y-2 pt-1">
                      <button
                        onClick={() => {
                          setGatewayStatus('idle');
                          setActivePaymentOrder(null);
                        }}
                        className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-bold text-xs active:scale-95 transition-all cursor-pointer shadow-md shadow-orange-500/20"
                      >
                        Try Again
                      </button>

                      <button
                        onClick={() => {
                          setGatewayStatus('idle');
                          setActivePaymentOrder(null);
                          setSubView(null);
                        }}
                        className="w-full py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold text-xs active:scale-95 transition-all cursor-pointer"
                      >
                        Back to Wallet
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      ) : subView === 'add_funds_history' ? (
        /* Add Funds History matching f_028.jpg */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setSubView(null)}
                className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <h2 className="text-base font-extrabold text-[#FF7700]">Add Funds History</h2>
            </div>
            <span className="text-xs font-mono text-slate-400">
              {filteredAddFunds.length} records
            </span>
          </div>

          {/* Status Filter Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {(['ALL', 'Success', 'Pending', 'Failure'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setAddFundsFilter(filter)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                  addFundsFilter === filter
                    ? 'bg-[#FF7700] text-white shadow-xs'
                    : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                {filter === 'ALL' ? 'All' : filter}
              </button>
            ))}
          </div>

          <div className="space-y-3">
            {filteredAddFunds.length === 0 ? (
              <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200/80 dark:border-slate-800 text-center shadow-xs">
                <FileClock className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-600 dark:text-slate-400">
                  No {addFundsFilter !== 'ALL' ? addFundsFilter.toLowerCase() : ''} records found
                </p>
              </div>
            ) : (
              filteredAddFunds.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedReceipt(item)}
                  className="bg-white dark:bg-slate-900 rounded-3xl p-4 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3 cursor-pointer hover:border-orange-300 dark:hover:border-slate-700 transition-all"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-500 font-mono flex items-center gap-1.5">
                      📅 {item.date}
                    </span>
                    <span className="text-base font-black text-[#FF7700] font-mono">
                      +₹{item.amount}
                    </span>
                  </div>

                  <div className="bg-slate-50 dark:bg-slate-800/80 rounded-2xl p-3 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 font-semibold block uppercase">
                        Order Id
                      </span>
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200 font-mono">
                        {item.orderId}
                      </span>
                    </div>

                    {/* Proper status indicator */}
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 ${
                        item.status === 'Failure'
                          ? 'bg-rose-50 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400 border border-rose-200 dark:border-rose-900'
                          : item.status === 'Pending'
                          ? 'bg-amber-50 text-amber-600 dark:bg-amber-950/60 dark:text-amber-400 border border-amber-200 dark:border-amber-900'
                          : 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-900'
                      }`}
                    >
                      {item.status === 'Failure' ? (
                        <XCircle className="w-3.5 h-3.5" />
                      ) : item.status === 'Pending' ? (
                        <Clock className="w-3.5 h-3.5" />
                      ) : (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      )}
                      <span>{item.status}</span>
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-1">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Request Type</span>
                      <span className="font-semibold text-emerald-600">{item.requestType}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block">Deposit Mode</span>
                      <span className="font-semibold text-slate-700 dark:text-slate-300">
                        {item.depositMode}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      ) : subView === 'withdraw_funds' ? (
        /* Withdraw Funds Flow */
        <div className="space-y-4">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setSubView(null)}
              className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <h2 className="text-base font-extrabold text-[#FF7700]">Withdraw Funds</h2>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex items-center justify-between text-xs pb-3 border-b border-slate-100 dark:border-slate-800">
              <span className="text-slate-500 font-semibold">Available for Withdrawal</span>
              <span className="font-black text-base text-[#FF7700] font-mono">
                ₹{user.walletBalance}
              </span>
            </div>

            {withdrawError && (
              <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{withdrawError}</span>
              </div>
            )}
            {withdrawSuccess && (
              <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 text-xs font-semibold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{withdrawSuccess}</span>
              </div>
            )}

            <div>
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                Enter Amount (Min. ₹300)
              </label>
              <input
                type="number"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
                placeholder="300"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-base font-bold font-mono outline-none focus:border-[#FF7700]"
              />

              {/* Preset Quick Chips for Withdrawal */}
              <div className="grid grid-cols-4 gap-2 mt-2">
                {['300', '500', '1000'].map((amt) => (
                  <button
                    key={amt}
                    onClick={() => setWithdrawAmount(amt)}
                    className="py-1.5 rounded-xl text-xs font-bold font-mono bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-all cursor-pointer"
                  >
                    ₹{amt}
                  </button>
                ))}
                <button
                  onClick={() => setWithdrawAmount(user.walletBalance.toString())}
                  className="py-1.5 rounded-xl text-xs font-bold font-mono bg-orange-100 dark:bg-orange-950/60 text-[#FF7700] hover:bg-orange-200 transition-all cursor-pointer"
                >
                  Max (All)
                </button>
              </div>
            </div>

            {/* Select Bank */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  Transfer to Bank Account
                </label>
                <button
                  onClick={() => setSubView('bank_details_history')}
                  className="text-[11px] font-bold text-[#FF7700] hover:underline cursor-pointer"
                >
                  Manage Bank
                </button>
              </div>

              {bankAccounts.length === 0 ? (
                <button
                  onClick={() => setSubView('add_bank_details')}
                  className="w-full p-3 rounded-2xl border border-dashed border-[#FF7700] text-[#FF7700] text-xs font-bold flex items-center justify-center gap-2 cursor-pointer bg-orange-50/30 dark:bg-orange-950/20"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Bank Account First</span>
                </button>
              ) : (
                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-xs text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-[#FF7700]" />
                      <span>{bankAccounts[0].bankName}</span>
                      <span className="text-[10px] px-2 py-0.2 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400 font-bold">
                        Verified
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono mt-1">
                      A/c: {bankAccounts[0].accountNumber} · IFSC: {bankAccounts[0].ifscCode}
                    </div>
                  </div>
                  <span className="text-xs text-slate-400 font-bold uppercase">
                    {bankAccounts[0].accountHolder}
                  </span>
                </div>
              )}
            </div>

            {/* Withdrawal Guidelines Card */}
            <div className="p-3 rounded-2xl bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200/80 dark:border-amber-900/40 text-amber-900 dark:text-amber-200 text-[11px] space-y-1">
              <div className="font-bold flex items-center gap-1 text-amber-700 dark:text-amber-400">
                <Info className="w-3.5 h-3.5 shrink-0" />
                <span>Withdrawal Policy</span>
              </div>
              <ul className="list-disc pl-4 space-y-0.5 text-[10.5px] text-amber-800 dark:text-amber-300">
                <li>Withdrawal Timing: 10:00 AM to 05:00 PM daily.</li>
                <li>Minimum withdrawal ₹300, Maximum ₹50,000 per request.</li>
                <li>Transfers processed instantly via IMPS / NEFT.</li>
              </ul>
            </div>

            <button
              onClick={handleWithdrawSubmit}
              disabled={bankAccounts.length === 0}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-bold text-sm shadow-md shadow-orange-500/25 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
            >
              Submit Withdrawal Request
            </button>
          </div>
        </div>
      ) : subView === 'withdraw_funds_history' ? (
        /* Withdraw Funds History matching f_030.jpg */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setSubView(null)}
                className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <h2 className="text-base font-extrabold text-[#FF7700]">Withdraw Funds History</h2>
            </div>
            <span className="text-xs font-mono text-slate-400">
              {filteredWithdrawFunds.length} records
            </span>
          </div>

          {/* Status Filter Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {(['ALL', 'Success', 'Pending', 'Failure'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setWithdrawFilter(filter)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                  withdrawFilter === filter
                    ? 'bg-[#FF7700] text-white shadow-xs'
                    : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                {filter === 'ALL' ? 'All' : filter}
              </button>
            ))}
          </div>

          <div className="space-y-3">
            {filteredWithdrawFunds.length === 0 ? (
              <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200/80 dark:border-slate-800 text-center shadow-xs">
                <FileClock className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-600 dark:text-slate-400">
                  No {withdrawFilter !== 'ALL' ? withdrawFilter.toLowerCase() : ''} withdrawal records found
                </p>
              </div>
            ) : (
              filteredWithdrawFunds.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedReceipt(item)}
                  className="bg-white dark:bg-slate-900 rounded-3xl p-4 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3 cursor-pointer hover:border-orange-300 dark:hover:border-slate-700 transition-all"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-500 font-mono flex items-center gap-1.5">
                      📅 {item.date}
                    </span>
                    <span className="text-base font-black text-[#FF7700] font-mono">
                      -₹{item.amount}
                    </span>
                  </div>

                  <div className="bg-slate-50 dark:bg-slate-800/80 rounded-2xl p-3 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 font-semibold block uppercase">
                        Order Id
                      </span>
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200 font-mono">
                        {item.orderId}
                      </span>
                    </div>

                    {/* Proper status indicator */}
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 ${
                        item.status === 'Failure'
                          ? 'bg-rose-50 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400 border border-rose-200 dark:border-rose-900'
                          : item.status === 'Pending'
                          ? 'bg-amber-50 text-amber-600 dark:bg-amber-950/60 dark:text-amber-400 border border-amber-200 dark:border-amber-900'
                          : 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-900'
                      }`}
                    >
                      {item.status === 'Failure' ? (
                        <XCircle className="w-3.5 h-3.5" />
                      ) : item.status === 'Pending' ? (
                        <Clock className="w-3.5 h-3.5" />
                      ) : (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      )}
                      <span>{item.status}</span>
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-xs pt-1 text-slate-400">
                    <div>
                      <span className="text-[10px] block">Bank Name</span>
                      <span className="font-semibold text-slate-700 dark:text-slate-300 truncate block">
                        {item.bankName || 'Bank of Baroda'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] block">Account Number</span>
                      <span className="font-semibold text-slate-700 dark:text-slate-300 font-mono truncate block">
                        {item.accountNumber || '•••• 4600'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] block">IFSC Code</span>
                      <span className="font-semibold text-slate-700 dark:text-slate-300 font-mono truncate block">
                        {item.ifscCode || 'BARB0DHAKAR'}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      ) : subView === 'add_bank_details' ? (
        /* Add Bank Details matching f_005.jpg with 30-Day Restriction Notice */
        <div className="space-y-4">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setSubView(null)}
              className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <h2 className="text-base font-extrabold text-[#FF7700]">Add Bank Details</h2>
          </div>

          {/* 30-Day Restriction Notice Banner matching specifications */}
          <div className="p-4 rounded-3xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 shadow-xs space-y-2">
            <div className="flex items-center gap-2 text-amber-800 dark:text-amber-300 font-black text-xs uppercase tracking-wider">
              <ShieldAlert className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
              <span>30-Day Security Restriction Policy</span>
            </div>
            <p className="text-xs text-amber-900/90 dark:text-amber-200 leading-relaxed">
              <strong>Notice:</strong> For your account safety and fraud prevention, bank details can only be updated or added once every <strong>30 days</strong>. Please verify your Account Number and IFSC Code carefully before submitting.
            </p>
            {isBankUpdateLocked && latestBank.lockUntil && (
              <div className="p-2 rounded-xl bg-amber-100/70 dark:bg-amber-900/50 text-[11px] font-bold text-amber-950 dark:text-amber-100 flex items-center gap-1.5 font-mono">
                <Lock className="w-3.5 h-3.5 shrink-0 text-amber-700" />
                <span>Existing Bank account is locked until {latestBank.lockUntil}.</span>
              </div>
            )}
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3.5">
            {bankError && (
              <div className="p-3.5 rounded-xl bg-rose-50 text-rose-600 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{bankError}</span>
              </div>
            )}
            {bankSuccess && (
              <div className="p-3.5 rounded-xl bg-emerald-50 text-emerald-600 text-xs font-semibold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{bankSuccess}</span>
              </div>
            )}

            <div>
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                Account Holder Name
              </label>
              <input
                type="text"
                value={accountHolder}
                onChange={(e) => setAccountHolder(e.target.value)}
                placeholder={user.name ? user.name.toUpperCase() : "Account Holder Name"}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-bold outline-none focus:border-[#FF7700]"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                Bank Name
              </label>
              <input
                type="text"
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
                placeholder="e.g. State Bank of India"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-bold outline-none focus:border-[#FF7700]"
              />

              {/* Popular Banks Quick Select */}
              <div className="flex flex-wrap gap-1.5 mt-2">
                {popularBanks.map((b) => (
                  <button
                    key={b}
                    type="button"
                    onClick={() => setBankName(b)}
                    className={`text-[10px] px-2.5 py-1 rounded-lg font-medium transition-all cursor-pointer ${
                      bankName === b
                        ? 'bg-[#FF7700] text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                    }`}
                  >
                    {b}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                Account Number
              </label>
              <input
                type="text"
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                placeholder="Enter Account Number"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-bold font-mono outline-none focus:border-[#FF7700]"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                Confirm Account Number
              </label>
              <input
                type="text"
                value={confirmAccountNumber}
                onChange={(e) => setConfirmAccountNumber(e.target.value)}
                placeholder="Re-enter Account Number"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-bold font-mono outline-none focus:border-[#FF7700]"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                IFSC Code
              </label>
              <input
                type="text"
                value={ifscCode}
                onChange={(e) => setIfscCode(e.target.value.toUpperCase())}
                placeholder="e.g. SBIN0001234"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-bold font-mono uppercase outline-none focus:border-[#FF7700]"
              />
            </div>

            {/* 30-day agreement acknowledgment */}
            <label className="flex items-start gap-2.5 pt-2 cursor-pointer">
              <input
                type="checkbox"
                checked={bankAgreement}
                onChange={(e) => setBankAgreement(e.target.checked)}
                className="mt-0.5 accent-[#FF7700] w-4 h-4 cursor-pointer"
              />
              <span className="text-xs text-slate-600 dark:text-slate-400 leading-snug">
                I understand that this bank account will be locked for <strong>30 days</strong> and cannot be modified until the lock period expires.
              </span>
            </label>

            <button
              onClick={handleAddBankSubmit}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-bold text-sm shadow-md shadow-orange-500/25 active:scale-95 transition-all cursor-pointer mt-2"
            >
              Save & Lock Bank Details (30 Days)
            </button>
          </div>
        </div>
      ) : (
        /* Bank Details History matching f_010.jpg with 30-Day Restriction Notice */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setSubView(null)}
                className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <h2 className="text-base font-extrabold text-[#FF7700]">My Bank Details</h2>
            </div>
            <button
              onClick={() => setSubView('add_bank_details')}
              className="text-xs font-bold text-[#FF7700] flex items-center gap-1 hover:underline cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add New</span>
            </button>
          </div>

          {/* 30-day restriction notice banner */}
          <div className="p-4 rounded-3xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 shadow-xs space-y-2">
            <div className="flex items-center gap-2 text-amber-800 dark:text-amber-300 font-extrabold text-xs uppercase tracking-wide">
              <Lock className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
              <span>30-Day Modification Rule Active</span>
            </div>
            <p className="text-xs text-amber-900/90 dark:text-amber-200 leading-relaxed">
              As per security regulations, bank account modifications are restricted for <strong>30 days</strong> from the update date.
            </p>
            {latestBank && latestBank.lockUntil && (
              <div className="flex items-center justify-between pt-1 text-[11px] font-mono text-amber-800 dark:text-amber-300 border-t border-amber-200/60 dark:border-amber-900/40">
                <span>Last Updated: {latestBank.updatedAt}</span>
                <span className="font-bold text-amber-900 dark:text-amber-100">Locked Until: {latestBank.lockUntil}</span>
              </div>
            )}
          </div>

          <div className="space-y-3">
            {bankAccounts.length === 0 ? (
              <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200/80 dark:border-slate-800 text-center shadow-xs">
                <Building2 className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-600 dark:text-slate-400">
                  No bank accounts linked yet
                </p>
                <button
                  onClick={() => setSubView('add_bank_details')}
                  className="mt-3 px-4 py-2 rounded-xl bg-[#FF7700] text-white font-bold text-xs shadow-xs cursor-pointer"
                >
                  Add Bank Account
                </button>
              </div>
            ) : (
              bankAccounts.map((b) => (
                <div
                  key={b.id}
                  className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3 relative"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-extrabold text-sm text-slate-900 dark:text-slate-100 uppercase tracking-wide">
                        {b.accountHolder}
                      </h3>
                      <p className="text-xs font-semibold text-[#FF7700] mt-0.5">{b.bankName}</p>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {b.isDefault && (
                        <span className="px-2.5 py-0.5 rounded-full bg-orange-100 dark:bg-orange-950 text-[#FF7700] text-[10px] font-bold">
                          Default
                        </span>
                      )}
                      {/* Proper status indicator */}
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 ${
                          b.status === 'Failure'
                            ? 'bg-rose-50 text-rose-600 dark:bg-rose-950 dark:text-rose-400'
                            : b.status === 'Pending'
                            ? 'bg-amber-50 text-amber-600 dark:bg-amber-950 dark:text-amber-400'
                            : 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400'
                        }`}
                      >
                        <Check className="w-3 h-3" />
                        <span>{b.status || 'Verified'}</span>
                      </span>
                    </div>
                  </div>

                  <div className="text-xs text-slate-500 dark:text-slate-400 space-y-1 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-2xl">
                    <p className="uppercase text-[11px] font-medium">Branch: {b.branch}</p>
                    <p className="font-mono">IFSC Code : <strong className="text-slate-800 dark:text-slate-200">{b.ifscCode}</strong></p>
                    <p className="font-mono">A/c Number : <strong className="text-slate-800 dark:text-slate-200">{b.accountNumber}</strong></p>
                    <div className="pt-2 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                      <span>Updated: {b.updatedAt}</span>
                      {b.lockUntil && (
                        <span className="text-amber-600 dark:text-amber-400 flex items-center gap-1">
                          <Lock className="w-3 h-3" />
                          Lock: {b.lockUntil}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Full Receipt Modal */}
      {selectedReceipt && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-slate-100">
                Transaction Details
              </h3>
              <button
                onClick={() => setSelectedReceipt(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="text-center py-2">
              <span className="text-xs text-slate-400 block font-medium">Amount</span>
              <span className="text-3xl font-black text-[#FF7700] font-mono">
                ₹{selectedReceipt.amount}
              </span>
              <div className="mt-2">
                <span
                  className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${
                    selectedReceipt.status === 'Failure'
                      ? 'bg-rose-50 text-rose-600'
                      : selectedReceipt.status === 'Pending'
                      ? 'bg-amber-50 text-amber-600'
                      : 'bg-emerald-50 text-emerald-600'
                  }`}
                >
                  ● {selectedReceipt.status}
                </span>
              </div>
            </div>

            <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/60 p-3.5 rounded-2xl font-mono">
              <div className="flex justify-between">
                <span className="text-slate-400">Order ID:</span>
                <span className="font-bold">{selectedReceipt.orderId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Date & Time:</span>
                <span>{selectedReceipt.date}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Type:</span>
                <span>{selectedReceipt.requestType}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Payment Mode:</span>
                <span>{selectedReceipt.depositMode}</span>
              </div>
              {selectedReceipt.bankName && selectedReceipt.bankName !== 'N/A' && (
                <div className="flex justify-between">
                  <span className="text-slate-400">Bank:</span>
                  <span>{selectedReceipt.bankName}</span>
                </div>
              )}
            </div>

            <button
              onClick={() => setSelectedReceipt(null)}
              className="w-full py-3 rounded-2xl bg-slate-900 dark:bg-slate-800 text-white font-bold text-xs active:scale-95 transition-all cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
