import React, { useState } from 'react';
import { Fingerprint, Delete, Check, RotateCcw, AlertCircle, ShieldCheck, Sparkles, Smartphone, ArrowLeft } from 'lucide-react';
import { auth, signInWithPopup, GoogleAuthProvider, FirebaseUser } from '../firebase';
import { authenticateWithDeviceBiometrics } from '../utils/biometricAuth';

interface LoginScreenProps {
  onLoginSuccess: (phone?: string) => void;
  savedMpin: string;
  onUpdateMpin: (newMpin: string) => void;
  phone: string;
  onNavigateToRegister: () => void;
  onGoogleLoginSuccess?: (firebaseUser: FirebaseUser) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  onLoginSuccess,
  savedMpin,
  onUpdateMpin,
  phone,
  onNavigateToRegister,
  onGoogleLoginSuccess,
}) => {
  const [activePhone, setActivePhone] = useState<string>(phone || '');
  const [isEditingPhone, setIsEditingPhone] = useState<boolean>(!phone);
  const [enteredPin, setEnteredPin] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [isBiometricScanning, setIsBiometricScanning] = useState<boolean>(false);
  const [biometricSuccess, setBiometricSuccess] = useState<boolean>(false);
  const [showForgotModal, setShowForgotModal] = useState<boolean>(false);
  const [isGoogleSigningIn, setIsGoogleSigningIn] = useState<boolean>(false);

  // Forgot MPIN state
  const [forgotStep, setForgotStep] = useState<'phone' | 'otp' | 'newPin'>('phone');
  const [forgotPhone, setForgotPhone] = useState<string>(phone);
  const [forgotOtp, setForgotOtp] = useState<string>('');
  const [newPin, setNewPin] = useState<string>('');
  const [confirmPin, setConfirmPin] = useState<string>('');
  const [forgotError, setForgotError] = useState<string>('');

  const handleKeyPress = (num: string) => {
    if (enteredPin.length < 4) {
      const updated = enteredPin + num;
      setEnteredPin(updated);
      setErrorMessage('');
    }
  };

  const handleBackspace = () => {
    if (enteredPin.length > 0) {
      setEnteredPin(enteredPin.slice(0, -1));
      setErrorMessage('');
    }
  };

  const handleClear = () => {
    setEnteredPin('');
    setErrorMessage('');
  };

  const handleLoginSubmit = () => {
    if (activePhone.length > 0 && activePhone.length !== 10) {
      setErrorMessage('Please enter a valid 10-digit mobile number');
      return;
    }

    if (enteredPin.length !== 4) {
      setErrorMessage('Please enter complete 4-digit MPIN');
      return;
    }

    if (enteredPin === savedMpin || enteredPin === '1234') {
      onLoginSuccess(activePhone || phone);
    } else {
      setErrorMessage('Incorrect MPIN. Try "1234" or use Fingerprint.');
      // Shake effect
      const box = document.getElementById('mpin-boxes');
      if (box) {
        box.classList.add('animate-bounce');
        setTimeout(() => box.classList.remove('animate-bounce'), 600);
      }
    }
  };

  const handleBiometricAuth = async () => {
    setIsBiometricScanning(true);
    setErrorMessage('');
    try {
      const result = await authenticateWithDeviceBiometrics('Scan fingerprint to login to RAMA777');
      if (result.success) {
        setBiometricSuccess(true);
        setTimeout(() => {
          onLoginSuccess(activePhone || phone);
        }, 600);
      } else {
        setErrorMessage(result.message || 'Fingerprint verification was cancelled or failed. Please use MPIN.');
        // Shake MPIN box to assist user
        const box = document.getElementById('mpin-boxes');
        if (box) {
          box.classList.add('animate-bounce');
          setTimeout(() => box.classList.remove('animate-bounce'), 600);
        }
      }
    } catch (err: any) {
      console.warn('Biometric error:', err);
      setErrorMessage(err.message || 'Device fingerprint prompt failed. Please use MPIN: 1234');
    } finally {
      setIsBiometricScanning(false);
    }
  };

  const handleGoogleSignIn = async () => {
    if (!auth) {
      setErrorMessage('Authentication service is initializing. Please login with MPIN or Fingerprint.');
      return;
    }
    setIsGoogleSigningIn(true);
    setErrorMessage('');
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      if (result.user) {
        if (onGoogleLoginSuccess) {
          onGoogleLoginSuccess(result.user);
        } else {
          onLoginSuccess();
        }
      }
    } catch (err: any) {
      console.warn('Google sign in error:', err);
      if (err.code === 'auth/popup-closed-by-user') {
        setErrorMessage('Google sign-in popup was closed.');
      } else if (err.code === 'auth/cancelled-popup-request') {
        // Ignored
      } else {
        setErrorMessage(err.message || 'Google Sign-In failed. Use MPIN: 1234');
      }
    } finally {
      setIsGoogleSigningIn(false);
    }
  };

  // Forgot MPIN actions
  const handleSendOtp = () => {
    if (!forgotPhone || forgotPhone.length < 10) {
      setForgotError('Please enter a valid 10-digit mobile number');
      return;
    }
    setForgotError('');
    setForgotStep('otp');
    setForgotOtp('7777'); // Pre-fill mock OTP for smooth convenience
  };

  const handleVerifyOtp = () => {
    if (forgotOtp !== '7777') {
      setForgotError('Invalid OTP. Use demo OTP 7777');
      return;
    }
    setForgotError('');
    setForgotStep('newPin');
  };

  const handleSaveNewPin = () => {
    if (newPin.length !== 4) {
      setForgotError('MPIN must be 4 digits');
      return;
    }
    if (newPin !== confirmPin) {
      setForgotError('New MPIN and Confirm MPIN do not match');
      return;
    }
    onUpdateMpin(newPin);
    setEnteredPin(newPin);
    setShowForgotModal(false);
    setForgotStep('phone');
    setForgotError('');
  };

  return (
    <div className="min-h-full flex flex-col justify-between bg-[#F4F5F7] dark:bg-slate-950 text-slate-800 dark:text-slate-100 transition-colors">
      {/* Top Branding Section */}
      <div className="pt-8 pb-3 px-6 flex flex-col items-center">
        {/* Brand Logo */}
        <div className="flex items-center gap-2 mb-2">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#E65100] to-[#FF7700] flex items-center justify-center shadow-md shadow-orange-500/20">
            <span className="text-white font-extrabold text-2xl tracking-tighter">R</span>
          </div>
          <span className="text-2xl font-black tracking-tight text-[#FF7700]">RAMA777</span>
        </div>
        <h1 className="text-lg font-bold text-slate-800 dark:text-slate-100">4-digit MPIN Login</h1>
      </div>

      {/* Main Card Container */}
      <div className="px-5 w-full max-w-sm mx-auto flex-1 flex flex-col justify-center">
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-200/80 dark:border-slate-800 flex flex-col items-center">
          <p className="text-xs text-center text-slate-500 dark:text-slate-400 font-medium mb-3 leading-relaxed">
            Please enter your 4-digit MPIN to login your account
          </p>

          {/* Dynamic Mobile Account Selector / Display */}
          {activePhone && !isEditingPhone ? (
            <div className="flex items-center justify-between w-full bg-slate-50 dark:bg-slate-800/70 rounded-2xl px-3.5 py-2 border border-slate-200/80 dark:border-slate-700/80 mb-4">
              <div className="flex items-center gap-2">
                <Smartphone className="w-3.5 h-3.5 text-[#FF7700]" />
                <span className="text-xs font-bold font-mono text-slate-800 dark:text-slate-200">
                  +91 {activePhone}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsEditingPhone(true)}
                className="text-[11px] font-bold text-[#FF7700] hover:underline cursor-pointer"
              >
                Switch Account
              </button>
            </div>
          ) : (
            <div className="w-full mb-4">
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10.5px] font-bold text-slate-500 uppercase tracking-wider">
                  Mobile Number
                </label>
                {activePhone && (
                  <button
                    type="button"
                    onClick={() => setIsEditingPhone(false)}
                    className="text-[10px] font-bold text-slate-400 hover:text-slate-600"
                  >
                    Cancel
                  </button>
                )}
              </div>
              <div className="relative flex items-center">
                <span className="absolute left-3 text-xs font-bold text-slate-400 font-mono">+91</span>
                <input
                  type="tel"
                  maxLength={10}
                  value={activePhone}
                  onChange={(e) => setActivePhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                  placeholder="Enter 10-digit mobile"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pl-11 pr-3 py-2 text-xs font-bold font-mono outline-none focus:border-[#FF7700]"
                />
              </div>
            </div>
          )}

          {/* 4 Distinct Circular / Rounded Input Boxes */}
          <div id="mpin-boxes" className="flex items-center justify-center gap-3.5 mb-4">
            {[0, 1, 2, 3].map((idx) => {
              const isFilled = enteredPin.length > idx;
              const isCurrent = enteredPin.length === idx;
              return (
                <div
                  key={idx}
                  className={`w-13 h-13 rounded-2xl flex items-center justify-center border-2 transition-all duration-200 ${
                    isFilled
                      ? 'border-[#FF7700] bg-orange-50/40 dark:bg-orange-950/20 shadow-sm'
                      : isCurrent
                      ? 'border-[#FF7700] shadow-sm bg-white dark:bg-slate-800'
                      : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/60'
                  }`}
                >
                  {isFilled ? (
                    <div className="w-3.5 h-3.5 rounded-full bg-slate-900 dark:bg-slate-100 transition-all scale-100" />
                  ) : isCurrent ? (
                    <div className="w-0.5 h-6 bg-[#FF7700] animate-pulse" />
                  ) : null}
                </div>
              );
            })}
          </div>

          {/* Error message */}
          {errorMessage ? (
            <div className="flex items-center gap-1.5 text-xs text-rose-500 font-medium mb-3">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          ) : (
            <div className="h-5 mb-1" />
          )}

          {/* Forgot MPIN Button */}
          <button
            onClick={() => {
              setForgotStep('phone');
              setShowForgotModal(true);
            }}
            className="text-xs font-semibold text-[#FF7700] hover:text-orange-600 dark:hover:text-orange-400 transition-colors mb-5 cursor-pointer py-1 px-3"
          >
            Forgot MPIN?
          </button>

          {/* Login Button */}
          <button
            onClick={handleLoginSubmit}
            disabled={enteredPin.length < 4}
            className={`w-full py-3.5 rounded-2xl font-semibold text-sm transition-all duration-200 shadow-md ${
              enteredPin.length === 4
                ? 'bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white shadow-orange-500/25 active:scale-[0.98] cursor-pointer'
                : 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-500 shadow-none cursor-not-allowed'
            }`}
          >
            Login
          </button>

          {/* Divider */}
          <div className="flex items-center gap-2 my-3 w-full">
            <div className="flex-1 h-px bg-slate-200 dark:bg-slate-800" />
            <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">or</span>
            <div className="flex-1 h-px bg-slate-200 dark:bg-slate-800" />
          </div>

          {/* Google Sign-in with Firebase Auth */}
          <button
            type="button"
            onClick={handleGoogleSignIn}
            disabled={isGoogleSigningIn}
            className="w-full py-2.5 px-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center justify-center gap-2 shadow-xs hover:border-[#FF7700] active:scale-[0.98] transition-all cursor-pointer"
          >
            <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
            </svg>
            {isGoogleSigningIn ? 'Signing in with Google...' : 'Continue with Google'}
          </button>
        </div>

        {/* Demo Helper Callout & New Registration Link */}
        <div className="mt-3 text-center space-y-2">
          <p className="text-[11px] text-slate-400 dark:text-slate-500">
            Default Demo MPIN: <span className="font-semibold text-slate-600 dark:text-slate-300">1234</span> or use Biometric
          </p>

          <div className="pt-1">
            <button
              onClick={onNavigateToRegister}
              className="text-xs font-bold text-[#FF7700] hover:text-orange-600 dark:hover:text-orange-400 underline decoration-2 underline-offset-4 cursor-pointer active:scale-95 transition-all"
            >
              New user? Register & Setup MPIN →
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Section: Biometric Fingerprint & Numeric Keypad */}
      <div className="w-full max-w-sm mx-auto px-4 pb-4 mt-2">
        {/* Biometric Scanning Feedback / Trigger */}
        <div className="flex flex-col items-center justify-center mb-3">
          <button
            onClick={handleBiometricAuth}
            disabled={isBiometricScanning}
            className="group relative flex flex-col items-center justify-center p-2 rounded-2xl active:scale-95 transition-transform cursor-pointer"
            title="Authenticate with Fingerprint"
          >
            <div
              className={`w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 ${
                biometricSuccess
                  ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30'
                  : isBiometricScanning
                  ? 'bg-orange-500 text-white animate-pulse-ring'
                  : errorMessage
                  ? 'bg-white dark:bg-slate-800 text-rose-500 dark:text-rose-400 border-2 border-rose-400/80 dark:border-rose-500/80 shadow-sm'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 shadow-sm hover:border-[#FF7700] hover:text-[#FF7700]'
              }`}
            >
              {biometricSuccess ? (
                <ShieldCheck className="w-7 h-7" />
              ) : (
                <Fingerprint className={`w-7 h-7 ${isBiometricScanning ? 'animate-pulse' : ''}`} />
              )}
            </div>
            <span
              className={`text-[10px] font-semibold mt-1 transition-colors text-center px-2 ${
                biometricSuccess
                  ? 'text-emerald-500'
                  : isBiometricScanning
                  ? 'text-orange-500 animate-pulse'
                  : errorMessage
                  ? 'text-rose-500 dark:text-rose-400 font-bold'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              {biometricSuccess
                ? 'Authenticated Successfully!'
                : isBiometricScanning
                ? 'Waiting for hardware fingerprint scan...'
                : errorMessage
                ? 'Sensor unverified • Please enter 4-digit MPIN'
                : 'Touch sensor for Hardware Fingerprint'}
            </span>
          </button>
        </div>

        {/* Custom Numeric Keypad */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-2.5 shadow-sm border border-slate-200/80 dark:border-slate-800">
          <div className="grid grid-cols-3 gap-1.5">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((digit) => (
              <button
                key={digit}
                onClick={() => handleKeyPress(digit.toString())}
                className="h-12 rounded-xl bg-slate-50 hover:bg-orange-50 dark:bg-slate-800/80 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-100 text-lg font-bold flex items-center justify-center active:scale-95 transition-all shadow-xs"
              >
                {digit}
              </button>
            ))}

            {/* Clear Key */}
            <button
              onClick={handleClear}
              className="h-12 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs font-bold tracking-wide uppercase flex items-center justify-center active:scale-95 transition-all"
            >
              Clear
            </button>

            {/* 0 Key */}
            <button
              onClick={() => handleKeyPress('0')}
              className="h-12 rounded-xl bg-slate-50 hover:bg-orange-50 dark:bg-slate-800/80 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-100 text-lg font-bold flex items-center justify-center active:scale-95 transition-all shadow-xs"
            >
              0
            </button>

            {/* Backspace Key */}
            <button
              onClick={handleBackspace}
              className="h-12 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 flex items-center justify-center active:scale-95 transition-all"
            >
              <Delete className="w-5 h-5" />
            </button>
          </div>

          {/* Done / Enter Row */}
          <div className="mt-1.5">
            <button
              onClick={handleLoginSubmit}
              className="w-full h-11 rounded-xl bg-slate-800 hover:bg-slate-900 dark:bg-slate-700 dark:hover:bg-slate-600 text-white font-semibold text-xs flex items-center justify-center gap-1.5 active:scale-[0.98] transition-all cursor-pointer"
            >
              <Check className="w-4 h-4 text-emerald-400" />
              <span>Done</span>
            </button>
          </div>
        </div>
      </div>

      {/* Forgot MPIN Modal */}
      {showForgotModal && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-orange-100 dark:bg-orange-950 flex items-center justify-center text-[#FF7700]">
                  <RotateCcw className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-slate-900 dark:text-slate-100 text-base">Reset 4-digit MPIN</h3>
              </div>
              <button
                onClick={() => setShowForgotModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-sm font-semibold"
              >
                ✕
              </button>
            </div>

            {forgotError && (
              <div className="mb-3 p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 text-xs flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{forgotError}</span>
              </div>
            )}

            {forgotStep === 'phone' && (
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
                  Enter your registered 10-digit mobile number to receive a verification OTP.
                </p>
                <div className="mb-4">
                  <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
                    Mobile Number
                  </label>
                  <div className="flex items-center border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2.5 bg-slate-50 dark:bg-slate-800">
                    <span className="text-xs font-bold text-slate-400 mr-2">+91</span>
                    <input
                      type="tel"
                      value={forgotPhone}
                      onChange={(e) => setForgotPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                      placeholder="6377972674"
                      className="bg-transparent text-sm font-semibold outline-none w-full"
                    />
                  </div>
                </div>
                <button
                  onClick={handleSendOtp}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-semibold text-xs active:scale-95 transition-all"
                >
                  Send Verification OTP
                </button>
              </div>
            )}

            {forgotStep === 'otp' && (
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
                  We sent a 4-digit OTP to +91 {forgotPhone}. Enter demo OTP <span className="font-bold text-orange-500">7777</span>.
                </p>
                <div className="mb-4">
                  <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
                    Enter OTP
                  </label>
                  <input
                    type="text"
                    maxLength={4}
                    value={forgotOtp}
                    onChange={(e) => setForgotOtp(e.target.value.replace(/\D/g, ''))}
                    placeholder="7777"
                    className="w-full border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2.5 bg-slate-50 dark:bg-slate-800 text-center text-lg font-bold tracking-widest outline-none focus:border-[#FF7700]"
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setForgotStep('phone')}
                    className="flex-1 py-3 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold text-xs"
                  >
                    Back
                  </button>
                  <button
                    onClick={handleVerifyOtp}
                    className="flex-1 py-3 rounded-xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-semibold text-xs active:scale-95 transition-all"
                  >
                    Verify OTP
                  </button>
                </div>
              </div>
            )}

            {forgotStep === 'newPin' && (
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
                  Enter your new 4-digit MPIN for RAMA777.
                </p>
                <div className="space-y-3 mb-4">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
                      New 4-digit MPIN
                    </label>
                    <input
                      type="password"
                      maxLength={4}
                      value={newPin}
                      onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ''))}
                      placeholder="****"
                      className="w-full border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2.5 bg-slate-50 dark:bg-slate-800 text-center text-lg font-bold tracking-widest outline-none focus:border-[#FF7700]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
                      Confirm New MPIN
                    </label>
                    <input
                      type="password"
                      maxLength={4}
                      value={confirmPin}
                      onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, ''))}
                      placeholder="****"
                      className="w-full border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2.5 bg-slate-50 dark:bg-slate-800 text-center text-lg font-bold tracking-widest outline-none focus:border-[#FF7700]"
                    />
                  </div>
                </div>
                <button
                  onClick={handleSaveNewPin}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-semibold text-xs active:scale-95 transition-all"
                >
                  Update & Save MPIN
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
