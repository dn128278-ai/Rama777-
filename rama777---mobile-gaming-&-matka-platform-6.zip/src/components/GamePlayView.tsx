import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  ArrowLeft,
  ChevronRight,
  ChevronDown,
  X,
  Trash2,
  Calendar,
  Wallet,
  Circle,
  Grid3X3,
  GitCommit,
  MoreHorizontal,
  Layers,
  Copy,
  Boxes,
  Split,
  Sparkles,
  Gauge,
  Target,
  Code,
  Users,
  Scale,
  CheckCircle2,
  AlertCircle,
  Zap,
} from 'lucide-react';
import { MarketItem, GameBid } from '../types';
import { formatMarketResult } from '../utils/marketEngine';
import {
  SINGLE_DIGITS,
  JODI_DIGITS,
  ODD_DIGITS,
  EVEN_DIGITS,
  RED_BRACKETS,
  QUICK_AMOUNT_CHIPS,
  SINGLE_PANAS_BY_SUM,
  DOUBLE_PANAS_BY_SUM,
  TRIPLE_PANAS,
  ALL_SINGLE_PANAS,
  ALL_DOUBLE_PANAS,
  getMatchingSinglePanas,
  getMatchingDoublePanas,
  getMatchingTriplePanas,
  generateSpMotor,
  generateDpMotor,
  generateGroupJodi,
} from '../utils/matkaNumbers';

interface GamePlayViewProps {
  market: MarketItem;
  walletBalance: number;
  onBack: () => void;
  onPlaceBid: (bid: Omit<GameBid, 'id' | 'date' | 'status'> | Omit<GameBid, 'id' | 'date' | 'status'>[]) => boolean;
  onRegisterBackHandler?: (handler: (() => boolean) | null) => void;
}

interface TableBidItem {
  id: string;
  number: string;
  points: number;
  session: 'Open' | 'Close';
  gameType: string;
}

export const GamePlayView: React.FC<GamePlayViewProps> = ({
  market,
  walletBalance,
  onBack,
  onPlaceBid,
  onRegisterBackHandler,
}) => {
  // Navigation: selected game mode (null = show 2-column game menu)
  const [selectedGameId, setSelectedGameId] = useState<string | null>(null);
  const selectedGameIdRef = useRef<string | null>(selectedGameId);

  useEffect(() => {
    selectedGameIdRef.current = selectedGameId;
  }, [selectedGameId]);

  // Handle entering a specific game mode
  const handleSelectGameMode = (gameId: string) => {
    setSelectedGameId(gameId);
  };

  // Register nested hardware back button handler with App.tsx
  useEffect(() => {
    if (onRegisterBackHandler) {
      if (selectedGameId) {
        onRegisterBackHandler(() => {
          setSelectedGameId(null);
          return true;
        });
      } else {
        onRegisterBackHandler(null);
      }
    }
  }, [selectedGameId, onRegisterBackHandler]);

  useEffect(() => {
    return () => {
      onRegisterBackHandler?.(null);
    };
  }, [onRegisterBackHandler]);

  // Top header back button action
  const handleHeaderBack = () => {
    if (selectedGameId) {
      setSelectedGameId(null);
    } else {
      onBack();
    }
  };

  // Tab mode toggle: 'EASY MODE' vs 'SPECIAL MODE'
  const [activeTabMode, setActiveTabMode] = useState<'EASY' | 'SPECIAL'>('EASY');

  // Market session state
  const isOpenSessionDisabled =
    market.allowedSession === 'close_only' || market.status === 'Running for Close';
  const isMarketClosed = market.status === 'Closed for Today' || !market.isOpen;

  const [session, setSession] = useState<'Open' | 'Close'>(
    isOpenSessionDisabled ? 'Close' : 'Open'
  );

  // Auto-switch to Close when Open session declares/closes and cleanly reset open-only temporary bids
  useEffect(() => {
    if (isOpenSessionDisabled && session === 'Open') {
      setSession('Close');
      setBidsTable((prev) => {
        const hasOpenOnly = prev.some(
          (b) => b.session === 'Open' && b.gameType !== 'JODI DIGIT' && b.gameType !== 'RED BRACKETS'
        );
        if (hasOpenOnly) {
          return prev.filter(
            (b) => b.session !== 'Open' || b.gameType === 'JODI DIGIT' || b.gameType === 'RED BRACKETS'
          );
        }
        return prev;
      });
      // Clear easy mode inputs and pana suggestions
      setEasyNumberInput('');
      setEasyPointsInput('');
      setPanaSuggestions([]);
      setShowPanaSuggestions(false);
      setBulkNumberInput('');
    }
  }, [isOpenSessionDisabled, session]);

  // Automated reset when market completes/closes for the day
  useEffect(() => {
    if (isMarketClosed) {
      setBidsTable([]);
      setSpecialGridInputs({});
      setEasyNumberInput('');
      setEasyPointsInput('');
      setPanaSuggestions([]);
      setShowPanaSuggestions(false);
      setBulkNumberInput('');
      setSangamOpenPana('');
      setSangamCloseDigit('');
      setSangamOpenDigit('');
      setSangamClosePana('');
      setSangamPoints('');
      setGroupJodiInput('');
      setMotorDigitsInput('');
    }
  }, [isMarketClosed]);

  // Modal states
  const [showSessionModal, setShowSessionModal] = useState<boolean>(false);
  const [showInsufficientBalanceModal, setShowInsufficientBalanceModal] = useState<boolean>(false);
  const [showSuccessModal, setShowSuccessModal] = useState<boolean>(false);
  const [successDetails, setSuccessDetails] = useState<{ count: number; totalPoints: number } | null>(null);
  const [errorMessage, setErrorMessage] = useState<string>('');

  // 1. Easy Mode inputs
  const [easyNumberInput, setEasyNumberInput] = useState<string>('');
  const [easyPointsInput, setEasyPointsInput] = useState<string>('');
  const numberInputRef = useRef<HTMLInputElement>(null);
  const pointsInputRef = useRef<HTMLInputElement>(null);
  const groupJodiPointsRef = useRef<HTMLInputElement>(null);
  const motorPointsRef = useRef<HTMLInputElement>(null);

  // Suggestions for single/double/triple pana in Easy Mode
  const [panaSuggestions, setPanaSuggestions] = useState<string[]>([]);
  const [showPanaSuggestions, setShowPanaSuggestions] = useState<boolean>(false);

  // 2. Special Mode direct grid inputs: { [numberStr]: pointsStr }
  const [specialGridInputs, setSpecialGridInputs] = useState<Record<string, string>>({});

  // 3. Jodi Grid filter by decade ('all', '0-9', '10-19', etc.)
  const [jodiDecadeFilter, setJodiDecadeFilter] = useState<string>('all');

  // 4. Bulk Mode preset points & input
  const [bulkPointsInput, setBulkPointsInput] = useState<string>('20');
  const [bulkNumberInput, setBulkNumberInput] = useState<string>('');

  // 5. Unified Interactive Bid Slip Table
  const [bidsTable, setBidsTable] = useState<TableBidItem[]>([]);

  // 6. Sangam inputs
  const [sangamOpenPana, setSangamOpenPana] = useState<string>('');
  const [sangamCloseDigit, setSangamCloseDigit] = useState<string>('');
  const [sangamClosePana, setSangamClosePana] = useState<string>('');
  const [sangamOpenDigit, setSangamOpenDigit] = useState<string>('');
  const [sangamPoints, setSangamPoints] = useState<string>('');

  // 7. Special & Motors specific states
  const [groupJodiInput, setGroupJodiInput] = useState<string>('');
  const [motorDigitsInput, setMotorDigitsInput] = useState<string>('');
  const [redBracketPresetPoints, setRedBracketPresetPoints] = useState<string>('50');

  // Today's formatted date (DD-MM-YYYY)
  const todayFormatted = useMemo(() => {
    const now = new Date();
    const d = now.getDate().toString().padStart(2, '0');
    const m = (now.getMonth() + 1).toString().padStart(2, '0');
    const y = now.getFullYear();
    return `${d}-${m}-${y}`;
  }, []);

  // Full catalog of 17 game types matching the authentic mobile platform layout
  const gameCategories = [
    { id: 'single_digit', label: 'Single Digit', isBulk: false, icon: Circle },
    { id: 'single_digit_bulk', label: 'Single Digit Bulk', isBulk: true, icon: Grid3X3 },
    { id: 'jodi_digit', label: 'Jodi Digits', isBulk: false, icon: GitCommit },
    { id: 'jodi_digit_bulk', label: 'Jodi Digits Bulk', isBulk: true, icon: MoreHorizontal },
    { id: 'single_pana', label: 'Single Pana', isBulk: false, icon: Layers },
    { id: 'single_pana_bulk', label: 'Single Pana Bulk', isBulk: true, icon: Layers },
    { id: 'double_pana', label: 'Double Pana', isBulk: false, icon: Copy },
    { id: 'double_pana_bulk', label: 'Double Pana Bulk', isBulk: true, icon: Copy },
    { id: 'triple_pana', label: 'Triple Pana', isBulk: false, icon: Boxes },
    { id: 'triple_pana_bulk', label: 'Triple Pana Bulk', isBulk: true, icon: Boxes },
    { id: 'half_sangam', label: 'Half Sangam', isBulk: false, icon: Split },
    { id: 'full_sangam', label: 'Full Sangam', isBulk: false, icon: Sparkles },
    { id: 'sp_motor', label: 'SP Motor', isBulk: false, icon: Gauge },
    { id: 'dp_motor', label: 'DP Motor', isBulk: false, icon: Target },
    { id: 'red_brackets', label: 'Red Brackets', isBulk: false, icon: Code },
    { id: 'group_jodi', label: 'Group Jodi', isBulk: false, icon: Users },
    { id: 'odd_even', label: 'Odd Even', isBulk: false, icon: Scale },
  ];

  const currentGame = gameCategories.find((g) => g.id === selectedGameId);

  // Clear sub-inputs when changing game or mode & auto-focus
  useEffect(() => {
    setEasyNumberInput('');
    setEasyPointsInput('');
    setSpecialGridInputs({});
    setBidsTable([]);
    setErrorMessage('');
    setShowPanaSuggestions(false);
    setGroupJodiInput('');
    setMotorDigitsInput('');
    if (selectedGameId && activeTabMode === 'EASY') {
      const timer = setTimeout(() => {
        numberInputRef.current?.focus();
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [selectedGameId, activeTabMode]);

  // Validation feedback helper for 3-digit panas in Easy Mode
  const panaValidationStatus = useMemo(() => {
    if (!easyNumberInput || easyNumberInput.length !== 3) return null;
    if (selectedGameId === 'single_pana') {
      const isValid = ALL_SINGLE_PANAS.includes(easyNumberInput);
      return {
        isValid,
        text: isValid ? '✓ Valid Single Pana' : '✕ Invalid Single Pana (must have 3 unique sorted digits)',
      };
    }
    if (selectedGameId === 'double_pana') {
      const isValid = ALL_DOUBLE_PANAS.includes(easyNumberInput);
      return {
        isValid,
        text: isValid ? '✓ Valid Double Pana' : '✕ Invalid Double Pana (must contain 2 identical digits)',
      };
    }
    if (selectedGameId === 'triple_pana') {
      const isValid = TRIPLE_PANAS.includes(easyNumberInput);
      return {
        isValid,
        text: isValid ? '✓ Valid Triple Pana' : '✕ Invalid Triple Pana (e.g. 000, 111, 222)',
      };
    }
    return null;
  }, [easyNumberInput, selectedGameId]);

  // Autocomplete suggestions handler with auto-focus shift on completed input
  const handlePanaInputChange = (val: string) => {
    const maxDigits =
      selectedGameId === 'single_digit' ? 1 : selectedGameId === 'jodi_digit' ? 2 : 3;
    const clean = val.replace(/\D/g, '').slice(0, maxDigits);
    setEasyNumberInput(clean);
    if (!clean) {
      setPanaSuggestions([]);
      setShowPanaSuggestions(false);
      return;
    }

    if (selectedGameId === 'single_pana') {
      const matches = getMatchingSinglePanas(clean);
      setPanaSuggestions(matches);
      setShowPanaSuggestions(matches.length > 0 && clean.length < 3);
    } else if (selectedGameId === 'double_pana') {
      const matches = getMatchingDoublePanas(clean);
      setPanaSuggestions(matches);
      setShowPanaSuggestions(matches.length > 0 && clean.length < 3);
    } else if (selectedGameId === 'triple_pana') {
      const matches = getMatchingTriplePanas(clean);
      setPanaSuggestions(matches);
      setShowPanaSuggestions(matches.length > 0 && clean.length < 3);
    }

    // Auto-focus shift to Points when user finishes entering required digits
    if (clean.length === maxDigits) {
      setTimeout(() => {
        pointsInputRef.current?.focus();
      }, 50);
    }
  };

  // Quick Amount helper for single digit / easy mode
  const applyQuickAmountToEasy = (amount: number) => {
    const current = parseInt(easyPointsInput || '0', 10);
    setEasyPointsInput((current + amount).toString());
    setErrorMessage('');
    setTimeout(() => {
      pointsInputRef.current?.focus();
    }, 40);
  };

  // Quick Amount addition to a specific grid box in Special Mode
  const handleQuickAddGridPoints = (numKey: string, amount: number) => {
    const current = parseInt(specialGridInputs[numKey] || '0', 10);
    const updatedVal = (current + amount).toString();
    setSpecialGridInputs((prev) => ({
      ...prev,
      [numKey]: updatedVal,
    }));
    setErrorMessage('');
  };

  // Special Mode direct grid point change
  const handleSpecialGridChange = (num: string, val: string) => {
    const clean = val.replace(/\D/g, '');
    setSpecialGridInputs((prev) => ({
      ...prev,
      [num]: clean,
    }));
    setErrorMessage('');
  };

  // Easy mode: Add single bid to table
  const handleAddEasyBid = () => {
    setErrorMessage('');
    if (isMarketClosed) {
      setErrorMessage(`Market is closed for today.`);
      return;
    }

    const num = easyNumberInput.trim();
    const pts = parseInt(easyPointsInput, 10);

    if (!num) {
      setErrorMessage('Please enter valid number/digit');
      return;
    }

    if (isNaN(pts) || pts <= 0) {
      setErrorMessage('Please enter valid points');
      return;
    }

    // Validation per game type
    if (selectedGameId === 'single_digit' && !SINGLE_DIGITS.includes(num)) {
      setErrorMessage('Single Digit must be 0-9');
      return;
    }

    if (selectedGameId === 'jodi_digit') {
      if (num.length !== 2 || isNaN(Number(num))) {
        setErrorMessage('Jodi must be 2 digits (00-99)');
        return;
      }
    }

    if (selectedGameId === 'single_pana' && !ALL_SINGLE_PANAS.includes(num)) {
      setErrorMessage('Invalid Single Pana number');
      return;
    }

    if (selectedGameId === 'double_pana' && !ALL_DOUBLE_PANAS.includes(num)) {
      setErrorMessage('Invalid Double Pana number');
      return;
    }

    if (selectedGameId === 'triple_pana' && !TRIPLE_PANAS.includes(num)) {
      setErrorMessage('Invalid Triple Pana number');
      return;
    }

    const newBidItem: TableBidItem = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      number: num,
      points: pts,
      session: selectedGameId === 'jodi_digit' || selectedGameId?.includes('sangam') ? 'Open' : session,
      gameType: currentGame?.label || 'BET',
    };

    setBidsTable((prev) => [newBidItem, ...prev]);
    setEasyNumberInput('');
    setEasyPointsInput('');
    setShowPanaSuggestions(false);
    setTimeout(() => {
      numberInputRef.current?.focus();
    }, 50);
  };

  // 1-Tap Odd / Even Batch Bets
  const handleAddOddEvenBatch = (choice: 'odd' | 'even') => {
    setErrorMessage('');
    const pts = parseInt(easyPointsInput, 10);
    if (isNaN(pts) || pts <= 0) {
      setErrorMessage('Please enter points per digit first');
      return;
    }

    const digits = choice === 'odd' ? ODD_DIGITS : EVEN_DIGITS;
    const items: TableBidItem[] = digits.map((d) => ({
      id: `${Date.now()}-${d}`,
      number: d,
      points: pts,
      session,
      gameType: `ODD EVEN (${choice.toUpperCase()})`,
    }));

    setBidsTable((prev) => [...items, ...prev]);
  };

  // 20 Red Brackets 1-Tap Batch Bet
  const handleAddRedBracketsBatch = () => {
    setErrorMessage('');
    const pts = parseInt(redBracketPresetPoints, 10);
    if (isNaN(pts) || pts <= 0) {
      setErrorMessage('Please enter valid points per red bracket');
      return;
    }

    const items: TableBidItem[] = RED_BRACKETS.map((pair) => ({
      id: `${Date.now()}-${pair}`,
      number: pair,
      points: pts,
      session: 'Open',
      gameType: 'RED BRACKETS',
    }));

    setBidsTable((prev) => [...items, ...prev]);
  };

  // Group Jodi generator
  const handleAddGroupJodiBatch = () => {
    setErrorMessage('');
    const pts = parseInt(easyPointsInput, 10);
    if (isNaN(pts) || pts <= 0) {
      setErrorMessage('Please enter valid points first');
      return;
    }
    const family = generateGroupJodi(groupJodiInput);
    if (family.length === 0) {
      setErrorMessage('Enter valid 2-digit Jodi (e.g. 12)');
      return;
    }

    const items: TableBidItem[] = family.map((j) => ({
      id: `${Date.now()}-${j}`,
      number: j,
      points: pts,
      session: 'Open',
      gameType: `GROUP JODI (${groupJodiInput})`,
    }));

    setBidsTable((prev) => [...items, ...prev]);
    setGroupJodiInput('');
  };

  // Motor Generator Add
  const handleAddMotorBids = (isDp: boolean) => {
    setErrorMessage('');
    const pts = parseInt(easyPointsInput, 10);
    if (isNaN(pts) || pts <= 0) {
      setErrorMessage('Please enter points per pana');
      return;
    }

    const generated = isDp ? generateDpMotor(motorDigitsInput) : generateSpMotor(motorDigitsInput);
    if (generated.length === 0) {
      setErrorMessage(isDp ? 'Enter at least 2 unique digits for DP Motor' : 'Enter at least 3 unique digits for SP Motor');
      return;
    }

    const items: TableBidItem[] = generated.map((p) => ({
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 5)}-${p}`,
      number: p,
      points: pts,
      session,
      gameType: isDp ? 'DP MOTOR' : 'SP MOTOR',
    }));

    setBidsTable((prev) => [...items, ...prev]);
    setMotorDigitsInput('');
  };

  // Sangam Add
  const handleAddSangamBid = (type: 'half_a' | 'half_b' | 'full') => {
    setErrorMessage('');
    const pts = parseInt(sangamPoints, 10);
    if (isNaN(pts) || pts <= 0) {
      setErrorMessage('Please enter valid points');
      return;
    }

    let numStr = '';
    if (type === 'half_a') {
      if (sangamOpenPana.length !== 3 || sangamCloseDigit.length !== 1) {
        setErrorMessage('Enter 3-digit Open Pana and 1-digit Close Ank');
        return;
      }
      numStr = `${sangamOpenPana} × ${sangamCloseDigit}`;
    } else if (type === 'half_b') {
      if (sangamOpenDigit.length !== 1 || sangamClosePana.length !== 3) {
        setErrorMessage('Enter 1-digit Open Ank and 3-digit Close Pana');
        return;
      }
      numStr = `${sangamOpenDigit} × ${sangamClosePana}`;
    } else {
      if (sangamOpenPana.length !== 3 || sangamClosePana.length !== 3) {
        setErrorMessage('Enter 3-digit Open Pana and 3-digit Close Pana');
        return;
      }
      numStr = `${sangamOpenPana} × ${sangamClosePana}`;
    }

    const newBidItem: TableBidItem = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      number: numStr,
      points: pts,
      session: 'Open',
      gameType: type === 'full' ? 'FULL SANGAM' : 'HALF SANGAM',
    };

    setBidsTable((prev) => [newBidItem, ...prev]);
    setSangamOpenPana('');
    setSangamCloseDigit('');
    setSangamOpenDigit('');
    setSangamClosePana('');
    setSangamPoints('');
  };

  // Bulk Mode keypad tap (Single Digit Bulk / Single Pana Bulk / Double Pana Bulk)
  const handleBulkDigitTap = (digitStr: string) => {
    const pts = parseInt(bulkPointsInput, 10);
    if (isNaN(pts) || pts <= 0) {
      setErrorMessage('Please enter points first');
      return;
    }
    setErrorMessage('');

    const digitNum = parseInt(digitStr, 10);

    if (selectedGameId === 'single_digit_bulk') {
      const newItem: TableBidItem = {
        id: `${Date.now()}-${digitStr}`,
        number: digitStr,
        points: pts,
        session,
        gameType: 'SINGLE DIGIT BULK',
      };
      setBidsTable((prev) => [newItem, ...prev]);
    } else if (selectedGameId === 'single_pana_bulk') {
      const panas = SINGLE_PANAS_BY_SUM[digitNum] || [];
      const newItems: TableBidItem[] = panas.map((p) => ({
        id: `${Date.now()}-${p}`,
        number: p,
        points: pts,
        session,
        gameType: 'SINGLE PANA BULK',
      }));
      setBidsTable((prev) => [...newItems, ...prev]);
    } else if (selectedGameId === 'double_pana_bulk') {
      const panas = DOUBLE_PANAS_BY_SUM[digitNum] || [];
      const newItems: TableBidItem[] = panas.map((p) => ({
        id: `${Date.now()}-${p}`,
        number: p,
        points: pts,
        session,
        gameType: 'DOUBLE PANA BULK',
      }));
      setBidsTable((prev) => [...newItems, ...prev]);
    }
  };

  // Bulk Jodi Digit typing (Frame 16: auto adds when 2 digits typed)
  const handleBulkJodiDigitInput = (val: string) => {
    const clean = val.replace(/\D/g, '').slice(0, 2);
    setBulkNumberInput(clean);
    if (clean.length === 2) {
      const pts = parseInt(bulkPointsInput, 10);
      if (isNaN(pts) || pts <= 0) {
        setErrorMessage('Please enter valid points first');
        return;
      }
      const newItem: TableBidItem = {
        id: `${Date.now()}-${clean}`,
        number: clean,
        points: pts,
        session: 'Open',
        gameType: 'JODI BULK',
      };
      setBidsTable((prev) => [newItem, ...prev]);
      setBulkNumberInput('');
    }
  };

  // Synthesize all active bids into a unified list
  // Combines explicitly added bidsTable items + active specialGridInputs!
  const allActiveBids: TableBidItem[] = useMemo(() => {
    const list: TableBidItem[] = [...bidsTable];

    if (activeTabMode === 'SPECIAL' && !currentGame?.isBulk) {
      for (const [num, ptsStr] of Object.entries(specialGridInputs)) {
        const pts = parseInt(ptsStr, 10);
        if (pts > 0) {
          list.push({
            id: `grid-${num}`,
            number: num,
            points: pts,
            session: selectedGameId === 'jodi_digit' || selectedGameId === 'red_brackets' ? 'Open' : session,
            gameType: currentGame?.label.toUpperCase() || 'SPECIAL BID',
          });
        }
      }
    }

    return list;
  }, [bidsTable, activeTabMode, currentGame, specialGridInputs, selectedGameId, session]);

  // Calculate live summary: Total Bids Count and Total Points Sum
  const { currentTotalBids, currentTotalPoints } = useMemo(() => {
    const count = allActiveBids.length;
    const pts = allActiveBids.reduce((acc, b) => acc + b.points, 0);
    return { currentTotalBids: count, currentTotalPoints: pts };
  }, [allActiveBids]);

  // Delete bid handler for interactive slip table
  const handleDeleteBid = (bid: TableBidItem) => {
    if (bid.id.startsWith('grid-')) {
      const num = bid.id.replace('grid-', '');
      setSpecialGridInputs((prev) => {
        const copy = { ...prev };
        delete copy[num];
        return copy;
      });
    } else {
      setBidsTable((prev) => prev.filter((b) => b.id !== bid.id));
    }
  };

  // Clear all bids in current slip
  const handleClearAllBids = () => {
    setBidsTable([]);
    setSpecialGridInputs({});
  };

  // Master Submission Handler with strict wallet balance verification
  const handleSubmitAllBids = () => {
    setErrorMessage('');

    if (isMarketClosed) {
      setErrorMessage(`This market is closed for today. Bidding will resume tomorrow at ${market.openTime}.`);
      return;
    }

    if (isOpenSessionDisabled && session === 'Open' && selectedGameId !== 'jodi_digit' && selectedGameId !== 'red_brackets') {
      setErrorMessage('Open session is already closed for this market. Please select Close session.');
      return;
    }

    if (currentTotalPoints <= 0) {
      setErrorMessage('Please enter bid points for at least one number.');
      return;
    }

    // STRICT WALLET BALANCE VERIFICATION
    // If total points exceed wallet balance, pop up error alert modal stating
    // "Insufficient Balance in wallet" with an "OK" button, preventing submission until sufficient funds are available!
    if (currentTotalPoints > walletBalance) {
      setShowInsufficientBalanceModal(true);
      return;
    }

    // Place all bids atomically as a complete batch
    const bidsToSubmit = allActiveBids.map((bid) => ({
      marketName: market.name,
      gameType: bid.gameType,
      session: bid.session,
      digitOrPana: bid.number,
      points: bid.points,
    }));

    const success = onPlaceBid(bidsToSubmit);
    if (!success) {
      setErrorMessage('Insufficient wallet balance or error submitting bids.');
      return;
    }
    const placedCount = bidsToSubmit.length;

    // Complete automated reset of bidding forms, active slip, and inputs
    setBidsTable([]);
    setSpecialGridInputs({});
    setEasyNumberInput('');
    setEasyPointsInput('');
    setPanaSuggestions([]);
    setShowPanaSuggestions(false);
    setBulkNumberInput('');
    setSangamOpenPana('');
    setSangamCloseDigit('');
    setSangamOpenDigit('');
    setSangamClosePana('');
    setSangamPoints('');
    setGroupJodiInput('');
    setMotorDigitsInput('');

    // Restore focus to number input for immediate next entry
    setTimeout(() => {
      numberInputRef.current?.focus();
    }, 100);

    setSuccessDetails({ count: placedCount, totalPoints: currentTotalPoints });
    setShowSuccessModal(true);
  };

  // Header Title determination
  const getHeaderTitle = () => {
    if (!selectedGameId) {
      return market.name;
    }
    const shortLabel = currentGame?.label || 'GAME';
    return `${market.name} - ${shortLabel}`;
  };

  // Filtered Jodis for Jodi special mode
  const displayedJodis = useMemo(() => {
    if (jodiDecadeFilter === 'all') return JODI_DIGITS;
    const [start, end] = jodiDecadeFilter.split('-').map(Number);
    return JODI_DIGITS.filter((j) => {
      const n = Number(j);
      return n >= start && n <= end;
    });
  }, [jodiDecadeFilter]);

  return (
    <div className="min-h-screen bg-[#F2F4F7] flex flex-col font-sans select-none">
      {/* 1. Top Navigation Bar with Back, Title, and Live Balance */}
      <header className="sticky top-0 z-30 bg-[#F2F4F7] px-4 py-3.5 flex items-center justify-between border-b border-slate-200/80 backdrop-blur-xs">
        <div className="flex items-center gap-3.5 min-w-0">
          <button
            onClick={handleHeaderBack}
            className="w-11 h-11 rounded-full bg-white shadow-xs border border-slate-200 flex items-center justify-center text-slate-800 active:scale-95 transition-all shrink-0 cursor-pointer hover:border-[#FF7700]"
            aria-label="Back"
          >
            <ArrowLeft className="w-5 h-5 text-slate-800" />
          </button>
          <h1 className="text-lg font-black text-slate-900 uppercase tracking-tight truncate max-w-[210px]">
            {getHeaderTitle()}
          </h1>
        </div>

        {/* Live Wallet Balance Display (₹0.00 format) */}
        <div className="bg-[#23272E] text-white rounded-2xl px-4 py-2 flex items-center gap-2 shadow-xs shrink-0">
          <Wallet className="w-4 h-4 text-orange-400" />
          <span className="text-sm font-black font-mono tracking-tight">
            ₹{walletBalance.toFixed(2)}
          </span>
        </div>
      </header>

      {/* 2. Main Content Area */}
      <main className="flex-1 pb-32 overflow-y-auto">
        {/* CASE A: No Game Selected -> 2-Column Game Selection Menu */}
        {!selectedGameId ? (
          <div className="p-3 sm:p-3.5 space-y-3">
            {/* Dynamic Market Status Bar */}
            <div className="bg-white rounded-xl p-3 border border-slate-200/90 shadow-2xs flex items-center justify-between">
              {(() => {
                const res = formatMarketResult(market);
                return (
                  <div>
                    <div className="text-xs font-black text-slate-900 tracking-tight flex items-center gap-2">
                      <span>{market.name}</span>
                      <span className="text-slate-500 font-mono font-medium">
                        ({res.openPana}-{res.jodi}-{res.closePana})
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 font-medium mt-0.5">
                      {market.openTime} • {market.closeTime}
                    </div>
                  </div>
                );
              })()}

              <span
                className={`px-2.5 py-1 rounded-full text-[10px] font-black tracking-tight ${
                  market.status === 'Running for Open'
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                    : market.status === 'Running for Close'
                    ? 'bg-amber-50 text-amber-700 border border-amber-200'
                    : 'bg-rose-50 text-rose-700 border border-rose-200'
                }`}
              >
                {market.status}
              </span>
            </div>

            {/* 2-Column Game Selection Grid with compact card sizing */}
            <div className="grid grid-cols-2 gap-2.5">
              {gameCategories.map((g) => {
                const IconComponent = g.icon;
                return (
                  <button
                    key={g.id}
                    onClick={() => handleSelectGameMode(g.id)}
                    disabled={isMarketClosed}
                    className={`bg-white rounded-xl p-3 border border-slate-200/90 shadow-2xs flex flex-col items-center justify-center text-center transition-all ${
                      isMarketClosed
                        ? 'opacity-60 cursor-not-allowed'
                        : 'hover:border-[#FF7700] hover:shadow-xs active:scale-95 cursor-pointer'
                    }`}
                  >
                    <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-[#E65100] to-[#FF7700] text-white flex items-center justify-center mb-2 shadow-sm shadow-orange-500/20">
                      <IconComponent className="w-5 h-5 text-white" />
                    </div>
                    <span className="text-xs font-extrabold text-slate-800 leading-tight">
                      {g.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        ) : (
          /* CASE B: Specific Game Selected -> Render Layouts */
          <div className="p-4 space-y-5">
            {/* Mode Switcher Tabs for non-bulk games */}
            {!currentGame?.isBulk &&
              selectedGameId !== 'half_sangam' &&
              selectedGameId !== 'full_sangam' && (
                <div className="grid grid-cols-2 gap-3.5">
                  <button
                    onClick={() => setActiveTabMode('EASY')}
                    className={`py-3.5 text-sm font-black rounded-2xl tracking-wide transition-all cursor-pointer shadow-xs ${
                      activeTabMode === 'EASY'
                        ? 'bg-[#FF7700] text-white border border-[#FF7700] shadow-sm shadow-orange-500/20'
                        : 'bg-white text-[#FF7700] border-2 border-[#FF7700] hover:bg-orange-50/50'
                    }`}
                  >
                    EASY MODE
                  </button>
                  <button
                    onClick={() => setActiveTabMode('SPECIAL')}
                    className={`py-3.5 text-sm font-black rounded-2xl tracking-wide transition-all cursor-pointer shadow-xs ${
                      activeTabMode === 'SPECIAL'
                        ? 'bg-[#FF7700] text-white border border-[#FF7700] shadow-sm shadow-orange-500/20'
                        : 'bg-white text-[#FF7700] border-2 border-[#FF7700] hover:bg-orange-50/50'
                    }`}
                  >
                    SPECIAL MODE
                  </button>
                </div>
              )}

            {/* Error Notification Banner */}
            {errorMessage && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Sub-view Rendering */}
            {/* ======================================================== */}
            {/* 1. BULK KEYPAD GAMES (Single Digit Bulk, Pana Bulk, etc.) */}
            {/* ======================================================== */}
            {currentGame?.isBulk ? (
              <div className="space-y-4">
                {/* Session selection if applicable */}
                {selectedGameId !== 'jodi_digit_bulk' && (
                  <div className="flex items-center justify-between gap-4">
                    <span className="text-sm font-extrabold text-slate-800">Select Game Type:</span>
                    <button
                      onClick={() => setShowSessionModal(true)}
                      className="bg-white border-2 border-slate-200 rounded-xl px-4 py-3 flex items-center justify-between gap-3 text-sm font-extrabold text-slate-800 shadow-xs cursor-pointer min-w-[140px]"
                    >
                      <span>{session}</span>
                      <ChevronDown className="w-4 h-4 text-[#FF7700]" />
                    </button>
                  </div>
                )}

                {/* Enter Points header with Quick Amount Chips */}
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between gap-4">
                    <span className="text-base font-extrabold text-slate-800">Enter Points:</span>
                    <input
                      type="text"
                      inputMode="numeric"
                      placeholder="Enter Points"
                      value={bulkPointsInput}
                      onChange={(e) => setBulkPointsInput(e.target.value.replace(/\D/g, ''))}
                      className="w-[160px] sm:w-[180px] h-14 sm:h-16 bg-white border-2 border-slate-200 rounded-2xl px-4 py-3 text-lg sm:text-xl font-black text-slate-900 outline-none focus:border-[#FF7700] shadow-xs placeholder:text-slate-400 placeholder:text-base"
                    />
                  </div>

                  {/* Quick Points Chips for Bulk */}
                  <div className="flex items-center justify-end gap-2">
                    {QUICK_AMOUNT_CHIPS.map((chip) => (
                      <button
                        key={chip}
                        type="button"
                        onClick={() => setBulkPointsInput(chip.toString())}
                        className="px-3 py-1.5 bg-white border-2 border-[#FF7700] text-[#FF7700] text-xs font-black rounded-xl active:scale-95 cursor-pointer hover:bg-orange-50 min-h-[36px]"
                      >
                        +{chip}
                      </button>
                    ))}
                  </div>
                </div>

                {/* For Jodi Bulk: Enter Jodi Digit input */}
                {selectedGameId === 'jodi_digit_bulk' ? (
                  <div className="flex items-center justify-between gap-4">
                    <span className="text-base font-extrabold text-slate-800">Enter Jodi Digit:</span>
                    <input
                      type="text"
                      inputMode="numeric"
                      placeholder="Enter Jodi"
                      value={bulkNumberInput}
                      onChange={(e) => handleBulkJodiDigitInput(e.target.value)}
                      className="w-[160px] sm:w-[180px] h-14 sm:h-16 bg-white border-2 border-slate-200 rounded-2xl px-4 py-3 text-lg sm:text-xl font-black text-slate-900 outline-none focus:border-[#FF7700] shadow-xs placeholder:text-slate-400 placeholder:text-base"
                    />
                  </div>
                ) : (
                  /* Digit Keypad (1 to 9, 0) matching Frame 18/23/43 */
                  <div className="bg-white/70 p-3 sm:p-4 rounded-3xl border border-slate-200/80 shadow-xs">
                    <div className="text-xs font-bold text-slate-500 mb-3 text-center">
                      Tap a digit button below to instantly place batch bids with ₹{bulkPointsInput || '0'}
                    </div>
                    <div className="grid grid-cols-5 gap-3">
                      {['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'].map((d) => (
                        <button
                          key={d}
                          onClick={() => handleBulkDigitTap(d)}
                          className="h-16 sm:h-20 rounded-2xl bg-gradient-to-tr from-[#E65100] to-[#FF7700] text-white text-2xl font-black shadow-md active:scale-90 transition-all flex items-center justify-center cursor-pointer shadow-orange-500/20 hover:brightness-105"
                        >
                          {d}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : activeTabMode === 'SPECIAL' ? (
              /* ======================================================== */
              /* 2. SPECIAL MODE GRIDS (0-9 Digits, 00-99 Jodis, Panas)    */
              /* ======================================================== */
              <div className="space-y-4">
                {/* Date & Session Bar */}
                <div className="grid grid-cols-2 gap-3.5">
                  <div className="bg-white border-2 border-slate-200 rounded-2xl px-4 py-3 flex items-center gap-2.5 text-sm font-extrabold text-slate-800 shadow-xs">
                    <Calendar className="w-4.5 h-4.5 text-[#FF7700]" />
                    <span>{todayFormatted}</span>
                  </div>

                  {selectedGameId !== 'jodi_digit' && selectedGameId !== 'red_brackets' ? (
                    <button
                      onClick={() => setShowSessionModal(true)}
                      className="bg-white border-2 border-slate-200 rounded-2xl px-4 py-3 flex items-center justify-between text-sm font-extrabold text-slate-800 shadow-xs cursor-pointer hover:border-[#FF7700]"
                    >
                      <span>{session}</span>
                      <ChevronDown className="w-4.5 h-4.5 text-[#FF7700]" />
                    </button>
                  ) : (
                    <div className="bg-white border-2 border-slate-200 rounded-2xl px-4 py-3 flex items-center justify-between text-sm font-extrabold text-slate-700 shadow-xs">
                      <span>Full Day</span>
                    </div>
                  )}
                </div>

                {/* 1. Single Digit Special Mode (0-9 grid with +50 quick buttons) */}
                {selectedGameId === 'single_digit' && (
                  <div className="space-y-3.5">
                    <div className="grid grid-cols-2 gap-3.5">
                      {[
                        { left: '0', right: '1' },
                        { left: '2', right: '3' },
                        { left: '4', right: '5' },
                        { left: '6', right: '7' },
                        { left: '8', right: '9' },
                      ].map((row) => (
                        <React.Fragment key={row.left}>
                          {/* Left box with +50 quick adder */}
                          <div className="bg-white rounded-2xl border-2 border-slate-200 overflow-hidden flex items-center shadow-xs h-14 sm:h-16 focus-within:border-[#FF7700]">
                            <div className="w-14 sm:w-16 h-full bg-gradient-to-tr from-[#E65100] to-[#FF7700] text-white flex items-center justify-center font-black text-base sm:text-lg shrink-0">
                              {row.left}
                            </div>
                            <input
                              type="text"
                              inputMode="numeric"
                              placeholder="0"
                              value={specialGridInputs[row.left] || ''}
                              onChange={(e) => handleSpecialGridChange(row.left, e.target.value)}
                              className="w-full px-3 py-3 text-sm sm:text-base font-black text-slate-900 outline-none"
                            />
                            <button
                              type="button"
                              onClick={() => handleQuickAddGridPoints(row.left, 50)}
                              className="px-2.5 py-1.5 mr-2 bg-orange-50 text-[#FF7700] font-black text-xs rounded-xl active:scale-90 border border-orange-200 hover:bg-orange-100 min-h-[34px] cursor-pointer"
                            >
                              +50
                            </button>
                          </div>
                          {/* Right box with +50 quick adder */}
                          <div className="bg-white rounded-2xl border-2 border-slate-200 overflow-hidden flex items-center shadow-xs h-14 sm:h-16 focus-within:border-[#FF7700]">
                            <div className="w-14 sm:w-16 h-full bg-gradient-to-tr from-[#E65100] to-[#FF7700] text-white flex items-center justify-center font-black text-base sm:text-lg shrink-0">
                              {row.right}
                            </div>
                            <input
                              type="text"
                              inputMode="numeric"
                              placeholder="0"
                              value={specialGridInputs[row.right] || ''}
                              onChange={(e) => handleSpecialGridChange(row.right, e.target.value)}
                              className="w-full px-3 py-3 text-sm sm:text-base font-black text-slate-900 outline-none"
                            />
                            <button
                              type="button"
                              onClick={() => handleQuickAddGridPoints(row.right, 50)}
                              className="px-2.5 py-1.5 mr-2 bg-orange-50 text-[#FF7700] font-black text-xs rounded-xl active:scale-90 border border-orange-200 hover:bg-orange-100 min-h-[34px] cursor-pointer"
                            >
                              +50
                            </button>
                          </div>
                        </React.Fragment>
                      ))}
                    </div>
                  </div>
                )}

                {/* 2. Jodi Digits Special Mode (00-99 grid with decade filter & quick chips) */}
                {selectedGameId === 'jodi_digit' && (
                  <div className="space-y-3.5">
                    {/* Decade filter chips */}
                    <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
                      {[
                        { id: 'all', label: 'All (00-99)' },
                        { id: '0-9', label: '00-09' },
                        { id: '10-19', label: '10-19' },
                        { id: '20-29', label: '20-29' },
                        { id: '30-39', label: '30-39' },
                        { id: '40-49', label: '40-49' },
                        { id: '50-59', label: '50-59' },
                        { id: '60-69', label: '60-69' },
                        { id: '70-79', label: '70-79' },
                        { id: '80-89', label: '80-89' },
                        { id: '90-99', label: '90-99' },
                      ].map((f) => (
                        <button
                          key={f.id}
                          onClick={() => setJodiDecadeFilter(f.id)}
                          className={`px-3.5 py-2 rounded-xl text-xs font-black whitespace-nowrap transition-all cursor-pointer min-h-[36px] ${
                            jodiDecadeFilter === f.id
                              ? 'bg-[#FF7700] text-white shadow-xs'
                              : 'bg-white text-slate-700 border-2 border-slate-200 hover:border-[#FF7700]'
                          }`}
                        >
                          {f.label}
                        </button>
                      ))}
                    </div>

                    {/* 00-99 interactive grid */}
                    <div className="grid grid-cols-2 gap-3 max-h-[50vh] overflow-y-auto pr-1">
                      {displayedJodis.map((jodi) => (
                        <div
                          key={jodi}
                          className="bg-white rounded-2xl border-2 border-slate-200 overflow-hidden flex items-center shadow-xs h-14 sm:h-16 focus-within:border-[#FF7700]"
                        >
                          <div className="w-14 sm:w-16 h-full bg-gradient-to-tr from-[#E65100] to-[#FF7700] text-white flex items-center justify-center font-black text-sm sm:text-base shrink-0">
                            {jodi}
                          </div>
                          <input
                            type="text"
                            inputMode="numeric"
                            placeholder="0"
                            value={specialGridInputs[jodi] || ''}
                            onChange={(e) => handleSpecialGridChange(jodi, e.target.value)}
                            className="w-full px-3 py-3 text-sm sm:text-base font-black text-slate-900 outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => handleQuickAddGridPoints(jodi, 50)}
                            className="px-2.5 py-1.5 mr-2 bg-orange-50 text-[#FF7700] font-black text-xs rounded-xl active:scale-90 border border-orange-200 hover:bg-orange-100 min-h-[34px] cursor-pointer"
                          >
                            +50
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 3. Single Pana Special Mode (grouped by sum 0-9) */}
                {selectedGameId === 'single_pana' && (
                  <div className="space-y-4.5 max-h-[55vh] overflow-y-auto pr-1">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 0].map((sumDigit) => (
                      <div key={sumDigit} className="space-y-2.5">
                        {/* Group banner */}
                        <div className="w-full bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-black text-sm sm:text-base py-2 rounded-2xl text-center shadow-xs">
                          {sumDigit}
                        </div>
                        {/* Panas in this sum */}
                        <div className="grid grid-cols-2 gap-3">
                          {SINGLE_PANAS_BY_SUM[sumDigit]?.map((pana) => (
                            <div
                              key={pana}
                              className="bg-white rounded-2xl border-2 border-slate-200 overflow-hidden flex items-center shadow-xs h-14 focus-within:border-[#FF7700]"
                            >
                              <div className="w-16 h-full bg-gradient-to-tr from-[#E65100] to-[#FF7700] text-white flex items-center justify-center font-black text-sm shrink-0">
                                {pana}
                              </div>
                              <input
                                type="text"
                                inputMode="numeric"
                                placeholder="0"
                                value={specialGridInputs[pana] || ''}
                                onChange={(e) => handleSpecialGridChange(pana, e.target.value)}
                                className="w-full px-3 py-3 text-sm font-black text-slate-900 outline-none"
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* 4. Double Pana Special Mode (grouped by sum 0-9) */}
                {selectedGameId === 'double_pana' && (
                  <div className="space-y-4.5 max-h-[55vh] overflow-y-auto pr-1">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 0].map((sumDigit) => (
                      <div key={sumDigit} className="space-y-2.5">
                        {/* Group banner */}
                        <div className="w-full bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-black text-sm sm:text-base py-2 rounded-2xl text-center shadow-xs">
                          {sumDigit}
                        </div>
                        {/* Double panas */}
                        <div className="grid grid-cols-2 gap-3">
                          {DOUBLE_PANAS_BY_SUM[sumDigit]?.map((pana) => (
                            <div
                              key={pana}
                              className="bg-white rounded-2xl border-2 border-slate-200 overflow-hidden flex items-center shadow-xs h-14 focus-within:border-[#FF7700]"
                            >
                              <div className="w-16 h-full bg-gradient-to-tr from-[#E65100] to-[#FF7700] text-white flex items-center justify-center font-black text-sm shrink-0">
                                {pana}
                              </div>
                              <input
                                type="text"
                                inputMode="numeric"
                                placeholder="0"
                                value={specialGridInputs[pana] || ''}
                                onChange={(e) => handleSpecialGridChange(pana, e.target.value)}
                                className="w-full px-3 py-3 text-sm font-black text-slate-900 outline-none"
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* 5. Triple Pana Special Mode (10 triple panas) */}
                {selectedGameId === 'triple_pana' && (
                  <div className="grid grid-cols-2 gap-3.5">
                    {TRIPLE_PANAS.map((pana) => (
                      <div
                        key={pana}
                        className="bg-white rounded-2xl border-2 border-slate-200 overflow-hidden flex items-center shadow-xs h-14 focus-within:border-[#FF7700]"
                      >
                        <div className="w-16 h-full bg-gradient-to-tr from-[#E65100] to-[#FF7700] text-white flex items-center justify-center font-black text-sm shrink-0">
                          {pana}
                        </div>
                        <input
                          type="text"
                          inputMode="numeric"
                          placeholder="0"
                          value={specialGridInputs[pana] || ''}
                          onChange={(e) => handleSpecialGridChange(pana, e.target.value)}
                          className="w-full px-3 py-3 text-sm font-black text-slate-900 outline-none"
                        />
                      </div>
                    ))}
                  </div>
                )}

                {/* 6. Red Brackets Special Mode */}
                {selectedGameId === 'red_brackets' && (
                  <div className="space-y-3.5">
                    <div className="text-sm font-extrabold text-slate-700">
                      All 20 Red Bracket Pairs (10 Half-Red + 10 Full-Red Pairs):
                    </div>
                    <div className="grid grid-cols-2 gap-3 max-h-[50vh] overflow-y-auto pr-1">
                      {RED_BRACKETS.map((pair) => (
                        <div
                          key={pair}
                          className="bg-white rounded-2xl border-2 border-red-200 overflow-hidden flex items-center shadow-xs h-14 sm:h-16 focus-within:border-red-500"
                        >
                          <div className="w-14 sm:w-16 h-full bg-red-700 text-white flex items-center justify-center font-black text-sm sm:text-base shrink-0">
                            {pair}
                          </div>
                          <input
                            type="text"
                            inputMode="numeric"
                            placeholder="0"
                            value={specialGridInputs[pair] || ''}
                            onChange={(e) => handleSpecialGridChange(pair, e.target.value)}
                            className="w-full px-3 py-3 text-sm sm:text-base font-black text-slate-900 outline-none"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              /* ======================================================== */
              /* 3. EASY MODE FORMS (Single Digit, Panas, Motors, Sangam)   */
              /* ======================================================== */
              <div className="space-y-4.5">
                {/* Session Selection for non-jodi / non-sangam */}
                {selectedGameId !== 'jodi_digit' &&
                  selectedGameId !== 'red_brackets' &&
                  selectedGameId !== 'group_jodi' &&
                  !selectedGameId?.includes('sangam') && (
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-sm font-extrabold text-slate-800">Select Game Type:</span>
                      <button
                        onClick={() => setShowSessionModal(true)}
                        className="bg-white border-2 border-slate-200 rounded-2xl px-4 py-3 flex items-center justify-between gap-3 text-sm font-extrabold text-slate-800 shadow-xs cursor-pointer min-w-[140px] hover:border-[#FF7700]"
                      >
                        <span>{session}</span>
                        <ChevronDown className="w-4.5 h-4.5 text-[#FF7700]" />
                      </button>
                    </div>
                  )}

                {/* 1-Tap Odd / Even Game Options */}
                {selectedGameId === 'odd_even' ? (
                  <div className="space-y-4 bg-white p-5 rounded-3xl border-2 border-slate-200 shadow-xs">
                    <div className="text-sm font-black text-slate-800">1-Tap Batch Bets: Odd or Even Digits</div>
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-base font-extrabold text-slate-800">Points per Digit:</span>
                      <input
                        type="text"
                        inputMode="numeric"
                        placeholder="Points"
                        value={easyPointsInput}
                        onChange={(e) => setEasyPointsInput(e.target.value.replace(/\D/g, ''))}
                        className="w-[160px] sm:w-[180px] h-14 sm:h-16 bg-slate-50 border-2 border-slate-200 rounded-2xl px-4 py-3 text-lg sm:text-xl font-black text-slate-900 outline-none focus:border-[#FF7700] shadow-xs placeholder:text-slate-400 placeholder:text-base"
                      />
                    </div>

                    <div className="flex gap-2 justify-end">
                      {QUICK_AMOUNT_CHIPS.map((chip) => (
                        <button
                          key={chip}
                          type="button"
                          onClick={() => setEasyPointsInput(chip.toString())}
                          className="px-3 py-1.5 bg-orange-50 text-[#FF7700] font-black text-xs rounded-xl border border-orange-200 cursor-pointer hover:bg-orange-100 min-h-[36px]"
                        >
                          +{chip}
                        </button>
                      ))}
                    </div>

                    <div className="grid grid-cols-2 gap-3.5 pt-2">
                      <button
                        onClick={() => handleAddOddEvenBatch('odd')}
                        className="py-4 rounded-2xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white text-sm font-black shadow-md active:scale-95 cursor-pointer flex flex-col items-center gap-1 shadow-orange-500/20"
                      >
                        <span>ODD (1, 3, 5, 7, 9)</span>
                        <span className="text-xs opacity-90 font-bold">5 Digits Batch</span>
                      </button>
                      <button
                        onClick={() => handleAddOddEvenBatch('even')}
                        className="py-4 rounded-2xl bg-[#E65100] text-white text-sm font-black shadow-md active:scale-95 cursor-pointer flex flex-col items-center gap-1 shadow-orange-500/20"
                      >
                        <span>EVEN (0, 2, 4, 6, 8)</span>
                        <span className="text-xs opacity-90 font-bold">5 Digits Batch</span>
                      </button>
                    </div>
                  </div>
                ) : selectedGameId === 'red_brackets' ? (
                  /* 20 Red Bracket Pairs Fast Action */
                  <div className="space-y-4 bg-white p-5 rounded-3xl border-2 border-slate-200 shadow-xs">
                    <div className="text-sm font-black text-red-800 flex items-center justify-between">
                      <span>20 Red Bracket Pairs (Half & Full Red)</span>
                      <span className="text-xs text-slate-500 font-bold">Total: 20 Jodis</span>
                    </div>

                    <div className="flex items-center justify-between gap-4">
                      <span className="text-base font-extrabold text-slate-800">Points per Bracket:</span>
                      <input
                        type="text"
                        inputMode="numeric"
                        placeholder="Points"
                        value={redBracketPresetPoints}
                        onChange={(e) => setRedBracketPresetPoints(e.target.value.replace(/\D/g, ''))}
                        className="w-[160px] sm:w-[180px] h-14 sm:h-16 bg-slate-50 border-2 border-slate-200 rounded-2xl px-4 py-3 text-lg sm:text-xl font-black text-slate-900 outline-none focus:border-red-500 shadow-xs placeholder:text-slate-400 placeholder:text-base"
                      />
                    </div>

                    <div className="flex gap-2 justify-end">
                      {QUICK_AMOUNT_CHIPS.map((chip) => (
                        <button
                          key={chip}
                          type="button"
                          onClick={() => setRedBracketPresetPoints(chip.toString())}
                          className="px-3 py-1.5 bg-red-50 text-red-800 font-black text-xs rounded-xl border border-red-200 cursor-pointer hover:bg-red-100 min-h-[36px]"
                        >
                          +{chip}
                        </button>
                      ))}
                    </div>

                    <button
                      onClick={handleAddRedBracketsBatch}
                      className="w-full py-4 rounded-2xl bg-red-700 hover:bg-red-800 text-white text-sm font-black shadow-md active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
                    >
                      <Zap className="w-5 h-5" />
                      <span>1-Tap Add All 20 Red Brackets (₹{20 * (parseInt(redBracketPresetPoints, 10) || 0)})</span>
                    </button>
                  </div>
                ) : selectedGameId === 'group_jodi' ? (
                  /* Group Jodi Family Generator */
                  <div className="space-y-4 bg-white p-5 rounded-3xl border-2 border-slate-200 shadow-xs">
                    <div className="text-sm font-black text-[#E65100]">Group Jodi Family Generator</div>
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-base font-extrabold text-slate-800">Enter Base Jodi:</span>
                      <input
                        type="text"
                        inputMode="numeric"
                        enterKeyHint="next"
                        maxLength={2}
                        placeholder="e.g. 12"
                        value={groupJodiInput}
                        onChange={(e) => {
                          const clean = e.target.value.replace(/\D/g, '').slice(0, 2);
                          setGroupJodiInput(clean);
                          if (clean.length === 2) {
                            setTimeout(() => groupJodiPointsRef.current?.focus(), 50);
                          }
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            groupJodiPointsRef.current?.focus();
                          }
                        }}
                        className="w-[160px] sm:w-[180px] h-14 sm:h-16 bg-slate-50 border-2 border-slate-200 rounded-2xl px-4 py-3 text-lg sm:text-xl font-black text-slate-900 outline-none focus:border-[#FF7700] shadow-xs placeholder:text-slate-400 placeholder:text-base"
                      />
                    </div>
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-base font-extrabold text-slate-800">Points per Jodi:</span>
                      <input
                        ref={groupJodiPointsRef}
                        type="text"
                        inputMode="numeric"
                        enterKeyHint="done"
                        placeholder="Points"
                        value={easyPointsInput}
                        onChange={(e) => setEasyPointsInput(e.target.value.replace(/\D/g, ''))}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleAddGroupJodiBatch();
                          }
                        }}
                        className="w-[160px] sm:w-[180px] h-14 sm:h-16 bg-slate-50 border-2 border-slate-200 rounded-2xl px-4 py-3 text-lg sm:text-xl font-black text-slate-900 outline-none focus:border-[#FF7700] shadow-xs placeholder:text-slate-400 placeholder:text-base"
                      />
                    </div>

                    <button
                      onClick={handleAddGroupJodiBatch}
                      className="w-full bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white text-sm font-black py-4 rounded-2xl shadow-md active:scale-98 cursor-pointer shadow-orange-500/20"
                    >
                      Generate & Add Family Jodis
                    </button>
                  </div>
                ) : selectedGameId === 'sp_motor' || selectedGameId === 'dp_motor' ? (
                  /* SP & DP Motor Generators */
                  <div className="space-y-3.5 bg-white p-5 rounded-3xl border-2 border-slate-200 shadow-xs">
                    <div className="text-sm font-black text-[#E65100]">
                      {selectedGameId === 'dp_motor' ? 'DP Motor Generator' : 'SP Motor Generator'}
                    </div>
                    <input
                      type="text"
                      inputMode="numeric"
                      enterKeyHint="next"
                      placeholder={selectedGameId === 'dp_motor' ? 'Enter 2-10 unique digits (e.g. 1234)' : 'Enter 3-10 unique digits (e.g. 12345)'}
                      value={motorDigitsInput}
                      onChange={(e) => setMotorDigitsInput(e.target.value.replace(/\D/g, ''))}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          motorPointsRef.current?.focus();
                        }
                      }}
                      className="w-full h-14 sm:h-16 bg-slate-50 border-2 border-slate-200 rounded-2xl px-4 py-3 text-lg sm:text-xl font-black text-slate-900 outline-none focus:border-[#FF7700] shadow-xs placeholder:text-slate-400 placeholder:text-base"
                    />
                    <input
                      ref={motorPointsRef}
                      type="text"
                      inputMode="numeric"
                      enterKeyHint="done"
                      placeholder="Enter Points per pana"
                      value={easyPointsInput}
                      onChange={(e) => setEasyPointsInput(e.target.value.replace(/\D/g, ''))}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddMotorBids(selectedGameId === 'dp_motor');
                        }
                      }}
                      className="w-full h-14 sm:h-16 bg-slate-50 border-2 border-slate-200 rounded-2xl px-4 py-3 text-lg sm:text-xl font-black text-slate-900 outline-none focus:border-[#FF7700] shadow-xs placeholder:text-slate-400 placeholder:text-base"
                    />
                    <button
                      onClick={() => handleAddMotorBids(selectedGameId === 'dp_motor')}
                      className="w-full bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white text-sm font-black py-4 rounded-2xl shadow-md active:scale-98 cursor-pointer shadow-orange-500/20"
                    >
                      Generate & Add Motor Panas
                    </button>
                  </div>
                ) : selectedGameId === 'half_sangam' ? (
                  /* Half Sangam Form */
                  <div className="space-y-4 bg-white p-5 rounded-3xl border-2 border-slate-200 shadow-xs">
                    <div className="text-sm font-black text-[#E65100]">Half Sangam Form A (Open Pana + Close Ank)</div>
                    <div className="grid grid-cols-2 gap-3">
                      <input
                        type="text"
                        placeholder="Open Pana"
                        maxLength={3}
                        value={sangamOpenPana}
                        onChange={(e) => setSangamOpenPana(e.target.value.replace(/\D/g, ''))}
                        className="h-14 sm:h-16 bg-slate-50 border-2 border-slate-200 rounded-2xl px-4 py-3 text-lg sm:text-xl font-black text-slate-900 outline-none focus:border-[#FF7700] shadow-xs placeholder:text-slate-400 placeholder:text-base"
                      />
                      <input
                        type="text"
                        placeholder="Close Ank"
                        maxLength={1}
                        value={sangamCloseDigit}
                        onChange={(e) => setSangamCloseDigit(e.target.value.replace(/\D/g, ''))}
                        className="h-14 sm:h-16 bg-slate-50 border-2 border-slate-200 rounded-2xl px-4 py-3 text-lg sm:text-xl font-black text-slate-900 outline-none focus:border-[#FF7700] shadow-xs placeholder:text-slate-400 placeholder:text-base"
                      />
                    </div>
                    <input
                      type="text"
                      placeholder="Enter Points"
                      value={sangamPoints}
                      onChange={(e) => setSangamPoints(e.target.value.replace(/\D/g, ''))}
                      className="w-full h-14 sm:h-16 bg-slate-50 border-2 border-slate-200 rounded-2xl px-4 py-3 text-lg sm:text-xl font-black text-slate-900 outline-none focus:border-[#FF7700] shadow-xs placeholder:text-slate-400 placeholder:text-base"
                    />
                    <button
                      onClick={() => handleAddSangamBid('half_a')}
                      className="w-full bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white text-sm font-black py-3.5 rounded-2xl shadow-md active:scale-98 cursor-pointer shadow-orange-500/20"
                    >
                      Add Form A
                    </button>

                    <div className="text-sm font-black text-[#E65100] pt-2">Half Sangam Form B (Open Ank + Close Pana)</div>
                    <div className="grid grid-cols-2 gap-3">
                      <input
                        type="text"
                        placeholder="Open Ank"
                        maxLength={1}
                        value={sangamOpenDigit}
                        onChange={(e) => setSangamOpenDigit(e.target.value.replace(/\D/g, ''))}
                        className="h-14 sm:h-16 bg-slate-50 border-2 border-slate-200 rounded-2xl px-4 py-3 text-lg sm:text-xl font-black text-slate-900 outline-none focus:border-[#FF7700] shadow-xs placeholder:text-slate-400 placeholder:text-base"
                      />
                      <input
                        type="text"
                        placeholder="Close Pana"
                        maxLength={3}
                        value={sangamClosePana}
                        onChange={(e) => setSangamClosePana(e.target.value.replace(/\D/g, ''))}
                        className="h-14 sm:h-16 bg-slate-50 border-2 border-slate-200 rounded-2xl px-4 py-3 text-lg sm:text-xl font-black text-slate-900 outline-none focus:border-[#FF7700] shadow-xs placeholder:text-slate-400 placeholder:text-base"
                      />
                    </div>
                    <input
                      type="text"
                      placeholder="Enter Points"
                      value={sangamPoints}
                      onChange={(e) => setSangamPoints(e.target.value.replace(/\D/g, ''))}
                      className="w-full h-14 sm:h-16 bg-slate-50 border-2 border-slate-200 rounded-2xl px-4 py-3 text-lg sm:text-xl font-black text-slate-900 outline-none focus:border-[#FF7700] shadow-xs placeholder:text-slate-400 placeholder:text-base"
                    />
                    <button
                      onClick={() => handleAddSangamBid('half_b')}
                      className="w-full bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white text-sm font-black py-3.5 rounded-2xl shadow-md active:scale-98 cursor-pointer shadow-orange-500/20"
                    >
                      Add Form B
                    </button>
                  </div>
                ) : selectedGameId === 'full_sangam' ? (
                  /* Full Sangam Form */
                  <div className="space-y-4 bg-white p-5 rounded-3xl border-2 border-slate-200 shadow-xs">
                    <div className="text-sm font-black text-[#E65100]">Full Sangam (Open Pana + Close Pana)</div>
                    <div className="grid grid-cols-2 gap-3">
                      <input
                        type="text"
                        placeholder="Open Pana"
                        maxLength={3}
                        value={sangamOpenPana}
                        onChange={(e) => setSangamOpenPana(e.target.value.replace(/\D/g, ''))}
                        className="h-14 sm:h-16 bg-slate-50 border-2 border-slate-200 rounded-2xl px-4 py-3 text-lg sm:text-xl font-black text-slate-900 outline-none focus:border-[#FF7700] shadow-xs placeholder:text-slate-400 placeholder:text-base"
                      />
                      <input
                        type="text"
                        placeholder="Close Pana"
                        maxLength={3}
                        value={sangamClosePana}
                        onChange={(e) => setSangamClosePana(e.target.value.replace(/\D/g, ''))}
                        className="h-14 sm:h-16 bg-slate-50 border-2 border-slate-200 rounded-2xl px-4 py-3 text-lg sm:text-xl font-black text-slate-900 outline-none focus:border-[#FF7700] shadow-xs placeholder:text-slate-400 placeholder:text-base"
                      />
                    </div>
                    <input
                      type="text"
                      placeholder="Enter Points"
                      value={sangamPoints}
                      onChange={(e) => setSangamPoints(e.target.value.replace(/\D/g, ''))}
                      className="w-full h-14 sm:h-16 bg-slate-50 border-2 border-slate-200 rounded-2xl px-4 py-3 text-lg sm:text-xl font-black text-slate-900 outline-none focus:border-[#FF7700] shadow-xs placeholder:text-slate-400 placeholder:text-base"
                    />
                    <button
                      onClick={() => handleAddSangamBid('full')}
                      className="w-full bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white text-sm font-black py-4 rounded-2xl shadow-md active:scale-98 cursor-pointer shadow-orange-500/20"
                    >
                      Add Full Sangam
                    </button>
                  </div>
                ) : (
                  /* Standard Easy Mode: Digit/Pana Input + Points + Suggestions + Quick Chips + Add button */
                  <div className="space-y-4">
                    <div className="flex items-center justify-between gap-4 relative">
                      <span className="text-base font-extrabold text-slate-800">
                        {selectedGameId === 'single_digit'
                          ? 'Digit:'
                          : selectedGameId === 'jodi_digit'
                          ? 'Enter Jodi Digit:'
                          : selectedGameId === 'single_pana'
                          ? 'Enter Single Pana:'
                          : selectedGameId === 'double_pana'
                          ? 'Enter Double Pana:'
                          : selectedGameId === 'triple_pana'
                          ? 'Enter Triple Pana:'
                          : 'Enter Number:'}
                      </span>
                      <div className="w-[160px] sm:w-[180px] relative">
                        <input
                          ref={numberInputRef}
                          type="text"
                          inputMode="numeric"
                          enterKeyHint="next"
                          maxLength={
                            selectedGameId === 'single_digit'
                              ? 1
                              : selectedGameId === 'jodi_digit'
                              ? 2
                              : 3
                          }
                          placeholder={
                            selectedGameId === 'single_digit'
                              ? 'Ank'
                              : selectedGameId === 'jodi_digit'
                              ? 'Enter Jodi'
                              : 'Pana'
                          }
                          value={easyNumberInput}
                          onChange={(e) => handlePanaInputChange(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              pointsInputRef.current?.focus();
                            }
                          }}
                          onFocus={() => {
                            if (panaSuggestions.length > 0) setShowPanaSuggestions(true);
                          }}
                          className="w-full h-14 sm:h-16 bg-white border-2 border-slate-200 rounded-2xl px-4 py-3 text-lg sm:text-xl font-black text-slate-900 outline-none focus:border-[#FF7700] shadow-xs placeholder:text-slate-400 placeholder:text-base"
                        />

                        {/* Autocomplete suggestion dropdown matching video frame 10 */}
                        {showPanaSuggestions && (
                          <div className="absolute top-full left-0 right-0 mt-1 bg-white border-2 border-slate-200 rounded-2xl shadow-xl z-20 max-h-52 overflow-y-auto divide-y divide-slate-100">
                            {panaSuggestions.map((sug) => (
                              <button
                                key={sug}
                                type="button"
                                onClick={() => {
                                  setEasyNumberInput(sug);
                                  setShowPanaSuggestions(false);
                                  setTimeout(() => {
                                    pointsInputRef.current?.focus();
                                  }, 50);
                                }}
                                className="w-full px-4 py-3 text-left text-base font-black text-slate-800 hover:bg-orange-50 active:bg-orange-100 cursor-pointer"
                              >
                                {sug}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Instant Pana validation status */}
                    {panaValidationStatus && (
                      <div
                        className={`text-xs font-black text-right ${
                          panaValidationStatus.isValid ? 'text-[#E65100]' : 'text-amber-700'
                        }`}
                      >
                        {panaValidationStatus.text}
                      </div>
                    )}

                    <div className="flex items-center justify-between gap-4">
                      <span className="text-base font-extrabold text-slate-800">
                        {selectedGameId === 'single_digit' ? 'Points:' : 'Enter Points:'}
                      </span>
                      <input
                        ref={pointsInputRef}
                        type="text"
                        inputMode="numeric"
                        enterKeyHint="done"
                        placeholder="Enter Points"
                        value={easyPointsInput}
                        onChange={(e) => setEasyPointsInput(e.target.value.replace(/\D/g, ''))}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleAddEasyBid();
                          }
                        }}
                        className="w-[160px] sm:w-[180px] h-14 sm:h-16 bg-white border-2 border-slate-200 rounded-2xl px-4 py-3 text-lg sm:text-xl font-black text-slate-900 outline-none focus:border-[#FF7700] shadow-xs placeholder:text-slate-400 placeholder:text-base"
                      />
                    </div>

                    {/* Quick Amount Chips */}
                    <div className="flex items-center justify-end gap-2 pt-0.5">
                      {QUICK_AMOUNT_CHIPS.map((chip) => (
                        <button
                          key={chip}
                          type="button"
                          onClick={() => applyQuickAmountToEasy(chip)}
                          className="px-3.5 py-1.5 bg-white border-2 border-[#FF7700] text-[#FF7700] text-xs font-black rounded-xl active:scale-95 cursor-pointer hover:bg-orange-50 min-h-[36px]"
                        >
                          +{chip}
                        </button>
                      ))}
                    </div>

                    <button
                      onClick={handleAddEasyBid}
                      className="w-full bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-black text-base py-4 rounded-2xl shadow-md active:scale-98 transition-all cursor-pointer mt-3 shadow-orange-500/25 tracking-wide"
                    >
                      Add
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* ======================================================== */}
            {/* 4. DYNAMIC INTERACTIVE BID SLIP TABLE (Always visible    */}
            {/*    whenever any bids are present in slip or added)       */}
            {/* ======================================================== */}
            <div className="space-y-3 pt-4">
              <div className="flex items-center justify-between">
                <div className="text-sm font-black text-slate-800 flex items-center gap-2">
                  <span>Interactive Bid Slip</span>
                  <span className="px-2.5 py-1 bg-orange-100 text-[#E65100] text-xs font-black rounded-full">
                    {currentTotalBids} Bids
                  </span>
                </div>

                {allActiveBids.length > 0 && (
                  <button
                    onClick={handleClearAllBids}
                    className="text-xs font-black text-rose-600 hover:text-rose-700 active:scale-95 cursor-pointer py-1 px-2"
                  >
                    Clear All
                  </button>
                )}
              </div>

              {/* Table Container */}
              <div className="bg-white rounded-2xl border-2 border-slate-200 shadow-xs overflow-hidden">
                {/* Table Header with Orange Divider */}
                <div className="bg-orange-50/80 border-b-2 border-[#FF7700] py-3 px-4 grid grid-cols-4 text-xs font-black text-[#E65100] text-center uppercase tracking-wider">
                  <span>Bids</span>
                  <span>Points</span>
                  <span>Type</span>
                  <span>Delete</span>
                </div>

                {/* Table Rows with Delete Option */}
                <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
                  {allActiveBids.length === 0 ? (
                    <div className="py-10 text-center text-sm text-slate-400 font-semibold">
                      No bids in slip. Enter numbers or points above to begin.
                    </div>
                  ) : (
                    allActiveBids.map((bid) => (
                      <div
                        key={bid.id}
                        className="py-3 px-4 grid grid-cols-4 text-sm font-bold text-slate-800 text-center items-center hover:bg-slate-50/80 transition-colors"
                      >
                        <span className="font-mono text-slate-900 font-black text-sm">{bid.number}</span>
                        <span className="text-[#E65100] font-mono font-black text-sm">₹{bid.points}</span>
                        <div>
                          <span
                            className={`px-2.5 py-1 rounded-lg text-xs font-black ${
                              bid.session === 'Open'
                                ? 'bg-orange-100 text-[#E65100]'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {bid.session}
                          </span>
                        </div>
                        <div className="flex justify-center">
                          <button
                            onClick={() => handleDeleteBid(bid)}
                            className="w-9 h-9 rounded-xl text-red-500 hover:bg-red-50 flex items-center justify-center active:scale-90 transition-all cursor-pointer"
                            aria-label={`Delete bid ${bid.number}`}
                          >
                            <Trash2 className="w-5 h-5 text-red-500" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* 3. Bottom Summary Bar showing total Bids count and total Points sum */}
      {selectedGameId && (
        <div className="fixed bottom-0 left-0 right-0 z-20 bg-white border-t-2 border-slate-200 px-5 py-3.5 flex items-center justify-between shadow-xl">
          <div className="flex items-center gap-7">
            <div>
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Bids</div>
              <div className="text-lg font-black text-slate-900 font-mono">
                {currentTotalBids}
              </div>
            </div>
            <div>
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Points</div>
              <div className="text-lg font-black text-slate-900 font-mono">
                ₹{currentTotalPoints}
              </div>
            </div>
          </div>

          {/* Submit Button with strict wallet verification */}
          <button
            onClick={handleSubmitAllBids}
            disabled={isMarketClosed}
            className={`px-10 py-3.5 rounded-2xl font-black text-base tracking-wide shadow-md active:scale-95 transition-all cursor-pointer ${
              isMarketClosed
                ? 'bg-slate-300 text-slate-500 cursor-not-allowed shadow-none'
                : 'bg-gradient-to-r from-[#FF7700] to-[#E65100] hover:from-[#E65100] hover:to-[#D84315] text-white shadow-md shadow-orange-500/25'
            }`}
          >
            Submit
          </button>
        </div>
      )}

      {/* 4. MODAL: Select Game Type (Open / Close Bottom Sheet Modal) */}
      {showSessionModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl overflow-hidden max-w-xs w-full shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            {/* Orange header */}
            <div className="bg-gradient-to-r from-[#FF7700] to-[#E65100] px-5 py-3.5 flex items-center justify-between text-white">
              <h3 className="text-sm font-bold tracking-tight">Select Game Type</h3>
              <button
                onClick={() => setShowSessionModal(false)}
                className="w-6 h-6 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4 text-white" />
              </button>
            </div>

            {/* Selection choices */}
            <div className="p-2 divide-y divide-slate-100">
              <button
                onClick={() => {
                  if (isOpenSessionDisabled) {
                    setErrorMessage('Open session is closed for this market.');
                  } else {
                    setSession('Open');
                    setShowSessionModal(false);
                  }
                }}
                disabled={isOpenSessionDisabled}
                className={`w-full px-4 py-3.5 flex items-center justify-between text-left transition-all ${
                  isOpenSessionDisabled
                    ? 'opacity-40 cursor-not-allowed'
                    : 'hover:bg-slate-50 active:bg-slate-100 cursor-pointer'
                }`}
              >
                <span className="text-sm font-bold text-slate-800">Open</span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>

              <button
                onClick={() => {
                  setSession('Close');
                  setShowSessionModal(false);
                }}
                className="w-full px-4 py-3.5 flex items-center justify-between text-left hover:bg-slate-50 active:bg-slate-100 transition-all cursor-pointer"
              >
                <span className="text-sm font-bold text-slate-800">Close</span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. MODAL: Insufficient Balance Error Alert Modal */}
      {/* Exact match to Frame 8: Red Circle with X, "Insufficient Balance in wallet", and "OK" button */}
      {showInsufficientBalanceModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 text-center max-w-xs w-full shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            {/* Big Red Circle with White X */}
            <div className="w-16 h-16 rounded-full bg-[#D32F2F] text-white flex items-center justify-center mx-auto mb-4 shadow-md shadow-red-500/20">
              <X className="w-9 h-9 stroke-[3]" />
            </div>

            {/* Exact Warning Text */}
            <h3 className="text-sm font-extrabold text-[#D32F2F] mb-6">
              Insufficient Balance in wallet
            </h3>

            {/* OK Button - Prevents submission until sufficient funds are available */}
            <button
              onClick={() => setShowInsufficientBalanceModal(false)}
              className="w-full bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-extrabold text-sm py-3 rounded-xl shadow-md active:scale-95 transition-all cursor-pointer shadow-orange-500/20"
            >
              OK
            </button>
          </div>
        </div>
      )}

      {/* 6. MODAL: Success Confirmation */}
      {showSuccessModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 text-center max-w-xs w-full shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            <div className="w-16 h-16 rounded-full bg-orange-100 text-[#FF7700] flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <h3 className="text-base font-extrabold text-slate-900 mb-1">
              Bids Placed Successfully!
            </h3>
            <p className="text-xs text-slate-500 font-medium mb-4">
              Placed {successDetails?.count} bids worth ₹{successDetails?.totalPoints} on {market.name} ({session}).
            </p>

            <button
              onClick={() => {
                setShowSuccessModal(false);
                setSelectedGameId(null);
              }}
              className="w-full bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-extrabold text-sm py-3 rounded-xl shadow-md active:scale-95 transition-all cursor-pointer shadow-orange-500/20"
            >
              OK
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
