import React from 'react';
import { Info, Play, Clock } from 'lucide-react';
import { MarketItem } from '../types';
import { formatMarketResult } from '../utils/marketEngine';

export interface MarketCardProps {
  market: MarketItem;
  onPlay: (market: MarketItem) => void;
  onOpenChart: (marketName: string) => void;
}

/**
 * MarketCard component for displaying Matka market items and dynamic results.
 * 
 * Result Display Formatting:
 * Resolves declared and partial results from backend/admin state.
 * When open pana, jodi, and close pana are declared, dynamically displays
 * the full formatted result (e.g., "333 - 99 - 333") instead of masked asterisks (**),
 * ensuring complete results are cleanly shown on the user home screen.
 */
export const MarketCard: React.FC<MarketCardProps> = ({
  market,
  onPlay,
  onOpenChart,
}) => {
  const isClosed = !market.isOpen;
  const isRunningOpen = market.status === 'Running for Open';
  const isRunningClose = market.status === 'Running for Close';

  // Dynamically resolve full formatted result
  const result = formatMarketResult({
    openPana: market.openPana,
    jodi: market.jodi,
    closePana: market.closePana,
  });

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl p-4.5 border border-slate-200/90 dark:border-slate-800 shadow-xs relative transition-all hover:shadow-sm">
      {/* Card Top Row: Name + Info and Orange Play Button */}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-black text-base tracking-tight text-[#FF7700] truncate">
              {market.name}
            </h3>
            <button
              onClick={() => onOpenChart(market.name)}
              className="text-[#FF7700] hover:text-orange-700 dark:hover:text-orange-400 p-1 rounded-full cursor-pointer active:scale-90 transition-transform"
              title="View Panel & Jodi Chart"
              aria-label={`View chart for ${market.name}`}
            >
              <Info className="w-4 h-4" />
            </button>
          </div>

          {/* Triplet Result with dynamic format resolution (e.g., 333 - 99 - 333) */}
          <div
            className="text-lg font-black font-mono tracking-tight mt-1 flex items-center gap-1.5 text-slate-950 dark:text-slate-100"
            data-testid="market-result-display"
          >
            <span className="font-extrabold">{result.openPana}</span>
            <span className="text-slate-400 font-normal">-</span>
            <span
              className={`font-black ${
                result.jodi !== '**' && !result.jodi.includes('*')
                  ? 'text-[#FF7700] dark:text-orange-400'
                  : 'text-slate-700 dark:text-slate-300'
              }`}
            >
              {result.jodi}
            </span>
            <span className="text-slate-400 font-normal">-</span>
            <span className="font-extrabold">{result.closePana}</span>
          </div>
        </div>

        {/* Orange Play Button for Active/Running Markets */}
        <button
          onClick={() => onPlay(market)}
          disabled={isClosed}
          className={`px-6 py-2.5 rounded-full font-black text-xs flex items-center gap-1.5 transition-all shadow-sm shrink-0 ${
            !isClosed
              ? 'bg-[#FF7700] hover:bg-[#E65100] text-white active:scale-95 cursor-pointer shadow-orange-500/25 hover:shadow-md'
              : 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-500 shadow-none cursor-not-allowed'
          }`}
        >
          <Play
            className={`w-3.5 h-3.5 ${
              !isClosed ? 'fill-white text-white' : 'fill-slate-400 text-slate-400'
            }`}
          />
          <span>Play</span>
        </button>
      </div>

      {/* Countdown & Session info pill */}
      <div className="mt-3 flex items-center justify-between gap-2">
        <span
          className={`px-3 py-1 rounded-full text-[11px] font-bold flex items-center gap-1.5 ${
            isRunningOpen
              ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/60'
              : isRunningClose
              ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800/60'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-700'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>{market.countdownText || market.status}</span>
        </span>

        <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 shrink-0">
          {market.allowedSession === 'all' && '🟢 Open & Close'}
          {market.allowedSession === 'close_only' && '🟡 Close Only'}
          {market.allowedSession === 'none' && '🔴 Closed'}
        </span>
      </div>

      {/* Hairline Divider */}
      <div className="my-3 border-t border-slate-100 dark:border-slate-800" />

      {/* Card Bottom Row: Timings & Status */}
      <div className="flex items-end justify-between text-xs gap-2">
        <div className="space-y-0.5 text-slate-500 dark:text-slate-400 font-medium text-[11px]">
          <div>
            Open Bids :{' '}
            <span className="font-bold text-slate-700 dark:text-slate-300">
              {market.openTime}
            </span>
          </div>
          <div>
            Close Bids :{' '}
            <span className="font-bold text-slate-700 dark:text-slate-300">
              {market.closeTime}
            </span>
          </div>
        </div>

        <div>
          <span
            className={`font-black text-xs ${
              isRunningOpen
                ? 'text-emerald-600 dark:text-emerald-400'
                : isRunningClose
                ? 'text-amber-600 dark:text-amber-400'
                : 'text-rose-600 dark:text-rose-400'
            }`}
          >
            {market.status}
          </span>
        </div>
      </div>
    </div>
  );
};
