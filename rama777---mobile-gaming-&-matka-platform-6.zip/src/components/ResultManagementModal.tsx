import React, { useState } from 'react';
import {
  X,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Trophy,
  Calendar,
  Clock,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';
import { MarketItem } from '../types';
import {
  declareMarketResult,
  formatDateDisplay,
} from '../services/marketResultService';
import { formatMarketResult, getDigitFromPana } from '../utils/marketEngine';

interface ResultManagementModalProps {
  markets: MarketItem[];
  currentTime: Date;
  onClose: () => void;
  onOpenChart?: (marketName: string) => void;
}

export const ResultManagementModal: React.FC<ResultManagementModalProps> = ({
  markets,
  currentTime,
  onClose,
  onOpenChart,
}) => {
  const [selectedMarketId, setSelectedMarketId] = useState<string>(
    markets[0]?.id || 'kalyan'
  );
  const [openPanaInput, setOpenPanaInput] = useState<string>('');
  const [closePanaInput, setClosePanaInput] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  const selectedMarket = markets.find((m) => m.id === selectedMarketId) || markets[0];

  // Derived calculations
  const formatted = selectedMarket ? formatMarketResult(selectedMarket) : null;
  const currentOpenDigit =
    openPanaInput.length === 3 ? getDigitFromPana(openPanaInput) : null;
  const currentCloseDigit =
    closePanaInput.length === 3 ? getDigitFromPana(closePanaInput) : null;
  const previewJodi =
    currentOpenDigit !== null && currentCloseDigit !== null
      ? `${currentOpenDigit}${currentCloseDigit}`
      : currentOpenDigit !== null
      ? `${currentOpenDigit}*`
      : currentCloseDigit !== null
      ? `*${currentCloseDigit}`
      : '**';

  // Declare Open Pana
  const handleDeclareOpen = async () => {
    if (openPanaInput.length !== 3 || !/^\d{3}$/.test(openPanaInput)) {
      setStatusMessage({
        type: 'error',
        text: 'Please enter a valid 3-digit Open Pana (e.g. 140, 238, 560)',
      });
      return;
    }

    setIsSubmitting(true);
    setStatusMessage(null);

    try {
      const res = await declareMarketResult({
        marketId: selectedMarket.id,
        marketName: selectedMarket.name,
        openPana: openPanaInput,
        closePana: selectedMarket.closePana !== '***' ? selectedMarket.closePana : undefined,
        date: currentTime,
        action: 'declare_open',
      });

      if (res.success) {
        setStatusMessage({
          type: 'success',
          text: `Open Pana ${openPanaInput} declared! Open Digit: ${currentOpenDigit}. Jodi updated to ${res.marketResult.jodi}. Market transitioned to Close session.`,
        });
        setOpenPanaInput('');
      }
    } catch {
      setStatusMessage({
        type: 'error',
        text: 'Failed to sync result to database. Please retry.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Declare Close Pana
  const handleDeclareClose = async () => {
    if (closePanaInput.length !== 3 || !/^\d{3}$/.test(closePanaInput)) {
      setStatusMessage({
        type: 'error',
        text: 'Please enter a valid 3-digit Close Pana (e.g. 180, 333, 470)',
      });
      return;
    }

    setIsSubmitting(true);
    setStatusMessage(null);

    try {
      const existingOpen =
        selectedMarket.openPana !== '***' ? selectedMarket.openPana : '140';

      const res = await declareMarketResult({
        marketId: selectedMarket.id,
        marketName: selectedMarket.name,
        openPana: existingOpen,
        closePana: closePanaInput,
        date: currentTime,
        action: 'declare_close',
      });

      if (res.success) {
        setStatusMessage({
          type: 'success',
          text: `Close Pana ${closePanaInput} declared! Full Result: ${existingOpen} - ${res.marketResult.jodi} - ${closePanaInput}. Market closed for today and synced into Chart History.`,
        });
        setClosePanaInput('');
      }
    } catch {
      setStatusMessage({
        type: 'error',
        text: 'Failed to sync close result. Please retry.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Declare Full Result (Open + Close together)
  const handleDeclareFull = async () => {
    if (
      openPanaInput.length !== 3 ||
      closePanaInput.length !== 3 ||
      !/^\d{3}$/.test(openPanaInput) ||
      !/^\d{3}$/.test(closePanaInput)
    ) {
      setStatusMessage({
        type: 'error',
        text: 'Enter both 3-digit Open Pana and 3-digit Close Pana (e.g. 140 and 180)',
      });
      return;
    }

    setIsSubmitting(true);
    setStatusMessage(null);

    try {
      const res = await declareMarketResult({
        marketId: selectedMarket.id,
        marketName: selectedMarket.name,
        openPana: openPanaInput,
        closePana: closePanaInput,
        date: currentTime,
        action: 'declare_full',
      });

      if (res.success) {
        setStatusMessage({
          type: 'success',
          text: `Full Result declared: ${openPanaInput} - ${res.marketResult.jodi} - ${closePanaInput}! Home card and charts updated automatically.`,
        });
        setOpenPanaInput('');
        setClosePanaInput('');
      }
    } catch {
      setStatusMessage({
        type: 'error',
        text: 'Failed to declare full result.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Automated Day Rollover / Market Reset
  const handleResetForNewDay = async () => {
    setIsSubmitting(true);
    setStatusMessage(null);

    try {
      const res = await declareMarketResult({
        marketId: selectedMarket.id,
        marketName: selectedMarket.name,
        date: currentTime,
        action: 'reset_day',
      });

      if (res.success) {
        setStatusMessage({
          type: 'success',
          text: `${selectedMarket.name} successfully reset for the new day! Status: Running for Open (*** - ** - ***). Active bidding inputs cleared.`,
        });
        setOpenPanaInput('');
        setClosePanaInput('');
      }
    } catch {
      setStatusMessage({
        type: 'error',
        text: 'Failed to reset market session.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3.5 bg-black/60 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-orange-100 dark:bg-orange-950/60 text-[#FF7700] flex items-center justify-center">
              <Trophy className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-black text-sm text-slate-900 dark:text-slate-100">
                Result Management & Live Declaration
              </h3>
              <p className="text-[10px] text-slate-400">
                Real-time chart sync & automated session reset
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Market Selector */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center justify-between">
            <span>Select Market:</span>
            <span className="text-[10px] text-slate-400 font-normal">
              {formatDateDisplay(currentTime)}
            </span>
          </label>
          <select
            value={selectedMarketId}
            onChange={(e) => {
              setSelectedMarketId(e.target.value);
              setStatusMessage(null);
            }}
            className="w-full h-11 px-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-slate-100 focus:outline-hidden focus:border-[#FF7700]"
          >
            {markets.map((m) => (
              <option key={m.id} value={m.id}>
                {m.name} ({m.openTime} - {m.closeTime})
              </option>
            ))}
          </select>
        </div>

        {/* Current Live State Card */}
        {selectedMarket && formatted && (
          <div className="bg-gradient-to-br from-orange-50 to-amber-50 dark:from-orange-950/20 dark:to-slate-900 rounded-2xl p-3.5 border border-orange-200/80 dark:border-orange-900/50 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-extrabold text-xs text-[#FF7700]">
                {selectedMarket.name}
              </span>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  selectedMarket.status === 'Running for Open'
                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                    : selectedMarket.status === 'Running for Close'
                    ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
                    : 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                }`}
              >
                {selectedMarket.status}
              </span>
            </div>

            {/* Triplet Result */}
            <div className="flex items-center justify-center gap-3 py-2 bg-white/80 dark:bg-slate-900/80 rounded-xl border border-orange-200/40">
              <div className="text-center">
                <div className="text-[9px] uppercase font-bold text-slate-400">Open Pana</div>
                <div className="text-base font-black font-mono text-slate-900 dark:text-slate-100">
                  {formatted.openPana}
                </div>
              </div>
              <span className="text-slate-300 font-bold">-</span>
              <div className="text-center">
                <div className="text-[9px] uppercase font-bold text-slate-400">Jodi</div>
                <div className="text-base font-black font-mono text-[#FF7700]">
                  {formatted.jodi}
                </div>
              </div>
              <span className="text-slate-300 font-bold">-</span>
              <div className="text-center">
                <div className="text-[9px] uppercase font-bold text-slate-400">Close Pana</div>
                <div className="text-base font-black font-mono text-slate-900 dark:text-slate-100">
                  {formatted.closePana}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-[10px] text-slate-500 font-medium pt-1">
              <span>Open: {selectedMarket.openTime}</span>
              <span>Close: {selectedMarket.closeTime}</span>
              {onOpenChart && (
                <button
                  onClick={() => {
                    onClose();
                    onOpenChart(selectedMarket.name);
                  }}
                  className="text-[#FF7700] font-bold hover:underline cursor-pointer"
                >
                  View Chart →
                </button>
              )}
            </div>
          </div>
        )}

        {/* Live Preview Bar */}
        {(openPanaInput || closePanaInput) && (
          <div className="bg-slate-100 dark:bg-slate-800/80 rounded-xl p-2.5 text-center text-xs">
            <span className="text-slate-500 text-[10px] uppercase font-bold block mb-0.5">
              Derived Result Preview
            </span>
            <span className="font-mono font-black text-sm text-slate-900 dark:text-slate-100">
              {openPanaInput || '***'} -{' '}
              <span className="text-[#FF7700] font-black">{previewJodi}</span> -{' '}
              {closePanaInput || '***'}
            </span>
          </div>
        )}

        {/* Inputs & Actions */}
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2.5">
            {/* Open Pana Input */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300">
                Open Pana (3 digits)
              </label>
              <input
                type="text"
                maxLength={3}
                placeholder="e.g. 140"
                value={openPanaInput}
                onChange={(e) => setOpenPanaInput(e.target.value.replace(/\D/g, ''))}
                className="w-full h-11 px-3 text-center text-sm font-mono font-black rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-hidden focus:border-[#FF7700]"
              />
              <button
                onClick={handleDeclareOpen}
                disabled={isSubmitting || openPanaInput.length !== 3}
                className="w-full py-2 rounded-xl bg-orange-600 hover:bg-orange-700 disabled:opacity-40 text-white font-bold text-xs transition-all cursor-pointer"
              >
                Declare Open
              </button>
            </div>

            {/* Close Pana Input */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300">
                Close Pana (3 digits)
              </label>
              <input
                type="text"
                maxLength={3}
                placeholder="e.g. 180"
                value={closePanaInput}
                onChange={(e) => setClosePanaInput(e.target.value.replace(/\D/g, ''))}
                className="w-full h-11 px-3 text-center text-sm font-mono font-black rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-hidden focus:border-[#FF7700]"
              />
              <button
                onClick={handleDeclareClose}
                disabled={isSubmitting || closePanaInput.length !== 3}
                className="w-full py-2 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-40 text-white font-bold text-xs transition-all cursor-pointer"
              >
                Declare Close
              </button>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              onClick={handleDeclareFull}
              disabled={
                isSubmitting || openPanaInput.length !== 3 || closePanaInput.length !== 3
              }
              className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-black text-xs disabled:opacity-40 flex items-center justify-center gap-1.5 shadow-xs cursor-pointer active:scale-95"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Declare Full</span>
            </button>

            <button
              onClick={handleResetForNewDay}
              disabled={isSubmitting}
              className="py-2.5 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 border border-slate-200 dark:border-slate-700"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Next Day Reset</span>
            </button>
          </div>
        </div>

        {/* Feedback Message */}
        {statusMessage && (
          <div
            className={`p-3 rounded-2xl text-xs flex items-start gap-2.5 ${
              statusMessage.type === 'success'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200 border border-emerald-200 dark:border-emerald-800'
                : 'bg-red-50 dark:bg-red-950/40 text-red-800 dark:text-red-200 border border-red-200 dark:border-red-800'
            }`}
          >
            {statusMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
            )}
            <span className="leading-snug">{statusMessage.text}</span>
          </div>
        )}

        {/* Informational Footer */}
        <div className="bg-slate-50 dark:bg-slate-800/40 rounded-xl p-2.5 text-[10px] text-slate-400 space-y-1">
          <p className="flex items-center gap-1 font-semibold text-slate-500 dark:text-slate-300">
            <TrendingUp className="w-3 h-3 text-[#FF7700]" />
            Live Sync Guarantees:
          </p>
          <p>• Declaring Open automatically transitions market to Close Session.</p>
          <p>• Declaring Close completes Jodi and auto-populates Panel & Jodi Charts.</p>
          <p>• Next Day Reset clears active slips, sets Open state & archives past draws.</p>
        </div>
      </div>
    </div>
  );
};
