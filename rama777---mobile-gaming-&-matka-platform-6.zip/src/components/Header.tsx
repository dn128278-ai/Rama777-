import React from 'react';
import { Menu, Bell, Wallet } from 'lucide-react';
import { MainTab } from '../types';

interface HeaderProps {
  currentTab: MainTab;
  walletBalance: number;
  unreadNotificationsCount: number;
  onOpenDrawer: () => void;
  onOpenNotifications: () => void;
  onNavigateToFunds: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  walletBalance,
  unreadNotificationsCount,
  onOpenDrawer,
  onOpenNotifications,
  onNavigateToFunds,
}) => {
  const getTabTitle = () => {
    switch (currentTab) {
      case 'history':
        return 'History';
      case 'passbook':
        return 'Passbook';
      case 'funds':
        return 'Funds';
      case 'support':
        return 'Support';
      default:
        return null;
    }
  };

  const title = getTabTitle();

  return (
    <header
      style={{ flexShrink: 0 }}
      className="shrink-0 z-30 bg-white dark:bg-slate-900 border-b border-slate-200/90 dark:border-slate-800 px-4 py-3 flex items-center justify-between transition-colors shadow-2xs"
    >
      {/* Left: Hamburger Menu and Title or Logo */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenDrawer}
          className="w-10 h-10 rounded-xl flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 active:scale-95 transition-all cursor-pointer"
          aria-label="Open menu"
        >
          <Menu className="w-6 h-6" />
        </button>

        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#E65100] to-[#FF7700] flex items-center justify-center shadow-xs">
            <span className="text-white font-extrabold text-base tracking-tighter">R</span>
          </div>
          <div>
            <span className="text-lg font-black tracking-tight text-[#FF7700] block leading-none">
              RAMA777
            </span>
            {title && (
              <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 block leading-none mt-0.5 uppercase tracking-wider">
                {title}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Right: Wallet Balance Pill with Wallet Icon & Bell Notification Icon */}
      <div className="flex items-center gap-2">
        <button
          onClick={onNavigateToFunds}
          className="bg-slate-100 hover:bg-orange-50 dark:bg-slate-800 dark:hover:bg-slate-700/80 border border-slate-200/70 dark:border-slate-700/70 rounded-full px-3 py-1 flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-2xs"
          title="View Wallet Funds"
        >
          <Wallet className="w-3.5 h-3.5 text-[#FF7700] shrink-0" />
          <span className="text-xs font-extrabold text-slate-900 dark:text-slate-100 font-mono tracking-tight">
            ₹{walletBalance}
          </span>
        </button>

        <button
          onClick={onOpenNotifications}
          className="relative w-10 h-10 rounded-xl flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 active:scale-95 transition-all cursor-pointer"
          aria-label="Notifications"
        >
          <Bell className="w-5 h-5" />
          {unreadNotificationsCount > 0 && (
            <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-[#FF7700] ring-2 ring-white dark:ring-slate-900" />
          )}
        </button>
      </div>
    </header>
  );
};
