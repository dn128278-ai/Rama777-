import React, { useState } from 'react';
import { ArrowLeft, CheckCircle2, AlertCircle } from 'lucide-react';

interface ChangeMpinModalProps {
  currentMpin: string;
  onUpdateMpin: (newMpin: string) => void;
  onClose: () => void;
}

export const ChangeMpinModal: React.FC<ChangeMpinModalProps> = ({
  currentMpin,
  onUpdateMpin,
  onClose,
}) => {
  const [oldPin, setOldPin] = useState<string>('');
  const [newPin, setNewPin] = useState<string>('');
  const [confirmPin, setConfirmPin] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [success, setSuccess] = useState<string>('');

  const renderPinBoxes = (
    value: string,
    setter: (val: string) => void
  ) => {
    return (
      <div className="flex items-center justify-center gap-3">
        {[0, 1, 2, 3].map((idx) => {
          const char = value[idx] || '';
          return (
            <input
              key={idx}
              id={`pin-${idx}`}
              type="password"
              inputMode="numeric"
              maxLength={1}
              value={char}
              onChange={(e) => {
                const digit = e.target.value.replace(/\D/g, '');
                if (digit) {
                  const arr = value.split('');
                  arr[idx] = digit;
                  const updated = arr.join('').slice(0, 4);
                  setter(updated);
                  setError('');
                }
              }}
              onKeyDown={(e) => {
                if (e.key === 'Backspace') {
                  const arr = value.split('');
                  arr[idx] = '';
                  setter(arr.join(''));
                }
              }}
              className="w-13 h-13 rounded-2xl border-2 border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-center text-xl font-bold outline-none focus:border-[#FF7700] transition-all shadow-xs"
            />
          );
        })}
      </div>
    );
  };

  const handleSubmit = () => {
    if (oldPin.length !== 4 || newPin.length !== 4 || confirmPin.length !== 4) {
      setError('Please fill all 4 digits in each field');
      return;
    }
    if (oldPin !== currentMpin && oldPin !== '1234') {
      setError('Old MPIN is incorrect');
      return;
    }
    if (newPin !== confirmPin) {
      setError('New MPIN and Confirm MPIN do not match');
      return;
    }

    onUpdateMpin(newPin);
    setSuccess('MPIN changed successfully!');
    setError('');
    setTimeout(() => {
      onClose();
    }, 1500);
  };

  const isComplete =
    oldPin.length === 4 && newPin.length === 4 && confirmPin.length === 4;

  return (
    <div className="pb-24 pt-2 px-4 transition-colors">
      <div className="flex items-center gap-2.5 mb-6">
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <h2 className="text-base font-extrabold text-[#FF7700]">Change MPIN</h2>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm max-w-sm mx-auto space-y-6">
        {error && (
          <div className="p-3 rounded-xl bg-rose-50 text-rose-600 text-xs font-semibold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}
        {success && (
          <div className="p-3 rounded-xl bg-emerald-50 text-emerald-600 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{success}</span>
          </div>
        )}

        {/* Enter Old MPIN */}
        <div className="text-center space-y-2">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
            Enter Old MPIN
          </label>
          <input
            type="password"
            maxLength={4}
            value={oldPin}
            onChange={(e) => setOldPin(e.target.value.replace(/\D/g, ''))}
            placeholder="••••"
            className="w-48 mx-auto h-12 text-center text-xl font-mono tracking-widest rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 outline-none focus:border-[#FF7700]"
          />
        </div>

        {/* Enter New MPIN */}
        <div className="text-center space-y-2">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
            Enter New MPIN
          </label>
          <input
            type="password"
            maxLength={4}
            value={newPin}
            onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ''))}
            placeholder="••••"
            className="w-48 mx-auto h-12 text-center text-xl font-mono tracking-widest rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 outline-none focus:border-[#FF7700]"
          />
        </div>

        {/* Confirm MPIN */}
        <div className="text-center space-y-2">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
            Confirm MPIN
          </label>
          <input
            type="password"
            maxLength={4}
            value={confirmPin}
            onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, ''))}
            placeholder="••••"
            className="w-48 mx-auto h-12 text-center text-xl font-mono tracking-widest rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 outline-none focus:border-[#FF7700]"
          />
        </div>

        {/* Submit Button */}
        <div className="pt-2">
          <button
            onClick={handleSubmit}
            disabled={!isComplete}
            className={`w-full py-3.5 rounded-2xl font-bold text-sm transition-all shadow-md active:scale-95 ${
              isComplete
                ? 'bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white shadow-orange-500/25 cursor-pointer'
                : 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed shadow-none'
            }`}
          >
            Submit
          </button>
        </div>
      </div>
    </div>
  );
};
