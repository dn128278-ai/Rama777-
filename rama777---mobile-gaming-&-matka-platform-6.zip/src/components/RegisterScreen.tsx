import React, { useState } from 'react';
import {
  User,
  Phone,
  Lock,
  Eye,
  EyeOff,
  Fingerprint,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  ArrowLeft,
  Sparkles,
} from 'lucide-react';
import { UserProfile } from '../types';
import { auth, signInWithPopup, GoogleAuthProvider, FirebaseUser } from '../firebase';
import { registerDeviceBiometric } from '../utils/biometricAuth';

interface RegisterScreenProps {
  onRegisterSuccess: (newUser: UserProfile) => void;
  onNavigateToLogin: () => void;
  onGoogleRegisterSuccess?: (firebaseUser: FirebaseUser) => void;
}

export const RegisterScreen: React.FC<RegisterScreenProps> = ({
  onRegisterSuccess,
  onNavigateToLogin,
  onGoogleRegisterSuccess,
}) => {
  const [name, setName] = useState<string>('');
  const [mobileNumber, setMobileNumber] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [mpin, setMpin] = useState<string>('');
  const [confirmMpin, setConfirmMpin] = useState<string>('');
  const [biometricEnabled, setBiometricEnabled] = useState<boolean>(true);
  const [isScanningFingerprint, setIsScanningFingerprint] = useState<boolean>(false);
  const [fingerprintRegistered, setFingerprintRegistered] = useState<boolean>(false);
  const [agreeTerms, setAgreeTerms] = useState<boolean>(true);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [successAnimation, setSuccessAnimation] = useState<boolean>(false);

  // Active sub-step or inline keypad for MPIN
  const [activeMpinField, setActiveMpinField] = useState<'mpin' | 'confirm'>('mpin');

  const handleMpinInput = (val: string, isConfirm: boolean) => {
    const clean = val.replace(/\D/g, '').slice(0, 4);
    if (isConfirm) {
      setConfirmMpin(clean);
    } else {
      setMpin(clean);
      if (clean.length === 4) {
        setActiveMpinField('confirm');
      }
    }
    setErrorMessage('');
  };

  const handleScanFingerprint = async () => {
    setIsScanningFingerprint(true);
    setErrorMessage('');
    try {
      const result = await registerDeviceBiometric(
        mobileNumber.trim() || 'user_' + Date.now(),
        name.trim() || 'New User'
      );
      if (result.success) {
        setFingerprintRegistered(true);
        setBiometricEnabled(true);
      } else {
        setErrorMessage(result.message || 'Fingerprint registration was not completed on this device.');
      }
    } catch (err: any) {
      console.warn('Biometric registration error:', err);
      setErrorMessage(err.message || 'Device fingerprint prompt failed.');
    } finally {
      setIsScanningFingerprint(false);
    }
  };

  const [isGoogleSigningUp, setIsGoogleSigningUp] = useState<boolean>(false);

  const handleGoogleSignUp = async () => {
    if (!auth) {
      setErrorMessage('Authentication service is initializing. Please register with mobile number.');
      return;
    }
    setIsGoogleSigningUp(true);
    setErrorMessage('');
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      if (result.user) {
        if (onGoogleRegisterSuccess) {
          onGoogleRegisterSuccess(result.user);
        } else {
          const newUser: UserProfile = {
            name: result.user.displayName || 'User',
            phone: mobileNumber || '9876543210',
            walletBalance: 100,
            mpin: mpin || '1234',
            biometricEnabled: true,
            appVersion: '2',
            email: result.user.email || undefined,
          };
          onRegisterSuccess(newUser);
        }
      }
    } catch (err: any) {
      console.warn('Google sign up error:', err);
      if (err.code === 'auth/popup-closed-by-user') {
        setErrorMessage('Google sign-up popup was closed.');
      } else {
        setErrorMessage(err.message || 'Google Sign-Up failed.');
      }
    } finally {
      setIsGoogleSigningUp(false);
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim()) {
      setErrorMessage('Please enter your full name');
      return;
    }
    if (mobileNumber.length !== 10) {
      setErrorMessage('Please enter a valid 10-digit mobile number');
      return;
    }
    if (password.length < 6) {
      setErrorMessage('Password must be at least 6 characters');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMessage('Passwords do not match');
      return;
    }
    if (mpin.length !== 4) {
      setErrorMessage('Please set a 4-digit MPIN');
      return;
    }
    if (mpin !== confirmMpin) {
      setErrorMessage('MPIN and Confirm MPIN do not match');
      return;
    }
    if (!agreeTerms) {
      setErrorMessage('Please agree to the Terms & Conditions');
      return;
    }

    setErrorMessage('');
    setSuccessAnimation(true);

    const newUser: UserProfile = {
      name: name.trim(),
      phone: mobileNumber,
      walletBalance: 100, // Welcome Bonus ₹100!
      mpin,
      biometricEnabled,
      appVersion: '2',
    };

    setTimeout(() => {
      onRegisterSuccess(newUser);
    }, 1200);
  };

  return (
    <div className="min-h-full flex flex-col justify-between bg-[#F4F5F7] dark:bg-slate-950 text-slate-800 dark:text-slate-100 transition-colors pb-8">
      {/* Top Header */}
      <div className="pt-6 pb-2 px-5 flex items-center justify-between">
        <button
          onClick={onNavigateToLogin}
          className="w-10 h-10 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 flex items-center justify-center shadow-xs active:scale-95 transition-all cursor-pointer"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#E65100] to-[#FF7700] flex items-center justify-center shadow-xs">
            <span className="text-white font-extrabold text-base tracking-tighter">R</span>
          </div>
          <span className="text-xl font-black tracking-tight text-[#FF7700]">RAMA777</span>
        </div>

        <div className="w-10" />
      </div>

      {/* Main Registration Card */}
      <div className="px-5 w-full max-w-sm mx-auto flex-1 flex flex-col justify-center my-2">
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-200/80 dark:border-slate-800">
          <div className="text-center mb-5">
            <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
              New Registration
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Create your account & get ₹100 Welcome Bonus
            </p>
          </div>

          {errorMessage && (
            <div className="mb-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 text-xs font-semibold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successAnimation && (
            <div className="mb-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 text-xs font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Account created successfully! Logging you in...</span>
            </div>
          )}

          <form onSubmit={handleRegister} className="space-y-4">
            {/* Field 1: Full Name */}
            <div>
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                Full Name
              </label>
              <div className="flex items-center border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/80 focus-within:border-[#FF7700] transition-colors">
                <User className="w-4 h-4 text-slate-400 mr-2.5 shrink-0" />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Girish Meena"
                  className="bg-transparent text-xs font-semibold text-slate-900 dark:text-slate-100 outline-none w-full"
                />
              </div>
            </div>

            {/* Field 2: Mobile Number */}
            <div>
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                Mobile Number
              </label>
              <div className="flex items-center border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/80 focus-within:border-[#FF7700] transition-colors">
                <span className="text-xs font-bold text-slate-500 mr-2 border-r border-slate-300 dark:border-slate-700 pr-2">
                  +91
                </span>
                <input
                  type="tel"
                  maxLength={10}
                  value={mobileNumber}
                  onChange={(e) => setMobileNumber(e.target.value.replace(/\D/g, ''))}
                  placeholder="6377972674"
                  className="bg-transparent text-xs font-semibold font-mono text-slate-900 dark:text-slate-100 outline-none w-full"
                />
              </div>
            </div>

            {/* Field 3: Password */}
            <div>
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                Password
              </label>
              <div className="flex items-center border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/80 focus-within:border-[#FF7700] transition-colors">
                <Lock className="w-4 h-4 text-slate-400 mr-2.5 shrink-0" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Min 6 characters"
                  className="bg-transparent text-xs font-semibold text-slate-900 dark:text-slate-100 outline-none w-full"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Field 4: Confirm Password */}
            <div>
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                Confirm Password
              </label>
              <div className="flex items-center border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/80 focus-within:border-[#FF7700] transition-colors">
                <Lock className="w-4 h-4 text-slate-400 mr-2.5 shrink-0" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-enter password"
                  className="bg-transparent text-xs font-semibold text-slate-900 dark:text-slate-100 outline-none w-full"
                />
              </div>
            </div>

            {/* Field 5: Setting up 4-digit MPIN */}
            <div className="pt-1">
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-2 text-center">
                Set 4-Digit MPIN for Fast Login
              </label>

              <div className="grid grid-cols-2 gap-3 mb-2">
                {/* MPIN Boxes */}
                <div>
                  <span className="text-[10px] font-semibold text-slate-400 block text-center mb-1">
                    4-Digit MPIN
                  </span>
                  <div className="flex justify-center gap-1.5">
                    {[0, 1, 2, 3].map((idx) => (
                      <div
                        key={idx}
                        className={`w-9 h-10 rounded-xl flex items-center justify-center border-2 font-mono font-bold text-sm transition-all ${
                          mpin.length > idx
                            ? 'border-[#FF7700] bg-orange-50/50 dark:bg-orange-950/20 text-[#FF7700]'
                            : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800'
                        }`}
                      >
                        {mpin[idx] ? '•' : ''}
                      </div>
                    ))}
                  </div>
                  <input
                    type="password"
                    maxLength={4}
                    value={mpin}
                    onChange={(e) => handleMpinInput(e.target.value, false)}
                    placeholder="1234"
                    className="w-full mt-1.5 text-center text-xs font-mono font-bold py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:border-[#FF7700]"
                  />
                </div>

                {/* Confirm MPIN Boxes */}
                <div>
                  <span className="text-[10px] font-semibold text-slate-400 block text-center mb-1">
                    Confirm MPIN
                  </span>
                  <div className="flex justify-center gap-1.5">
                    {[0, 1, 2, 3].map((idx) => (
                      <div
                        key={idx}
                        className={`w-9 h-10 rounded-xl flex items-center justify-center border-2 font-mono font-bold text-sm transition-all ${
                          confirmMpin.length > idx
                            ? 'border-[#FF7700] bg-orange-50/50 dark:bg-orange-950/20 text-[#FF7700]'
                            : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800'
                        }`}
                      >
                        {confirmMpin[idx] ? '•' : ''}
                      </div>
                    ))}
                  </div>
                  <input
                    type="password"
                    maxLength={4}
                    value={confirmMpin}
                    onChange={(e) => handleMpinInput(e.target.value, true)}
                    placeholder="1234"
                    className="w-full mt-1.5 text-center text-xs font-mono font-bold py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:border-[#FF7700]"
                  />
                </div>
              </div>
            </div>

            {/* Field 6: Fingerprint Integration Section */}
            <div className="bg-slate-50 dark:bg-slate-800/60 rounded-2xl p-3 border border-slate-200 dark:border-slate-700/80">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Fingerprint className="w-4 h-4 text-[#FF7700]" />
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    Fingerprint Integration
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setBiometricEnabled(!biometricEnabled)}
                  className={`w-9 h-5 flex items-center rounded-full p-0.5 cursor-pointer transition-colors ${
                    biometricEnabled ? 'bg-[#FF7700]' : 'bg-slate-300 dark:bg-slate-600'
                  }`}
                >
                  <div
                    className={`bg-white w-4 h-4 rounded-full shadow-sm transform transition-transform ${
                      biometricEnabled ? 'translate-x-4' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {biometricEnabled && (
                <div className="text-center pt-1">
                  <button
                    type="button"
                    onClick={handleScanFingerprint}
                    disabled={isScanningFingerprint}
                    className="flex items-center justify-center gap-2 mx-auto px-4 py-2 rounded-xl bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 hover:border-[#FF7700] text-xs font-bold text-slate-700 dark:text-slate-200 active:scale-95 transition-all cursor-pointer shadow-2xs"
                  >
                    {fingerprintRegistered ? (
                      <>
                        <ShieldCheck className="w-4 h-4 text-emerald-500" />
                        <span className="text-emerald-600 dark:text-emerald-400">
                          Fingerprint Enrolled
                        </span>
                      </>
                    ) : isScanningFingerprint ? (
                      <>
                        <Fingerprint className="w-4 h-4 text-[#FF7700] animate-pulse" />
                        <span>Scanning Fingerprint...</span>
                      </>
                    ) : (
                      <>
                        <Fingerprint className="w-4 h-4 text-[#FF7700]" />
                        <span>Touch to Enroll Fingerprint</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>

            {/* Terms and conditions */}
            <div className="flex items-start gap-2 pt-1">
              <input
                type="checkbox"
                id="terms"
                checked={agreeTerms}
                onChange={(e) => setAgreeTerms(e.target.checked)}
                className="mt-0.5 rounded border-slate-300 text-[#FF7700] focus:ring-[#FF7700]"
              />
              <label htmlFor="terms" className="text-[11px] text-slate-500 dark:text-slate-400">
                I agree to the Terms & Conditions and certify that I am 18+ years of age.
              </label>
            </div>

            {/* Submit Registration Button */}
            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-bold text-sm shadow-md shadow-orange-500/25 hover:brightness-105 active:scale-95 transition-all cursor-pointer"
            >
              Register & Setup MPIN
            </button>

            {/* Divider */}
            <div className="flex items-center gap-2 my-2 w-full">
              <div className="flex-1 h-px bg-slate-200 dark:bg-slate-800" />
              <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">or</span>
              <div className="flex-1 h-px bg-slate-200 dark:bg-slate-800" />
            </div>

            {/* Google Sign-up Button */}
            <button
              type="button"
              onClick={handleGoogleSignUp}
              disabled={isGoogleSigningUp}
              className="w-full py-2.5 px-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center justify-center gap-2 shadow-xs hover:border-[#FF7700] active:scale-[0.98] transition-all cursor-pointer"
            >
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              {isGoogleSigningUp ? 'Signing up with Google...' : 'Sign up with Google'}
            </button>
          </form>
        </div>

        {/* Link back to login */}
        <div className="mt-4 text-center">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Already have an account?{' '}
            <button
              onClick={onNavigateToLogin}
              className="font-bold text-[#FF7700] hover:underline cursor-pointer ml-1"
            >
              Login with MPIN
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};
