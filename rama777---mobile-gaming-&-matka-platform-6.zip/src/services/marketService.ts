import { collection, onSnapshot, DocumentData, QuerySnapshot } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { MarketItem } from '../types';
import {
  evaluateMarkets,
  formatRemainingDuration,
  parseTimeString,
  formatMarketResult,
} from '../utils/marketEngine';

/**
 * Evaluates dynamic status and countdown for a MarketItem given a specific reference time.
 * If the admin explicitly provided custom results (openPana, jodi, closePana), status, or isOpen,
 * those admin values are honored while countdowns update dynamically.
 */
export function evaluateSingleMarket(
  market: MarketItem,
  currentTime: Date
): MarketItem {
  const year = currentTime.getFullYear();
  const month = currentTime.getMonth();
  const day = currentTime.getDate();
  const nowMs = currentTime.getTime();
  const currentDateKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

  // If market belongs to a previous date and we are in a new day before open time, automatically reset
  const isPreviousDay = market.marketDate && market.marketDate !== currentDateKey;

  // Ensure result fields are dynamically resolved and complete
  const formattedRes = formatMarketResult({
    openPana: isPreviousDay ? '***' : market.openPana,
    jodi: isPreviousDay ? '**' : market.jodi,
    closePana: isPreviousDay ? '***' : market.closePana,
  });

  const parsedOpen =
    market.openHour !== undefined && market.openMinute !== undefined
      ? { hour: market.openHour, minute: market.openMinute }
      : parseTimeString(market.openTime);

  const parsedClose =
    market.closeHour !== undefined && market.closeMinute !== undefined
      ? { hour: market.closeHour, minute: market.closeMinute }
      : parseTimeString(market.closeTime);

  // If time could not be parsed, return market as-is with fallback
  if (!parsedOpen || !parsedClose) {
    return {
      ...market,
      openPana: formattedRes.openPana,
      jodi: formattedRes.jodi,
      closePana: formattedRes.closePana,
      isOpen: market.isOpen ?? true,
      countdownText: market.countdownText || market.status || 'Active',
      marketDate: currentDateKey,
    };
  }

  const openHour = parsedOpen.hour;
  const openMinute = parsedOpen.minute;
  const closeHour = parsedClose.hour;
  const closeMinute = parsedClose.minute;

  const crossesMidnight =
    closeHour < openHour || (closeHour === openHour && closeMinute < openMinute);

  const openDateTime = new Date(year, month, day, openHour, openMinute, 0, 0);
  const closeDateTime = crossesMidnight
    ? new Date(year, month, day + 1, closeHour, closeMinute, 0, 0)
    : new Date(year, month, day, closeHour, closeMinute, 0, 0);

  const openMs = openDateTime.getTime();
  const closeMs = closeDateTime.getTime();

  let autoStatus: 'Running for Open' | 'Running for Close' | 'Closed for Today';
  let autoIsOpen: boolean;
  let autoAllowedSession: 'all' | 'close_only' | 'none';
  let countdownText: string;
  let timeRemainingMs: number;

  if (nowMs < openMs) {
    autoStatus = 'Running for Open';
    autoIsOpen = true;
    autoAllowedSession = 'all';
    timeRemainingMs = openMs - nowMs;
    countdownText = `Open Bids close in ${formatRemainingDuration(timeRemainingMs)}`;
  } else if (nowMs >= openMs && nowMs < closeMs) {
    autoStatus = 'Running for Close';
    autoIsOpen = true;
    autoAllowedSession = 'close_only';
    timeRemainingMs = closeMs - nowMs;
    countdownText = `Close Bids close in ${formatRemainingDuration(timeRemainingMs)}`;
  } else {
    autoStatus = 'Closed for Today';
    autoIsOpen = false;
    autoAllowedSession = 'none';
    timeRemainingMs = 0;
    countdownText = `Closed • Next Open tomorrow at ${market.openTime}`;
  }

  // Admin overrides if explicitly set in Firestore database for TODAY's date
  const status = (market as any).isDisabled
    ? 'Closed for Today'
    : !isPreviousDay && market.status
    ? market.status
    : autoStatus;

  const isOpen = (market as any).isDisabled
    ? false
    : !isPreviousDay && typeof market.isOpen === 'boolean'
    ? market.isOpen
    : status === 'Closed for Today'
    ? false
    : autoIsOpen;

  const allowedSession =
    !isPreviousDay && market.allowedSession
      ? market.allowedSession
      : (!isOpen
      ? 'none'
      : status === 'Running for Close'
      ? 'close_only'
      : autoAllowedSession);

  return {
    ...market,
    openPana: formattedRes.openPana,
    jodi: formattedRes.jodi,
    closePana: formattedRes.closePana,
    openHour,
    openMinute,
    closeHour,
    closeMinute,
    status,
    isOpen,
    allowedSession,
    timeRemainingMs,
    countdownText: (market as any).isDisabled
      ? 'Market Temporarily Closed'
      : market.countdownText && !isPreviousDay
      ? market.countdownText
      : countdownText,
    marketDate: currentDateKey,
  };
}

/**
 * Transforms a Firestore Document from the Netlify Admin Panel into a normalized MarketItem
 */
export function transformFirestoreDocToMarket(
  docId: string,
  data: DocumentData,
  currentTime: Date
): MarketItem {
  const name = (
    data.name ||
    data.marketName ||
    data.market_name ||
    data.title ||
    docId
  )
    .toString()
    .trim()
    .toUpperCase();

  const openTime = (data.openTime || data.open_time || data.open || '10:00 AM').toString().trim();
  const closeTime = (data.closeTime || data.close_time || data.close || '12:00 PM').toString().trim();

  // Weekend schedules from Admin Panel
  const dayOfWeek = currentTime.getDay(); // 0 is Sunday, 6 is Saturday
  const isSaturday = dayOfWeek === 6;
  const isSunday = dayOfWeek === 0;
  const isWeekendClosed =
    (isSaturday && data.saturdayOpen === false) || (isSunday && data.sundayOpen === false);

  const isDisabled = Boolean(data.isDisabled) || isWeekendClosed;

  // Derive Jodi from openDigit/closeDigit if provided
  let derivedJodi = data.jodi ?? data.jodi_digit ?? data.jodiResult ?? data.jodiDigit;
  if (!derivedJodi && (data.openDigit || data.closeDigit)) {
    const oD = data.openDigit && data.openDigit !== '*' ? String(data.openDigit).trim() : '*';
    const cD = data.closeDigit && data.closeDigit !== '*' ? String(data.closeDigit).trim() : '*';
    if (oD !== '*' || cD !== '*') {
      derivedJodi = `${oD}${cD}`;
    }
  }

  // Dynamic result resolution from any admin schema field
  const formattedRes = formatMarketResult({
    openPana: data.openPana ?? data.open_pana ?? data.openPanna ?? data.open_panna ?? data.openResult,
    jodi: derivedJodi,
    closePana: data.closePana ?? data.close_pana ?? data.closePanna ?? data.close_panna ?? data.closeResult,
    result: data.formattedResult ?? data.result ?? data.marketResult ?? data.fullResult,
  });

  // Check explicit isOpenNow boolean from Netlify Admin Panel
  let explicitIsOpen: boolean | undefined = undefined;
  if (isDisabled) {
    explicitIsOpen = false;
  } else if (typeof data.isOpenNow === 'boolean') {
    explicitIsOpen = data.isOpenNow;
  } else if (typeof data.isOpen === 'boolean') {
    explicitIsOpen = data.isOpen;
  } else if (typeof data.is_open === 'boolean') {
    explicitIsOpen = data.is_open;
  }

  let explicitStatus = data.status || data.market_status;
  if (isDisabled) {
    explicitStatus = 'Closed for Today';
  } else if (!explicitStatus && explicitIsOpen === false) {
    explicitStatus = 'Closed for Today';
  }

  const rawItem: MarketItem = {
    id: docId,
    name,
    openPana: formattedRes.openPana,
    jodi: formattedRes.jodi,
    closePana: formattedRes.closePana,
    openTime,
    closeTime,
    status: explicitStatus as any,
    isOpen: explicitIsOpen as any,
    allowedSession: data.allowedSession,
    countdownText: isWeekendClosed
      ? 'Market Closed on Weekends'
      : isDisabled
      ? 'Market Temporarily Closed'
      : data.countdownText,
  };

  (rawItem as any).isDisabled = isDisabled;

  return evaluateSingleMarket(rawItem, currentTime);
}

/**
 * Subscribes to real-time updates from the Firebase Firestore 'markets' collection (rama777-37ef1)
 * using onSnapshot. Reflects any admin or database updates instantly.
 */
export function subscribeToRealtimeMarkets(
  onMarketsUpdate: (markets: MarketItem[], source: 'firestore' | 'fallback') => void,
  getCurrentTime: () => Date
): () => void {
  const collectionPath = 'markets';

  try {
    const marketsCol = collection(db, collectionPath);
    const unsubscribe = onSnapshot(
      marketsCol,
      (snapshot: QuerySnapshot<DocumentData>) => {
        const currentTime = getCurrentTime();

        if (snapshot.empty) {
          // If Firestore collection has no documents yet, use the default evaluated markets
          const fallback = evaluateMarkets(currentTime);
          onMarketsUpdate(fallback, 'fallback');
          return;
        }

        const items: MarketItem[] = [];
        snapshot.forEach((doc) => {
          const data = doc.data();
          const item = transformFirestoreDocToMarket(doc.id, data, currentTime);
          items.push(item);
        });

        // Sort items by custom order if available, or alphabetically by name
        items.sort((a, b) => {
          const orderA = (a as any).order ?? 999;
          const orderB = (b as any).order ?? 999;
          if (orderA !== orderB) return orderA - orderB;
          return a.name.localeCompare(b.name);
        });

        onMarketsUpdate(items, 'firestore');
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, collectionPath);
        // Fall back gracefully so UI is 100% stable
        const fallback = evaluateMarkets(getCurrentTime());
        onMarketsUpdate(fallback, 'fallback');
      }
    );

    return unsubscribe;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, collectionPath);
    const fallback = evaluateMarkets(getCurrentTime());
    onMarketsUpdate(fallback, 'fallback');
    return () => {};
  }
}
