import {
  collection,
  doc,
  onSnapshot,
  setDoc,
  addDoc,
  getDoc,
  DocumentData,
  QuerySnapshot,
  query,
  where,
  orderBy,
  limit,
} from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import {
  UserProfile,
  Transaction,
  FundHistoryItem,
  BankAccount,
  GameBid,
  AppNotification,
} from '../types';

export interface ManualUpiConfig {
  enabled: boolean;
  upiId: string;
  merchantName: string;
  qrCodeUrl: string;
  requireScreenshot?: boolean;
  instructions?: string;
}

export interface PaymentGatewayConfig {
  merchantVpa: string;
  merchantName: string;
  status: 'active' | 'maintenance';
  minDeposit: number;
  maxDeposit?: number;
  minWithdrawal: number;
  welcomeBonusEnabled: boolean;
  bonusAmount: number;
  activeGateway?: 'manual_upi' | 'phonepe' | 'paytm' | 'razorpay' | string;
  manualUpi?: ManualUpiConfig;
  phonepe?: {
    enabled?: boolean;
    merchantId?: string;
  };
  paytm?: {
    enabled?: boolean;
    mid?: string;
  };
  razorpay?: {
    enabled?: boolean;
    keyId?: string;
  };
  updatedAt?: string;
}

export const DEFAULT_GATEWAY_CONFIG: PaymentGatewayConfig = {
  merchantVpa: '0793748A0296660.bqr@kotak',
  merchantName: 'RAMA77 GAMING ENTERPRISES',
  status: 'active',
  minDeposit: 100,
  maxDeposit: 100000,
  minWithdrawal: 300,
  welcomeBonusEnabled: true,
  bonusAmount: 100,
  activeGateway: 'manual_upi',
  manualUpi: {
    enabled: true,
    upiId: '0793748A0296660.bqr@kotak',
    merchantName: 'RAMA77 GAMING ENTERPRISES',
    qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=upi://pay?pa=0793748A0296660.bqr@kotak&pn=RAMA77%20GAMING&cu=INR',
    requireScreenshot: true,
    instructions: 'Scan QR code or copy UPI ID. Pay using any UPI app (PhonePe, GPay, Paytm) and enter the 12-digit UTR/Ref No.',
  },
};

export interface UserAuthScope {
  uid: string;
  phone: string;
}

/**
 * Resolves the currently authenticated user's unique dynamic identifier.
 * Uses Firebase Auth UID (auth.currentUser.uid), user.uid, or registered mobile number.
 * Returns empty scope if unauthenticated.
 */
export function resolveUserAuthScope(userParam?: Partial<UserProfile> | string | null): UserAuthScope {
  let uid = '';
  let phone = '';

  // 1. Firebase Auth current user
  if (auth?.currentUser) {
    if (auth.currentUser.uid) {
      uid = auth.currentUser.uid.trim();
    }
    if (auth.currentUser.phoneNumber) {
      phone = auth.currentUser.phoneNumber.replace(/\D/g, '');
    }
  }

  // 2. Explicit argument
  if (typeof userParam === 'string') {
    const trimmed = userParam.trim();
    const digits = trimmed.replace(/\D/g, '');
    if (digits.length === 10) {
      phone = digits;
    }
    if (!uid) {
      uid = trimmed;
    }
  } else if (userParam && typeof userParam === 'object') {
    if (userParam.uid) uid = String(userParam.uid).trim();
    else if (userParam.id) uid = String(userParam.id).trim();

    if (userParam.phone) {
      const digits = String(userParam.phone).replace(/\D/g, '');
      if (digits) phone = digits;
    }
  }

  // 3. Persistent localStorage session
  if (!uid) {
    const storedUid = localStorage.getItem('rama777_user_uid');
    if (storedUid) uid = storedUid.trim();
  }
  if (!phone) {
    const storedPhone = localStorage.getItem('rama777_user_phone');
    if (storedPhone) {
      const digits = storedPhone.replace(/\D/g, '');
      if (digits) phone = digits;
    }
  }

  // If uid is not set but phone is known, use phone as the unique account ID
  if (!uid && phone) {
    uid = phone;
  }

  return { uid, phone };
}

export function getUserIdentifier(userOrPhone?: Partial<UserProfile> | string | null): string {
  const scope = resolveUserAuthScope(userOrPhone);
  return scope.uid || scope.phone;
}

/**
 * Strict data isolation predicate: confirms that a Firestore document belongs exclusively
 * to the currently authenticated user by checking UID, UserID, and mobile number.
 */
export function isDocumentOwnedByUser(data: DocumentData, scope: UserAuthScope): boolean {
  if (!scope.uid && !scope.phone) return false;

  const docUid = String(data.uid || data.userId || data.user_id || '').trim();
  const docPhone = String(data.userPhone || data.phone || data.mobile || data.mobileNumber || '').replace(/\D/g, '');

  // A document with neither UID nor Phone is unowned / legacy and must never be leaked
  if (!docUid && !docPhone) {
    return false;
  }

  // 1. Exact UID match
  if (scope.uid && docUid && docUid === scope.uid) {
    return true;
  }

  // 2. Exact Phone match (e.g. 10-digit mobile number)
  if (scope.phone && docPhone && docPhone === scope.phone) {
    return true;
  }

  // 3. Document UID is the user's phone or prefixed with user_
  if (scope.phone && docUid) {
    if (docUid === scope.phone || docUid === `user_${scope.phone}`) {
      return true;
    }
  }

  // 4. Scope UID is the doc phone or doc phone with user_
  if (scope.uid) {
    if (docPhone && (scope.uid === docPhone || scope.uid === `user_${docPhone}`)) {
      return true;
    }
    if (docUid && (`user_${docUid}` === scope.uid || docUid === `user_${scope.uid}`)) {
      return true;
    }
  }

  return false;
}

// ==========================================
// 1. User Profile & Live Wallet Sync ('users')
// ==========================================
export function subscribeToUserWallet(
  userParam: string | Partial<UserProfile>,
  onUpdate: (userData: Partial<UserProfile>) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);
  const targetId = scope.uid || scope.phone;

  if (!targetId) {
    onUpdate({ walletBalance: 0 });
    return () => {};
  }

  const userDocRef = doc(db, 'users', targetId);

  try {
    const unsubscribe = onSnapshot(
      userDocRef,
      (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();

          // Dynamic balance resolution (default 0 for fresh accounts)
          const walletBalance =
            typeof data.walletBalance === 'number'
              ? data.walletBalance
              : typeof data.wallet_balance === 'number'
              ? data.wallet_balance
              : typeof data.balance === 'number'
              ? data.balance
              : typeof data.points === 'number'
              ? data.points
              : 0;

          onUpdate({
            uid: targetId,
            id: targetId,
            name: data.name || data.userName || data.user_name || undefined,
            walletBalance,
            mpin: data.mpin || undefined,
            biometricEnabled:
              typeof data.biometricEnabled === 'boolean'
                ? data.biometricEnabled
                : typeof data.biometric_enabled === 'boolean'
                ? data.biometric_enabled
                : undefined,
            phone: data.phone || data.mobile || scope.phone || undefined,
          });
        } else {
          // If document does not exist under targetId, check if it was keyed by phone
          if (scope.phone && scope.phone !== targetId) {
            getDoc(doc(db, 'users', scope.phone))
              .then((altSnap) => {
                if (altSnap.exists()) {
                  const altData = altSnap.data();
                  const bal =
                    typeof altData.walletBalance === 'number'
                      ? altData.walletBalance
                      : typeof altData.wallet_balance === 'number'
                      ? altData.wallet_balance
                      : typeof altData.balance === 'number'
                      ? altData.balance
                      : 0;
                  onUpdate({
                    uid: targetId,
                    id: targetId,
                    name: altData.name || altData.userName || undefined,
                    walletBalance: bal,
                    phone: scope.phone,
                  });
                  return;
                }
                // Brand new user account starts with clean 0 balance
                onUpdate({ walletBalance: 0, uid: targetId, id: targetId });
              })
              .catch(() => {
                onUpdate({ walletBalance: 0, uid: targetId, id: targetId });
              });
          } else {
            // Brand new user account starts with clean 0 balance
            onUpdate({ walletBalance: 0, uid: targetId, id: targetId });
          }
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, `users/${targetId}`);
        onUpdate({ walletBalance: 0 });
      }
    );
    return unsubscribe;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `users/${targetId}`);
    onUpdate({ walletBalance: 0 });
    return () => {};
  }
}

/**
 * Writes user profile directly to 'users/{uid}' dynamically matching Netlify Admin Panel schema
 */
export async function syncUserToFirestore(user: UserProfile): Promise<void> {
  const scope = resolveUserAuthScope(user);
  const uid = scope.uid || scope.phone;
  if (!uid) return;

  const cleanPhone = scope.phone || (user.phone || '').replace(/\D/g, '');
  const userDocRef = doc(db, 'users', uid);

  try {
    const nowIso = new Date().toISOString();
    await setDoc(
      userDocRef,
      {
        id: uid,
        uid,
        userId: uid,
        user_id: uid,
        phone: cleanPhone || uid,
        mobile: cleanPhone || uid,
        mobileNumber: cleanPhone || uid,
        name: user.name || 'User',
        userName: user.name || 'User',
        user_name: user.name || 'User',
        walletBalance: typeof user.walletBalance === 'number' ? user.walletBalance : 0,
        wallet_balance: typeof user.walletBalance === 'number' ? user.walletBalance : 0,
        balance: typeof user.walletBalance === 'number' ? user.walletBalance : 0,
        transferWalletBalance: 0,
        mpin: user.mpin || '1234',
        biometricEnabled: Boolean(user.biometricEnabled),
        biometric_enabled: Boolean(user.biometricEnabled),
        appVersion: user.appVersion || '2',
        status: 'active',
        role: 'user',
        bettingDisabled: false,
        registeredAt: nowIso,
        createdAt: nowIso,
        updatedAt: nowIso,
        lastActive: nowIso,
        lastLogin: nowIso,
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `users/${uid}`);
  }
}

// ==========================================
// 2. Withdrawal Requests Sync ('withdrawals')
// ==========================================
export function subscribeToWithdrawals(
  userParam: string | Partial<UserProfile>,
  onUpdate: (withdrawals: FundHistoryItem[], hasData: boolean) => void
): () => void {
  const collectionPath = 'withdrawals';
  const scope = resolveUserAuthScope(userParam);

  if (!scope.uid && !scope.phone) {
    onUpdate([], false);
    return () => {};
  }

  try {
    const colRef = collection(db, collectionPath);
    const unsubscribe = onSnapshot(
      colRef,
      (snapshot: QuerySnapshot<DocumentData>) => {
        const items: FundHistoryItem[] = [];

        snapshot.forEach((docSnap) => {
          const data = docSnap.data();

          // STRICT DATA ISOLATION: Must match the authenticated user's UID or sanitized phone
          if (isDocumentOwnedByUser(data, scope)) {
            const rawStatus = (data.status || 'Pending').toString();
            let normalizedStatus: 'Pending' | 'Success' | 'Failure' = 'Pending';
            if (/^(success|approved|completed)$/i.test(rawStatus)) {
              normalizedStatus = 'Success';
            } else if (/^(failure|rejected|failed|declined)$/i.test(rawStatus)) {
              normalizedStatus = 'Failure';
            }

            items.push({
              id: docSnap.id,
              orderId: data.orderId || data.order_id || docSnap.id,
              date:
                data.date ||
                (data.createdAt
                  ? new Date(data.createdAt).toLocaleString()
                  : 'Recent'),
              amount: Number(data.amount) || 0,
              status: normalizedStatus,
              requestType: 'Debit',
              depositMode: data.depositMode || data.payment_mode || data.paymentMethod || 'Bank Transfer',
              bankName: data.bankName || data.bank_name || '',
              accountNumber: data.accountNumber || data.account_number || '',
              ifscCode: data.ifscCode || data.ifsc_code || '',
              adminRemark: data.adminRemark || data.admin_remark || '',
              utrOrReference: data.utrOrReference || data.reference || data.utr || '',
            });
          }
        });

        items.sort((a, b) => b.orderId.localeCompare(a.orderId));
        onUpdate(items, items.length > 0);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, collectionPath);
        onUpdate([], false);
      }
    );
    return unsubscribe;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, collectionPath);
    onUpdate([], false);
    return () => {};
  }
}

/**
 * Writes withdrawal request directly to BOTH 'withdrawals/{orderId}' and 'withdraw_requests/{orderId}'
 * to ensure 100% real-time synchronization with the Netlify Admin Panel.
 */
export async function createWithdrawalInFirestore(
  item: FundHistoryItem,
  user: UserProfile
): Promise<void> {
  const scope = resolveUserAuthScope(user);
  const uid = scope.uid || scope.phone;
  const cleanPhone = scope.phone || (user.phone || '').replace(/\D/g, '');
  const nowIso = new Date().toISOString();

  const payload = {
    id: item.orderId,
    orderId: item.orderId,
    order_id: item.orderId,
    uid,
    userId: uid,
    user_id: uid,
    userPhone: cleanPhone || uid,
    phone: cleanPhone || uid,
    mobile: cleanPhone || uid,
    userName: user.name || 'User',
    user_name: user.name || 'User',
    amount: item.amount,
    status: (item.status || 'pending').toLowerCase(),
    requestType: 'Debit',
    request_type: 'Debit',
    paymentMethod: 'Bank Transfer',
    depositMode: item.depositMode || 'Bank Transfer',
    payment_mode: item.depositMode || 'Bank Transfer',
    bankName: item.bankName || '',
    bank_name: item.bankName || '',
    accountNumber: item.accountNumber || '',
    account_number: item.accountNumber || '',
    ifscCode: item.ifscCode || '',
    ifsc_code: item.ifscCode || '',
    accountDetails: `${item.bankName || 'Bank'} A/C ${item.accountNumber || ''} (IFSC: ${item.ifscCode || ''})`,
    date: item.date,
    createdAt: nowIso,
    requestedAt: nowIso,
    updatedAt: nowIso,
  };

  try {
    await Promise.all([
      setDoc(doc(db, 'withdrawals', item.orderId), payload, { merge: true }),
      setDoc(doc(db, 'withdraw_requests', item.orderId), payload, { merge: true }),
    ]);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `withdrawals/${item.orderId}`);
  }
}

// ==========================================
// 3. Deposit History Sync ('deposits')
// ==========================================
export function subscribeToDeposits(
  userParam: string | Partial<UserProfile>,
  onUpdate: (deposits: FundHistoryItem[], hasData: boolean) => void
): () => void {
  const collectionPath = 'deposits';
  const scope = resolveUserAuthScope(userParam);

  if (!scope.uid && !scope.phone) {
    onUpdate([], false);
    return () => {};
  }

  try {
    const colRef = collection(db, collectionPath);
    const unsubscribe = onSnapshot(
      colRef,
      (snapshot: QuerySnapshot<DocumentData>) => {
        const items: FundHistoryItem[] = [];

        snapshot.forEach((docSnap) => {
          const data = docSnap.data();

          // STRICT DATA ISOLATION: Must match the authenticated user's UID or sanitized phone
          if (isDocumentOwnedByUser(data, scope)) {
            const rawStatus = (data.status || 'Success').toString();
            let normalizedStatus: 'Success' | 'Pending' | 'Failure' = 'Success';
            if (/^(failure|failed|rejected|declined)$/i.test(rawStatus)) {
              normalizedStatus = 'Failure';
            } else if (/^(pending|waiting|verifying)$/i.test(rawStatus)) {
              normalizedStatus = 'Pending';
            }

            items.push({
              id: docSnap.id,
              orderId: data.orderId || data.order_id || docSnap.id,
              date:
                data.date ||
                (data.createdAt
                  ? new Date(data.createdAt).toLocaleString()
                  : 'Recent'),
              amount: Number(data.amount) || 0,
              status: normalizedStatus,
              requestType: 'Credit',
              depositMode: data.depositMode || data.paymentMode || data.payment_mode || 'UPI',
              adminRemark: data.adminRemark || data.admin_remark || '',
              utrOrReference: data.utrNumber || data.utr || data.utrOrReference || '',
            });
          }
        });

        items.sort((a, b) => b.orderId.localeCompare(a.orderId));
        onUpdate(items, items.length > 0);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, collectionPath);
        onUpdate([], false);
      }
    );
    return unsubscribe;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, collectionPath);
    onUpdate([], false);
    return () => {};
  }
}

/**
 * Writes deposit record directly to BOTH 'deposits/{orderId}' and 'deposit_requests/{orderId}'
 * with authenticated user UID for real-time synchronization with Netlify Admin Panel.
 */
export async function createDepositInFirestore(
  item: FundHistoryItem,
  user: UserProfile,
  bonus: number = 0
): Promise<void> {
  const scope = resolveUserAuthScope(user);
  const uid = scope.uid || scope.phone;
  const cleanPhone = scope.phone || (user.phone || '').replace(/\D/g, '');
  const nowIso = new Date().toISOString();

  const utr = (item as any).utrNumber || (item as any).utr || item.utrOrReference || '';

  const depositPayload = {
    id: item.orderId,
    orderId: item.orderId,
    order_id: item.orderId,
    uid,
    userId: uid,
    user_id: uid,
    amount: item.amount,
    bonus,
    totalAmount: item.amount + bonus,
    total_amount: item.amount + bonus,
    status: (item.status || 'Success').toString(),
    requestType: 'Credit',
    request_type: 'Credit',
    depositMode: item.depositMode || 'UPI',
    payment_mode: item.depositMode || 'UPI',
    userPhone: cleanPhone || uid,
    phone: cleanPhone || uid,
    mobile: cleanPhone || uid,
    userName: user.name || 'User',
    user_name: user.name || 'User',
    utr,
    utrNumber: utr,
    date: item.date,
    createdAt: nowIso,
    requestedAt: nowIso,
    updatedAt: nowIso,
  };

  try {
    await Promise.all([
      setDoc(doc(db, 'deposits', item.orderId), depositPayload, { merge: true }),
      setDoc(doc(db, 'deposit_requests', item.orderId), depositPayload, { merge: true }),
    ]);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `deposits/${item.orderId}`);
  }
}

// ==========================================
// 4. Passbook Transactions Sync ('transactions')
// ==========================================
export function subscribeToTransactions(
  userParam: string | Partial<UserProfile>,
  onUpdate: (transactions: Transaction[], hasData: boolean) => void
): () => void {
  const collectionPath = 'transactions';
  const scope = resolveUserAuthScope(userParam);

  if (!scope.uid && !scope.phone) {
    onUpdate([], false);
    return () => {};
  }

  try {
    const colRef = collection(db, collectionPath);
    const unsubscribe = onSnapshot(
      colRef,
      (snapshot: QuerySnapshot<DocumentData>) => {
        const items: Transaction[] = [];

        snapshot.forEach((docSnap) => {
          const data = docSnap.data();

          // STRICT DATA ISOLATION: Must match the authenticated user's UID or sanitized phone
          if (isDocumentOwnedByUser(data, scope)) {
            items.push({
              id: docSnap.id,
              title: data.title || 'Wallet Transaction',
              referenceId: data.referenceId || data.reference_id || docSnap.id,
              description: data.description || '',
              amount: Number(data.amount) || 0,
              type: data.type === 'debit' ? 'debit' : 'credit',
              status: (data.status || 'SUCCESS') as any,
              date:
                data.date ||
                (data.createdAt
                  ? new Date(data.createdAt).toLocaleString()
                  : ''),
              previousBalance:
                Number(data.previousBalance ?? data.previous_balance) || 0,
              currentBalance:
                Number(data.currentBalance ?? data.current_balance) || 0,
            });
          }
        });

        items.sort((a, b) => b.id.localeCompare(a.id));
        onUpdate(items, items.length > 0);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, collectionPath);
        onUpdate([], false);
      }
    );
    return unsubscribe;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, collectionPath);
    onUpdate([], false);
    return () => {};
  }
}

/**
 * Writes transaction directly to 'transactions/{txId}' with authenticated user UID
 */
export async function recordTransactionInFirestore(
  tx: Transaction,
  userParam: string | Partial<UserProfile>
): Promise<void> {
  const collectionPath = 'transactions';
  const scope = resolveUserAuthScope(userParam);
  const uid = scope.uid || scope.phone;
  const cleanPhone = scope.phone || (typeof userParam === 'string' ? userParam.replace(/\D/g, '') : (userParam?.phone || '').replace(/\D/g, ''));
  const txId = tx.referenceId || tx.id;
  const txDocRef = doc(db, collectionPath, txId);

  try {
    const nowIso = new Date().toISOString();
    await setDoc(txDocRef, {
      id: txId,
      txId,
      referenceId: tx.referenceId,
      reference_id: tx.referenceId,
      title: tx.title,
      description: tx.description,
      amount: tx.amount,
      type: tx.type,
      status: tx.status,
      date: tx.date,
      previousBalance: tx.previousBalance,
      previous_balance: tx.previousBalance,
      currentBalance: tx.currentBalance,
      current_balance: tx.currentBalance,
      uid,
      userId: uid,
      user_id: uid,
      userPhone: cleanPhone || uid,
      phone: cleanPhone || uid,
      mobile: cleanPhone || uid,
      createdAt: nowIso,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${collectionPath}/${txId}`);
  }
}

// ==========================================
// 5. Game Bids & Win History ('bids')
// ==========================================
export function subscribeToBids(
  userParam: string | Partial<UserProfile>,
  onUpdate: (bids: GameBid[], hasData: boolean) => void
): () => void {
  const collectionPath = 'bids';
  const scope = resolveUserAuthScope(userParam);

  if (!scope.uid && !scope.phone) {
    onUpdate([], false);
    return () => {};
  }

  try {
    const colRef = collection(db, collectionPath);
    const unsubscribe = onSnapshot(
      colRef,
      (snapshot: QuerySnapshot<DocumentData>) => {
        const items: GameBid[] = [];

        snapshot.forEach((docSnap) => {
          const data = docSnap.data();

          // STRICT DATA ISOLATION: Must match the authenticated user's UID or sanitized phone
          if (isDocumentOwnedByUser(data, scope)) {
            items.push({
              id: docSnap.id,
              marketName: data.marketName || data.market_name || 'Kalyan',
              gameType: data.gameType || data.game_type || 'SINGLE DIGIT',
              session: data.session || 'Open',
              digitOrPana: String(data.digitOrPana ?? data.digit ?? ''),
              points: Number(data.points) || 0,
              date:
                data.date ||
                (data.createdAt
                  ? new Date(data.createdAt).toLocaleString()
                  : 'Today'),
              status: (data.status || 'Placed') as any,
              winAmount:
                typeof data.winAmount === 'number'
                  ? data.winAmount
                  : typeof data.win_amount === 'number'
                  ? data.win_amount
                  : undefined,
            });
          }
        });

        items.sort((a, b) => b.id.localeCompare(a.id));
        onUpdate(items, items.length > 0);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, collectionPath);
        onUpdate([], false);
      }
    );
    return unsubscribe;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, collectionPath);
    onUpdate([], false);
    return () => {};
  }
}

export async function placeBidInFirestore(
  bid: Omit<GameBid, 'id' | 'date' | 'status'>,
  user: UserProfile
): Promise<string> {
  const collectionPath = 'bids';
  const scope = resolveUserAuthScope(user);
  const uid = scope.uid || scope.phone;
  const cleanPhone = scope.phone || (user.phone || '').replace(/\D/g, '');

  try {
    const now = new Date();
    const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
      .toString()
      .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    })}`;

    const colRef = collection(db, collectionPath);
    const docRef = await addDoc(colRef, {
      ...bid,
      market_name: bid.marketName,
      game_type: bid.gameType,
      digit_or_pana: bid.digitOrPana,
      points: bid.points,
      amount: bid.points,
      uid,
      userId: uid,
      user_id: uid,
      userPhone: cleanPhone || uid,
      phone: cleanPhone || uid,
      mobile: cleanPhone || uid,
      userName: user.name || 'User',
      user_name: user.name || 'User',
      status: 'Placed',
      date: dateStr,
      createdAt: now.toISOString(),
    });
    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, collectionPath);
    return `bid-${Date.now()}`;
  }
}

// ==========================================
// 6. Payment Gateway Settings ('settings/payment_gateway')
// ==========================================
export function subscribeToPaymentGateway(
  onUpdate: (config: PaymentGatewayConfig) => void
): () => void {
  const settingDocRef = doc(db, 'settings', 'payment_gateway');

  try {
    const unsubscribe = onSnapshot(
      settingDocRef,
      (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();

          const merchantVpa =
            data.merchantVpa ||
            data.merchant_vpa ||
            data.manualUpi?.upiId ||
            data.upiId ||
            DEFAULT_GATEWAY_CONFIG.merchantVpa;

          const merchantName =
            data.merchantName ||
            data.merchant_name ||
            data.manualUpi?.merchantName ||
            DEFAULT_GATEWAY_CONFIG.merchantName;

          const qrCodeUrl =
            data.manualUpi?.qrCodeUrl ||
            data.qrCodeUrl ||
            `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=upi://pay?pa=${encodeURIComponent(merchantVpa)}&pn=${encodeURIComponent(merchantName)}&cu=INR`;

          const manualUpi: ManualUpiConfig = {
            enabled: data.manualUpi?.enabled !== false,
            upiId: data.manualUpi?.upiId || merchantVpa,
            merchantName: data.manualUpi?.merchantName || merchantName,
            qrCodeUrl,
            requireScreenshot: data.manualUpi?.requireScreenshot ?? true,
            instructions:
              data.manualUpi?.instructions ||
              'Scan QR code or copy UPI ID. Pay using any UPI app (PhonePe, GPay, Paytm) and enter the 12-digit UTR/Ref No.',
          };

          onUpdate({
            merchantVpa,
            merchantName,
            status: data.status === 'maintenance' ? 'maintenance' : 'active',
            minDeposit:
              typeof data.minDeposit === 'number'
                ? data.minDeposit
                : typeof data.min_deposit === 'number'
                ? data.min_deposit
                : DEFAULT_GATEWAY_CONFIG.minDeposit,
            maxDeposit:
              typeof data.maxDeposit === 'number'
                ? data.maxDeposit
                : DEFAULT_GATEWAY_CONFIG.maxDeposit,
            minWithdrawal:
              typeof data.minWithdrawal === 'number'
                ? data.minWithdrawal
                : typeof data.min_withdrawal === 'number'
                ? data.min_withdrawal
                : DEFAULT_GATEWAY_CONFIG.minWithdrawal,
            welcomeBonusEnabled:
              typeof data.welcomeBonusEnabled === 'boolean'
                ? data.welcomeBonusEnabled
                : true,
            bonusAmount:
              typeof data.bonusAmount === 'number' ? data.bonusAmount : 100,
            activeGateway: data.activeGateway || data.active_gateway || 'manual_upi',
            manualUpi,
            phonepe: data.phonepe,
            paytm: data.paytm,
            razorpay: data.razorpay,
            updatedAt: data.updatedAt,
          });
        } else {
          // If Firestore doesn't have document yet, use the default config with live QR
          onUpdate(DEFAULT_GATEWAY_CONFIG);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, 'settings/payment_gateway');
        onUpdate(DEFAULT_GATEWAY_CONFIG);
      }
    );
    return unsubscribe;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, 'settings/payment_gateway');
    onUpdate(DEFAULT_GATEWAY_CONFIG);
    return () => {};
  }
}

/**
 * Updates live payment gateway configuration in Firestore
 */
export async function updatePaymentGatewayConfig(
  config: Partial<PaymentGatewayConfig>
): Promise<void> {
  try {
    const settingDocRef = doc(db, 'settings', 'payment_gateway');
    await setDoc(
      settingDocRef,
      {
        ...config,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'settings/payment_gateway');
  }
}

// ==========================================
// 7. Bank Accounts ('bank_accounts')
// ==========================================
export function subscribeToBankAccounts(
  userParam: string | Partial<UserProfile>,
  onUpdate: (banks: BankAccount[], hasData: boolean) => void
): () => void {
  const collectionPath = 'bank_accounts';
  const scope = resolveUserAuthScope(userParam);

  if (!scope.uid && !scope.phone) {
    onUpdate([], false);
    return () => {};
  }

  try {
    const colRef = collection(db, collectionPath);
    const unsubscribe = onSnapshot(
      colRef,
      (snapshot: QuerySnapshot<DocumentData>) => {
        const items: BankAccount[] = [];

        snapshot.forEach((docSnap) => {
          const data = docSnap.data();

          if (isDocumentOwnedByUser(data, scope)) {
            items.push({
              id: docSnap.id,
              accountHolder: data.accountHolder || data.account_holder || '',
              bankName: data.bankName || data.bank_name || '',
              branch: data.branch || 'MAIN BRANCH',
              ifscCode: data.ifscCode || data.ifsc_code || '',
              accountNumber: data.accountNumber || data.account_number || '',
              isDefault: Boolean(data.isDefault ?? data.is_default),
              status: (data.status || 'Verified') as any,
              lockUntil: data.lockUntil || data.lock_until,
              updatedAt: data.updatedAt || 'Recently',
            });
          }
        });

        onUpdate(items, items.length > 0);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, collectionPath);
        onUpdate([], false);
      }
    );
    return unsubscribe;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, collectionPath);
    onUpdate([], false);
    return () => {};
  }
}

export async function addBankAccountToFirestore(
  bank: Omit<BankAccount, 'id' | 'updatedAt'>,
  user: UserProfile
): Promise<void> {
  const collectionPath = 'bank_accounts';
  const scope = resolveUserAuthScope(user);
  const uid = scope.uid || scope.phone;
  const cleanPhone = scope.phone || (user.phone || '').replace(/\D/g, '');

  if (!uid && !cleanPhone) {
    console.warn('Cannot add bank account without user identification');
    return;
  }

  try {
    const now = new Date();
    const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
      .toString()
      .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    })}`;

    const lockDate = new Date();
    lockDate.setDate(lockDate.getDate() + 30);
    const lockDateStr = `${lockDate.getDate().toString().padStart(2, '0')}/${(lockDate.getMonth() + 1)
      .toString()
      .padStart(2, '0')}/${lockDate.getFullYear()}`;

    const colRef = collection(db, collectionPath);
    await addDoc(colRef, {
      ...bank,
      account_holder: bank.accountHolder,
      bank_name: bank.bankName,
      account_number: bank.accountNumber,
      ifsc_code: bank.ifscCode,
      uid,
      userId: uid,
      user_id: uid,
      userPhone: cleanPhone || uid,
      phone: cleanPhone || uid,
      mobile: cleanPhone || uid,
      updatedAt: dateStr,
      lockUntil: lockDateStr,
      lock_until: lockDateStr,
      status: bank.status || 'Success',
      createdAt: now.toISOString(),
    });

    // Sync bankDetail sub-object directly to the user document so Netlify Admin panel's Users table shows it
    if (uid) {
      await setDoc(
        doc(db, 'users', uid),
        {
          bankDetail: {
            accountHolderName: bank.accountHolder,
            bankName: bank.bankName,
            accountNumber: bank.accountNumber,
            ifsc: bank.ifscCode,
            upiId: (bank as any).upiId || '',
            isVerified: true,
          },
          updatedAt: now.toISOString(),
        },
        { merge: true }
      );
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, collectionPath);
  }
}

// ==========================================
// 8. Notifications & Broadcasts ('notifications')
// ==========================================
export function subscribeToNotifications(
  userParam: string | Partial<UserProfile>,
  onUpdate: (notifications: AppNotification[], hasData: boolean) => void
): () => void {
  const collectionPath = 'notifications';
  const scope = resolveUserAuthScope(userParam);

  try {
    const colRef = collection(db, collectionPath);
    const unsubscribe = onSnapshot(
      colRef,
      (snapshot: QuerySnapshot<DocumentData>) => {
        if (snapshot.empty) {
          onUpdate([], false);
          return;
        }

        const items: AppNotification[] = [];

        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          const targetPhone = (
            data.targetPhone ||
            data.target_phone ||
            data.phone ||
            data.userId ||
            data.user_id ||
            'all'
          )
            .toString()
            .trim();
          const cleanTarget = targetPhone.replace(/\D/g, '');
          const docUid = (data.uid || data.userId || data.user_id || '').toString().trim();

          // Include notification if broadcast to 'all' or matches this user's UID or phone
          const isBroadcast = targetPhone.toLowerCase() === 'all' || (!cleanTarget && !docUid);
          const isUserMatch = isDocumentOwnedByUser(data, scope);

          if (isBroadcast || isUserMatch) {
            let timeStr = data.time || '';
            if (!timeStr && data.createdAt) {
              try {
                const date = new Date(data.createdAt);
                timeStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
              } catch {
                timeStr = 'Just now';
              }
            }

            let notifType: 'bonus' | 'bid' | 'alert' = 'alert';
            if (data.type === 'bonus' || data.type === 'bid' || data.type === 'alert') {
              notifType = data.type;
            } else if (data.category === 'bonus' || data.tag === 'bonus') {
              notifType = 'bonus';
            } else if (data.category === 'bid' || data.tag === 'bid') {
              notifType = 'bid';
            }

            items.push({
              id: docSnap.id,
              title: data.title || data.heading || data.subject || 'RAMA777 Notice',
              message: data.message || data.body || data.desc || data.description || '',
              time: timeStr || 'Recent',
              read: typeof data.read === 'boolean' ? data.read : false,
              type: notifType,
            });
          }
        });

        // Sort descending so newest broadcast alerts from admin panel appear on top
        items.sort((a, b) => b.id.localeCompare(a.id));
        onUpdate(items, items.length > 0);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, collectionPath);
        onUpdate([], false);
      }
    );
    return unsubscribe;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, collectionPath);
    return () => {};
  }
}

export async function broadcastNotificationInFirestore(
  notif: Omit<AppNotification, 'id'> & { id?: string; targetPhone?: string }
): Promise<void> {
  const collectionPath = 'notifications';
  try {
    const notifId = notif.id || `notif-${Date.now()}`;
    const notifDocRef = doc(db, collectionPath, notifId);
    const nowIso = new Date().toISOString();
    await setDoc(notifDocRef, {
      id: notifId,
      title: notif.title,
      heading: notif.title,
      message: notif.message,
      body: notif.message,
      time: notif.time,
      read: notif.read ?? false,
      type: notif.type || 'alert',
      targetPhone: notif.targetPhone || 'all',
      target_phone: notif.targetPhone || 'all',
      createdAt: nowIso,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, collectionPath);
  }
}

/**
 * Neutralized seeding function to ensure brand new users start with a clean slate
 * and no fake static accounts/transactions are forced into Firestore.
 */
export async function seedInitialDataToFirestore(
  _user: UserProfile,
  _initialTransactions: Transaction[],
  _initialWithdrawals: FundHistoryItem[],
  _initialDeposits: FundHistoryItem[],
  _initialBanks: BankAccount[],
  _initialNotifications?: AppNotification[]
): Promise<void> {
  // Intentionally a no-op to protect per-user data isolation.
  // Real user transactions and accounts are created dynamically when performed by the user.
}

