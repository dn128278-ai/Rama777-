import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';

interface PaymentRecord {
  orderId: string;
  amount: number;
  bonus: number;
  method: string;
  userPhone: string;
  status: 'PENDING' | 'SUCCESS' | 'FAILED' | 'CANCELLED';
  reason?: string;
  utr?: string;
  verifiedAt?: string;
  createdAt: number;
}

// In-memory order tracking registry
const paymentOrders = new Map<string, PaymentRecord>();

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json());

  // 1. Initialize Payment Order
  app.post('/api/initiate-payment', (req, res) => {
    const { orderId, amount, bonus = 0, method = 'UPI Intent', userPhone = '6377972674' } = req.body;
    if (!orderId || !amount) {
      return res.status(400).json({ success: false, error: 'Missing orderId or amount' });
    }

    const record: PaymentRecord = {
      orderId,
      amount: Number(amount) || 0,
      bonus: Number(bonus) || 0,
      method,
      userPhone,
      status: 'PENDING',
      createdAt: Date.now(),
    };
    paymentOrders.set(orderId, record);

    // STRICT SECURITY POLICY:
    // Completely removed any simulated gateway fallback timers or mock success triggers.
    // The order remains in PENDING status until an authentic gateway callback / webhook is received
    // from Kotak Gateway, or explicit failure/cancellation occurs.

    return res.json({ success: true, order: record });
  });

  // 1b. User Cancellation Endpoint
  app.post('/api/cancel-payment', (req, res) => {
    const { orderId } = req.body;
    if (!orderId) {
      return res.status(400).json({ success: false, error: 'Missing orderId' });
    }
    const existing = paymentOrders.get(orderId);
    if (existing) {
      existing.status = 'CANCELLED';
      existing.reason = 'CANCELLED_BY_USER';
      paymentOrders.set(orderId, existing);
    }
    return res.json({ success: true, status: 'CANCELLED', orderId });
  });

  // 2. Kotak Gateway Webhook Callback Endpoint
  app.post(['/api/kotak-webhook', '/api/payment-callback'], (req, res) => {
    const {
      orderId,
      order_id,
      status,
      responseCode,
      response_code,
      utr,
      rrn,
      reason,
      amount,
    } = req.body;

    const targetOrderId = orderId || order_id;
    if (!targetOrderId) {
      return res.status(400).json({ success: false, error: 'Missing orderId in callback payload' });
    }

    const isSuccess =
      /^(success|00|successful)$/i.test(status || '') ||
      responseCode === '00' ||
      response_code === '00';

    const isIncorrectPin =
      responseCode === 'U30' ||
      responseCode === 'ZM' ||
      /pin/i.test(reason || '') ||
      /incorrect.*pin/i.test(status || '');

    const isCancelled =
      /^(cancelled|cancel|aborted)$/i.test(status || '') ||
      responseCode === 'ZA';

    const existing: PaymentRecord = paymentOrders.get(targetOrderId) || {
      orderId: targetOrderId,
      amount: Number(amount) || 0,
      bonus: 0,
      method: 'Kotak UPI Intent',
      userPhone: '6377972674',
      status: 'PENDING',
      createdAt: Date.now(),
    };

    if (isSuccess) {
      existing.status = 'SUCCESS';
      existing.utr = utr || rrn || `KTK${Date.now().toString().slice(-8)}${Math.floor(1000 + Math.random() * 9000)}`;
      existing.verifiedAt = new Date().toISOString();
    } else if (isIncorrectPin) {
      existing.status = 'FAILED';
      existing.reason = 'INCORRECT_PIN';
    } else if (isCancelled) {
      existing.status = 'CANCELLED';
      existing.reason = 'CANCELLED_BY_USER';
    } else {
      existing.status = 'FAILED';
      existing.reason = reason || 'PAYMENT_DECLINED';
    }

    paymentOrders.set(targetOrderId, existing);

    return res.json({
      success: true,
      received: true,
      orderId: targetOrderId,
      status: existing.status,
      reason: existing.reason,
    });
  });

  // 3. Payment Verification Endpoint
  // Strictly validates payment outcome against gateway status. ONLY returns SUCCESS when payment is confirmed.
  // Rejects and returns failure status for failed, cancelled, or pending transactions.
  app.post('/api/verify-payment', (req, res) => {
    const {
      orderId,
      amount,
      bonus = 0,
      method = 'PhonePe / UPI Intent',
      userPhone,
      userAction,
      intentStatus,
    } = req.body;

    if (!orderId || amount === undefined || amount === null) {
      return res.status(400).json({
        success: false,
        verified: false,
        error: 'Invalid payment verification payload: missing orderId or amount',
      });
    }

    const numericAmount = Math.max(0, Number(amount) || 0);
    const numericBonus = Math.max(0, Number(bonus) || 0);

    // Check existing order status in registry
    const recorded = paymentOrders.get(orderId);
    if (!recorded) {
      return res.status(404).json({
        success: false,
        verified: false,
        status: 'NOT_FOUND',
        error: 'Order not found in payment registry. Cannot verify unknown order.',
        creditedAmount: 0,
      });
    }

    // Check user cancellation / failure overrides
    if (userAction === 'cancel' || intentStatus === 'CANCELLED' || userAction === 'aborted') {
      recorded.status = 'CANCELLED';
      recorded.reason = 'CANCELLED_BY_USER';
      paymentOrders.set(orderId, recorded);
      return res.json({
        success: false,
        verified: false,
        status: 'CANCELLED',
        reason: 'CANCELLED_BY_USER',
        orderId,
        amount: numericAmount,
        error: 'Payment Cancelled: User cancelled the payment.',
        creditedAmount: 0,
      });
    }

    if (userAction === 'incorrect_pin' || intentStatus === 'INCORRECT_PIN') {
      recorded.status = 'FAILED';
      recorded.reason = 'INCORRECT_PIN';
      paymentOrders.set(orderId, recorded);
      return res.json({
        success: false,
        verified: false,
        status: 'FAILED',
        reason: 'INCORRECT_PIN',
        orderId,
        amount: numericAmount,
        error: 'Payment Failed: Incorrect UPI PIN entered. Bank declined the transaction.',
        creditedAmount: 0,
      });
    }

    if (recorded.status === 'FAILED') {
      return res.json({
        success: false,
        verified: false,
        status: 'FAILED',
        reason: recorded.reason || 'PAYMENT_DECLINED',
        orderId,
        amount: numericAmount,
        error: recorded.reason === 'INCORRECT_PIN'
          ? 'Payment Failed: Incorrect UPI PIN entered. Bank declined the transaction.'
          : 'Payment Failed: Bank rejected the transaction.',
        creditedAmount: 0,
      });
    }

    if (recorded.status === 'CANCELLED') {
      return res.json({
        success: false,
        verified: false,
        status: 'CANCELLED',
        reason: 'CANCELLED_BY_USER',
        orderId,
        amount: numericAmount,
        error: 'Payment Cancelled: User cancelled the payment.',
        creditedAmount: 0,
      });
    }

    // Still pending bank confirmation - check if timed out (> 120 seconds)
    if (recorded.status === 'PENDING') {
      if (Date.now() - (recorded.createdAt || 0) > 120000) {
        recorded.status = 'FAILED';
        recorded.reason = 'PAYMENT_TIMED_OUT';
        paymentOrders.set(orderId, recorded);
        return res.json({
          success: false,
          verified: false,
          status: 'FAILED',
          reason: 'PAYMENT_TIMED_OUT',
          orderId,
          amount: numericAmount,
          error: 'Payment Timed Out: Gateway confirmation was not received within the time window. 0 points credited.',
          creditedAmount: 0,
        });
      }

      return res.json({
        success: false,
        verified: false,
        status: 'PENDING',
        orderId,
        amount: numericAmount,
        message: 'Payment confirmation is still pending from Kotak Gateway / bank.',
        creditedAmount: 0,
      });
    }

    // ONLY when gateway confirmed SUCCESS
    if (recorded.status === 'SUCCESS') {
      const totalCredited = recorded.amount + recorded.bonus;
      return res.json({
        success: true,
        verified: true,
        status: 'SUCCESS',
        orderId,
        utr: recorded.utr,
        merchantVpa: '0793748A0296660.bqr@kotak',
        amount: recorded.amount,
        bonus: recorded.bonus,
        creditedAmount: totalCredited,
        method: recorded.method || method,
        userPhone: recorded.userPhone || userPhone || '6377972674',
        verifiedAt: recorded.verifiedAt,
        message: `₹${totalCredited} verified and credited to wallet balance`,
      });
    }

    return res.status(400).json({
      success: false,
      verified: false,
      status: 'UNKNOWN',
      error: 'Unknown order status',
      creditedAmount: 0,
    });
  });

  // 4. Query Order Status Endpoint
  app.get('/api/payment-status/:orderId', (req, res) => {
    const { orderId } = req.params;
    const order = paymentOrders.get(orderId);
    if (!order) {
      return res.status(404).json({ success: false, error: 'Order not found' });
    }

    // Timeout safety: if pending for over 120 seconds, mark as FAILED
    if (order.status === 'PENDING' && Date.now() - (order.createdAt || 0) > 120000) {
      order.status = 'FAILED';
      order.reason = 'PAYMENT_TIMED_OUT';
      paymentOrders.set(orderId, order);
    }

    return res.json({ success: true, order });
  });

  // 5. Health Check Endpoint
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      merchantVpa: '0793748A0296660.bqr@kotak',
      gateway: 'Kotak Merchant UPI Intent',
    });
  });

  // Mount Vite dev middleware or serve static production build
  if (process.env.NODE_ENV === 'production') {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
