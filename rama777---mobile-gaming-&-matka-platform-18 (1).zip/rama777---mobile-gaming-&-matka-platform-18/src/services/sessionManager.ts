/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Secure Session & Token Management Engine for RAMA777.
 * Features:
 * 1. Cryptographically Signed Session Tokens (HMAC-SHA256)
 * 2. Sliding Idle Session Timeout (15-minute auto-expiry on inactivity)
 * 3. Tamper-evident session verification & auto-revocation
 * 4. Active user interaction tracking to prevent premature timeouts during gameplay
 */

import { UserProfile, UserRole } from '../types';
import { computeHmac, secureStorage, onTamperDetected } from '../utils/security';

const SESSION_TOKEN_KEY = 'rama777_sec_session_token';
const LAST_ACTIVITY_KEY = 'rama777_sec_last_activity';
const SESSION_SECRET_SEED = 'RAMA777_SESSION_AUTH_PEPPER_2026';

// 15 minutes of inactivity before session lock/timeout
export const IDLE_TIMEOUT_MS = 15 * 60 * 1000;
// Maximum absolute session token lifetime: 24 hours
export const MAX_SESSION_LIFETIME_MS = 24 * 60 * 60 * 1000;

export interface SecureSessionToken {
  token: string;
  uid: string;
  role: UserRole;
  issuedAt: number;
  expiresAt: number;
  nonce: string;
  signature: string;
}

/**
 * Generates a signed cryptographic session token for authenticated users
 */
export function generateSessionToken(user: UserProfile): SecureSessionToken {
  const uid = user.uid || user.id || user.phone || 'anonymous';
  const role: UserRole = user.role || 'user';
  const issuedAt = Date.now();
  const expiresAt = issuedAt + MAX_SESSION_LIFETIME_MS;
  const nonce = Math.random().toString(36).substring(2, 10);

  const payloadString = `${uid}:${role}:${issuedAt}:${expiresAt}:${nonce}`;
  const signature = computeHmac(SESSION_SECRET_SEED, payloadString);
  const token = btoa(`${payloadString}:${signature.substring(0, 16)}`);

  const sessionObj: SecureSessionToken = {
    token,
    uid,
    role,
    issuedAt,
    expiresAt,
    nonce,
    signature,
  };

  // Securely store token and update activity timestamp
  secureStorage.setItem(SESSION_TOKEN_KEY, sessionObj);
  updateLastActivity();

  return sessionObj;
}

/**
 * Validates the cryptographic signature, expiration, and format of the current session token
 */
export function validateSessionToken(): {
  isValid: boolean;
  isExpired: boolean;
  token?: SecureSessionToken;
  error?: string;
} {
  try {
    const sessionObj = secureStorage.getItem<SecureSessionToken | null>(SESSION_TOKEN_KEY, null);
    if (!sessionObj || !sessionObj.token || !sessionObj.signature) {
      return { isValid: false, isExpired: false, error: 'No active session token' };
    }

    const now = Date.now();

    // 1. Check absolute token expiration
    if (now > sessionObj.expiresAt) {
      revokeSession();
      return { isValid: false, isExpired: true, error: 'Session token has expired' };
    }

    // 2. Check idle inactivity timeout
    const lastActivity = getLastActivity();
    if (now - lastActivity > IDLE_TIMEOUT_MS) {
      revokeSession();
      return { isValid: false, isExpired: true, error: 'Session locked due to 15 minutes of inactivity' };
    }

    // 3. Re-compute HMAC and verify signature authenticity
    const payloadString = `${sessionObj.uid}:${sessionObj.role}:${sessionObj.issuedAt}:${sessionObj.expiresAt}:${sessionObj.nonce}`;
    const expectedSig = computeHmac(SESSION_SECRET_SEED, payloadString);

    if (expectedSig !== sessionObj.signature) {
      console.warn('[SECURITY] Invalid session token signature. Revoking session.');
      revokeSession();
      return { isValid: false, isExpired: false, error: 'Invalid session token signature' };
    }

    return { isValid: true, isExpired: false, token: sessionObj };
  } catch (err: any) {
    return { isValid: false, isExpired: false, error: err?.message || 'Token validation failed' };
  }
}

/**
 * Updates last active timestamp to slide the idle timeout forward
 */
export function updateLastActivity(): void {
  try {
    sessionStorage.setItem(LAST_ACTIVITY_KEY, Date.now().toString());
  } catch {}
}

export function getLastActivity(): number {
  try {
    const raw = sessionStorage.getItem(LAST_ACTIVITY_KEY);
    return raw ? parseInt(raw, 10) : Date.now();
  } catch {
    return Date.now();
  }
}

/**
 * Immediately revokes active session token and clears credentials
 */
export function revokeSession(): void {
  try {
    secureStorage.removeItem(SESSION_TOKEN_KEY);
    sessionStorage.removeItem(LAST_ACTIVITY_KEY);
  } catch {}
}

/**
 * Initializes automatic activity listeners and tamper detection
 */
export function initSessionWatchdog(onSessionExpired: (reason: string) => void): () => void {
  let timer: any = null;

  const handleActivity = () => {
    updateLastActivity();
  };

  const checkStatus = () => {
    const result = validateSessionToken();
    if (!result.isValid && result.isExpired) {
      onSessionExpired(result.error || 'Your session has expired. Please sign in with MPIN.');
    }
  };

  // Activity events
  if (typeof window !== 'undefined') {
    window.addEventListener('mousemove', handleActivity, { passive: true });
    window.addEventListener('keydown', handleActivity, { passive: true });
    window.addEventListener('touchstart', handleActivity, { passive: true });
    window.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        checkStatus();
        updateLastActivity();
      }
    });

    // Heartbeat check every 30 seconds
    timer = setInterval(checkStatus, 30000);
  }

  // Subscribe to storage tamper events: automatically lock/logout if auth session tampering is detected
  const unsubTamper = onTamperDetected((details) => {
    if (
      details.key === SESSION_TOKEN_KEY ||
      details.key === 'rama777_active_session' ||
      details.key === 'rama777_registered_accounts'
    ) {
      revokeSession();
      onSessionExpired(`Security alert: Unauthorized tampering detected in ${details.key}. Session locked.`);
    }
  });

  return () => {
    if (timer) clearInterval(timer);
    if (typeof window !== 'undefined') {
      window.removeEventListener('mousemove', handleActivity);
      window.removeEventListener('keydown', handleActivity);
      window.removeEventListener('touchstart', handleActivity);
    }
    unsubTamper();
  };
}
