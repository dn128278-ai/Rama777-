/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Sliding-Window Rate Limiter & Anti-Brute-Force Shield for RAMA777.
 * Defends against automated script attacks, credential stuffing,
 * rapid-click double spending, and API flooding.
 */

interface RateLimitConfig {
  maxAttempts: number;
  windowMs: number;
  lockoutMs?: number;
}

interface ActionRecord {
  timestamps: number[];
  lockedUntil?: number;
}

const memoryStore = new Map<string, ActionRecord>();
const STORAGE_PREFIX = 'rama777_rl_';

// Default Rate Limiting Policies for sensitive gaming & financial operations
export const RATE_LIMIT_POLICIES: Record<string, RateLimitConfig> = {
  // Login & Credential Actions
  'auth:login': { maxAttempts: 5, windowMs: 120000, lockoutMs: 60000 }, // 5 tries / 2 min -> 60s lock
  'auth:mpin': { maxAttempts: 4, windowMs: 60000, lockoutMs: 60000 },  // 4 tries / 1 min -> 60s lock
  'auth:register': { maxAttempts: 3, windowMs: 300000, lockoutMs: 120000 },

  // Financial & Wallet Actions
  'funds:deposit': { maxAttempts: 3, windowMs: 10000, lockoutMs: 15000 }, // 3 tries / 10s
  'funds:withdraw': { maxAttempts: 2, windowMs: 15000, lockoutMs: 30000 },
  'funds:add_bank': { maxAttempts: 3, windowMs: 60000, lockoutMs: 60000 },

  // Gaming Actions
  'game:place_bid': { maxAttempts: 5, windowMs: 3000, lockoutMs: 5000 }, // Prevent rapid double-tap
  'support:send_chat': { maxAttempts: 5, windowMs: 10000, lockoutMs: 15000 },
};

function getRecord(actionKey: string): ActionRecord {
  // Check memory first
  let record = memoryStore.get(actionKey);
  if (!record) {
    try {
      const raw = sessionStorage.getItem(STORAGE_PREFIX + actionKey);
      if (raw) {
        record = JSON.parse(raw);
      }
    } catch {}
  }
  return record || { timestamps: [] };
}

function saveRecord(actionKey: string, record: ActionRecord) {
  memoryStore.set(actionKey, record);
  try {
    sessionStorage.setItem(STORAGE_PREFIX + actionKey, JSON.stringify(record));
  } catch {}
}

export interface RateLimitCheckResult {
  allowed: boolean;
  remainingAttempts: number;
  retryAfterSeconds: number;
  errorMessage?: string;
}

/**
 * Checks whether an action is currently permitted under rate limiting policy
 */
export function checkRateLimit(
  policyName: keyof typeof RATE_LIMIT_POLICIES | string,
  identifier: string = 'global'
): RateLimitCheckResult {
  const policy = RATE_LIMIT_POLICIES[policyName] || { maxAttempts: 5, windowMs: 30000, lockoutMs: 30000 };
  const actionKey = `${policyName}:${identifier}`;
  const now = Date.now();
  const record = getRecord(actionKey);

  // 1. Check if currently locked out
  if (record.lockedUntil && record.lockedUntil > now) {
    const retryAfter = Math.ceil((record.lockedUntil - now) / 1000);
    return {
      allowed: false,
      remainingAttempts: 0,
      retryAfterSeconds: retryAfter,
      errorMessage: `Too many attempts. For security, please wait ${retryAfter}s before retrying.`,
    };
  }

  // 2. Filter out timestamps outside sliding window
  const windowStart = now - policy.windowMs;
  record.timestamps = record.timestamps.filter((ts) => ts > windowStart);

  const remaining = Math.max(0, policy.maxAttempts - record.timestamps.length);

  if (record.timestamps.length >= policy.maxAttempts) {
    const lockout = policy.lockoutMs || policy.windowMs;
    record.lockedUntil = now + lockout;
    saveRecord(actionKey, record);
    const retryAfter = Math.ceil(lockout / 1000);
    return {
      allowed: false,
      remainingAttempts: 0,
      retryAfterSeconds: retryAfter,
      errorMessage: `Rate limit exceeded. Please wait ${retryAfter}s before trying again.`,
    };
  }

  return {
    allowed: true,
    remainingAttempts: remaining,
    retryAfterSeconds: 0,
  };
}

/**
 * Registers an attempt (e.g. after a failed login or upon initiating an action)
 */
export function recordActionAttempt(
  policyName: keyof typeof RATE_LIMIT_POLICIES | string,
  identifier: string = 'global',
  success: boolean = false
): RateLimitCheckResult {
  const policy = RATE_LIMIT_POLICIES[policyName] || { maxAttempts: 5, windowMs: 30000, lockoutMs: 30000 };
  const actionKey = `${policyName}:${identifier}`;
  const now = Date.now();
  const record = getRecord(actionKey);

  if (success) {
    // Reset consecutive failed attempts on success
    record.timestamps = [];
    record.lockedUntil = undefined;
    saveRecord(actionKey, record);
    return {
      allowed: true,
      remainingAttempts: policy.maxAttempts,
      retryAfterSeconds: 0,
    };
  }

  // Add attempt timestamp
  const windowStart = now - policy.windowMs;
  record.timestamps = record.timestamps.filter((ts) => ts > windowStart);
  record.timestamps.push(now);

  if (record.timestamps.length >= policy.maxAttempts) {
    const lockout = policy.lockoutMs || policy.windowMs;
    record.lockedUntil = now + lockout;
    saveRecord(actionKey, record);
    const retryAfter = Math.ceil(lockout / 1000);
    return {
      allowed: false,
      remainingAttempts: 0,
      retryAfterSeconds: retryAfter,
      errorMessage: `Security cooldown active. Please wait ${retryAfter}s.`,
    };
  }

  saveRecord(actionKey, record);
  return {
    allowed: true,
    remainingAttempts: Math.max(0, policy.maxAttempts - record.timestamps.length),
    retryAfterSeconds: 0,
  };
}
