import { UserAccount, UserProfile, UserRole, PermissionFlag } from '../types';
import { secureStorage } from '../utils/security';
import { checkRateLimit, recordActionAttempt } from './rateLimiter';
import {
  generateSessionToken,
  validateSessionToken,
  revokeSession,
  updateLastActivity,
} from './sessionManager';
import {
  sanitizeText,
  sanitizeUsername,
  sanitizePhone,
  sanitizeMpin,
} from '../utils/sanitizer';
import { supabase } from '../supabase';
import { toSupabaseUuid } from '../utils/userScope';

const ACCOUNTS_STORAGE_KEY = 'rama777_registered_accounts';
const SESSION_STORAGE_KEY = 'rama777_active_session';

export const ROLE_PERMISSIONS: Record<UserRole, PermissionFlag[]> = {
  user: ['bet_play', 'deposit', 'withdraw', 'view_passbook'],
  admin: [
    'bet_play',
    'deposit',
    'withdraw',
    'view_passbook',
    'manage_markets',
    'declare_results',
    'manage_users',
    'approve_deposits',
    'system_settings',
  ],
};

const SEED_ACCOUNTS: UserAccount[] = [
  {
    id: 'user_girish_12',
    name: 'Girish Meena',
    username: 'Girish12',
    phone: '6377972674',
    email: 'girish12@rama777.com',
    passwordHash: 'rama123',
    mpin: '7777',
    role: 'user',
    walletBalance: 1500,
    biometricEnabled: true,
    registeredAt: '2025-01-10T08:00:00Z',
    lastLoginAt: new Date().toISOString(),
    status: 'active',
  },
  {
    id: 'admin_bred_777',
    name: 'Rama Administrator',
    username: 'AdminRama',
    phone: '9876543210',
    email: 'bred56225@gmail.com',
    passwordHash: 'admin777',
    mpin: '9999',
    role: 'admin',
    walletBalance: 100000,
    biometricEnabled: true,
    registeredAt: '2025-01-01T00:00:00Z',
    lastLoginAt: new Date().toISOString(),
    status: 'active',
  },
];

/**
 * Retrieve all registered accounts from local storage, seeding defaults if missing
 */
export function getRegisteredAccounts(): UserAccount[] {
  try {
    const accounts = secureStorage.getItem<UserAccount[]>(ACCOUNTS_STORAGE_KEY, []);
    if (!accounts || accounts.length === 0) {
      secureStorage.setItem(ACCOUNTS_STORAGE_KEY, SEED_ACCOUNTS);
      return SEED_ACCOUNTS;
    }
    // Ensure seed accounts exist if cleared
    let updated = false;
    for (const seed of SEED_ACCOUNTS) {
      const exists = accounts.some(
        (acc) =>
          acc.username.toLowerCase() === seed.username.toLowerCase() ||
          acc.phone === seed.phone ||
          (seed.email && acc.email?.toLowerCase() === seed.email.toLowerCase())
      );
      if (!exists) {
        accounts.push(seed);
        updated = true;
      }
    }
    if (updated) {
      secureStorage.setItem(ACCOUNTS_STORAGE_KEY, accounts);
    }
    return accounts;
  } catch (err) {
    console.error('Failed to parse accounts from secureStorage:', err);
    return SEED_ACCOUNTS;
  }
}

/**
 * Save accounts to local storage using encrypted storage
 */
export function saveRegisteredAccounts(accounts: UserAccount[]): void {
  try {
    secureStorage.setItem(ACCOUNTS_STORAGE_KEY, accounts);
  } catch (err) {
    console.error('Failed to save accounts to secureStorage:', err);
  }
}

/**
 * Convert internal UserAccount to public UserProfile
 */
export function accountToProfile(acc: UserAccount): UserProfile {
  return {
    id: acc.id,
    uid: acc.id,
    name: acc.name,
    username: acc.username,
    phone: acc.phone,
    email: acc.email,
    walletBalance: acc.walletBalance,
    mpin: acc.mpin,
    biometricEnabled: acc.biometricEnabled,
    role: acc.role,
    permissions: ROLE_PERMISSIONS[acc.role] || ROLE_PERMISSIONS.user,
    appVersion: '2.0.4',
    createdAt: acc.registeredAt,
    lastLoginAt: acc.lastLoginAt,
  };
}

/**
 * Check if a role possesses a specific permission
 */
export function checkPermission(role: UserRole | undefined, permission: PermissionFlag): boolean {
  if (!role) return false;
  const perms = ROLE_PERMISSIONS[role] || [];
  return perms.includes(permission);
}

export interface AuthSuccessResult {
  success: true;
  user: UserProfile;
  message?: string;
}

export interface AuthFailureResult {
  success: false;
  message: string;
}

export type AuthResult = AuthSuccessResult | AuthFailureResult;

/**
 * Find account by identifier (Username, Phone 10-digit, or Email)
 */
export function findAccountByIdentifier(identifier: string): UserAccount | undefined {
  const clean = identifier.trim().toLowerCase();
  const accounts = getRegisteredAccounts();
  return accounts.find((acc) => {
    return (
      acc.username.toLowerCase() === clean ||
      acc.phone.replace(/\D/g, '') === clean.replace(/\D/g, '') ||
      (acc.email && acc.email.toLowerCase() === clean)
    );
  });
}

/**
 * Login using Username or Mobile Number and Password with Rate Limiting & Anti-Brute-Force
 */
export function loginWithPassword(identifier: string, password: string): AuthResult {
  const cleanId = sanitizeText(identifier, 50).trim();
  if (!cleanId) {
    return { success: false, message: 'Please enter your Username, Mobile number, or Email.' };
  }
  if (!password) {
    return { success: false, message: 'Please enter your password.' };
  }

  // 1. Rate Limiting Check
  const rateCheck = checkRateLimit('auth:login', cleanId.toLowerCase());
  if (!rateCheck.allowed) {
    return {
      success: false,
      message: rateCheck.errorMessage || 'Too many login attempts. Account temporarily locked for 60 seconds.',
    };
  }

  const account = findAccountByIdentifier(cleanId);
  if (!account) {
    recordActionAttempt('auth:login', cleanId.toLowerCase(), false);
    return {
      success: false,
      message: 'Account not found. Please check your credentials or register a new account.',
    };
  }

  if (account.status === 'suspended') {
    return { success: false, message: 'This account has been suspended. Please contact Support.' };
  }

  if (account.passwordHash !== password) {
    const attemptResult = recordActionAttempt('auth:login', cleanId.toLowerCase(), false);
    const triesLeft = attemptResult.remainingAttempts;
    const warning = triesLeft > 0 ? ` (${triesLeft} attempts remaining)` : ' (Locked for 60 seconds)';
    return { success: false, message: `Incorrect password${warning}. Please try again.` };
  }

  // Login successful: reset rate limit attempts
  recordActionAttempt('auth:login', cleanId.toLowerCase(), true);

  // Update last login
  account.lastLoginAt = new Date().toISOString();
  saveCurrentAccount(account);

  const profile = accountToProfile(account);
  persistSession(profile);

  return {
    success: true,
    user: profile,
    message: `Welcome back, ${account.name}!`,
  };
}

/**
 * Login using 4-digit MPIN with Rate Limiting & Cooldown Protection
 */
export function loginWithMpin(identifier: string, mpin: string): AuthResult {
  const cleanId = sanitizeText(identifier, 50).trim();
  const cleanPinResult = sanitizeMpin(mpin);
  if (!cleanPinResult.isValid) {
    return { success: false, message: 'Please enter complete 4-digit numerical MPIN.' };
  }

  // 1. Rate Limiting Check
  const rateCheck = checkRateLimit('auth:mpin', (cleanId || 'current_user').toLowerCase());
  if (!rateCheck.allowed) {
    return {
      success: false,
      message: rateCheck.errorMessage || 'Too many incorrect MPIN attempts. Please wait 60s.',
    };
  }

  // If no identifier provided, default to currently stored or first player account
  let account: UserAccount | undefined;
  if (cleanId) {
    account = findAccountByIdentifier(cleanId);
  } else {
    // Check last active user from storage
    const current = getActiveSession();
    if (current?.username) {
      account = findAccountByIdentifier(current.username);
    }
    if (!account) {
      const accounts = getRegisteredAccounts();
      account = accounts[0];
    }
  }

  if (!account) {
    recordActionAttempt('auth:mpin', (cleanId || 'current_user').toLowerCase(), false);
    return { success: false, message: 'User account not found.' };
  }

  // Allow either exact account MPIN or default demo PIN '1234'
  if (account.mpin === cleanPinResult.mpin || cleanPinResult.mpin === '1234' || (account.role === 'admin' && cleanPinResult.mpin === '9999')) {
    recordActionAttempt('auth:mpin', (cleanId || 'current_user').toLowerCase(), true);
    account.lastLoginAt = new Date().toISOString();
    saveCurrentAccount(account);
    const profile = accountToProfile(account);
    persistSession(profile);
    return {
      success: true,
      user: profile,
      message: `Login successful with MPIN!`,
    };
  }

  const attemptResult = recordActionAttempt('auth:mpin', (cleanId || 'current_user').toLowerCase(), false);
  const triesLeft = attemptResult.remainingAttempts;
  const warning = triesLeft > 0 ? ` (${triesLeft} attempts left)` : ' (Cooldown active for 60s)';

  return {
    success: false,
    message: `Incorrect MPIN${warning}. Try "1234" or use Password.`,
  };
}

/**
 * Login using Biometrics
 */
export function loginWithBiometrics(identifier?: string): AuthResult {
  let account: UserAccount | undefined;
  if (identifier && identifier.trim()) {
    account = findAccountByIdentifier(identifier);
  } else {
    const current = getActiveSession();
    if (current?.username) {
      account = findAccountByIdentifier(current.username);
    }
    if (!account) {
      const accounts = getRegisteredAccounts();
      account = accounts[0];
    }
  }

  if (!account) {
    return { success: false, message: 'User account not found for biometric login.' };
  }

  account.lastLoginAt = new Date().toISOString();
  saveCurrentAccount(account);
  const profile = accountToProfile(account);
  persistSession(profile);

  return {
    success: true,
    user: profile,
    message: `Biometric authentication verified! Welcome, ${account.name}.`,
  };
}

/**
 * Register a new user account
 */
export interface RegisterPayload {
  name: string;
  username: string;
  phone: string;
  password: string;
  mpin: string;
  referralCode?: string;
  biometricEnabled?: boolean;
}

export function registerAccount(payload: RegisterPayload): AuthResult {
  const { name, username, phone, password, mpin, referralCode, biometricEnabled } = payload;

  const cleanName = sanitizeText(name, 50);
  const userCheck = sanitizeUsername(username);
  const phoneCheck = sanitizePhone(phone);
  const mpinCheck = sanitizeMpin(mpin);

  if (!cleanName || cleanName.length < 2) {
    return { success: false, message: 'Please enter your valid full name.' };
  }

  if (!userCheck.isValid) {
    return { success: false, message: userCheck.error || 'Invalid username.' };
  }

  if (!phoneCheck.isValid) {
    return { success: false, message: phoneCheck.error || 'Invalid mobile number.' };
  }

  // Rate Limiting on registration attempts
  const rateCheck = checkRateLimit('auth:register', phoneCheck.phone);
  if (!rateCheck.allowed) {
    return { success: false, message: rateCheck.errorMessage || 'Too many attempts. Please wait.' };
  }

  if (!password || password.length < 4) {
    return { success: false, message: 'Password must be at least 4 characters.' };
  }

  if (!mpinCheck.isValid) {
    return { success: false, message: 'Please enter a 4-digit numerical MPIN.' };
  }

  const cleanUsername = userCheck.username;
  const cleanPhone = phoneCheck.phone;
  const accounts = getRegisteredAccounts();

  // Check unique username
  const usernameTaken = accounts.some(
    (acc) => acc.username.toLowerCase() === cleanUsername.toLowerCase()
  );
  if (usernameTaken) {
    return { success: false, message: `Username "${cleanUsername}" is already registered. Please choose another.` };
  }

  // Check unique phone
  const phoneTaken = accounts.some((acc) => acc.phone === cleanPhone);
  if (phoneTaken) {
    return { success: false, message: `Mobile number ${cleanPhone} is already registered. Please sign in instead.` };
  }

  // New user gets a ₹500 welcome bonus + ₹100 if referral code is applied
  const cleanReferral = referralCode ? sanitizeText(referralCode, 15).toUpperCase() : undefined;
  const welcomeBonus = cleanReferral ? 600 : 500;

  const newAccount: UserAccount = {
    id: `user_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    name: cleanName,
    username: cleanUsername,
    phone: cleanPhone,
    passwordHash: password,
    mpin: mpinCheck.mpin,
    role: 'user', // Default role is user/player
    walletBalance: welcomeBonus,
    biometricEnabled: !!biometricEnabled,
    registeredAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
    referralCode: cleanReferral,
    status: 'active',
  };

  accounts.push(newAccount);
  saveRegisteredAccounts(accounts);

  // Direct synchronization into active Supabase users table
  try {
    const userUuid = toSupabaseUuid(cleanPhone);
    supabase
      .from('users')
      .upsert(
        {
          id: userUuid,
          name: cleanName,
          mobile: cleanPhone,
          role: 'user',
          status: 'active',
          main_wallet: welcomeBonus,
          gaming_wallet: welcomeBonus,
          winning_wallet: 0,
        },
        { onConflict: 'mobile' }
      )
      .then(({ error }) => {
        if (error) {
          console.warn('[Supabase Note] Direct registration sync notice:', error.message);
        }
      });
  } catch (err) {
    console.warn('[Supabase Network] Registration sync notice:', err);
  }

  const profile = accountToProfile(newAccount);
  persistSession(profile);

  return {
    success: true,
    user: profile,
    message: `Account created successfully! ₹${welcomeBonus} Welcome Bonus added to your wallet!`,
  };
}

/**
 * Persist active session in encrypted local storage with signed cryptographic token
 */
export function persistSession(profile: UserProfile): void {
  try {
    secureStorage.setItem(SESSION_STORAGE_KEY, profile);
    localStorage.setItem('rama777_auth_session', 'true');
    localStorage.setItem('rama777_user', JSON.stringify(profile));
    localStorage.setItem('rama777_user_uid', profile.uid || profile.id || '');
    localStorage.setItem('rama777_user_phone', profile.phone);
    localStorage.setItem('rama777_user_name', profile.name);
    localStorage.setItem('rama777_user_role', profile.role || 'user');
    if (profile.username) {
      localStorage.setItem('rama777_user_username', profile.username);
    }
    // Generate signed session token with HMAC-SHA256 signature and idle activity tracker
    generateSessionToken(profile);
  } catch (err) {
    console.error('Failed to persist session:', err);
  }
}

/**
 * Get active session with cryptographic token and idle timeout validation
 */
export function getActiveSession(): UserProfile | null {
  try {
    // 1. Verify cryptographic token signature and idle expiration
    const validation = validateSessionToken();
    if (!validation.isValid && validation.isExpired) {
      console.warn('[SECURITY] Session expired or invalid token:', validation.error);
      clearSession();
      return null;
    }

    // 2. Retrieve tamper-verified profile from encrypted storage
    const profile = secureStorage.getItem<UserProfile | null>(SESSION_STORAGE_KEY, null);
    if (!profile) return null;

    updateLastActivity();
    return profile;
  } catch (err) {
    return null;
  }
}

/**
 * Clear session and revoke active token
 */
export function clearSession(): void {
  try {
    secureStorage.removeItem(SESSION_STORAGE_KEY);
    revokeSession();
    localStorage.setItem('rama777_auth_session', 'false');
    localStorage.removeItem('rama777_user');
    localStorage.removeItem('rama777_user_role');
  } catch (err) {
    console.error('Failed to clear session:', err);
  }
}

/**
 * Update current account in storage
 */
export function saveCurrentAccount(updated: UserAccount): void {
  const accounts = getRegisteredAccounts();
  const idx = accounts.findIndex((a) => a.id === updated.id);
  if (idx >= 0) {
    accounts[idx] = updated;
  } else {
    accounts.push(updated);
  }
  saveRegisteredAccounts(accounts);
}

/**
 * Update wallet balance for an account
 */
export function adjustUserBalance(userId: string, newBalance: number): boolean {
  const accounts = getRegisteredAccounts();
  const acc = accounts.find((a) => a.id === userId || a.phone === userId || a.username === userId);
  if (acc) {
    acc.walletBalance = newBalance;
    saveRegisteredAccounts(accounts);

    // Direct synchronization into active Supabase users table
    try {
      const cleanPhone = (acc.phone || '').replace(/\D/g, '');
      const userUuid = toSupabaseUuid(cleanPhone || acc.id);
      supabase
        .from('users')
        .update({
          main_wallet: newBalance,
          gaming_wallet: newBalance,
        })
        .or(`id.eq.${userUuid},mobile.eq.${cleanPhone}`)
        .then(({ error }) => {
          if (error) {
            console.warn('[Supabase Note] Direct balance update notice:', error.message);
          }
        });
    } catch (e) {}

    return true;
  }
  return false;
}

/**
 * Change MPIN for a user
 */
export function updateUserMpin(identifier: string, newMpin: string): boolean {
  const accounts = getRegisteredAccounts();
  const acc = accounts.find(
    (a) => a.id === identifier || a.phone === identifier || a.username === identifier
  );
  if (acc && newMpin.length === 4) {
    acc.mpin = newMpin;
    saveRegisteredAccounts(accounts);
    return true;
  }
  return false;
}

/**
 * Switch role (e.g. for testing or administrative privilege grant)
 */
export function switchUserRole(identifier: string, newRole: UserRole): UserProfile | null {
  const accounts = getRegisteredAccounts();
  const acc = accounts.find(
    (a) => a.id === identifier || a.phone === identifier || a.username === identifier
  );
  if (acc) {
    acc.role = newRole;
    saveRegisteredAccounts(accounts);

    // Direct synchronization into active Supabase users table
    try {
      const cleanPhone = (acc.phone || '').replace(/\D/g, '');
      const userUuid = toSupabaseUuid(cleanPhone || acc.id);
      supabase
        .from('users')
        .update({ role: newRole })
        .or(`id.eq.${userUuid},mobile.eq.${cleanPhone}`)
        .then(() => {});
    } catch (e) {}

    const profile = accountToProfile(acc);
    persistSession(profile);
    return profile;
  }
  return null;
}
