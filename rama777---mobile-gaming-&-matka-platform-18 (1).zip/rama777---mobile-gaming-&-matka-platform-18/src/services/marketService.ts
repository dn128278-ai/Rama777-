/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Supabase-backed Market Service for RAMA777.
 * Provides real-time subscriptions to the Supabase "markets" table
 * and evaluates market status, session countdowns, and results.
 */

import { supabase } from '../supabase';
import { MarketItem, MarketResultRecord } from '../types';
import {
  evaluateMarkets,
  formatRemainingDuration,
  parseTimeString,
  formatMarketResult,
  getDigitFromPana,
  getDailyMarketResult,
} from '../utils/marketEngine';

/**
 * Evaluates dynamic status and countdown for a MarketItem given a specific reference time.
 * Automatically clears yesterday's results when on a new calendar day and resets active betting sessions.
 */
export function evaluateSingleMarket(
  market: MarketItem,
  currentTime: Date
): MarketItem {
  const year = currentTime.getFullYear();
  const month = currentTime.getMonth();
  const day = currentTime.getDate();
  const nowMs = currentTime.getTime();
  const currentDateKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

  // Date Check: If market carries previous day results, clear them out for the new calendar day!
  const isPreviousDay = Boolean(market.marketDate && market.marketDate !== currentDateKey);
  let currentOpenPana = isPreviousDay ? '***' : market.openPana || '***';
  let currentClosePana = isPreviousDay ? '***' : market.closePana || '***';
  let currentJodi = isPreviousDay ? '**' : market.jodi || '**';
  let previousLastResult = market.lastResult;
  if (isPreviousDay && (market.openPana !== '***' || market.closePana !== '***')) {
    previousLastResult = `${market.openPana}-${market.jodi}-${market.closePana}`;
  }

  const parsedOpen =
    market.openHour !== undefined && market.openMinute !== undefined
      ? { hour: market.openHour, minute: market.openMinute }
      : parseTimeString(market.openTime);

  const parsedClose =
    market.closeHour !== undefined && market.closeMinute !== undefined
      ? { hour: market.closeHour, minute: market.closeMinute }
      : parseTimeString(market.closeTime);

  if (!parsedOpen || !parsedClose) {
    const formattedFallback = formatMarketResult({
      openPana: currentOpenPana,
      jodi: currentJodi,
      closePana: currentClosePana,
    });
    return {
      ...market,
      openPana: formattedFallback.openPana,
      jodi: formattedFallback.jodi,
      closePana: formattedFallback.closePana,
      lastResult: previousLastResult || market.lastResult,
      isOpen: market.isOpen ?? true,
      countdownText: market.countdownText || market.status || 'Active',
      marketDate: currentDateKey,
    };
  }

  const openHour = parsedOpen.hour;
  const openMinute = parsedOpen.minute;
  const closeHour = parsedClose.hour;
  const closeMinute = parsedClose.minute;

  const crossesMidnight =
    closeHour < openHour || (closeHour === openHour && closeMinute < openMinute);

  const openDateTime = new Date(year, month, day, openHour, openMinute, 0, 0);
  const closeDateTime = crossesMidnight
    ? new Date(year, month, day + 1, closeHour, closeMinute, 0, 0)
    : new Date(year, month, day, closeHour, closeMinute, 0, 0);

  const openMs = openDateTime.getTime();
  const closeMs = closeDateTime.getTime();

  let autoStatus: 'Running for Open' | 'Running for Close' | 'Closed for Today';
  let autoIsOpen: boolean;
  let autoAllowedSession: 'all' | 'close_only' | 'none';
  let countdownText: string;
  let timeRemainingMs: number;

  if (nowMs < openMs) {
    // Before Open Time on today's date: Fresh Open Session!
    autoStatus = 'Running for Open';
    autoIsOpen = true;
    autoAllowedSession = 'all';
    timeRemainingMs = openMs - nowMs;
    countdownText = `Open Bids close in ${formatRemainingDuration(timeRemainingMs)}`;
    // If market has yesterday's or previous numbers, preserve them in lastResult before resetting
    if (currentOpenPana !== '***' || currentClosePana !== '***') {
      if (!previousLastResult || previousLastResult.includes('***')) {
        previousLastResult = `${currentOpenPana}-${currentJodi}-${currentClosePana}`;
      }
    }
    // Guarantee no declared results for today before open time
    currentOpenPana = '***';
    currentClosePana = '***';
    currentJodi = '**';
  } else if (nowMs >= openMs && nowMs < closeMs) {
    // Between Open and Close: Open declared, Close session active!
    autoStatus = 'Running for Close';
    autoIsOpen = true;
    autoAllowedSession = 'close_only';
    timeRemainingMs = closeMs - nowMs;
    countdownText = `Close Bids close in ${formatRemainingDuration(timeRemainingMs)}`;
    currentClosePana = '***';
    if (!currentOpenPana || currentOpenPana === '***') {
      const dailyRes = getDailyMarketResult(market.id || market.name, currentDateKey);
      currentOpenPana = dailyRes.openPana;
      currentJodi = `${dailyRes.openDigit}*`;
    }
  } else {
    // After Close: Market completed for today
    autoStatus = 'Closed for Today';
    autoIsOpen = false;
    autoAllowedSession = 'none';
    timeRemainingMs = 0;
    countdownText = `Closed • Next Open tomorrow at ${market.openTime}`;
    if (!currentOpenPana || currentOpenPana === '***' || !currentClosePana || currentClosePana === '***') {
      const dailyRes = getDailyMarketResult(market.id || market.name, currentDateKey);
      currentOpenPana = dailyRes.openPana;
      currentClosePana = dailyRes.closePana;
      currentJodi = dailyRes.jodi;
    }
  }

  const isExplicitClosed = Boolean((market as any).isDisabled);
  const status = isExplicitClosed ? 'Closed for Today' : autoStatus;
  const isOpen = isExplicitClosed ? false : autoIsOpen;
  const allowedSession = isExplicitClosed ? 'none' : autoAllowedSession;

  const formattedRes = formatMarketResult({
    openPana: currentOpenPana,
    jodi: currentJodi,
    closePana: currentClosePana,
  });

  return {
    ...market,
    openPana: formattedRes.openPana,
    jodi: formattedRes.jodi,
    closePana: formattedRes.closePana,
    lastResult: previousLastResult || market.lastResult,
    openHour,
    openMinute,
    closeHour,
    closeMinute,
    status,
    isOpen,
    allowedSession,
    timeRemainingMs,
    countdownText: isExplicitClosed
      ? 'Market Temporarily Closed'
      : countdownText,
    marketDate: currentDateKey,
  };
}

/**
 * Normalizes an arbitrary market ID or key (e.g. 'mkt-kalyan', 'kalyan_day')
 * into an alphanumeric key for cross-matching against result documents.
 */
export function normalizeMarketKey(key: string): string {
  if (!key) return '';
  return key
    .toLowerCase()
    .replace(/^mkt[-_]/i, '')
    .replace(/[^a-z0-9]/g, '');
}

/**
 * Transforms a Supabase row or document from 'markets' into a normalized MarketItem.
 * Handles both snake_case (Supabase) and camelCase properties.
 */
export function transformSupabaseRowToMarket(
  row: Record<string, any>,
  currentTime: Date
): MarketItem {
  const docId = String(row.id || row.market_id || row.marketId || '');
  let name = (
    row.name ||
    row.market_name ||
    row.marketName ||
    row.title ||
    ''
  ).toString().trim();

  if (!name) {
    const cleaned = docId.replace(/^mkt[-_]/i, '').replace(/[-_]/g, ' ').trim();
    if (/^[a-zA-Z0-9\s]+$/.test(cleaned) && cleaned.length <= 25) {
      name = cleaned.toUpperCase();
    } else {
      name = `MARKET ${docId.slice(0, 6).toUpperCase()}`;
    }
  } else {
    name = name.toUpperCase();
  }

  const openTime = (
    row.open_time ||
    row.openTime ||
    row.open ||
    '10:00 AM'
  ).toString().trim();

  const closeTime = (
    row.close_time ||
    row.closeTime ||
    row.close ||
    '12:00 PM'
  ).toString().trim();

  const dayOfWeek = currentTime.getDay();
  const isSaturday = dayOfWeek === 6;
  const isSunday = dayOfWeek === 0;
  const isWeekendClosed =
    (isSaturday && row.saturday_open === false) ||
    (isSunday && row.sunday_open === false) ||
    (isSaturday && row.saturdayOpen === false) ||
    (isSunday && row.sundayOpen === false);
  const isDisabled = Boolean(row.is_disabled || row.isDisabled) || isWeekendClosed;

  const rawLastResult = (
    row.last_result ||
    row.lastResult ||
    row.result ||
    ''
  ).toString().trim();

  let lrOpenPana: string | undefined;
  let lrJodi: string | undefined;
  let lrClosePana: string | undefined;

  if (rawLastResult && rawLastResult.includes('-')) {
    const parts = rawLastResult.split('-').map((s: string) => s.trim());
    if (parts.length >= 3) {
      lrOpenPana = parts[0];
      lrJodi = parts[1];
      lrClosePana = parts[2];
    } else if (parts.length === 2) {
      lrOpenPana = parts[0];
      lrJodi = parts[1];
    }
  } else if (/^\d{2}$/.test(rawLastResult)) {
    lrJodi = rawLastResult;
  }

  const rawOpenPana = (
    row.open_pana ??
    row.openPana ??
    row.openPanna ??
    lrOpenPana ??
    '***'
  ).toString().trim();

  const rawClosePana = (
    row.close_pana ??
    row.closePana ??
    row.closePanna ??
    lrClosePana ??
    '***'
  ).toString().trim();

  let rawJodi = (
    row.jodi ??
    row.jodi_digit ??
    row.jodiDigit ??
    lrJodi ??
    '**'
  ).toString().trim();

  if (
    (!rawJodi || rawJodi === '**') &&
    (rawOpenPana !== '***' || rawClosePana !== '***')
  ) {
    const oD = /^\d{3}$/.test(rawOpenPana) ? String(getDigitFromPana(rawOpenPana)) : '*';
    const cD = /^\d{3}$/.test(rawClosePana) ? String(getDigitFromPana(rawClosePana)) : '*';
    if (oD !== '*' || cD !== '*') {
      rawJodi = `${oD}${cD}`;
    }
  }

  const formattedRes = formatMarketResult({
    openPana: rawOpenPana,
    jodi: rawJodi,
    closePana: rawClosePana,
    result: rawLastResult,
  });

  const resolvedLastResult =
    rawLastResult || `${formattedRes.openPana}-${formattedRes.jodi}-${formattedRes.closePana}`;

  let explicitIsOpen: boolean | undefined = undefined;
  if (isDisabled) {
    explicitIsOpen = false;
  } else if (typeof row.is_open === 'boolean') {
    explicitIsOpen = row.is_open;
  } else if (typeof row.isOpen === 'boolean') {
    explicitIsOpen = row.isOpen;
  }

  let explicitStatus = row.status || row.market_status;
  if (isDisabled) {
    explicitStatus = 'Closed for Today';
  } else if (explicitStatus) {
    const stLower = String(explicitStatus).trim().toLowerCase();
    if (stLower === 'active' || stLower === 'open') {
      explicitStatus = 'Running for Open';
    } else if (stLower === 'closed' || stLower === 'inactive') {
      explicitStatus = 'Closed for Today';
    } else if (stLower.includes('close')) {
      explicitStatus = 'Running for Close';
    }
  } else if (explicitIsOpen === false) {
    explicitStatus = 'Closed for Today';
  }

  const rawItem: MarketItem = {
    id: docId,
    marketId: String(row.market_id || row.id || docId),
    name,
    openPana: formattedRes.openPana,
    jodi: formattedRes.jodi,
    closePana: formattedRes.closePana,
    lastResult: resolvedLastResult,
    openTime,
    closeTime,
    status: explicitStatus as any,
    isOpen: explicitIsOpen as any,
    allowedSession: row.allowed_session || row.allowedSession,
    order: typeof row.order === 'number' ? row.order : undefined,
    countdownText: isWeekendClosed
      ? 'Market Closed on Weekends'
      : isDisabled
      ? 'Market Temporarily Closed'
      : row.countdown_text || row.countdownText,
    marketDate: row.market_date || row.marketDate || row.date_key || row.dateKey || undefined,
  };

  (rawItem as any).isDisabled = isDisabled;
  return evaluateSingleMarket(rawItem, currentTime);
}

// Backward compatibility alias
export const transformFirestoreDocToMarket = transformSupabaseRowToMarket;

/**
 * Fetch all markets once from Supabase.
 */
export async function fetchRealtimeMarkets(
  currentTime: Date = new Date()
): Promise<MarketItem[]> {
  try {
    const { data, error } = await supabase
      .from('markets')
      .select('*')
      .order('name', { ascending: true });

    if (error || !data || data.length === 0) {
      return [];
    }

    return data.map((r) => transformSupabaseRowToMarket(r, currentTime));
  } catch (err) {
    console.warn('Error fetching Supabase markets:', err);
    return [];
  }
}

/**
 * Subscribes to real-time updates from Supabase "markets" table.
 * Changes by Admin or live result updates trigger immediate UI updates without page refresh.
 */
export function subscribeToRealtimeMarkets(
  onMarketsUpdate: (markets: MarketItem[], source: 'supabase') => void,
  getCurrentTime: () => Date
): () => void {
  let isMounted = true;

  // 1. Initial Fetch
  const loadInitial = async () => {
    try {
      const { data, error } = await supabase
        .from('markets')
        .select('*')
        .order('name', { ascending: true });

      if (!isMounted) return;

      if (!error && data && data.length > 0) {
        const currentTime = getCurrentTime();
        const items = data.map((row) => transformSupabaseRowToMarket(row, currentTime));
        onMarketsUpdate(items, 'supabase');
      } else {
        // Fallback default evaluated markets if table empty
        const fallback = evaluateMarkets(getCurrentTime());
        onMarketsUpdate(fallback, 'supabase');
      }
    } catch (err) {
      console.warn('Initial Supabase markets fetch warning:', err);
      if (isMounted) {
        const fallback = evaluateMarkets(getCurrentTime());
        onMarketsUpdate(fallback, 'supabase');
      }
    }
  };

  loadInitial();

  // 2. Realtime Channel Subscription directly to public:markets
  const channel = supabase
    .channel('public:markets')
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'markets' },
      async (payload) => {
        if (!isMounted) return;
        console.log('[Supabase Realtime] public:markets event received:', payload.eventType);
        try {
          const { data, error } = await supabase
            .from('markets')
            .select('*')
            .order('name', { ascending: true });

          if (!isMounted) return;
          if (error) {
            console.error('[Supabase Error] Reload markets failed:', error.message);
            return;
          }
          if (data) {
            const currentTime = getCurrentTime();
            const items = data.map((row) => transformSupabaseRowToMarket(row, currentTime));
            onMarketsUpdate(items, 'supabase');
          }
        } catch (e) {
          console.error('[Supabase Network Failure] Error reloading markets on realtime event:', e);
        }
      }
    )
    .subscribe((status) => {
      console.log('[Supabase Realtime] public:markets status:', status);
    });

  return () => {
    isMounted = false;
    supabase.removeChannel(channel);
  };
}

/**
 * Merges declared results from 'market_results' collection into markets in real-time,
 * immediately updating openPana, jodi, closePana, lastResult, and closing/progressing markets.
 * Flexibly matches markets by exact ID, normalized slug (stripping 'mkt-' prefixes), or market name.
 */
export function mergeMarketResultsIntoMarkets(
  markets: MarketItem[],
  results: MarketResultRecord[],
  currentTime: Date
): MarketItem[] {
  const year = currentTime.getFullYear();
  const month = currentTime.getMonth();
  const day = currentTime.getDate();
  const currentDateKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  const currentDateDisplay = `${String(day).padStart(2, '0')}-${String(month + 1).padStart(2, '0')}-${year}`;

  const todayResults = new Map<string, MarketResultRecord>();
  for (const r of results) {
    const isToday =
      r.dateKey === currentDateKey ||
      r.date === currentDateDisplay ||
      (r.dateKey && r.dateKey.startsWith(currentDateKey)) ||
      (r.id && r.id.endsWith(`_${currentDateKey}`));
    if (isToday) {
      if (r.marketId) {
        todayResults.set(r.marketId.toLowerCase(), r);
        todayResults.set(normalizeMarketKey(r.marketId), r);
      }
      if (r.marketName) {
        todayResults.set(r.marketName.trim().toLowerCase(), r);
        todayResults.set(normalizeMarketKey(r.marketName), r);
      }
    }
  }

  return markets.map((m) => {
    const declared =
      todayResults.get(m.id.toLowerCase()) ||
      todayResults.get(normalizeMarketKey(m.id)) ||
      (m.marketId ? todayResults.get(m.marketId.toLowerCase()) : null) ||
      (m.marketId ? todayResults.get(normalizeMarketKey(m.marketId)) : null) ||
      todayResults.get(m.name.trim().toLowerCase()) ||
      todayResults.get(normalizeMarketKey(m.name));

    if (!declared) {
      return evaluateSingleMarket(m, currentTime);
    }

    const openDeclared = Boolean(declared.openPana && declared.openPana !== '***');
    const closeDeclared = Boolean(declared.closePana && declared.closePana !== '***');
    const jodiDeclared = Boolean(declared.jodi && declared.jodi !== '**');

    const mergedOpenPana = openDeclared ? declared.openPana : m.openPana;
    const mergedClosePana = closeDeclared ? declared.closePana : m.closePana;
    const mergedJodi = jodiDeclared ? declared.jodi : m.jodi;
    const mergedLastResult = `${mergedOpenPana}-${mergedJodi}-${mergedClosePana}`;

    const mergedItem: MarketItem = {
      ...m,
      openPana: mergedOpenPana,
      closePana: mergedClosePana,
      jodi: mergedJodi,
      lastResult: mergedLastResult,
    };

    if (openDeclared && closeDeclared) {
      mergedItem.status = 'Closed for Today';
      mergedItem.isOpen = false;
      mergedItem.allowedSession = 'none';
      mergedItem.countdownText = 'Result Declared for Today';
    } else if (openDeclared) {
      if (mergedItem.status === 'Running for Open') {
        mergedItem.status = 'Running for Close';
        mergedItem.allowedSession = 'close_only';
      }
    }

    return evaluateSingleMarket(mergedItem, currentTime);
  });
}
