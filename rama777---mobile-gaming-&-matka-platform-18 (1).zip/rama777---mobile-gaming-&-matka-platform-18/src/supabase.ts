/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Supabase Client Initialization for RAMA777
 * Direct hardcoded configuration with instant fallback.
 */

import { createClient } from '@supabase/supabase-js';

// Hardcoded default connection constants
const DEFAULT_SUPABASE_URL = 'https://ekngcegflrtmlblxulyt.supabase.co';
const DEFAULT_SUPABASE_ANON_KEY = 'sb_publishable_h1WzUpjPRT57tQEQPsFKWg_5sbEILhB';

// Resolves directly with guaranteed hardcoded fallback without waiting for .env files
export const SUPABASE_URL =
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_URL)
    ? String(import.meta.env.VITE_SUPABASE_URL).trim()
    : DEFAULT_SUPABASE_URL;

export const SUPABASE_ANON_KEY =
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_ANON_KEY)
    ? String(import.meta.env.VITE_SUPABASE_ANON_KEY).trim()
    : DEFAULT_SUPABASE_ANON_KEY;

export const supabase = createClient(
  SUPABASE_URL || DEFAULT_SUPABASE_URL,
  SUPABASE_ANON_KEY || DEFAULT_SUPABASE_ANON_KEY,
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
    },
    realtime: {
      params: {
        eventsPerSecond: 15,
      },
    },
  }
);

export default supabase;
