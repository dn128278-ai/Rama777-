/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Input Sanitization & Anti-Injection Guard for RAMA777.
 * Prevents Cross-Site Scripting (XSS), SQL/NoSQL injection, prototype pollution,
 * and malicious parameter manipulation across all user forms.
 */

/**
 * Escapes dangerous HTML and script characters to prevent Stored & Reflected XSS
 */
export function sanitizeHtml(input: unknown): string {
  if (typeof input !== 'string') return '';
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;')
    .replace(/javascript:/gi, '')
    .replace(/on\w+=/gi, '')
    .trim();
}

/**
 * Strips all control characters and dangerous code symbols while preserving readable text
 */
export function sanitizeText(input: unknown, maxLength: number = 200): string {
  if (typeof input !== 'string') return '';
  const cleaned = input
    .replace(/[<>'"`;\\]/g, '')
    .replace(/[\x00-\x1F\x7F]/g, '')
    .trim();
  return cleaned.slice(0, maxLength);
}

/**
 * Strictly sanitizes and validates 10-digit Indian Mobile Numbers
 */
export function sanitizePhone(input: unknown): { isValid: boolean; phone: string; error?: string } {
  if (!input) return { isValid: false, phone: '', error: 'Mobile number is required' };
  const digits = String(input).replace(/\D/g, '');
  if (digits.length !== 10) {
    return { isValid: false, phone: digits, error: 'Mobile number must be exactly 10 digits' };
  }
  if (!/^[6-9]/.test(digits)) {
    return { isValid: false, phone: digits, error: 'Indian mobile numbers must start with 6, 7, 8, or 9' };
  }
  return { isValid: true, phone: digits };
}

/**
 * Sanitizes Username (letters, numbers, underscores only, 3-20 chars)
 */
export function sanitizeUsername(input: unknown): { isValid: boolean; username: string; error?: string } {
  if (typeof input !== 'string') return { isValid: false, username: '', error: 'Username is required' };
  const clean = input.trim();
  if (clean.length < 3) {
    return { isValid: false, username: clean, error: 'Username must be at least 3 characters' };
  }
  if (clean.length > 20) {
    return { isValid: false, username: clean.slice(0, 20), error: 'Username cannot exceed 20 characters' };
  }
  if (!/^[a-zA-Z0-9_]+$/.test(clean)) {
    return { isValid: false, username: clean, error: 'Username can only contain letters, numbers, and underscores' };
  }
  return { isValid: true, username: clean };
}

/**
 * Strictly sanitizes 4-digit Security MPIN
 */
export function sanitizeMpin(input: unknown): { isValid: boolean; mpin: string } {
  const digits = String(input || '').replace(/\D/g, '').slice(0, 4);
  return {
    isValid: digits.length === 4,
    mpin: digits,
  };
}

/**
 * Sanitizes and validates monetary amounts and gaming points.
 * Defends against negative values, Infinity, NaN, scientific notation (e.g. 1e12),
 * and unauthorized decimals where integers are required.
 */
export function sanitizeAmount(
  input: unknown,
  min: number = 1,
  max: number = 1000000,
  allowDecimals: boolean = false
): { isValid: boolean; amount: number; error?: string } {
  if (input === null || input === undefined || input === '') {
    return { isValid: false, amount: 0, error: 'Amount is required' };
  }

  // Reject exponential / scientific notation like 1e10
  const strVal = String(input).trim();
  if (/[eE]/.test(strVal)) {
    return { isValid: false, amount: 0, error: 'Invalid numeric format' };
  }

  const num = Number(strVal);
  if (isNaN(num) || !isFinite(num)) {
    return { isValid: false, amount: 0, error: 'Amount must be a valid number' };
  }

  if (num < min) {
    return { isValid: false, amount: num, error: `Minimum amount is ₹${min.toLocaleString('en-IN')}` };
  }

  if (num > max) {
    return { isValid: false, amount: num, error: `Maximum amount cannot exceed ₹${max.toLocaleString('en-IN')}` };
  }

  const cleanAmount = allowDecimals ? Math.round(num * 100) / 100 : Math.floor(num);
  return { isValid: true, amount: cleanAmount };
}

/**
 * Sanitizes UPI Transaction Reference / UTR Number
 * UTR is strictly 8 to 18 alphanumeric characters
 */
export function sanitizeUtr(input: unknown): { isValid: boolean; utr: string; error?: string } {
  if (typeof input !== 'string') return { isValid: false, utr: '', error: 'UTR number is required' };
  const clean = input.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (clean.length < 8) {
    return { isValid: false, utr: clean, error: 'UTR must be at least 8 alphanumeric characters' };
  }
  if (clean.length > 22) {
    return { isValid: false, utr: clean.slice(0, 22), error: 'UTR cannot exceed 22 characters' };
  }
  return { isValid: true, utr: clean };
}

/**
 * Sanitizes and validates Indian Financial System Code (IFSC)
 * Format: 4 letters + '0' + 6 letters/digits (e.g. SBIN0001234)
 */
export function sanitizeIfsc(input: unknown): { isValid: boolean; ifsc: string; error?: string } {
  if (typeof input !== 'string') return { isValid: false, ifsc: '', error: 'IFSC code is required' };
  const clean = input.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (clean.length !== 11) {
    return { isValid: false, ifsc: clean, error: 'IFSC code must be exactly 11 characters' };
  }
  if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(clean)) {
    return { isValid: false, ifsc: clean, error: 'Invalid IFSC format (e.g. SBIN0001234)' };
  }
  return { isValid: true, ifsc: clean };
}

/**
 * Sanitizes Bank Account Number (strictly 9 to 18 digits)
 */
export function sanitizeBankAccount(input: unknown): { isValid: boolean; accountNumber: string; error?: string } {
  const digits = String(input || '').replace(/\D/g, '');
  if (digits.length < 9 || digits.length > 18) {
    return { isValid: false, accountNumber: digits, error: 'Account number must be 9 to 18 digits' };
  }
  return { isValid: true, accountNumber: digits };
}
