import { MarketItem, StarlineResult } from '../types';

export interface MarketScheduleConfig {
  id: string;
  name: string;
  openTime: string;
  closeTime: string;
  openHour: number;
  openMinute: number;
  closeHour: number;
  closeMinute: number;
  crossesMidnight?: boolean;
}

// Master market schedules matching authentic Indian Matka schedules
export const MARKET_SCHEDULES: MarketScheduleConfig[] = [
  {
    id: 'devi_morning',
    name: 'DEVI MORNING',
    openTime: '08:55 AM',
    closeTime: '09:55 AM',
    openHour: 8,
    openMinute: 55,
    closeHour: 9,
    closeMinute: 55,
  },
  {
    id: 'surya_morning',
    name: 'SURYA MORNING',
    openTime: '10:05 AM',
    closeTime: '11:05 AM',
    openHour: 10,
    openMinute: 5,
    closeHour: 11,
    closeMinute: 5,
  },
  {
    id: 'sridevi',
    name: 'SRIDEVI',
    openTime: '11:40 AM',
    closeTime: '12:40 PM',
    openHour: 11,
    openMinute: 40,
    closeHour: 12,
    closeMinute: 40,
  },
  {
    id: 'time_bazar',
    name: 'TIME BAZAR',
    openTime: '01:12 PM',
    closeTime: '02:12 PM',
    openHour: 13,
    openMinute: 12,
    closeHour: 14,
    closeMinute: 12,
  },
  {
    id: 'madhur_day',
    name: 'MADHUR DAY',
    openTime: '01:30 PM',
    closeTime: '02:30 PM',
    openHour: 13,
    openMinute: 30,
    closeHour: 14,
    closeMinute: 30,
  },
  {
    id: 'milan_day',
    name: 'MILAN DAY',
    openTime: '03:00 PM',
    closeTime: '05:00 PM',
    openHour: 15,
    openMinute: 0,
    closeHour: 17,
    closeMinute: 0,
  },
  {
    id: 'kalyan',
    name: 'KALYAN',
    openTime: '04:15 PM',
    closeTime: '06:15 PM',
    openHour: 16,
    openMinute: 15,
    closeHour: 18,
    closeMinute: 15,
  },
  {
    id: 'madhur_night',
    name: 'MADHUR NIGHT',
    openTime: '08:30 PM',
    closeTime: '10:30 PM',
    openHour: 20,
    openMinute: 30,
    closeHour: 22,
    closeMinute: 30,
  },
  {
    id: 'surya_night',
    name: 'SURYA NIGHT',
    openTime: '09:05 PM',
    closeTime: '11:00 PM',
    openHour: 21,
    openMinute: 5,
    closeHour: 23,
    closeMinute: 0,
  },
  {
    id: 'milan_night',
    name: 'MILAN NIGHT',
    openTime: '09:16 PM',
    closeTime: '11:16 PM',
    openHour: 21,
    openMinute: 16,
    closeHour: 23,
    closeMinute: 16,
  },
  {
    id: 'kalyan_night',
    name: 'KALYAN NIGHT',
    openTime: '09:20 PM',
    closeTime: '11:35 PM',
    openHour: 21,
    openMinute: 20,
    closeHour: 23,
    closeMinute: 35,
  },
  {
    id: 'rajdhani_night',
    name: 'RAJDHANI NIGHT',
    openTime: '09:30 PM',
    closeTime: '11:45 PM',
    openHour: 21,
    openMinute: 30,
    closeHour: 23,
    closeMinute: 45,
  },
  {
    id: 'main_bazar',
    name: 'MAIN BAZAR',
    openTime: '09:40 PM',
    closeTime: '12:05 AM',
    openHour: 21,
    openMinute: 40,
    closeHour: 0,
    closeMinute: 5,
    crossesMidnight: true,
  },
];

// Pool of authentic 3-digit Panas in Matka
const AUTHENTIC_PANAS = [
  '128', '137', '146', '236', '245', '290', '380', '470', '489', '560', '678', '579',
  '140', '159', '230', '249', '258', '348', '357', '680', '789', '118', '226', '334',
  '180', '238', '333', '389', '020', '237', '256', '470', '799', '447', '158', '118',
  '789', '668', '690', '160', '567', '125', '234', '147', '258', '369', '150', '240',
  '168', '267', '347', '356', '890', '112', '220', '338', '446', '554', '662', '770',
  '270', '379', '469', '478', '568', '126', '135', '189', '234', '289', '379', '469',
];

// Simple deterministic hash based on market ID and date string (YYYY-MM-DD)
function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0; // Convert to 32bit integer
  }
  return Math.abs(hash);
}

// Calculate the single digit from Pana sum modulo 10
export function getDigitFromPana(pana: string): number {
  if (!pana) return 0;
  const digits = pana.split('').map((d) => parseInt(d, 10));
  const sum = digits.reduce((acc, curr) => acc + (isNaN(curr) ? 0 : curr), 0);
  return sum % 10;
}

export interface FormattedMarketResult {
  openPana: string;
  jodi: string;
  closePana: string;
  formatted: string; // e.g. "333 - 99 - 333"
  isFullDeclared: boolean;
  isOpenDeclared: boolean;
  isCloseDeclared: boolean;
}

/**
 * Dynamic Matka Result Formatter.
 * Resolves declared and partial results from backend, Firestore, or admin state.
 * When open pana and close pana are declared (e.g., 333 and 333), dynamically derives
 * the full 2-digit jodi (e.g., 99) even if the raw backend state holds masked asterisks (**),
 * returning "333 - 99 - 333" cleanly.
 */
export function formatMarketResult(market: {
  openPana?: string | null;
  jodi?: string | null;
  closePana?: string | null;
  result?: string | null;
  marketResult?: string | null;
  fullResult?: string | null;
}): FormattedMarketResult {
  let openPana = (market.openPana ?? '').toString().trim();
  let jodi = (market.jodi ?? '').toString().trim();
  let closePana = (market.closePana ?? '').toString().trim();

  // 1. Check if a composite result string was provided (e.g. "333-99-333" or "333 - ** - 333")
  const composite = (market.result || market.marketResult || market.fullResult || '').toString().trim();
  if (composite && composite.includes('-')) {
    const parts = composite.split(/[-–—]/).map((p) => p.trim());
    if (parts.length >= 3) {
      if (!openPana || openPana === '***') openPana = parts[0];
      if (!jodi || jodi === '**') jodi = parts[1];
      if (!closePana || closePana === '***') closePana = parts[2];
    } else if (parts.length === 2) {
      if (!jodi || jodi === '**') jodi = parts[0];
      if (!closePana || closePana === '***') closePana = parts[1];
    }
  }

  // Normalize defaults
  if (!openPana) openPana = '***';
  if (!jodi) jodi = '**';
  if (!closePana) closePana = '***';

  const isOpenValidPana = /^\d{3}$/.test(openPana);
  const isCloseValidPana = /^\d{3}$/.test(closePana);

  const openDigit = isOpenValidPana ? getDigitFromPana(openPana) : null;
  const closeDigit = isCloseValidPana ? getDigitFromPana(closePana) : null;

  // 2. Dynamic Jodi calculation when open and/or close are declared from backend/admin state
  if (isOpenValidPana && isCloseValidPana) {
    // Both open pana and close pana are declared (e.g. 333 and 333)
    // If jodi is masked ('**', '9*', '*9') or undeclared/missing, dynamically derive it!
    if (!/^\d{2}$/.test(jodi) || jodi === '**' || jodi.includes('*')) {
      jodi = `${openDigit}${closeDigit}`;
    }
  } else if (isOpenValidPana && !isCloseValidPana) {
    // Only open pana is declared (close is still '***')
    if (jodi === '**' || !jodi) {
      jodi = `${openDigit}*`;
    } else if (jodi.length === 1 && /^\d$/.test(jodi)) {
      jodi = `${jodi}*`;
    }
  } else if (!isOpenValidPana && isCloseValidPana) {
    // Only close pana is declared
    if (jodi === '**' || !jodi) {
      jodi = `*${closeDigit}`;
    }
  }

  const isFullDeclared = !openPana.includes('*') && !jodi.includes('*') && !closePana.includes('*');

  return {
    openPana,
    jodi,
    closePana,
    formatted: `${openPana} - ${jodi} - ${closePana}`,
    isFullDeclared,
    isOpenDeclared: isOpenValidPana,
    isCloseDeclared: isCloseValidPana,
  };
}

// Generate deterministic daily result for a market on a given date
export function getDailyMarketResult(marketId: string, dateStr: string) {
  const seedOpen = hashString(`${marketId}-open-${dateStr}`);
  const openPanaIndex = seedOpen % AUTHENTIC_PANAS.length;
  const openPana = AUTHENTIC_PANAS[openPanaIndex];
  const openDigit = getDigitFromPana(openPana);

  const seedClose = hashString(`${marketId}-close-${dateStr}`);
  const closePanaIndex = (seedClose + 7) % AUTHENTIC_PANAS.length;
  const closePana = AUTHENTIC_PANAS[closePanaIndex];
  const closeDigit = getDigitFromPana(closePana);

  const jodi = `${openDigit}${closeDigit}`;

  return {
    openPana,
    openDigit,
    closePana,
    closeDigit,
    jodi,
  };
}

// Helper to format remaining duration into "Xh Ym" or "Ym Zs"
export function formatRemainingDuration(diffMs: number): string {
  if (diffMs <= 0) return '0m';
  const totalSeconds = Math.floor(diffMs / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  if (hours > 0) {
    return `${hours}h ${minutes}m`;
  }
  if (minutes > 0) {
    return `${minutes}m ${seconds}s`;
  }
  return `${seconds}s`;
}

// Parse string like "04:15 PM" or "16:15" into hour & minute
export function parseTimeString(timeStr?: string): { hour: number; minute: number } | null {
  if (!timeStr || typeof timeStr !== 'string') return null;
  const match = timeStr.trim().match(/(\d{1,2}):(\d{2})\s*(AM|PM)?/i);
  if (!match) return null;
  let hour = parseInt(match[1], 10);
  const minute = parseInt(match[2], 10);
  const ampm = match[3]?.toUpperCase();
  if (ampm === 'PM' && hour < 12) hour += 12;
  if (ampm === 'AM' && hour === 12) hour = 0;
  return { hour, minute };
}

// Core calculation: Evaluate dynamic status of all markets for a specific time and date
export function evaluateMarkets(currentTime: Date, baseMarkets?: MarketItem[]): MarketItem[] {
  const year = currentTime.getFullYear();
  const month = currentTime.getMonth();
  const day = currentTime.getDate();

  const dateKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  const nowMs = currentTime.getTime();

  return MARKET_SCHEDULES.map((config) => {
    const dailyResult = getDailyMarketResult(config.id, dateKey);
    const base = baseMarkets?.find((b) => b.id === config.id);

    // Open DateTime
    const openDateTime = new Date(year, month, day, config.openHour, config.openMinute, 0, 0);

    // Close DateTime
    let closeDateTime: Date;
    if (config.crossesMidnight) {
      // e.g. 12:05 AM is next calendar day
      closeDateTime = new Date(year, month, day + 1, config.closeHour, config.closeMinute, 0, 0);
    } else {
      closeDateTime = new Date(year, month, day, config.closeHour, config.closeMinute, 0, 0);
    }

    const openMs = openDateTime.getTime();
    const closeMs = closeDateTime.getTime();

    let status: 'Running for Open' | 'Running for Close' | 'Closed for Today';
    let isOpen: boolean;
    let allowedSession: 'all' | 'close_only' | 'none';
    let openPanaDisplay: string;
    let jodiDisplay: string;
    let closePanaDisplay: string;
    let countdownText: string;
    let timeRemainingMs: number;

    const isBaseFromToday = Boolean(base && base.marketDate === dateKey);
    const hasBaseResults =
      isBaseFromToday &&
      base &&
      ((base.openPana && base.openPana !== '***') ||
        (base.closePana && base.closePana !== '***') ||
        (base.jodi && base.jodi !== '**'));

    const previousResult =
      base?.lastResult ||
      (base && base.openPana && base.openPana !== '***' && base.closePana && base.closePana !== '***'
        ? `${base.openPana}-${base.jodi}-${base.closePana}`
        : undefined);

    if (nowMs < openMs) {
      // Case 1: Before Open time on the new calendar day -> Fresh Open Bidding session
      status = 'Running for Open';
      isOpen = true;
      allowedSession = 'all';
      timeRemainingMs = openMs - nowMs;
      countdownText = `Open Bids close in ${formatRemainingDuration(timeRemainingMs)}`;
      // Clear out yesterday's numbers: no result declared yet for today
      openPanaDisplay = '***';
      jodiDisplay = '**';
      closePanaDisplay = '***';
    } else if (nowMs >= openMs && nowMs < closeMs) {
      // Case 2: Between Open and Close -> Running for Close (Open declared, Close bidding active)
      status = 'Running for Close';
      isOpen = true;
      allowedSession = 'close_only';
      timeRemainingMs = closeMs - nowMs;
      countdownText = `Close Bids close in ${formatRemainingDuration(timeRemainingMs)}`;

      if (hasBaseResults && base?.openPana && base.openPana !== '***') {
        openPanaDisplay = base.openPana;
        const openD = getDigitFromPana(base.openPana);
        jodiDisplay = `${openD}*`;
      } else {
        openPanaDisplay = dailyResult.openPana;
        jodiDisplay = `${dailyResult.openDigit}*`;
      }
      closePanaDisplay = '***';
    } else {
      // Case 3: After Close time -> Closed for Today (Full result declared)
      status = 'Closed for Today';
      isOpen = false;
      allowedSession = 'none';
      timeRemainingMs = 0;
      countdownText = `Closed • Next Open tomorrow at ${config.openTime}`;

      if (hasBaseResults && base?.openPana && base.openPana !== '***' && base?.closePana && base.closePana !== '***') {
        openPanaDisplay = base.openPana;
        jodiDisplay = base.jodi;
        closePanaDisplay = base.closePana;
      } else {
        openPanaDisplay = dailyResult.openPana;
        jodiDisplay = dailyResult.jodi;
        closePanaDisplay = dailyResult.closePana;
      }
    }

    // Final sanity formatting
    const finalFormatted = formatMarketResult({
      openPana: openPanaDisplay,
      jodi: jodiDisplay,
      closePana: closePanaDisplay,
    });

    return {
      id: config.id,
      name: config.name,
      openPana: finalFormatted.openPana,
      jodi: finalFormatted.jodi,
      closePana: finalFormatted.closePana,
      lastResult: previousResult,
      openTime: config.openTime,
      closeTime: config.closeTime,
      status,
      isOpen,
      openHour: config.openHour,
      openMinute: config.openMinute,
      closeHour: config.closeHour,
      closeMinute: config.closeMinute,
      countdownText,
      allowedSession,
      timeRemainingMs,
      marketDate: dateKey,
    };
  });
}

// Bombay Starline Slot Configuration
export interface StarlineSlotItem {
  id: string;
  time: string;
  hour: number;
  minute: number;
  status: 'Closed' | 'Running for Open' | 'Upcoming';
  result: string;
  countdownText?: string;
  isCurrentActive?: boolean;
}

export const STARLINE_SLOT_HOURS = [
  { time: '09:30 AM', hour: 9, minute: 30 },
  { time: '10:30 AM', hour: 10, minute: 30 },
  { time: '11:30 AM', hour: 11, minute: 30 },
  { time: '12:30 PM', hour: 12, minute: 30 },
  { time: '01:30 PM', hour: 13, minute: 30 },
  { time: '02:30 PM', hour: 14, minute: 30 },
  { time: '03:30 PM', hour: 15, minute: 30 },
  { time: '04:30 PM', hour: 16, minute: 30 },
  { time: '05:30 PM', hour: 17, minute: 30 },
  { time: '06:30 PM', hour: 18, minute: 30 },
  { time: '07:30 PM', hour: 19, minute: 30 },
  { time: '08:30 PM', hour: 20, minute: 30 },
  { time: '09:30 PM', hour: 21, minute: 30 },
];

export function evaluateStarlineSlots(currentTime: Date): StarlineSlotItem[] {
  const year = currentTime.getFullYear();
  const month = currentTime.getMonth();
  const day = currentTime.getDate();
  const dateKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  const nowMs = currentTime.getTime();

  let activeFound = false;

  return STARLINE_SLOT_HOURS.map((slot, index) => {
    const slotDateTime = new Date(year, month, day, slot.hour, slot.minute, 0, 0);
    const slotMs = slotDateTime.getTime();

    // Deterministic pana and single digit result for this slot and date
    const seed = hashString(`starline-${index}-${dateKey}`);
    const pana = AUTHENTIC_PANAS[seed % AUTHENTIC_PANAS.length];
    const digit = getDigitFromPana(pana);
    const declaredResult = `${pana}-${digit}`;

    let status: 'Closed' | 'Running for Open' | 'Upcoming';
    let result: string;
    let countdownText: string | undefined;
    let isCurrentActive = false;

    if (nowMs >= slotMs) {
      status = 'Closed';
      result = declaredResult;
    } else {
      // Future slot
      if (!activeFound) {
        // Earliest upcoming slot is actively running for bets!
        status = 'Running for Open';
        result = '***-*';
        isCurrentActive = true;
        activeFound = true;
        const diffMs = slotMs - nowMs;
        countdownText = `Bids close in ${formatRemainingDuration(diffMs)}`;
      } else {
        status = 'Upcoming';
        result = '***-*';
        countdownText = `Starts after previous draw`;
      }
    }

    return {
      id: `starline-${index}`,
      time: slot.time,
      hour: slot.hour,
      minute: slot.minute,
      status,
      result,
      countdownText,
      isCurrentActive,
    };
  });
}

// Bombay Jackpot Slot Configuration
export interface JackpotSlotItem {
  id: string;
  time: string;
  hour: number;
  minute: number;
  status: 'Closed' | 'Running for Open' | 'Upcoming';
  result: string;
  countdownText?: string;
  isCurrentActive?: boolean;
}

export const JACKPOT_SLOT_HOURS = [
  { time: '10:00 AM', hour: 10, minute: 0 },
  { time: '12:00 PM', hour: 12, minute: 0 },
  { time: '02:00 PM', hour: 14, minute: 0 },
  { time: '04:00 PM', hour: 16, minute: 0 },
  { time: '06:00 PM', hour: 18, minute: 0 },
  { time: '08:00 PM', hour: 20, minute: 0 },
  { time: '10:00 PM', hour: 22, minute: 0 },
];

export function evaluateJackpotSlots(currentTime: Date): JackpotSlotItem[] {
  const year = currentTime.getFullYear();
  const month = currentTime.getMonth();
  const day = currentTime.getDate();
  const dateKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  const nowMs = currentTime.getTime();

  let activeFound = false;

  return JACKPOT_SLOT_HOURS.map((slot, index) => {
    const slotDateTime = new Date(year, month, day, slot.hour, slot.minute, 0, 0);
    const slotMs = slotDateTime.getTime();

    // Deterministic 2-digit Jodi
    const seed = hashString(`jackpot-${index}-${dateKey}`);
    const jodiVal = (seed % 100).toString().padStart(2, '0');

    let status: 'Closed' | 'Running for Open' | 'Upcoming';
    let result: string;
    let countdownText: string | undefined;
    let isCurrentActive = false;

    if (nowMs >= slotMs) {
      status = 'Closed';
      result = jodiVal;
    } else {
      if (!activeFound) {
        status = 'Running for Open';
        result = '**';
        isCurrentActive = true;
        activeFound = true;
        const diffMs = slotMs - nowMs;
        countdownText = `Draw in ${formatRemainingDuration(diffMs)}`;
      } else {
        status = 'Upcoming';
        result = '**';
        countdownText = `Upcoming draw`;
      }
    }

    return {
      id: `jackpot-${index}`,
      time: slot.time,
      hour: slot.hour,
      minute: slot.minute,
      status,
      result,
      countdownText,
      isCurrentActive,
    };
  });
}

// Convert evaluated Starline slots to StarlineResult array for backward compatibility
export function convertSlotsToStarlineResults(slots: StarlineSlotItem[], dateStr: string): StarlineResult[] {
  return slots.map((s) => ({
    time: s.time,
    date: dateStr,
    result: s.result,
  }));
}
