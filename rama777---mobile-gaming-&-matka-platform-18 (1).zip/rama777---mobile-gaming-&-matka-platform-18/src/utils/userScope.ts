/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Universal user identity and UUID resolution utilities for RAMA777.
 * Enables seamless cross-table user record matching across raw IDs, phone numbers, and UUIDs.
 */

export function toSupabaseUuid(rawId: string): string {
  if (!rawId) return '00000000-0000-0000-0000-000000000000';
  if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(rawId)) {
    return rawId;
  }
  let hex = '';
  for (let i = 0; i < rawId.length; i++) {
    hex += rawId.charCodeAt(i).toString(16);
  }
  hex = hex.padEnd(32, '0').slice(0, 32);
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-4${hex.slice(13, 16)}-a${hex.slice(17, 20)}-${hex.slice(20, 32)}`;
}

/**
 * Universal helper to match Supabase database records against the active user scope
 * across multiple ID formats (raw string ID, phone number, and UUID-hashed representations).
 */
export function isMatchingUser(
  recordUserId: string | null | undefined,
  currentUser: { uid?: string; id?: string; phone?: string } | string,
  recordPhoneOrMobile?: string | null
): boolean {
  if (!recordUserId && !recordPhoneOrMobile) return true; // broadcast or generic record
  let cleanPhone = '';
  let rawUid = '';

  if (typeof currentUser === 'string') {
    const digits = currentUser.replace(/\D/g, '');
    if (digits.length === 10) cleanPhone = digits;
    rawUid = currentUser.trim();
  } else if (currentUser && typeof currentUser === 'object') {
    if (currentUser.phone) cleanPhone = String(currentUser.phone).replace(/\D/g, '');
    rawUid = (currentUser.uid || currentUser.id || '').trim();
  }

  if (recordUserId) {
    if (rawUid && recordUserId === rawUid) return true;
    if (cleanPhone && recordUserId === cleanPhone) return true;
    if (rawUid && recordUserId.toLowerCase() === toSupabaseUuid(rawUid).toLowerCase()) return true;
    if (cleanPhone && recordUserId.toLowerCase() === toSupabaseUuid(cleanPhone).toLowerCase()) return true;
  }

  if (recordPhoneOrMobile && cleanPhone) {
    const cleanRec = String(recordPhoneOrMobile).replace(/\D/g, '');
    if (cleanRec && (cleanRec === cleanPhone || cleanRec.includes(cleanPhone) || cleanPhone.includes(cleanRec))) {
      return true;
    }
  }

  return false;
}
