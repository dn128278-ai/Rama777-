/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RATAN567 Admin Panel for RAMA777 Platform
 * Real-time direct read/write to shared Supabase backend tables:
 * users, bids, markets, transactions, passbook, deposits, withdrawals, agents, notifications, game_rates.
 */

import React, { useState, useEffect } from 'react';
import {
  X,
  Crown,
  ShieldCheck,
  Users,
  Trophy,
  Wallet,
  CheckCircle2,
  AlertCircle,
  Search,
  Sparkles,
  ArrowRight,
  TrendingUp,
  RefreshCw,
  Clock,
  BarChart3,
  Bell,
  Send,
  PlusCircle,
  ArrowDownLeft,
  ArrowUpRight,
  UserCheck,
  Ban,
  Check,
  Building2,
  DollarSign,
} from 'lucide-react';
import { MarketItem, UserProfile, UserAccount } from '../types';
import {
  getRegisteredAccounts,
  adjustUserBalance,
  switchUserRole,
} from '../services/authService';
import { declareMarketResult } from '../services/marketResultService';
import { formatMarketResult, getDigitFromPana } from '../utils/marketEngine';
import {
  broadcastNotificationInFirestore,
  fetchAdminUsers,
  updateUserWalletInSupabase,
  fetchAdminDeposits,
  updateDepositStatusInSupabase,
  fetchAdminWithdrawals,
  updateWithdrawalStatusInSupabase,
  fetchAdminAgents,
  createAgentInSupabase,
  updateAgentInSupabase,
} from '../services/firestoreSyncService';
import {
  evaluateAndSettleBidsForMarket,
  fetchGameRatesFromSupabase,
  DEFAULT_GAME_RATES,
  GameRateSection,
} from '../services/gameRatesService';
import { fetchRealtimeMarkets } from '../services/marketService';
import { supabase } from '../supabase';
import { toSupabaseUuid } from '../utils/userScope';

interface AdminPanelModalProps {
  currentUser: UserProfile;
  markets: MarketItem[];
  currentTime: Date;
  onClose: () => void;
  onUpdateMarkets?: (updated: MarketItem[]) => void;
  onSwitchUser?: (newUser: UserProfile) => void;
}

type AdminTab =
  | 'results'
  | 'users'
  | 'deposits'
  | 'withdrawals'
  | 'markets'
  | 'analytics'
  | 'agents'
  | 'rates'
  | 'notices';

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  currentUser,
  markets,
  currentTime,
  onClose,
  onUpdateMarkets,
  onSwitchUser,
}) => {
  const isAdmin = currentUser.role === 'admin';

  // Sub-tabs in RATAN567 Admin Panel
  const [activeTab, setActiveTab] = useState<AdminTab>('results');

  // Live Supabase tables state
  const [liveBids, setLiveBids] = useState<any[]>([]);
  const [analyticsMarketFilter, setAnalyticsMarketFilter] = useState<string>('all');
  const [analyticsGameTypeFilter, setAnalyticsGameTypeFilter] = useState<string>('all');
  const [isLoadingBids, setIsLoadingBids] = useState<boolean>(false);

  // Live Users state from Supabase
  const [supabaseUsers, setSupabaseUsers] = useState<any[]>([]);
  const [isLoadingUsers, setIsLoadingUsers] = useState<boolean>(false);
  const [userSearchQuery, setUserSearchQuery] = useState<string>('');

  // Live Deposits state from Supabase
  const [depositsList, setDepositsList] = useState<any[]>([]);
  const [depositFilter, setDepositFilter] = useState<'ALL' | 'Pending' | 'Success' | 'Failure'>('ALL');
  const [isProcessingDeposit, setIsProcessingDeposit] = useState<string | null>(null);

  // Live Withdrawals state from Supabase
  const [withdrawalsList, setWithdrawalsList] = useState<any[]>([]);
  const [withdrawalFilter, setWithdrawalFilter] = useState<'ALL' | 'Pending' | 'Success' | 'Failure'>('ALL');
  const [isProcessingWithdrawal, setIsProcessingWithdrawal] = useState<string | null>(null);

  // Live Agents state from Supabase
  const [agentsList, setAgentsList] = useState<any[]>([]);
  const [showAddAgent, setShowAddAgent] = useState<boolean>(false);
  const [newAgentName, setNewAgentName] = useState<string>('');
  const [newAgentMobile, setNewAgentMobile] = useState<string>('');
  const [newAgentCommission, setNewAgentCommission] = useState<string>('5');
  const [isCreatingAgent, setIsCreatingAgent] = useState<boolean>(false);
  const [gameRateSections, setGameRateSections] = useState<GameRateSection[]>(DEFAULT_GAME_RATES);

  // Elevation passcode for standard users
  const [adminPasscode, setAdminPasscode] = useState<string>('');
  const [authError, setAuthError] = useState<string>('');
  const [actionNotice, setActionNotice] = useState<string>('');

  // Results declaration state
  const [selectedMarketId, setSelectedMarketId] = useState<string>(markets[0]?.id || 'kalyan');
  const [openPanaInput, setOpenPanaInput] = useState<string>('');
  const [closePanaInput, setClosePanaInput] = useState<string>('');
  const [isSubmittingResult, setIsSubmittingResult] = useState<boolean>(false);

  // Selected market derived
  const selectedMarket = markets.find((m) => m.id === selectedMarketId) || markets[0];
  const currentOpenDigit =
    openPanaInput.length === 3 ? getDigitFromPana(openPanaInput) : null;
  const currentCloseDigit =
    closePanaInput.length === 3 ? getDigitFromPana(closePanaInput) : null;

  // Market creation state
  const [showAddMarket, setShowAddMarket] = useState<boolean>(false);
  const [newMarketName, setNewMarketName] = useState<string>('');
  const [newMarketOpenTime, setNewMarketOpenTime] = useState<string>('11:00 AM');
  const [newMarketCloseTime, setNewMarketCloseTime] = useState<string>('01:00 PM');
  const [isCreatingMarket, setIsCreatingMarket] = useState<boolean>(false);

  // Admin Broadcast Notification state
  const [notifTitle, setNotifTitle] = useState<string>('');
  const [notifMessage, setNotifMessage] = useState<string>('');
  const [notifType, setNotifType] = useState<'alert' | 'bonus' | 'bid'>('alert');
  const [isSendingNotif, setIsSendingNotif] = useState<boolean>(false);

  // ==========================================
  // REAL-TIME POSTGRES CHANNELS & DATA LOAD
  // ==========================================

  // 1. Fetch & Subscribe to Supabase 'bids'
  const loadBids = async () => {
    setIsLoadingBids(true);
    try {
      const { data, error } = await supabase
        .from('bids')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);
      if (!error && data) setLiveBids(data);
    } catch (err) {
      console.warn('Load bids note:', err);
    } finally {
      setIsLoadingBids(false);
    }
  };

  // 2. Fetch & Subscribe to Supabase 'users'
  const loadUsers = async () => {
    setIsLoadingUsers(true);
    try {
      const users = await fetchAdminUsers();
      // Merge with local seed accounts so demo accounts like Girish Meena are always available
      const localAccs = getRegisteredAccounts();
      const merged = [...users];
      for (const loc of localAccs) {
        if (!merged.some((u) => u.mobile === loc.phone || u.id === loc.id)) {
          merged.push({
            id: loc.id,
            name: loc.name,
            mobile: loc.phone,
            role: loc.role,
            status: loc.status || 'active',
            main_wallet: loc.walletBalance,
            gaming_wallet: loc.walletBalance,
            winning_wallet: 0,
          });
        }
      }
      setSupabaseUsers(merged);
    } finally {
      setIsLoadingUsers(false);
    }
  };

  // 3. Fetch & Subscribe to Supabase 'deposits'
  const loadDeposits = async () => {
    const deps = await fetchAdminDeposits();
    setDepositsList(deps);
  };

  // 4. Fetch & Subscribe to Supabase 'withdrawals'
  const loadWithdrawals = async () => {
    const withs = await fetchAdminWithdrawals();
    setWithdrawalsList(withs);
  };

  // 5. Fetch & Subscribe to Supabase 'agents'
  const loadAgents = async () => {
    const ags = await fetchAdminAgents();
    setAgentsList(ags);
  };

  useEffect(() => {
    let isMounted = true;
    loadBids();
    loadUsers();
    loadDeposits();
    loadWithdrawals();
    loadAgents();
    fetchGameRatesFromSupabase().then((rates) => {
      if (isMounted) setGameRateSections(rates);
    });

    // Attach Postgres Realtime Channel Listeners for all tables
    const adminChannel = supabase
      .channel('public:ratan567:admin:realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'bids' }, () => {
        if (isMounted) loadBids();
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'users' }, () => {
        if (isMounted) loadUsers();
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'deposits' }, () => {
        if (isMounted) loadDeposits();
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'withdrawals' }, () => {
        if (isMounted) loadWithdrawals();
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'agents' }, () => {
        if (isMounted) loadAgents();
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'markets' }, () => {
        if (isMounted && onUpdateMarkets) {
          fetchRealtimeMarkets(currentTime).then((m) => onUpdateMarkets(m));
        }
      })
      .subscribe();

    // 2. Window event listener for in-app withdrawal updates
    const handleInAppWithdrawal = () => {
      if (isMounted) {
        loadWithdrawals();
        loadUsers();
      }
    };
    if (typeof window !== 'undefined') {
      window.addEventListener('rama777:withdrawal_updated', handleInAppWithdrawal);
    }

    // 3. Fallback polling every 3 seconds while Admin Panel is open
    const pollInterval = setInterval(() => {
      if (isMounted) {
        loadWithdrawals();
        loadDeposits();
      }
    }, 3000);

    return () => {
      isMounted = false;
      clearInterval(pollInterval);
      if (typeof window !== 'undefined') {
        window.removeEventListener('rama777:withdrawal_updated', handleInAppWithdrawal);
      }
      supabase.removeChannel(adminChannel);
    };
  }, []);

  // Admin Elevation
  const handleElevateToAdmin = () => {
    if (adminPasscode === '9999' || adminPasscode === 'admin777') {
      const elevated = switchUserRole(currentUser.id || currentUser.phone, 'admin');
      if (elevated && onSwitchUser) {
        onSwitchUser(elevated);
      }
      setAuthError('');
      setActionNotice('Admin access granted successfully.');
    } else {
      setAuthError('Invalid Admin Passcode. Use "9999" or switch to the Admin account.');
    }
  };

  // Declare Result Handler
  const handleDeclareResult = async () => {
    if (!openPanaInput && !closePanaInput) {
      setActionNotice('Please enter at least Open Pana or Close Pana.');
      return;
    }

    setIsSubmittingResult(true);
    setActionNotice('');

    try {
      const now = currentTime || new Date();

      const res = await declareMarketResult({
        marketId: selectedMarket.id,
        marketName: selectedMarket.name,
        openPana: openPanaInput || selectedMarket.openPana,
        closePana: closePanaInput || selectedMarket.closePana,
        date: now,
        action: 'declare_full',
      });

      if (res.success) {
        // Automatically evaluate placed bids and settle rate-based winnings
        evaluateAndSettleBidsForMarket({
          marketId: selectedMarket.id,
          marketName: selectedMarket.name,
          openPana: openPanaInput || selectedMarket.openPana,
          jodi: res.marketResult.jodi,
          closePana: closePanaInput || selectedMarket.closePana,
        }).catch((err) => console.warn('Admin settlement notice:', err));

        setActionNotice(
          `Result declared for ${selectedMarket.name}: ${res.marketResult.jodi}. Winning payouts settled!`
        );
        setOpenPanaInput('');
        setClosePanaInput('');
      } else {
        setActionNotice('Result declaration failed.');
      }
    } catch (err: any) {
      setActionNotice(err.message || 'Failed to declare result.');
    } finally {
      setIsSubmittingResult(false);
    }
  };

  // Direct Wallet Balance Adjustment
  const handleAdjustBalance = async (userRow: any, delta: number) => {
    const curBal = Number(userRow.main_wallet ?? userRow.wallet_balance ?? 0);
    const newBal = Math.max(0, curBal + delta);

    // Update in Supabase users, transactions, passbook
    await updateUserWalletInSupabase(userRow.id, userRow.mobile, newBal, delta);

    // Also update local storage
    adjustUserBalance(userRow.mobile || userRow.id, newBal);

    setActionNotice(`Updated ${userRow.name || userRow.mobile}'s wallet to ₹${newBal.toLocaleString('en-IN')}`);
    loadUsers();

    if ((currentUser.phone === userRow.mobile || currentUser.id === userRow.id) && onSwitchUser) {
      onSwitchUser({ ...currentUser, walletBalance: newBal });
    }
  };

  // Deposit Approval / Rejection
  const handleDepositAction = async (dep: any, action: 'Success' | 'Failure') => {
    setIsProcessingDeposit(dep.id);
    try {
      await updateDepositStatusInSupabase(dep.id, action, dep.mobile, Number(dep.amount));
      setActionNotice(`Deposit of ₹${dep.amount} for ${dep.mobile} marked as ${action}!`);
      loadDeposits();
      loadUsers();
    } catch (err: any) {
      setActionNotice(`Error updating deposit: ${err.message}`);
    } finally {
      setIsProcessingDeposit(null);
    }
  };

  // Withdrawal Approval / Rejection
  const handleWithdrawalAction = async (wth: any, action: 'Success' | 'Failure') => {
    setIsProcessingWithdrawal(wth.id);
    try {
      await updateWithdrawalStatusInSupabase(wth.id, action, wth.mobile, Number(wth.amount));
      setActionNotice(`Withdrawal of ₹${wth.amount} for ${wth.mobile} marked as ${action}!`);
      loadWithdrawals();
      loadUsers();
    } catch (err: any) {
      setActionNotice(`Error updating withdrawal: ${err.message}`);
    } finally {
      setIsProcessingWithdrawal(null);
    }
  };

  // Toggle Market Status
  const handleToggleMarketStatus = async (market: MarketItem) => {
    try {
      const nextIsOpen = !market.isOpen;
      const nextStatus = nextIsOpen ? 'ACTIVE' : 'CLOSED';
      const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(market.id);
      const targetId = isUuid ? market.id : toSupabaseUuid(market.id || market.name);

      const { error } = await supabase
        .from('markets')
        .update({
          status: nextStatus,
          updated_at: new Date().toISOString(),
        })
        .or(`id.eq.${targetId},name.ilike.${market.name}`);

      if (error) throw error;
      setActionNotice(`${market.name} is now ${nextStatus}`);
    } catch (err: any) {
      setActionNotice(`Failed to toggle: ${err.message}`);
    }
  };

  // Create Market
  const handleCreateMarket = async () => {
    if (!newMarketName.trim()) {
      setActionNotice('Please enter a market name.');
      return;
    }

    setIsCreatingMarket(true);
    try {
      const payload = {
        name: newMarketName.trim().toUpperCase(),
        open_time: newMarketOpenTime.trim() || '11:00 AM',
        close_time: newMarketCloseTime.trim() || '01:00 PM',
        status: 'ACTIVE',
        open_pana: '***',
        close_pana: '***',
        jodi: '**',
        updated_at: new Date().toISOString(),
      };

      const { data, error } = await supabase.from('markets').insert(payload).select();
      if (error) throw error;
      const createdId = data && data[0] ? data[0].id : '';
      setActionNotice(`Market "${newMarketName.toUpperCase()}" created in Supabase! (ID: ${createdId.slice(0, 8)})`);
      setNewMarketName('');
      setShowAddMarket(false);
    } catch (err: any) {
      setActionNotice(`Failed to create market: ${err.message}`);
    } finally {
      setIsCreatingMarket(false);
    }
  };

  // Create Agent
  const handleCreateAgent = async () => {
    if (!newAgentName.trim() || !newAgentMobile.trim()) {
      setActionNotice('Please provide agent name and mobile number.');
      return;
    }
    setIsCreatingAgent(true);
    try {
      await createAgentInSupabase({
        name: newAgentName.trim(),
        mobile: newAgentMobile.trim(),
        commission_rate: Number(newAgentCommission) || 5,
        status: 'Active',
      });
      setActionNotice(`Agent "${newAgentName}" registered in Supabase!`);
      setNewAgentName('');
      setNewAgentMobile('');
      setShowAddAgent(false);
      loadAgents();
    } catch (err: any) {
      setActionNotice(`Agent creation failed: ${err.message}`);
    } finally {
      setIsCreatingAgent(false);
    }
  };

  // Send Broadcast Notification
  const handleSendBroadcastNotification = async () => {
    if (!notifTitle.trim() || !notifMessage.trim()) {
      setActionNotice('Please enter both title and message.');
      return;
    }
    setIsSendingNotif(true);
    try {
      await broadcastNotificationInFirestore({
        title: notifTitle.trim(),
        message: notifMessage.trim(),
        type: notifType,
        time: 'Just now',
        read: false,
        targetPhone: 'all',
      });
      setActionNotice('Broadcast notification sent to all connected players!');
      setNotifTitle('');
      setNotifMessage('');
    } catch (err: any) {
      setActionNotice(`Broadcast error: ${err.message}`);
    } finally {
      setIsSendingNotif(false);
    }
  };

  // Pending counts for badges
  const pendingDepositsCount = depositsList.filter((d) => String(d.status).toLowerCase() === 'pending').length;
  const pendingWithdrawalsCount = withdrawalsList.filter((w) => String(w.status).toLowerCase() === 'pending').length;

  // Filtered lists
  const filteredUsers = supabaseUsers.filter(
    (u) =>
      (u.name || '').toLowerCase().includes(userSearchQuery.toLowerCase()) ||
      (u.mobile || '').includes(userSearchQuery)
  );

  const filteredDeposits = depositsList.filter((d) => {
    if (depositFilter === 'ALL') return true;
    return String(d.status).toLowerCase() === depositFilter.toLowerCase();
  });

  const filteredWithdrawals = withdrawalsList.filter((w) => {
    if (withdrawalFilter === 'ALL') return true;
    const statusStr = String(w.status || '').toLowerCase();
    if (withdrawalFilter === 'Success') {
      return statusStr === 'success' || statusStr === 'approved';
    }
    if (withdrawalFilter === 'Failure') {
      return statusStr === 'failure' || statusStr === 'rejected';
    }
    if (withdrawalFilter === 'Pending') {
      return statusStr === 'pending';
    }
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex flex-col justify-end sm:justify-center items-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full sm:max-w-xl h-[94vh] sm:h-[88vh] bg-[#090a0f] text-slate-100 rounded-t-3xl sm:rounded-3xl border border-zinc-800 shadow-2xl flex flex-col overflow-hidden">
        {/* Top Header */}
        <div className="p-3.5 sm:p-4 bg-gradient-to-r from-[#141624] via-[#1a130d] to-[#0f1018] border-b border-zinc-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-orange-500/20 text-orange-400 border border-orange-500/40 flex items-center justify-center">
              <Crown className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-black text-white flex items-center gap-1.5">
                <span>RATAN567 Admin Panel</span>
                <span className="text-[9px] font-mono px-2 py-0.5 rounded-full bg-orange-400/20 text-orange-300 border border-orange-400/30 font-bold">
                  RAMA777 CORE
                </span>
              </h2>
              <p className="text-[10px] text-slate-400">
                Shared Supabase Realtime Backend &bull; Operator: {currentUser.name}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#11131c] text-slate-300 hover:text-white flex items-center justify-center border border-zinc-800 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* If Not Admin: Security Guard Screen */}
        {!isAdmin ? (
          <div className="flex-1 p-6 flex flex-col items-center justify-center text-center overflow-y-auto">
            <div className="w-16 h-16 rounded-3xl bg-rose-950/60 border border-rose-500/40 text-rose-400 flex items-center justify-center mb-4 shadow-xl">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-white mb-1">Administrator Access Required</h3>
            <p className="text-xs text-slate-400 max-w-xs mb-5">
              You are currently signed in as a standard Player (<b>{currentUser.name}</b>). This section
              is restricted to market operators and platform administrators.
            </p>

            {authError && (
              <div className="w-full max-w-xs mb-3 p-2 rounded-xl bg-rose-950 border border-rose-500/50 text-rose-300 text-xs">
                {authError}
              </div>
            )}

            <div className="w-full max-w-xs bg-[#11131c] p-4 rounded-2xl border border-zinc-800 mb-4 text-left">
              <label className="text-[11px] font-bold text-slate-300 block mb-1">
                Enter Admin Master PIN / Passcode
              </label>
              <input
                type="password"
                value={adminPasscode}
                onChange={(e) => setAdminPasscode(e.target.value)}
                placeholder="Enter 9999"
                className="w-full px-3 py-2 bg-[#090a0f] border border-zinc-800 focus:border-orange-500 rounded-xl text-sm font-mono tracking-widest text-center text-white outline-none mb-3"
              />
              <button
                type="button"
                onClick={handleElevateToAdmin}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs cursor-pointer shadow-md active:scale-95 transition-all"
              >
                Elevate Current Session to Admin
              </button>
            </div>

            <p className="text-[11px] text-slate-500">
              Demo Admin Passcode: <span className="font-mono text-orange-400 font-bold">9999</span>
            </p>
          </div>
        ) : (
          /* Admin Authorized View */
          <>
            {/* Scrollable Sub-tab Navigation */}
            <div className="flex items-center gap-1 p-1.5 bg-[#0d0f16] border-b border-zinc-800 text-[11px] font-bold overflow-x-auto shrink-0 scrollbar-none">
              {[
                { id: 'results' as AdminTab, label: 'Results', icon: Trophy },
                { id: 'users' as AdminTab, label: 'Users', icon: Users },
                { id: 'deposits' as AdminTab, label: 'Deposits', icon: ArrowDownLeft, badge: pendingDepositsCount },
                { id: 'withdrawals' as AdminTab, label: 'Withdrawals', icon: ArrowUpRight, badge: pendingWithdrawalsCount },
                { id: 'markets' as AdminTab, label: 'Markets', icon: Clock },
                { id: 'analytics' as AdminTab, label: 'Bets', icon: BarChart3 },
                { id: 'rates' as AdminTab, label: 'Rates', icon: DollarSign },
                { id: 'agents' as AdminTab, label: 'Agents', icon: UserCheck },
                { id: 'notices' as AdminTab, label: 'Notices', icon: Bell },
              ].map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => {
                      setActiveTab(tab.id);
                      setActionNotice('');
                    }}
                    className={`py-1.5 px-3 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-all cursor-pointer ${
                      isActive
                        ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-black font-black shadow-md'
                        : 'text-slate-400 hover:text-white bg-[#11131c]'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5 shrink-0" />
                    <span>{tab.label}</span>
                    {tab.badge !== undefined && tab.badge > 0 && (
                      <span className={`px-1.5 py-0.2 rounded-full text-[9px] font-mono font-black ${
                        isActive ? 'bg-black text-amber-300' : 'bg-orange-500 text-black'
                      }`}>
                        {tab.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Notification Banner */}
            {actionNotice && (
              <div className="mx-4 mt-3 p-2.5 rounded-xl bg-orange-950/60 border border-orange-500/50 text-orange-200 text-xs flex items-center gap-2 shrink-0 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 text-orange-400 shrink-0" />
                <span>{actionNotice}</span>
              </div>
            )}

            {/* TAB 1: DECLARE RESULTS */}
            {activeTab === 'results' && (
              <div className="flex-1 p-4 overflow-y-auto space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1.5">
                    Select Target Market
                  </label>
                  <select
                    value={selectedMarketId}
                    onChange={(e) => setSelectedMarketId(e.target.value)}
                    className="w-full px-3 py-2.5 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs font-bold text-white outline-none cursor-pointer"
                  >
                    {markets.map((m) => (
                      <option key={m.id} value={m.id} className="bg-[#090a0f]">
                        {m.name} &bull; {m.openTime} - {m.closeTime}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Market Current Status Card */}
                {selectedMarket && (
                  <div className="bg-[#11131c] p-3.5 rounded-2xl border border-zinc-800">
                    <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                      <span>Currently Declared</span>
                      <span className="font-mono text-orange-400">{selectedMarket.status}</span>
                    </div>
                    <div className="text-lg font-mono font-black text-amber-400 tracking-wider">
                      {formatMarketResult(selectedMarket).formatted}
                    </div>
                  </div>
                )}

                {/* Pana Inputs */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-400 block mb-1">
                      Open Pana (3 digits)
                    </label>
                    <input
                      type="text"
                      maxLength={3}
                      value={openPanaInput}
                      onChange={(e) => setOpenPanaInput(e.target.value.replace(/\D/g, ''))}
                      placeholder="e.g. 140"
                      className="w-full px-3 py-2 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-sm font-mono tracking-widest text-center text-white outline-none"
                    />
                    <span className="text-[10px] text-slate-500 block text-center mt-1">
                      Digit: {currentOpenDigit !== null ? currentOpenDigit : '-'}
                    </span>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-slate-400 block mb-1">
                      Close Pana (3 digits)
                    </label>
                    <input
                      type="text"
                      maxLength={3}
                      value={closePanaInput}
                      onChange={(e) => setClosePanaInput(e.target.value.replace(/\D/g, ''))}
                      placeholder="e.g. 360"
                      className="w-full px-3 py-2 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-sm font-mono tracking-widest text-center text-white outline-none"
                    />
                    <span className="text-[10px] text-slate-500 block text-center mt-1">
                      Digit: {currentCloseDigit !== null ? currentCloseDigit : '-'}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  disabled={isSubmittingResult}
                  onClick={handleDeclareResult}
                  className="w-full py-3 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-black font-black text-xs rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-1.5 transition-all active:scale-95 disabled:opacity-50"
                >
                  <Trophy className="w-4 h-4" />
                  <span>{isSubmittingResult ? 'Declaring & Settling...' : 'Declare Live Result & Settle Bids'}</span>
                </button>
              </div>
            )}

            {/* TAB 2: LIVE USERS MANAGEMENT */}
            {activeTab === 'users' && (
              <div className="flex-1 p-4 overflow-y-auto space-y-3">
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={userSearchQuery}
                    onChange={(e) => setUserSearchQuery(e.target.value)}
                    placeholder="Search player by name or mobile..."
                    className="w-full pl-9 pr-3 py-2 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white placeholder-slate-500 outline-none"
                  />
                </div>

                <div className="text-[11px] font-bold text-slate-400 flex items-center justify-between px-1">
                  <span>Supabase Users ({filteredUsers.length})</span>
                  <button
                    onClick={loadUsers}
                    className="text-orange-400 flex items-center gap-1 hover:underline cursor-pointer"
                  >
                    <RefreshCw className={`w-3 h-3 ${isLoadingUsers ? 'animate-spin' : ''}`} />
                    <span>Refresh</span>
                  </button>
                </div>

                <div className="space-y-2 max-h-[52vh] overflow-y-auto pr-0.5">
                  {filteredUsers.map((u) => (
                    <div
                      key={u.id || u.mobile}
                      className="bg-[#11131c] p-3 rounded-2xl border border-zinc-800 flex flex-col gap-2"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-xs font-bold text-white flex items-center gap-1.5">
                            <span>{u.name || 'RAMA User'}</span>
                            <span
                              className={`text-[9px] px-1.5 py-0.2 rounded-md font-mono font-bold ${
                                u.role === 'admin'
                                  ? 'bg-orange-400/20 text-orange-300 border border-orange-400/30'
                                  : 'bg-zinc-800 text-slate-300 border border-zinc-700'
                              }`}
                            >
                              {(u.role || 'user').toUpperCase()}
                            </span>
                          </div>
                          <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                            {u.mobile} &bull; Status: <span className="text-emerald-400">{u.status || 'Active'}</span>
                          </div>
                        </div>

                        <div className="text-right">
                          <div className="text-xs font-black text-amber-400 font-mono">
                            ₹{Number(u.main_wallet ?? u.wallet_balance ?? 0).toLocaleString('en-IN')}
                          </div>
                          <span className="text-[9px] text-slate-400">
                            Win: ₹{Number(u.winning_wallet ?? 0).toLocaleString('en-IN')}
                          </span>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center justify-between pt-1 border-t border-zinc-800">
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleAdjustBalance(u, 500)}
                            className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-orange-400 rounded-lg text-[10px] font-bold cursor-pointer"
                          >
                            +₹500
                          </button>
                          <button
                            type="button"
                            onClick={() => handleAdjustBalance(u, 1000)}
                            className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-orange-400 rounded-lg text-[10px] font-bold cursor-pointer"
                          >
                            +₹1000
                          </button>
                          <button
                            type="button"
                            onClick={() => handleAdjustBalance(u, -500)}
                            className="px-2 py-1 bg-rose-950/80 hover:bg-rose-900 text-rose-300 rounded-lg text-[10px] font-bold cursor-pointer"
                          >
                            -₹500
                          </button>
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono">
                          ID: {(u.id || '').slice(0, 8)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 3: DEPOSITS MANAGEMENT */}
            {activeTab === 'deposits' && (
              <div className="flex-1 p-4 overflow-y-auto space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    {(['ALL', 'Pending', 'Success', 'Failure'] as const).map((filter) => (
                      <button
                        key={filter}
                        type="button"
                        onClick={() => setDepositFilter(filter)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                          depositFilter === filter
                            ? 'bg-orange-500 text-black font-black'
                            : 'bg-[#11131c] text-slate-400 hover:text-white'
                        }`}
                      >
                        {filter}
                      </button>
                    ))}
                  </div>
                  <button
                    onClick={loadDeposits}
                    className="text-xs text-orange-400 flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Reload</span>
                  </button>
                </div>

                <div className="space-y-2 max-h-[54vh] overflow-y-auto pr-0.5">
                  {filteredDeposits.length === 0 ? (
                    <div className="py-8 text-center text-xs text-slate-500">
                      No deposits found in Supabase.
                    </div>
                  ) : (
                    filteredDeposits.map((dep) => (
                      <div
                        key={dep.id}
                        className="bg-[#11131c] p-3 rounded-2xl border border-zinc-800 space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="text-xs font-bold text-white block">{dep.mobile || 'Player'}</span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              UTR: {dep.utr || 'N/A'} &bull; {dep.created_at ? new Date(dep.created_at).toLocaleTimeString() : 'Recent'}
                            </span>
                          </div>
                          <div className="text-right">
                            <span className="text-sm font-black text-emerald-400 font-mono block">
                              +₹{Number(dep.amount || 0).toLocaleString('en-IN')}
                            </span>
                            <span
                              className={`text-[9px] px-2 py-0.5 rounded-full font-mono font-bold ${
                                String(dep.status).toLowerCase() === 'success'
                                  ? 'bg-emerald-500/20 text-emerald-300'
                                  : String(dep.status).toLowerCase() === 'failure'
                                  ? 'bg-rose-500/20 text-rose-300'
                                  : 'bg-amber-500/20 text-amber-300'
                              }`}
                            >
                              {dep.status || 'Pending'}
                            </span>
                          </div>
                        </div>

                        {String(dep.status).toLowerCase() === 'pending' && (
                          <div className="flex items-center gap-2 pt-1 border-t border-zinc-800">
                            <button
                              type="button"
                              disabled={isProcessingDeposit === dep.id}
                              onClick={() => handleDepositAction(dep, 'Success')}
                              className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold cursor-pointer active:scale-95 transition-all flex items-center justify-center gap-1"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>Approve (+Credit Wallet)</span>
                            </button>
                            <button
                              type="button"
                              disabled={isProcessingDeposit === dep.id}
                              onClick={() => handleDepositAction(dep, 'Failure')}
                              className="py-1.5 px-3 bg-rose-950 hover:bg-rose-900 text-rose-300 rounded-lg text-xs font-bold cursor-pointer active:scale-95 transition-all flex items-center justify-center gap-1"
                            >
                              <Ban className="w-3.5 h-3.5" />
                              <span>Reject</span>
                            </button>
                          </div>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* TAB 4: WITHDRAWALS MANAGEMENT */}
            {activeTab === 'withdrawals' && (
              <div className="flex-1 p-4 overflow-y-auto space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    {(['ALL', 'Pending', 'Success', 'Failure'] as const).map((filter) => (
                      <button
                        key={filter}
                        type="button"
                        onClick={() => setWithdrawalFilter(filter)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                          withdrawalFilter === filter
                            ? 'bg-orange-500 text-black font-black'
                            : 'bg-[#11131c] text-slate-400 hover:text-white'
                        }`}
                      >
                        {filter}
                      </button>
                    ))}
                  </div>
                  <button
                    onClick={loadWithdrawals}
                    className="text-xs text-orange-400 flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Reload</span>
                  </button>
                </div>

                <div className="space-y-2 max-h-[54vh] overflow-y-auto pr-0.5">
                  {filteredWithdrawals.length === 0 ? (
                    <div className="py-8 text-center text-xs text-slate-500">
                      No withdrawals found in Supabase.
                    </div>
                  ) : (
                    filteredWithdrawals.map((wth) => {
                      let bankParsed: any = {};
                      try {
                        if (wth.bank_details) {
                          bankParsed = typeof wth.bank_details === 'string' ? JSON.parse(wth.bank_details) : wth.bank_details;
                        }
                      } catch {}

                      return (
                        <div
                          key={wth.id}
                          className="bg-[#11131c] p-3 rounded-2xl border border-zinc-800 space-y-2"
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <span className="text-xs font-bold text-white block">{wth.mobile || 'Player'}</span>
                              <span className="text-[10px] text-slate-400 font-mono">
                                {bankParsed.bankName || 'Bank'}: {bankParsed.accountNumber ? `A/C ${bankParsed.accountNumber}` : ''} {bankParsed.ifsc ? `(${bankParsed.ifsc})` : ''}
                              </span>
                            </div>
                            <div className="text-right">
                              <span className="text-sm font-black text-rose-400 font-mono block">
                                ₹{Number(wth.amount || 0).toLocaleString('en-IN')}
                              </span>
                              <span
                                className={`text-[9px] px-2 py-0.5 rounded-full font-mono font-bold ${
                                  String(wth.status).toLowerCase() === 'success' ||
                                  String(wth.status).toLowerCase() === 'approved'
                                    ? 'bg-emerald-500/20 text-emerald-300'
                                    : String(wth.status).toLowerCase() === 'failure' ||
                                      String(wth.status).toLowerCase() === 'rejected'
                                    ? 'bg-rose-500/20 text-rose-300'
                                    : 'bg-amber-500/20 text-amber-300'
                                }`}
                              >
                                {String(wth.status).toLowerCase() === 'approved'
                                  ? 'Approved'
                                  : String(wth.status).toLowerCase() === 'rejected'
                                  ? 'Rejected'
                                  : wth.status || 'Pending'}
                              </span>
                            </div>
                          </div>

                          {String(wth.status).toLowerCase() === 'pending' && (
                            <div className="flex items-center gap-2 pt-1 border-t border-zinc-800">
                              <button
                                type="button"
                                disabled={isProcessingWithdrawal === wth.id}
                                onClick={() => handleWithdrawalAction(wth, 'Success')}
                                className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold cursor-pointer active:scale-95 transition-all flex items-center justify-center gap-1 disabled:opacity-50"
                              >
                                <Check className="w-3.5 h-3.5" />
                                <span>{isProcessingWithdrawal === wth.id ? 'Updating...' : 'Approve & Mark Paid'}</span>
                              </button>
                              <button
                                type="button"
                                disabled={isProcessingWithdrawal === wth.id}
                                onClick={() => handleWithdrawalAction(wth, 'Failure')}
                                className="py-1.5 px-3 bg-rose-950 hover:bg-rose-900 text-rose-300 rounded-lg text-xs font-bold cursor-pointer active:scale-95 transition-all flex items-center justify-center gap-1 disabled:opacity-50"
                              >
                                <Ban className="w-3.5 h-3.5" />
                                <span>Reject (+Refund)</span>
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}

            {/* TAB 5: MARKET CONTROLS */}
            {activeTab === 'markets' && (
              <div className="flex-1 p-4 overflow-y-auto space-y-3">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-bold text-slate-300">
                    Live Supabase Markets ({markets.length})
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowAddMarket(!showAddMarket)}
                    className="px-2.5 py-1 bg-orange-500/20 hover:bg-orange-500/30 text-orange-400 border border-orange-500/40 rounded-xl text-[11px] font-bold cursor-pointer transition-all flex items-center gap-1"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>{showAddMarket ? 'Cancel' : 'Add Market'}</span>
                  </button>
                </div>

                {/* Add Market Form */}
                {showAddMarket && (
                  <div className="bg-[#141624] p-3.5 rounded-2xl border border-orange-500/30 space-y-3 animate-in fade-in">
                    <div className="text-xs font-black text-orange-300 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Create New Supabase Market</span>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-400 block mb-1">
                        Market Name
                      </label>
                      <input
                        type="text"
                        value={newMarketName}
                        onChange={(e) => setNewMarketName(e.target.value)}
                        placeholder="e.g. RAJDHANI DAY"
                        className="w-full px-3 py-2 bg-[#090a0f] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white uppercase outline-none font-bold"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 block mb-1">
                          Open Time
                        </label>
                        <input
                          type="text"
                          value={newMarketOpenTime}
                          onChange={(e) => setNewMarketOpenTime(e.target.value)}
                          placeholder="11:00 AM"
                          className="w-full px-2.5 py-1.5 bg-[#090a0f] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white outline-none font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 block mb-1">
                          Close Time
                        </label>
                        <input
                          type="text"
                          value={newMarketCloseTime}
                          onChange={(e) => setNewMarketCloseTime(e.target.value)}
                          placeholder="01:00 PM"
                          className="w-full px-2.5 py-1.5 bg-[#090a0f] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white outline-none font-mono"
                        />
                      </div>
                    </div>

                    <button
                      type="button"
                      disabled={isCreatingMarket}
                      onClick={handleCreateMarket}
                      className="w-full py-2 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-black font-black text-xs rounded-xl shadow-md cursor-pointer transition-all active:scale-95 disabled:opacity-50"
                    >
                      {isCreatingMarket ? 'Saving to Supabase...' : 'Create & Sync to Supabase'}
                    </button>
                  </div>
                )}

                {/* Markets List */}
                <div className="space-y-2 max-h-[52vh] overflow-y-auto pr-0.5">
                  {markets.map((m) => (
                    <div
                      key={m.id}
                      className="bg-[#11131c] p-3 rounded-2xl border border-zinc-800 flex items-center justify-between"
                    >
                      <div className="min-w-0 pr-2">
                        <div className="text-xs font-bold text-white flex items-center gap-1.5">
                          <span className="truncate">{m.name}</span>
                          <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-zinc-800 text-zinc-400">
                            {m.id}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                          {m.openTime} - {m.closeTime} &bull; {m.lastResult || `${m.openPana}-${m.jodi}-${m.closePana}`}
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleToggleMarketStatus(m)}
                        className={`text-[10px] px-2.5 py-1.5 rounded-xl font-bold font-mono cursor-pointer transition-all shrink-0 ${
                          m.isOpen
                            ? 'bg-emerald-950/60 hover:bg-emerald-900/60 text-emerald-400 border border-emerald-500/30'
                            : 'bg-rose-950/60 hover:bg-rose-900/60 text-rose-400 border border-rose-500/30'
                        }`}
                        title="Click to toggle status in Supabase"
                      >
                        {m.isOpen ? 'ACTIVE (Click to Close)' : 'CLOSED (Click to Open)'}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 6: BET ANALYTICS */}
            {activeTab === 'analytics' && (
              <div className="flex-1 p-4 overflow-y-auto space-y-4">
                {(() => {
                  const filtered = liveBids.filter((b) => {
                    const matchMkt = analyticsMarketFilter === 'all' || b.market_id === analyticsMarketFilter;
                    const matchType = analyticsGameTypeFilter === 'all' || b.game_type === analyticsGameTypeFilter;
                    return matchMkt && matchType;
                  });
                  const totalPoints = filtered.reduce((acc, b) => acc + (Number(b.points) || 0), 0);

                  const digitCounts: Record<string, number> = {};
                  filtered.forEach((b) => {
                    const d = String(b.digits || '');
                    digitCounts[d] = (digitCounts[d] || 0) + (Number(b.points) || 0);
                  });
                  const topDigitEntry = Object.entries(digitCounts).sort((a, b) => b[1] - a[1])[0];

                  return (
                    <>
                      <div className="grid grid-cols-3 gap-2">
                        <div className="bg-[#11131c] p-2.5 rounded-xl border border-zinc-800">
                          <span className="text-[10px] text-slate-400 block font-bold">Total Bets</span>
                          <span className="text-base font-mono font-black text-white">{filtered.length}</span>
                        </div>
                        <div className="bg-[#11131c] p-2.5 rounded-xl border border-zinc-800">
                          <span className="text-[10px] text-slate-400 block font-bold">Total Points</span>
                          <span className="text-base font-mono font-black text-amber-400">₹{totalPoints.toLocaleString('en-IN')}</span>
                        </div>
                        <div className="bg-[#11131c] p-2.5 rounded-xl border border-zinc-800">
                          <span className="text-[10px] text-slate-400 block font-bold">Top Digit/Pana</span>
                          <span className="text-base font-mono font-black text-orange-400">
                            {topDigitEntry ? `#${topDigitEntry[0]}` : '-'}
                          </span>
                        </div>
                      </div>

                      {/* Filters */}
                      <div className="flex items-center gap-2">
                        <select
                          value={analyticsMarketFilter}
                          onChange={(e) => setAnalyticsMarketFilter(e.target.value)}
                          className="flex-1 px-2.5 py-1.5 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-[11px] font-bold text-white outline-none"
                        >
                          <option value="all">All Markets ({markets.length})</option>
                          {markets.map((m) => (
                            <option key={m.id} value={m.id}>
                              {m.name}
                            </option>
                          ))}
                        </select>

                        <select
                          value={analyticsGameTypeFilter}
                          onChange={(e) => setAnalyticsGameTypeFilter(e.target.value)}
                          className="flex-1 px-2.5 py-1.5 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-[11px] font-bold text-white outline-none"
                        >
                          <option value="all">All Game Types</option>
                          <option value="Single Digit">Single Digit</option>
                          <option value="Jodi Digits">Jodi Digits</option>
                          <option value="Single Pana">Single Pana</option>
                          <option value="Double Pana">Double Pana</option>
                          <option value="Triple Pana">Triple Pana</option>
                          <option value="Half Sangam">Half Sangam</option>
                          <option value="Full Sangam">Full Sangam</option>
                        </select>
                      </div>

                      {/* Live Bids Feed */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-[11px] font-bold text-slate-400">
                          <span className="flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                            Live Supabase Bets Stream ({filtered.length})
                          </span>
                          <span className="text-[10px] text-zinc-500 font-mono">Real-time synced</span>
                        </div>

                        {isLoadingBids ? (
                          <div className="py-8 text-center text-xs text-slate-500">Loading live bets...</div>
                        ) : filtered.length === 0 ? (
                          <div className="py-8 text-center bg-[#11131c] rounded-2xl border border-zinc-800 text-xs text-slate-400">
                            No bets placed matching the filter.
                          </div>
                        ) : (
                          <div className="space-y-1.5 max-h-[44vh] overflow-y-auto pr-0.5">
                            {filtered.map((b) => {
                              const marketObj = markets.find((m) => m.id === b.market_id);
                              const marketDisplayName = marketObj ? marketObj.name : 'Matka Market';
                              return (
                                <div
                                  key={b.id}
                                  className="p-2.5 bg-[#11131c] rounded-xl border border-zinc-800 flex items-center justify-between hover:border-zinc-700 transition-all"
                                >
                                  <div>
                                    <div className="flex items-center gap-1.5">
                                      <span className="text-xs font-bold text-white">{marketDisplayName}</span>
                                      <span className="text-[10px] px-1.5 py-0.2 bg-zinc-800 text-zinc-300 rounded font-mono">
                                        {b.game_type}
                                      </span>
                                    </div>
                                    <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                                      Digit/Pana: <span className="text-orange-400 font-bold">#{b.digits}</span> &bull; {b.created_at ? new Date(b.created_at).toLocaleTimeString() : 'Recent'}
                                    </div>
                                  </div>

                                  <div className="text-right">
                                    <div className="text-xs font-mono font-black text-amber-400">
                                      ₹{Number(b.points || 0).toLocaleString('en-IN')}
                                    </div>
                                    <span
                                      className={`text-[9px] font-mono px-1.5 py-0.2 rounded font-bold ${
                                        b.status === 'WON'
                                          ? 'bg-emerald-500/20 text-emerald-300'
                                          : b.status === 'LOST'
                                          ? 'bg-rose-500/20 text-rose-300'
                                          : 'bg-amber-500/20 text-amber-300'
                                      }`}
                                    >
                                      {b.status || 'PENDING'}
                                    </span>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    </>
                  );
                })()}
              </div>
            )}

            {/* TAB 7: AGENTS MANAGEMENT */}
            {activeTab === 'agents' && (
              <div className="flex-1 p-4 overflow-y-auto space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-300">
                    Registered Agents ({agentsList.length})
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowAddAgent(!showAddAgent)}
                    className="px-2.5 py-1 bg-orange-500/20 hover:bg-orange-500/30 text-orange-400 border border-orange-500/40 rounded-xl text-[11px] font-bold cursor-pointer transition-all flex items-center gap-1"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>{showAddAgent ? 'Cancel' : 'Add Agent'}</span>
                  </button>
                </div>

                {showAddAgent && (
                  <div className="bg-[#141624] p-3.5 rounded-2xl border border-orange-500/30 space-y-2.5 animate-in fade-in">
                    <span className="text-xs font-bold text-orange-300 block">Register New Agent</span>
                    <input
                      type="text"
                      value={newAgentName}
                      onChange={(e) => setNewAgentName(e.target.value)}
                      placeholder="Agent Full Name"
                      className="w-full px-3 py-1.5 bg-[#090a0f] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white outline-none"
                    />
                    <input
                      type="text"
                      value={newAgentMobile}
                      onChange={(e) => setNewAgentMobile(e.target.value.replace(/\D/g, ''))}
                      placeholder="Agent 10-Digit Mobile"
                      className="w-full px-3 py-1.5 bg-[#090a0f] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white outline-none font-mono"
                    />
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-400">Commission %:</span>
                      <input
                        type="number"
                        value={newAgentCommission}
                        onChange={(e) => setNewAgentCommission(e.target.value)}
                        className="w-20 px-2 py-1 bg-[#090a0f] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white outline-none font-mono"
                      />
                    </div>
                    <button
                      type="button"
                      disabled={isCreatingAgent}
                      onClick={handleCreateAgent}
                      className="w-full py-2 bg-gradient-to-r from-orange-500 to-amber-500 text-black font-black text-xs rounded-xl shadow-md cursor-pointer transition-all active:scale-95 disabled:opacity-50"
                    >
                      {isCreatingAgent ? 'Saving...' : 'Save Agent to Supabase'}
                    </button>
                  </div>
                )}

                <div className="space-y-2 max-h-[52vh] overflow-y-auto pr-0.5">
                  {agentsList.length === 0 ? (
                    <div className="py-8 text-center text-xs text-slate-500">
                      No agents registered in Supabase yet.
                    </div>
                  ) : (
                    agentsList.map((ag) => (
                      <div
                        key={ag.id}
                        className="bg-[#11131c] p-3 rounded-2xl border border-zinc-800 flex items-center justify-between"
                      >
                        <div>
                          <div className="text-xs font-bold text-white flex items-center gap-1.5">
                            <span>{ag.name || 'Agent'}</span>
                            <span className="text-[10px] text-orange-400 font-mono font-bold">
                              {ag.commission_rate ?? 5}% Comm
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono block mt-0.5">
                            Mobile: {ag.mobile || 'N/A'}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={async () => {
                            const newStatus = ag.status === 'Active' ? 'Inactive' : 'Active';
                            await updateAgentInSupabase(ag.id, { status: newStatus });
                            loadAgents();
                          }}
                          className={`text-[10px] px-2.5 py-1 rounded-lg font-mono font-bold cursor-pointer transition-all ${
                            ag.status === 'Active'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : 'bg-zinc-800 text-slate-400'
                          }`}
                        >
                          {ag.status || 'Active'}
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* TAB: GAME RATES */}
            {activeTab === 'rates' && (
              <div className="flex-1 p-4 overflow-y-auto space-y-4">
                <div className="bg-[#11131c] p-3.5 rounded-2xl border border-zinc-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-xl bg-orange-500/20 text-orange-400 border border-orange-500/30 flex items-center justify-center">
                        <DollarSign className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-white">Live Game Win Rates & Multipliers</h4>
                        <p className="text-[10px] text-slate-400">Directly synchronized with Supabase game_rates backend</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => fetchGameRatesFromSupabase().then(setGameRateSections)}
                      className="px-2.5 py-1 rounded-lg bg-orange-500/20 text-orange-400 border border-orange-500/30 text-[10px] font-bold flex items-center gap-1 cursor-pointer hover:bg-orange-500/30"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Refresh</span>
                    </button>
                  </div>
                </div>

                <div className="space-y-4">
                  {gameRateSections.map((sec) => (
                    <div key={sec.sectionKey} className="bg-[#11131c] p-3.5 rounded-2xl border border-zinc-800 space-y-2.5">
                      <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
                        <span className="text-xs font-black text-amber-400 uppercase tracking-wider">{sec.category}</span>
                        <span className="text-[10px] font-mono text-slate-400 font-bold bg-zinc-800/80 px-2 py-0.5 rounded-full">{sec.items.length} Game Types</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {sec.items.map((item) => (
                          <div key={item.name} className="flex items-center justify-between p-2 rounded-xl bg-[#090a0f] border border-zinc-800/80">
                            <div>
                              <span className="text-xs font-bold text-white block">{item.name}</span>
                              <span className="text-[10px] font-mono text-orange-400 font-bold">{item.ratio}</span>
                            </div>
                            <span className="text-xs font-mono font-black text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-lg">
                              {item.multiplier}x
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB: NOTICES & BROADCASTS */}
            {activeTab === 'notices' && (
              <div className="flex-1 p-4 overflow-y-auto space-y-4">
                <div className="bg-[#11131c] p-3.5 rounded-2xl border border-zinc-800 space-y-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-orange-500/20 text-orange-400 border border-orange-500/30 flex items-center justify-center">
                      <Bell className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">Broadcast Instant Alert</h4>
                      <p className="text-[10px] text-slate-400">Pushes directly to user notifications screen via Supabase Realtime</p>
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-400 block mb-1">
                      Notification Title
                    </label>
                    <input
                      type="text"
                      value={notifTitle}
                      onChange={(e) => setNotifTitle(e.target.value)}
                      placeholder="e.g. Kalyan Market Bids Open!"
                      className="w-full px-3 py-2 bg-[#090a0f] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-400 block mb-1">
                      Message Content
                    </label>
                    <textarea
                      rows={3}
                      value={notifMessage}
                      onChange={(e) => setNotifMessage(e.target.value)}
                      placeholder="Enter announcement details, bonus offers, or market schedules..."
                      className="w-full px-3 py-2 bg-[#090a0f] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white outline-none resize-none"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-400 block mb-1">
                      Notification Category
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {(['alert', 'bonus', 'bid'] as const).map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => setNotifType(t)}
                          className={`py-1.5 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
                            notifType === t
                              ? 'bg-orange-500 text-black font-black'
                              : 'bg-[#090a0f] text-slate-400 border border-zinc-800'
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    type="button"
                    disabled={isSendingNotif}
                    onClick={handleSendBroadcastNotification}
                    className="w-full py-2.5 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-black font-black text-xs rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-1.5 transition-all active:scale-95 disabled:opacity-50"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isSendingNotif ? 'Broadcasting...' : 'Broadcast to All Players'}</span>
                  </button>
                </div>

                <div className="p-3 bg-[#11131c] rounded-2xl border border-zinc-800 text-[11px] text-slate-400 space-y-1">
                  <div className="font-bold text-slate-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Supabase Real-time Active</span>
                  </div>
                  <p>
                    All broadcast alerts trigger instant Supabase Postgres Realtime event notifications, updating the bell icon badge and Notification Center immediately across both RATAN567 Admin and RAMA777 User App.
                  </p>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
