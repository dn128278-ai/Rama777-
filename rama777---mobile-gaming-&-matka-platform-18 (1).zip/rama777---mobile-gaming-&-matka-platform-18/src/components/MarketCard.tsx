import React from 'react';
import { Info, Play, Clock } from 'lucide-react';
import { MarketItem } from '../types';
import { formatMarketResult } from '../utils/marketEngine';

export interface MarketCardProps {
  market: MarketItem;
  onPlay: (market: MarketItem) => void;
  onOpenChart: (marketName: string) => void;
}

/**
 * MarketCard component for displaying Matka market items and dynamic results.
 * Clean light mode card on crisp white with sharp typography and orange CTA buttons.
 */
export const MarketCard: React.FC<MarketCardProps> = ({
  market,
  onPlay,
  onOpenChart,
}) => {
  const isClosed = !market.isOpen;
  const isRunningOpen = market.status === 'Running for Open';
  const isRunningClose = market.status === 'Running for Close';

  // Dynamically resolve full formatted result
  const result = formatMarketResult({
    openPana: market.openPana,
    jodi: market.jodi,
    closePana: market.closePana,
  });

  return (
    <div className="bg-white rounded-3xl p-4.5 border border-slate-200 hover:border-orange-400 shadow-sm hover:shadow-md relative transition-all">
      {/* Card Top Row: Name + Info and Orange Play Button */}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-black text-base tracking-tight text-[#FF7700] truncate">
              {market.name}
            </h3>
            <button
              onClick={() => onOpenChart(market.name)}
              className="text-[#FF7700] hover:text-orange-600 p-1 rounded-full cursor-pointer active:scale-90 transition-transform"
              title="View Panel & Jodi Chart"
              aria-label={`View chart for ${market.name}`}
            >
              <Info className="w-4 h-4" />
            </button>
          </div>

          {/* Triplet Result with dynamic format resolution (e.g., 333 - 99 - 333) */}
          <div
            className="text-lg font-black font-mono tracking-tight mt-1 flex items-center gap-1.5 text-slate-900"
            data-testid="market-result-display"
          >
            <span className="font-extrabold text-slate-900">{result.openPana}</span>
            <span className="text-slate-400 font-normal">-</span>
            <span
              className={`font-black ${
                result.jodi !== '**' && !result.jodi.includes('*')
                  ? 'text-[#FF7700] underline decoration-[#FF7700]/50 decoration-2'
                  : 'text-slate-900'
              }`}
            >
              {result.jodi}
            </span>
            <span className="text-slate-400 font-normal">-</span>
            <span className="font-extrabold text-slate-900">{result.closePana}</span>
          </div>

          {/* Timing details */}
          <div className="flex items-center gap-2 text-[11px] text-slate-500 font-medium mt-1">
            <span>Open: {market.openTime}</span>
            <span>•</span>
            <span>Close: {market.closeTime}</span>
          </div>
        </div>

        {/* Play Action Button */}
        <button
          onClick={() => onPlay(market)}
          disabled={isClosed}
          className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 transition-all cursor-pointer ${
            isClosed
              ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
              : 'bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white shadow-md shadow-orange-500/25 hover:shadow-orange-500/40 active:scale-95 border border-orange-400'
          }`}
          title={isClosed ? 'Market Closed' : 'Place Bids'}
          aria-label={`Play on ${market.name}`}
        >
          <Play className={`w-5 h-5 ${isClosed ? 'text-slate-400' : 'text-white fill-white'}`} />
        </button>
      </div>

      {/* Card Bottom Status Bar */}
      <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs">
        <div className="flex items-center gap-1.5">
          <span
            className={`w-2 h-2 rounded-full ${
              isRunningOpen
                ? 'bg-emerald-500 animate-pulse'
                : isRunningClose
                ? 'bg-amber-500 animate-pulse'
                : 'bg-rose-500'
            }`}
          />
          <span
            className={`font-bold ${
              isRunningOpen
                ? 'text-emerald-700'
                : isRunningClose
                ? 'text-amber-700'
                : 'text-rose-600'
            }`}
          >
            {market.status}
          </span>
        </div>

        {market.countdownText && (
          <div className="flex items-center gap-1 text-[11px] font-mono font-semibold text-slate-500">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
            <span>{market.countdownText}</span>
          </div>
        )}
      </div>
    </div>
  );
};
