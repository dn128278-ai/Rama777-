import React, { useState } from 'react';
import {
  Home,
  LineChart,
  Lock,
  Bell,
  HelpCircle,
  MessageSquarePlus,
  IndianRupee,
  FileText,
  Settings,
  Globe,
  Moon,
  Sun,
  Share2,
  LogOut,
  User,
  X,
  Crown,
  Fingerprint,
} from 'lucide-react';
import { UserProfile } from '../types';
import { isBiometricEnabled, setBiometricEnabled } from '../services/webAuthnService';

interface SideDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onSelectOption: (option: string) => void;
  onLogout: () => void;
}

interface MenuItem {
  id: string;
  label: string;
  icon: React.ElementType;
  badge?: string;
  badgeColor?: string;
}

export const SideDrawer: React.FC<SideDrawerProps> = ({
  isOpen,
  onClose,
  user,
  isDarkMode,
  onToggleDarkMode,
  onSelectOption,
  onLogout,
}) => {
  const [showExitDialog, setShowExitDialog] = useState<boolean>(false);
  const [biometricActive, setBiometricActive] = useState<boolean>(() => isBiometricEnabled());

  if (!isOpen) return null;

  const isAdmin = user.role === 'admin';

  const menuItems: MenuItem[] = [
    { id: 'home', label: 'Home', icon: Home },
    ...(user.role === 'admin'
      ? [{ id: 'admin_panel', label: 'RATAN567 Admin Panel', icon: Crown }]
      : []),
    { id: 'charts', label: 'Charts', icon: LineChart },
    { id: 'change_mpin', label: 'Change MPIN', icon: Lock },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'how_to_play', label: 'How To Play?', icon: HelpCircle },
    { id: 'submit_ideas', label: 'Submit User Ideas', icon: MessageSquarePlus },
    { id: 'game_rates', label: 'Game Rates', icon: IndianRupee },
    { id: 'terms', label: 'Terms & Conditions', icon: FileText },
    { id: 'settings', label: 'Settings', icon: Settings },
    { id: 'language', label: 'Language', icon: Globe },
  ];

  const handleShareApp = () => {
    if (navigator.share) {
      navigator.share({
        title: 'RAMA777 Mobile App',
        text: 'Download & Play on RAMA777 - India\'s premier mobile matka & gaming app!',
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('RAMA777 app link copied to clipboard!');
    }
  };

  const handleConfirmExit = () => {
    setShowExitDialog(false);
    onClose();
    onLogout();
  };

  return (
    <div className="absolute inset-0 z-50 flex overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-xs transition-opacity animate-in fade-in"
        onClick={onClose}
      />

      {/* Drawer Body */}
      <div className="relative w-4/5 max-w-xs h-full bg-white text-slate-800 border-r border-slate-200 shadow-2xl flex flex-col z-10 animate-in slide-in-from-left duration-200 overflow-y-auto">
        {/* Top Header Profile Card */}
        <div className="bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white p-5 pt-7 relative shrink-0">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white/80 hover:text-white p-1 rounded-full cursor-pointer"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3.5 mt-2">
            <div className="w-14 h-14 rounded-full bg-white text-[#FF7700] flex items-center justify-center shadow-md relative">
              <User className="w-8 h-8" />
              {isAdmin && (
                <div className="absolute -top-1 -right-1 bg-amber-400 text-slate-950 p-1 rounded-full shadow-md">
                  <Crown className="w-3.5 h-3.5" />
                </div>
              )}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-lg font-bold leading-tight">{user.name}</h2>
              </div>
              <p className="text-xs text-orange-100 font-mono tracking-wide mt-0.5">{user.phone}</p>
              <div className="mt-1 flex items-center gap-1.5">
                <span
                  className={`text-[9px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                    isAdmin
                      ? 'bg-amber-400 text-slate-950 shadow-xs'
                      : 'bg-orange-500/20 text-orange-100 border border-orange-400/40'
                  }`}
                >
                  {isAdmin ? '👑 Super Admin' : 'VIP Player'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Menu Navigation List */}
        <div className="flex-1 py-2 divide-y divide-slate-100 overflow-y-auto">
          <div className="py-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onClose();
                    onSelectOption(item.id);
                  }}
                  className="w-full flex items-center justify-between px-5 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50 hover:text-[#FF7700] active:bg-slate-100 transition-colors cursor-pointer text-left"
                >
                  <div className="flex items-center gap-3.5 truncate">
                    <Icon className="w-5 h-5 text-slate-400 group-hover:text-[#FF7700] shrink-0" />
                    <span className="truncate">{item.label}</span>
                  </div>
                  {item.badge && (
                    <span
                      className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded-md uppercase shrink-0 ${
                        item.badgeColor || 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Dark Mode Toggle Item */}
          <div className="px-5 py-3 flex items-center justify-between">
            <div className="flex items-center gap-4">
              {isDarkMode ? (
                <Moon className="w-5 h-5 text-orange-500 shrink-0" />
              ) : (
                <Sun className="w-5 h-5 text-amber-500 shrink-0" />
              )}
              <span className="text-sm font-semibold text-slate-700">
                Dark Mode
              </span>
            </div>

            {/* Toggle Switch */}
            <button
              onClick={onToggleDarkMode}
              className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors ${
                isDarkMode ? 'bg-[#FF7700]' : 'bg-slate-200'
              }`}
            >
              <div
                className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                  isDarkMode ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Biometric Login Toggle Item */}
          <div className="px-5 py-3 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Fingerprint className="w-5 h-5 text-[#FF7700] shrink-0" />
              <div>
                <span className="text-sm font-semibold text-slate-700 block">
                  Biometric Login
                </span>
                <span className="text-[10px] text-slate-400">
                  Fingerprint / Face ID
                </span>
              </div>
            </div>

            {/* Toggle Switch */}
            <button
              type="button"
              onClick={() => {
                const next = !biometricActive;
                setBiometricActive(next);
                setBiometricEnabled(next);
              }}
              className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors ${
                biometricActive ? 'bg-[#FF7700]' : 'bg-slate-200'
              }`}
            >
              <div
                className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                  biometricActive ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Share App Item */}
          <div className="py-1">
            <button
              onClick={handleShareApp}
              className="w-full flex items-center gap-4 px-5 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50 hover:text-[#FF7700] active:bg-slate-100 transition-colors cursor-pointer text-left"
            >
              <Share2 className="w-5 h-5 text-slate-400 shrink-0" />
              <span>Share App</span>
            </button>

            {/* Exit App Trigger */}
            <button
              onClick={() => setShowExitDialog(true)}
              className="w-full flex items-center gap-4 px-5 py-3 text-sm font-semibold text-rose-600 hover:bg-rose-50 active:bg-rose-100 transition-colors cursor-pointer text-left"
            >
              <LogOut className="w-5 h-5 text-rose-500 shrink-0" />
              <span>Exit app</span>
            </button>
          </div>
        </div>

        {/* Footer with App Version */}
        <div className="p-4 border-t border-slate-100 text-center shrink-0">
          <p className="text-xs text-slate-400 font-medium">
            App Version: {user.appVersion}
          </p>
        </div>
      </div>

      {/* Exit App Confirmation Dialog */}
      {showExitDialog && (
        <div className="absolute inset-0 z-60 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-xs bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 text-center animate-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-3 shadow-xs border border-rose-200">
              <LogOut className="w-6 h-6" />
            </div>

            <h3 className="font-extrabold text-base text-slate-900 mb-1">
              Exit App
            </h3>
            <p className="text-xs text-slate-500 font-medium mb-5 leading-relaxed">
              Do you really want to close this app?
            </p>

            <div className="grid grid-cols-2 gap-2.5">
              <button
                onClick={() => setShowExitDialog(false)}
                className="py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-50 active:scale-95 transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmExit}
                className="py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-rose-700 text-white font-bold text-xs shadow-md shadow-rose-500/20 active:scale-95 transition-all cursor-pointer"
              >
                Yes, Exit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
