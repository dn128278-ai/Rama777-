import React, { useState } from 'react';
import {
  Headphones,
  ChevronRight,
  Send,
  ArrowLeft,
  MessageSquare,
  Clock,
  CheckCircle2,
  HelpCircle,
  PhoneCall,
} from 'lucide-react';
import { SupportChatMessage } from '../types';

interface IssueCategory {
  id: string;
  title: string;
  desc: string;
  badge: string;
  quickQueries: string[];
}

export const SupportTab: React.FC = () => {
  const [selectedIssue, setSelectedIssue] = useState<IssueCategory | null>(null);
  const [chatInput, setChatInput] = useState<string>('');
  const [messages, setMessages] = useState<SupportChatMessage[]>([
    {
      id: 'm1',
      sender: 'agent',
      text: 'Namaste! Welcome to Rama 777 Priority Support. Please select an issue category or message us directly.',
      timestamp: 'Just now',
    },
  ]);

  const issues = [
    {
      id: 'deposit',
      title: 'Deposit Issue',
      desc: 'Fund not credited, UPI pending, or bonus inquiries',
      badge: 'High Priority',
      quickQueries: [
        'Amount debited from bank but not credited in wallet',
        'UPI transaction shows Pending in Add Funds History',
        '₹100 Welcome Bonus not added after payment',
      ],
    },
    {
      id: 'withdraw',
      title: 'Withdraw Issue',
      desc: 'Bank payout delays, penny drop, or account verification',
      badge: 'Instant IMPS',
      quickQueries: [
        'Withdrawal request pending for over 30 minutes',
        'Need assistance with 30-day bank update policy',
        'Penny drop verification failed for bank account',
      ],
    },
    {
      id: 'other',
      title: 'Other Issue',
      desc: 'MPIN reset, game rules, rates, or general questions',
      badge: '24x7 Help',
      quickQueries: [
        'How to change or reset my 4-digit MPIN?',
        'Clarification on Bombay Starline & Jodi rates',
        'Submit a suggestion for Rama 777 app',
      ],
    },
  ];

  const handleSelectIssue = (issue: typeof issues[0]) => {
    setSelectedIssue(issue);
    setMessages((prev) => [
      ...prev,
      {
        id: `u-${Date.now()}`,
        sender: 'user',
        text: `Category Selected: ${issue.title}`,
        timestamp: 'Just now',
      },
      {
        id: `a-${Date.now()}`,
        sender: 'agent',
        text: `Hello! You have reached our dedicated ${issue.title} desk. You can tap a quick query below or type your transaction details/query. Our team resolves 98% of queries within 5 minutes.`,
        timestamp: 'Just now',
      },
    ]);
  };

  const handleSendText = (textToSend: string) => {
    if (!textToSend.trim()) return;
    const text = textToSend.trim();
    setChatInput('');

    const newMsg: SupportChatMessage = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: 'Just now',
    };

    setMessages((prev) => [...prev, newMsg]);

    setTimeout(() => {
      const ticketId = Math.floor(100000 + Math.random() * 900000);
      setMessages((prev) => [
        ...prev,
        {
          id: `a-${Date.now()}`,
          sender: 'agent',
          text: `Ticket #RAMA-${ticketId} logged under "${selectedIssue?.title || 'General'}". An executive is reviewing your request. For immediate resolution, you can also connect directly on WhatsApp (+91 6377972674).`,
          timestamp: 'Just now',
        },
      ]);
    }, 800);
  };

  return (
    <div className="pb-6 pt-2 px-4 transition-colors bg-white">
      {!selectedIssue ? (
        /* Direct Category Selection View */
        <div className="space-y-6 pt-2 text-center">
          {/* Orange Headset Silhouette */}
          <div className="w-24 h-24 mx-auto rounded-full bg-orange-50 border border-orange-200 flex items-center justify-center text-[#FF7700] shadow-sm">
            <Headphones className="w-14 h-14" />
          </div>

          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              Rama 777
            </h2>
            <h3 className="text-xl font-black text-[#FF7700] tracking-tight">
              Chat Support
            </h3>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-2">
              SELECT AN ISSUE CATEGORY
            </p>
          </div>

          {/* Issue Cards with Direct Category Selection */}
          <div className="space-y-3 pt-1 text-left">
            {issues.map((issue) => (
              <button
                key={issue.id}
                onClick={() => handleSelectIssue(issue)}
                className="w-full bg-white rounded-3xl p-4.5 border border-slate-200 flex items-center justify-between shadow-xs hover:border-[#FF7700] hover:bg-slate-50 active:scale-[0.99] transition-all cursor-pointer group"
              >
                <div className="pr-3">
                  <div className="flex items-center gap-2">
                    <h4 className="font-extrabold text-sm text-slate-900 group-hover:text-[#FF7700] transition-colors">
                      {issue.title}
                    </h4>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-orange-50 text-[#FF7700] border border-orange-200">
                      {issue.badge}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">{issue.desc}</p>
                </div>

                <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs shrink-0 group-hover:scale-105 transition-transform">
                  <ChevronRight className="w-5 h-5" />
                </div>
              </button>
            ))}
          </div>

          {/* Quick Contact Options */}
          <div className="pt-2 grid grid-cols-2 gap-2.5">
            <button
              onClick={() =>
                window.open('https://wa.me/916377972674?text=Hello%20RAMA777%20Support', '_blank')
              }
              className="py-3 px-2 rounded-2xl border-2 border-emerald-500/80 bg-emerald-50 text-emerald-700 font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all shadow-xs hover:bg-emerald-100"
            >
              <MessageSquare className="w-4 h-4 fill-current" />
              <span>WhatsApp Help</span>
            </button>

            <button
              onClick={() => window.open('tel:+916377972674')}
              className="py-3 px-2 rounded-2xl border-2 border-orange-500/80 bg-orange-50 text-[#FF7700] font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all shadow-xs hover:bg-orange-100"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Call Helpline</span>
            </button>
          </div>
        </div>
      ) : (
        /* Live Category Chat View */
        <div className="flex flex-col h-[calc(100vh-140px)] bg-white">
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 shrink-0">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setSelectedIssue(null)}
                className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div>
                <h3 className="font-extrabold text-sm text-slate-900">
                  {selectedIssue.title}
                </h3>
                <span className="text-[10px] text-emerald-600 font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  Priority Officer Online
                </span>
              </div>
            </div>

            <button
              onClick={() =>
                window.open(
                  `https://wa.me/916377972674?text=${encodeURIComponent(
                    `Hello RAMA777 Support, I need help regarding: ${selectedIssue.title}`
                  )}`,
                  '_blank'
                )
              }
              className="px-2.5 py-1 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-700 text-xs font-bold flex items-center gap-1 cursor-pointer active:scale-95 hover:bg-emerald-100"
            >
              <MessageSquare className="w-3.5 h-3.5 fill-current" />
              <span>WhatsApp</span>
            </button>
          </div>

          {/* Quick Issue Questions Pills */}
          <div className="py-2 overflow-x-auto flex gap-2 shrink-0 border-b border-slate-100">
            {selectedIssue.quickQueries.map((query, idx) => (
              <button
                key={idx}
                onClick={() => handleSendText(query)}
                className="shrink-0 text-[11px] font-semibold bg-slate-50 hover:bg-orange-50 hover:text-[#FF7700] text-slate-700 px-3 py-1.5 rounded-full border border-slate-200 transition-all cursor-pointer text-left"
              >
                {query}
              </button>
            ))}
          </div>

          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto py-3 space-y-3">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white rounded-br-xs shadow-xs'
                      : 'bg-slate-100 text-slate-800 border border-slate-200 rounded-bl-xs shadow-xs'
                  }`}
                >
                  <p>{msg.text}</p>
                  <span className="text-[9px] opacity-70 block text-right mt-1 font-mono">
                    {msg.timestamp}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Chat Input */}
          <div className="pt-2 flex items-center gap-2 shrink-0">
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendText(chatInput)}
              placeholder={`Describe your ${selectedIssue.title.toLowerCase()}...`}
              className="flex-1 bg-slate-50 border border-slate-200 focus:border-[#FF7700] rounded-2xl px-4 py-3 text-xs text-slate-900 placeholder-slate-400 outline-none"
            />
            <button
              onClick={() => handleSendText(chatInput)}
              className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center active:scale-90 transition-transform cursor-pointer shadow-xs"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
