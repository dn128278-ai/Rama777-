import React, { useState } from 'react';
import { ArrowLeft, Bell, CheckCircle2 } from 'lucide-react';
import { AppNotification } from '../types';

export const NotificationsModal: React.FC<{
  notifications: AppNotification[];
  onClose: () => void;
  onClear: () => void;
}> = ({ notifications, onClose, onClear }) => {
  return (
    <div className="pb-24 pt-2 px-4 transition-colors bg-white">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2.5">
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <h2 className="text-base font-extrabold text-[#FF7700]">Notifications</h2>
        </div>
        <button
          onClick={onClear}
          className="text-xs font-semibold text-slate-500 hover:text-[#FF7700] cursor-pointer"
        >
          Clear All
        </button>
      </div>

      <div className="space-y-3">
        {notifications.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center shadow-xs">
            <Bell className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-700">
              No new notifications
            </p>
          </div>
        ) : (
          notifications.map((n) => (
            <div
              key={n.id}
              className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs space-y-1"
            >
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-xs text-slate-900">
                  {n.title}
                </h4>
                <span className="text-[10px] text-slate-400 font-mono">{n.time}</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                {n.message}
              </p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export const HowToPlayModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  return (
    <div className="pb-24 pt-2 px-4 transition-colors bg-white">
      <div className="flex items-center gap-2.5 mb-5">
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <h2 className="text-base font-extrabold text-[#FF7700]">How To Play?</h2>
      </div>

      <div className="space-y-4">
        {[
          {
            title: 'Single Digit (1 ka 10)',
            desc: 'Pick any single number between 0 and 9 for either Open or Close session. If your chosen digit matches the opening or closing sum digit, you win 10x your points!',
          },
          {
            title: 'Jodi Digit (1 ka 100)',
            desc: 'Predict both open and close digits together as a pair from 00 to 99. A winning Jodi pays an incredible 100x return!',
          },
          {
            title: 'Single Pana (1 ka 160)',
            desc: 'Pana is a 3-digit combination in ascending order (e.g. 140, 799). Single Pana has 3 unique digits with payout of 160x.',
          },
          {
            title: 'Double Pana & Triple Pana',
            desc: 'Double Pana features 2 identical digits (e.g. 118, payout 300x). Triple Pana features all 3 identical digits (e.g. 777, payout 900x)!',
          },
          {
            title: 'Half Sangam & Full Sangam',
            desc: 'Combine Pana and single digits for maximum jackpot payouts up to 10,000x your bid points.',
          },
        ].map((item, idx) => (
          <div
            key={idx}
            className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-1.5"
          >
            <h4 className="font-extrabold text-sm text-[#FF7700]">{item.title}</h4>
            <p className="text-xs text-slate-600 leading-relaxed font-medium">
              {item.desc}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export const SubmitIdeasModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [feedback, setFeedback] = useState<string>('');
  const [submitted, setSubmitted] = useState<boolean>(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedback.trim()) return;
    setSubmitted(true);
    setTimeout(() => {
      onClose();
    }, 1500);
  };

  return (
    <div className="pb-24 pt-2 px-4 transition-colors bg-white">
      <div className="flex items-center gap-2.5 mb-5">
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <h2 className="text-base font-extrabold text-[#FF7700]">Submit User Ideas</h2>
      </div>

      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
        {submitted ? (
          <div className="text-center py-6 space-y-2">
            <CheckCircle2 className="w-12 h-12 text-[#FF7700] mx-auto" />
            <h4 className="font-extrabold text-sm text-slate-900">
              Thank you for your valuable feedback!
            </h4>
            <p className="text-xs text-slate-500">
              Our development team reviews user suggestions regularly.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <p className="text-xs text-slate-500 leading-relaxed">
              Have an idea to improve RAMA777? Tell us what new game modes or improvements you want to see!
            </p>

            <textarea
              rows={4}
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              placeholder="Write your idea or suggestion here..."
              className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-3.5 text-xs text-slate-900 placeholder-slate-400 outline-none focus:border-[#FF7700]"
            />

            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white font-bold text-sm shadow-md shadow-orange-500/25 active:scale-95 transition-all cursor-pointer"
            >
              Submit Idea
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export const SettingsModal: React.FC<{
  biometric: boolean;
  onToggleBiometric: () => void;
  language: string;
  onChangeLanguage: (lang: string) => void;
  onClose: () => void;
}> = ({ biometric, onToggleBiometric, language, onChangeLanguage, onClose }) => {
  const [soundEnabled, setSoundEnabled] = useState(true);

  return (
    <div className="pb-24 pt-2 px-4 transition-colors bg-white">
      <div className="flex items-center gap-2.5 mb-5">
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <h2 className="text-base font-extrabold text-[#FF7700]">Settings</h2>
      </div>

      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs divide-y divide-slate-100">
        <div className="py-3 flex items-center justify-between">
          <div>
            <h4 className="font-bold text-xs text-slate-900">
              Biometric Fingerprint Login
            </h4>
            <p className="text-[10px] text-slate-500">Unlock RAMA777 with one touch</p>
          </div>
          <button
            onClick={onToggleBiometric}
            className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors ${
              biometric ? 'bg-[#FF7700]' : 'bg-slate-200'
            }`}
          >
            <div
              className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                biometric ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        <div className="py-3 flex items-center justify-between">
          <div>
            <h4 className="font-bold text-xs text-slate-900">
              Sound Effects
            </h4>
            <p className="text-[10px] text-slate-500">Play sound on bid placement</p>
          </div>
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors ${
              soundEnabled ? 'bg-[#FF7700]' : 'bg-slate-200'
            }`}
          >
            <div
              className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                soundEnabled ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        <div className="py-3 flex items-center justify-between">
          <div>
            <h4 className="font-bold text-xs text-slate-900">
              App Language
            </h4>
            <p className="text-[10px] text-slate-500">Current: {language}</p>
          </div>
          <div className="flex gap-1.5">
            {['English', 'हिन्दी'].map((l) => (
              <button
                key={l}
                onClick={() => onChangeLanguage(l)}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  language === l
                    ? 'bg-[#FF7700] text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-700 border border-slate-200'
                }`}
              >
                {l}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export const LanguageModal: React.FC<{
  currentLanguage: string;
  onSelectLanguage: (lang: string) => void;
  onClose: () => void;
}> = ({ currentLanguage, onSelectLanguage, onClose }) => {
  const languages = [
    { code: 'en', name: 'English', native: 'English' },
    { code: 'hi', name: 'Hindi', native: 'हिन्दी' },
    { code: 'mr', name: 'Marathi', native: 'मराठी' },
    { code: 'gu', name: 'Gujarati', native: 'ગુજરાતી' },
    { code: 'te', name: 'Telugu', native: 'తెలుగు' },
    { code: 'ta', name: 'Tamil', native: 'தமிழ்' },
  ];

  return (
    <div className="pb-24 pt-2 px-4 transition-colors bg-white">
      <div className="flex items-center gap-2.5 mb-5">
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <h2 className="text-base font-extrabold text-[#FF7700]">Language Selection</h2>
      </div>

      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-2.5">
        <p className="text-xs text-slate-500 mb-2 font-medium">Select your preferred app language:</p>
        {languages.map((lang) => {
          const isSelected = currentLanguage === lang.name || currentLanguage === lang.native;
          return (
            <button
              key={lang.code}
              onClick={() => {
                onSelectLanguage(lang.name);
                setTimeout(() => onClose(), 200);
              }}
              className={`w-full p-3.5 rounded-2xl border flex items-center justify-between transition-all cursor-pointer ${
                isSelected
                  ? 'border-[#FF7700] bg-orange-50 text-[#FF7700] shadow-2xs'
                  : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
              }`}
            >
              <div className="text-left">
                <span className="font-extrabold text-sm block text-slate-900">{lang.native}</span>
                <span className="text-[11px] text-slate-500 font-medium">{lang.name}</span>
              </div>
              {isSelected && <CheckCircle2 className="w-5 h-5 text-[#FF7700]" />}
            </button>
          );
        })}
      </div>
    </div>
  );
};
