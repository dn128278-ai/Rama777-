/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Dynamic Game Rates screen connected to Supabase 'game_rates' table.
 * Categorized under RAMA777, BOMBAY STARLINE, and BOMBAY JACKPOT.
 */

import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  RefreshCw,
  Zap,
  ShieldCheck,
  Search,
  Calculator,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';
import {
  GameRateSection,
  GameRateItem,
  DEFAULT_GAME_RATES,
  subscribeToGameRates,
  fetchGameRatesFromSupabase,
} from '../services/gameRatesService';

interface GameRatesModalProps {
  onClose: () => void;
}

export const GameRatesModal: React.FC<GameRatesModalProps> = ({ onClose }) => {
  const [sections, setSections] = useState<GameRateSection[]>(DEFAULT_GAME_RATES);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [lastUpdated, setLastUpdated] = useState<string>('Just now');
  const [selectedCategory, setSelectedCategory] = useState<'ALL' | 'RAMA777' | 'BOMBAY STARLINE' | 'BOMBAY JACKPOT'>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [calculatorGame, setCalculatorGame] = useState<GameRateItem | null>(null);
  const [calculatorAmount, setCalculatorAmount] = useState<string>('100');

  useEffect(() => {
    // Subscribe to live Supabase 'game_rates' changes
    const unsub = subscribeToGameRates((updatedSections) => {
      setSections(updatedSections);
      setLastUpdated(
        new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      );
    });

    return () => {
      unsub();
    };
  }, []);

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    try {
      const data = await fetchGameRatesFromSupabase();
      setSections(data);
      setLastUpdated(
        new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      );
    } catch (e) {
      console.warn('Manual refresh error:', e);
    } finally {
      setTimeout(() => setIsRefreshing(false), 300);
    }
  };

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'dice-1':
        return '🎲';
      case 'spade':
        return '🂡';
      case 'dice-2':
        return '⚁';
      case 'spade-pair':
        return '🂢';
      case 'brackets':
        return '{ }';
      case 'cards-3':
        return '🎴';
      case 'coin-a':
      case 'coin-b':
        return '🪙';
      case 'coin-gold':
        return '💰';
      default:
        return '🎯';
    }
  };

  // Filter sections by category and search query
  const filteredSections = sections
    .filter((sec) => selectedCategory === 'ALL' || sec.sectionKey === selectedCategory)
    .map((sec) => {
      if (!searchQuery.trim()) return sec;
      const q = searchQuery.toLowerCase().trim();
      const matchedItems = sec.items.filter(
        (item) =>
          item.name.toLowerCase().includes(q) ||
          item.ratio.toLowerCase().includes(q) ||
          item.multiplier.toString().includes(q)
      );
      return {
        ...sec,
        items: matchedItems,
      };
    })
    .filter((sec) => sec.items.length > 0);

  const totalRatesCount = sections.reduce((acc, s) => acc + s.items.length, 0);

  return (
    <div className="pb-24 pt-2 px-4 transition-colors min-h-screen bg-white select-none">
      {/* Top Header Bar */}
      <div className="flex items-center justify-between mb-3.5">
        <div className="flex items-center gap-2.5">
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95 transition-transform"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h2 className="text-base font-extrabold text-[#FF7700] flex items-center gap-1.5">
              <span>Game Rates</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            </h2>
            <p className="text-[10px] text-slate-500 font-medium">
              Live Supabase Ratios • Updated {lastUpdated}
            </p>
          </div>
        </div>

        {/* Refresh button */}
        <button
          onClick={handleManualRefresh}
          disabled={isRefreshing}
          className="flex items-center gap-1 text-[11px] font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 py-1.5 px-2.5 rounded-lg transition-colors cursor-pointer active:scale-95 disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-[#FF7700] ${isRefreshing ? 'animate-spin' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      {/* Trust banner */}
      <div className="mb-3.5 bg-orange-50/70 border border-orange-200/80 rounded-xl p-2.5 flex items-center justify-between text-xs text-orange-950">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-[#FF7700] shrink-0" />
          <span className="font-semibold text-[11px]">Instant Automated Payouts at Official Rates</span>
        </div>
        <div className="flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-md">
          <ShieldCheck className="w-3 h-3 text-emerald-600" />
          <span>Supabase Live</span>
        </div>
      </div>

      {/* Category Segmented Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl mb-3 overflow-x-auto">
        <button
          onClick={() => setSelectedCategory('ALL')}
          className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
            selectedCategory === 'ALL'
              ? 'bg-[#FF7700] text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          All ({totalRatesCount})
        </button>
        <button
          onClick={() => setSelectedCategory('RAMA777')}
          className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
            selectedCategory === 'RAMA777'
              ? 'bg-[#FF7700] text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          RAMA777
        </button>
        <button
          onClick={() => setSelectedCategory('BOMBAY STARLINE')}
          className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
            selectedCategory === 'BOMBAY STARLINE'
              ? 'bg-[#FF7700] text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          BOMBAY STARLINE
        </button>
        <button
          onClick={() => setSelectedCategory('BOMBAY JACKPOT')}
          className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
            selectedCategory === 'BOMBAY JACKPOT'
              ? 'bg-[#FF7700] text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          BOMBAY JACKPOT
        </button>
      </div>

      {/* Search Input */}
      <div className="relative mb-4">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search game rates (e.g. Jodi, Pana, Sangam)..."
          className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-orange-500 font-medium"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 px-1 font-bold"
          >
            ✕
          </button>
        )}
      </div>

      {/* Interactive Payout Calculator Card (when tapped) */}
      {calculatorGame && (
        <div className="mb-4 bg-gradient-to-br from-orange-50 to-amber-50/50 border-2 border-orange-300 rounded-2xl p-3.5 shadow-sm">
          <div className="flex items-center justify-between pb-2 border-b border-orange-200 mb-2.5">
            <div className="flex items-center gap-2">
              <Calculator className="w-4 h-4 text-[#FF7700]" />
              <span className="text-xs font-black text-slate-900">
                Payout Calculator: {calculatorGame.name}
              </span>
            </div>
            <button
              onClick={() => setCalculatorGame(null)}
              className="text-xs font-bold text-slate-400 hover:text-slate-600"
            >
              ✕ Close
            </button>
          </div>

          <div className="flex items-center gap-3 mb-2.5">
            <div className="flex-1">
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                Bet Amount (₹)
              </label>
              <input
                type="number"
                min="10"
                step="10"
                value={calculatorAmount}
                onChange={(e) => setCalculatorAmount(e.target.value)}
                className="w-full bg-white border border-orange-300 rounded-xl px-3 py-1.5 text-sm font-black text-slate-900 focus:outline-none font-mono"
              />
            </div>
            <div className="text-center px-1 text-slate-400 font-bold">×</div>
            <div>
              <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                Ratio
              </div>
              <div className="bg-orange-100 text-[#FF7700] border border-orange-300 rounded-xl px-3 py-1.5 text-xs font-black font-mono">
                {calculatorGame.multiplier}x
              </div>
            </div>
          </div>

          {/* Quick chip increments */}
          <div className="flex items-center gap-1.5 mb-2.5 overflow-x-auto">
            {['10', '50', '100', '500', '1000'].map((amt) => (
              <button
                key={amt}
                onClick={() => setCalculatorAmount(amt)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                  calculatorAmount === amt
                    ? 'bg-[#FF7700] text-white'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                ₹{amt}
              </button>
            ))}
          </div>

          {/* Winning calculation result */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5 flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-800 flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
              <span>Estimated Winning Return:</span>
            </span>
            <span className="text-sm font-black text-emerald-700 font-mono">
              ₹{(parseInt(calculatorAmount || '0', 10) * calculatorGame.multiplier).toLocaleString('en-IN')}
            </span>
          </div>
        </div>
      )}

      {/* Dynamic Sections: RAMA777, BOMBAY STARLINE, BOMBAY JACKPOT */}
      <div className="space-y-5">
        {filteredSections.map((section) => (
          <div key={section.sectionKey} className="space-y-2.5">
            {/* Section Header */}
            <div className="flex items-center justify-between py-1">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#FF7700]" />
                <h3 className="font-black text-xs text-slate-900 tracking-wider uppercase">
                  {section.category}
                </h3>
              </div>
              <span className="text-[10px] font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">
                {section.items.length} Rates
              </span>
            </div>

            {/* Rates Grid */}
            <div className="space-y-2">
              {section.items.map((item, iIdx) => (
                <div
                  key={item.id || iIdx}
                  onClick={() => {
                    setCalculatorGame(item);
                  }}
                  className="bg-white rounded-2xl p-3 px-4 border border-slate-200/90 flex items-center justify-between shadow-xs hover:border-orange-400 hover:bg-orange-50/20 transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-orange-500/10 text-[#FF7700] border border-orange-200 flex items-center justify-center text-sm font-bold shadow-2xs shrink-0 group-hover:bg-[#FF7700] group-hover:text-white transition-colors">
                      {getIcon(item.icon)}
                    </div>
                    <div>
                      <span className="font-extrabold text-xs text-slate-800 block group-hover:text-[#FF7700] transition-colors">
                        {item.name}
                      </span>
                      <span className="text-[10px] text-slate-400 font-semibold flex items-center gap-1">
                        <span>Multiplier: {item.multiplier}x</span>
                        <span className="text-orange-400 font-bold">• Tap to calculate</span>
                      </span>
                    </div>
                  </div>

                  {/* Ratio badge */}
                  <div className="flex items-center gap-2">
                    <div className="text-right">
                      <span className="inline-block bg-orange-50 border border-orange-200/80 font-black text-xs font-mono text-[#FF7700] px-2.5 py-1 rounded-lg tracking-tight shadow-2xs">
                        {item.ratio}
                      </span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-[#FF7700] transition-colors" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}

        {filteredSections.length === 0 && (
          <div className="py-12 text-center text-slate-400 text-xs font-semibold">
            No game rates match &quot;{searchQuery}&quot;. Clear search to view all.
          </div>
        )}
      </div>

      {/* Bottom Footer Note */}
      <div className="mt-8 text-center text-[11px] text-slate-400 font-medium">
        All winning bets are calculated and credited automatically using these exact Supabase ratios.
      </div>
    </div>
  );
};
