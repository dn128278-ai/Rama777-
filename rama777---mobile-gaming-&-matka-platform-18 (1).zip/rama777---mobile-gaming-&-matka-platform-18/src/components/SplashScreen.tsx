import React from 'react';

interface SplashScreenProps {
  onFinish?: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = () => {
  return (
    <div
      className="w-full bg-white flex items-center justify-center select-none"
      style={{
        height: '100vh',
        maxHeight: '100vh',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      <div
        className="w-full max-w-md mx-auto bg-white text-slate-900 flex flex-col items-center justify-between p-8 text-center"
        style={{
          height: '100vh',
          maxHeight: '100vh',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        {/* Top spacer to balance layout */}
        <div className="w-full h-8" />

        {/* Center: Branded Orange RAMA777 Logo & Spinner */}
        <div className="flex flex-col items-center justify-center animate-in fade-in zoom-in duration-300">
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-[#E65100] via-[#FF7700] to-[#FFA000] p-1 shadow-xl shadow-orange-500/25 flex items-center justify-center mb-5">
            <div className="w-full h-full bg-white rounded-2xl flex flex-col items-center justify-center">
              <span className="text-3xl font-black tracking-tight text-[#FF7700]">
                RAMA
              </span>
              <span className="text-sm font-extrabold tracking-widest text-amber-500 -mt-1 font-mono">
                777
              </span>
            </div>
          </div>

          <h1 className="text-3xl font-black tracking-tight text-[#FF7700] mb-1">
            RAMA777
          </h1>
          <p className="text-xs text-slate-500 font-medium tracking-wide mb-6">
            India&apos;s Premier Mobile Matka &amp; Gaming Platform
          </p>

          <div className="w-7 h-7 border-3 border-[#FF7700] border-t-transparent rounded-full animate-spin" />
        </div>

        {/* Bottom Footer: App Version & Trust Metric */}
        <div className="w-full pb-4 flex flex-col items-center gap-1">
          <div className="flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs font-bold text-slate-800">
              Trusted by 1 Million Users.
            </span>
          </div>
          <span className="text-[11px] font-mono text-slate-400 font-semibold tracking-wider">
            App Version: 1.0.2
          </span>
        </div>
      </div>
    </div>
  );
};
