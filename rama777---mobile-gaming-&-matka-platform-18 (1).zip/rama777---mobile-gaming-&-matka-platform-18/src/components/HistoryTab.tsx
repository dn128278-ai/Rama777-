import React, { useState, useMemo } from 'react';
import {
  Clock,
  FileCheck2,
  ChevronRight,
  ArrowLeft,
  Trophy,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  TrendingUp,
  Sparkles,
} from 'lucide-react';
import { GameBid, StarlineResult, MarketItem } from '../types';
import { getGameMultiplier } from '../services/gameRatesService';
import { INITIAL_MARKETS } from '../data/initialData';

interface HistoryTabProps {
  bids: GameBid[];
  starlineResults: StarlineResult[];
  markets?: MarketItem[];
}

export const HistoryTab: React.FC<HistoryTabProps> = ({
  bids,
  starlineResults,
  markets = INITIAL_MARKETS,
}) => {
  const [activeSubView, setActiveSubView] = useState<string | null>(null);
  const [selectedDate] = useState<string>(
    new Date().toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' })
  );
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'WON' | 'PLACED' | 'LOST'>('ALL');
  const [selectedMarketFilter, setSelectedMarketFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const historyOptions = [
    { id: 'game_bid_history', title: 'Game Bid History', type: 'clock', subtitle: 'View all placed Matka bids & winning payouts' },
    { id: 'starline_bid_history', title: 'Starline Bid History', type: 'clock', subtitle: 'Hourly starline game bids' },
    { id: 'jackpot_bid_history', title: 'Jackpot Bid History', type: 'clock', subtitle: 'Jackpot session bids' },
    { id: 'game_result_history', title: 'Game Result History', type: 'check', subtitle: 'Daily market open/close declared results' },
    { id: 'starline_result_history', title: 'Starline Result History', type: 'check', subtitle: 'Hourly starline winning numbers' },
    { id: 'jackpot_result_history', title: 'Jackpot Result History', type: 'check', subtitle: 'Bombay jackpot result charts' },
  ];

  // Distinct list of market names present in current bids for filtering
  const availableMarkets = useMemo(() => {
    const set = new Set<string>();
    bids.forEach((b) => {
      const name = (b.marketName || '').trim();
      if (name && name !== 'Matka Market') set.add(name);
    });
    return Array.from(set);
  }, [bids]);

  // Filtered bids according to active subview and user filters
  const filteredBids = useMemo(() => {
    return bids.filter((b) => {
      const mName = (b.marketName || '').toLowerCase();

      // Subview category filtering
      if (activeSubView === 'starline_bid_history') {
        if (!mName.includes('starline')) return false;
      } else if (activeSubView === 'jackpot_bid_history') {
        if (!mName.includes('jackpot')) return false;
      } else if (activeSubView === 'game_bid_history') {
        if (mName.includes('starline') || mName.includes('jackpot')) return false;
      }

      // Status filtering
      const isWon = String(b.status).toUpperCase() === 'WON' || String(b.status).toUpperCase() === 'WIN';
      const isLost = String(b.status).toUpperCase() === 'LOST';
      const isPlaced = !isWon && !isLost;

      if (statusFilter === 'WON' && !isWon) return false;
      if (statusFilter === 'PLACED' && !isPlaced) return false;
      if (statusFilter === 'LOST' && !isLost) return false;

      // Market filtering
      if (selectedMarketFilter !== 'ALL' && b.marketName !== selectedMarketFilter) {
        return false;
      }

      // Search query filtering
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchMarket = (b.marketName || '').toLowerCase().includes(query);
        const matchGame = (b.gameType || '').toLowerCase().includes(query);
        const matchDigits = String(b.digitOrPana || '').includes(query);
        if (!matchMarket && !matchGame && !matchDigits) return false;
      }

      return true;
    });
  }, [bids, activeSubView, statusFilter, selectedMarketFilter, searchQuery]);

  // Aggregate statistics for the filtered bids
  const stats = useMemo(() => {
    let totalPoints = 0;
    let totalWinnings = 0;
    let winsCount = 0;

    filteredBids.forEach((b) => {
      totalPoints += Number(b.points) || 0;
      const isWon = String(b.status).toUpperCase() === 'WON' || String(b.status).toUpperCase() === 'WIN';
      if (isWon) {
        winsCount++;
        const mult = getGameMultiplier(b.gameType);
        const payout = Number(b.winAmount) || (Number(b.points) || 0) * mult;
        totalWinnings += payout;
      }
    });

    return { totalPoints, totalWinnings, winsCount, count: filteredBids.length };
  }, [filteredBids]);

  return (
    <div className="pb-10 pt-2 px-3 sm:px-4 transition-colors bg-white min-h-[500px]">
      {!activeSubView ? (
        /* Root Menu List */
        <div className="space-y-3">
          <div className="flex items-center justify-between pb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Activity & Records
            </span>
            <span className="text-[11px] font-semibold text-slate-500 bg-slate-100 px-2.5 py-0.5 rounded-full">
              Today: {selectedDate}
            </span>
          </div>

          {historyOptions.map((opt) => (
            <button
              key={opt.id}
              onClick={() => {
                setActiveSubView(opt.id);
                setStatusFilter('ALL');
                setSelectedMarketFilter('ALL');
                setSearchQuery('');
              }}
              className="w-full bg-white rounded-2xl p-3.5 border border-slate-200 flex items-center justify-between shadow-xs hover:border-[#FF7700] hover:bg-orange-50/20 active:scale-[0.99] transition-all cursor-pointer text-left group"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs shrink-0 group-hover:scale-105 transition-transform">
                  {opt.type === 'clock' ? (
                    <Clock className="w-5 h-5" />
                  ) : (
                    <FileCheck2 className="w-5 h-5" />
                  )}
                </div>
                <div>
                  <h3 className="font-bold text-slate-800 text-sm group-hover:text-[#FF7700] transition-colors">
                    {opt.title}
                  </h3>
                  <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                    {opt.subtitle}
                  </p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-[#FF7700] group-hover:translate-x-0.5 transition-all shrink-0" />
            </button>
          ))}
        </div>
      ) : activeSubView === 'game_result_history' ? (
        /* Game Result History Subview */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setActiveSubView(null)}
                className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div>
                <h2 className="text-base font-extrabold text-[#FF7700]">
                  Game Result History
                </h2>
                <p className="text-[11px] text-slate-500">Live & Declared Market Results</p>
              </div>
            </div>
            <div className="border border-[#FF7700] text-[#FF7700] bg-orange-50 px-3 py-1 rounded-full text-xs font-bold font-mono">
              {selectedDate}
            </div>
          </div>

          <div className="space-y-2.5">
            {markets.map((m) => {
              const hasOpen = m.openPana && m.openPana !== '***';
              const hasClose = m.closePana && m.closePana !== '***';
              const isDeclared = hasOpen && hasClose;

              return (
                <div
                  key={m.id}
                  className="bg-white rounded-2xl p-4 border border-slate-200 flex items-center justify-between shadow-xs hover:border-slate-300 transition-all"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                      <h4 className="font-extrabold text-sm text-slate-900 tracking-wide">
                        {m.name}
                      </h4>
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono">
                      Open: {m.openTime} · Close: {m.closeTime}
                    </div>
                    <div className="text-[10px] font-semibold text-slate-400">
                      Status: <span className="text-slate-700">{m.status}</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="font-black font-mono text-base tracking-wider text-slate-900 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl shadow-2xs">
                      {m.openPana || '***'} - {m.jodi || '**'} - {m.closePana || '***'}
                    </div>
                    <span
                      className={`inline-block mt-1 text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        isDeclared
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : hasOpen
                          ? 'bg-amber-50 text-amber-700 border border-amber-200'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {isDeclared ? 'Full Result' : hasOpen ? 'Open Declared' : 'Running'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : activeSubView === 'starline_result_history' || activeSubView === 'jackpot_result_history' ? (
        /* Starline & Jackpot Result History */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setActiveSubView(null)}
                className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div>
                <h2 className="text-base font-extrabold text-[#FF7700]">
                  {activeSubView === 'jackpot_result_history' ? 'Jackpot Result History' : 'Starline Result History'}
                </h2>
                <p className="text-[11px] text-slate-500">Hourly declared winning numbers</p>
              </div>
            </div>
            <div className="border border-[#FF7700] text-[#FF7700] bg-orange-50 px-3 py-1 rounded-full text-xs font-bold font-mono">
              {selectedDate}
            </div>
          </div>

          <div className="space-y-2.5">
            {starlineResults.map((sr, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl p-3.5 border border-slate-200 flex items-center justify-between shadow-xs hover:border-slate-300 transition-all"
              >
                <div>
                  <div className="font-extrabold text-sm text-slate-900">
                    {sr.time}
                  </div>
                  <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                    {sr.date || selectedDate}
                  </div>
                </div>

                <div className="w-28 py-2 rounded-xl bg-orange-50 text-center font-black font-mono text-sm text-[#FF7700] tracking-wider border border-orange-200 shadow-2xs">
                  {sr.result}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Game Bid History Subview (Matka, Starline, Jackpot) */
        <div className="space-y-4">
          {/* Header Bar */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setActiveSubView(null)}
                className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div>
                <h2 className="text-base font-extrabold text-[#FF7700]">
                  {historyOptions.find((o) => o.id === activeSubView)?.title}
                </h2>
                <p className="text-[11px] text-slate-500">
                  {stats.count} bids placed · {stats.winsCount} wins
                </p>
              </div>
            </div>
            <div className="border border-[#FF7700] text-[#FF7700] bg-orange-50 px-3 py-1 rounded-full text-xs font-bold font-mono">
              {selectedDate}
            </div>
          </div>

          {/* Quick Summary Cards */}
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-2.5 text-center">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                Total Bids
              </span>
              <span className="text-base font-black text-slate-900 font-mono">
                {stats.count}
              </span>
            </div>
            <div className="bg-orange-50/50 border border-orange-200 rounded-2xl p-2.5 text-center">
              <span className="text-[10px] font-bold text-[#FF7700] uppercase tracking-wider block">
                Staked
              </span>
              <span className="text-base font-black text-[#FF7700] font-mono">
                ₹{stats.totalPoints}
              </span>
            </div>
            <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-2.5 text-center">
              <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block">
                Total Won
              </span>
              <span className="text-base font-black text-emerald-700 font-mono">
                ₹{stats.totalWinnings}
              </span>
            </div>
          </div>

          {/* Search & Filter Controls */}
          <div className="space-y-2">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search market, game type, or digits..."
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-[#FF7700] focus:bg-white transition-all"
              />
            </div>

            {/* Status Tabs */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
              {(['ALL', 'WON', 'PLACED', 'LOST'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setStatusFilter(tab)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                    statusFilter === tab
                      ? 'bg-[#FF7700] text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {tab === 'ALL'
                    ? 'All Bids'
                    : tab === 'WON'
                    ? '🏆 Wins'
                    : tab === 'PLACED'
                    ? '⏳ Placed'
                    : '❌ Lost'}
                </button>
              ))}

              {availableMarkets.length > 1 && (
                <select
                  value={selectedMarketFilter}
                  onChange={(e) => setSelectedMarketFilter(e.target.value)}
                  className="px-2.5 py-1.5 rounded-xl text-xs font-bold bg-slate-100 text-slate-700 border border-slate-200 focus:outline-none focus:border-[#FF7700]"
                >
                  <option value="ALL">All Markets</option>
                  {availableMarkets.map((m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  ))}
                </select>
              )}
            </div>
          </div>

          {/* Bid Records List */}
          {filteredBids.length === 0 ? (
            <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center shadow-xs">
              <Clock className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-sm font-semibold text-slate-700">
                No matching bids found
              </p>
              <p className="text-xs text-slate-400 mt-1">
                {statusFilter !== 'ALL' || searchQuery
                  ? 'Try clearing the search or status filters.'
                  : 'Place a bid in Kalyan, Sridevi, or another market to see records here.'}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredBids.map((bid) => {
                const multiplier = getGameMultiplier(bid.gameType);
                const isWon =
                  String(bid.status).toUpperCase() === 'WON' ||
                  String(bid.status).toUpperCase() === 'WIN';
                const isLost = String(bid.status).toUpperCase() === 'LOST';
                const calculatedWin = Number(bid.winAmount) || (Number(bid.points) || 0) * multiplier;

                return (
                  <div
                    key={bid.id}
                    className={`bg-white rounded-2xl p-4 border transition-all shadow-xs ${
                      isWon
                        ? 'border-emerald-300 bg-emerald-50/20'
                        : isLost
                        ? 'border-slate-200 bg-white'
                        : 'border-orange-200 bg-orange-50/10'
                    }`}
                  >
                    {/* Header Row: Dynamic Market Name & Status Badge */}
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`w-2 h-2 rounded-full ${
                              isWon
                                ? 'bg-emerald-500'
                                : isLost
                                ? 'bg-slate-300'
                                : 'bg-[#FF7700]'
                            }`}
                          />
                          <h4 className="font-extrabold text-sm text-slate-900 tracking-wide uppercase">
                            {bid.marketName || 'Kalyan'}
                          </h4>
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-xs text-slate-600 font-semibold">
                            {bid.gameType}
                          </span>
                          <span className="text-[10px] text-slate-400">·</span>
                          <span className="text-xs text-slate-500 font-medium">
                            {bid.session || 'Open'} Session
                          </span>
                          <span className="text-[10px] font-bold text-[#FF7700] bg-orange-50 border border-orange-200 px-1.5 py-0.2 rounded-md">
                            1 ka {multiplier}
                          </span>
                        </div>
                      </div>

                      {/* Status Badge */}
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-black tracking-wide flex items-center gap-1 shrink-0 ${
                          isWon
                            ? 'bg-emerald-500 text-white shadow-xs'
                            : isLost
                            ? 'bg-rose-50 text-rose-700 border border-rose-300'
                            : 'bg-orange-50 text-[#FF7700] border border-orange-300'
                        }`}
                      >
                        {isWon ? (
                          <>
                            <Trophy className="w-3.5 h-3.5" />
                            WON · ₹{calculatedWin}
                          </>
                        ) : isLost ? (
                          <>
                            <XCircle className="w-3 h-3" />
                            LOST
                          </>
                        ) : (
                          <>
                            <Clock className="w-3 h-3" />
                            PLACED
                          </>
                        )}
                      </span>
                    </div>

                    {/* Middle Row: Digit, Points, and Winning Details */}
                    <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="text-slate-500">Number / Pana:</span>
                        <span className="px-2 py-0.5 bg-slate-100 rounded-lg font-mono font-black text-slate-900 text-sm tracking-wider border border-slate-200">
                          {bid.digitOrPana}
                        </span>
                      </div>

                      <div className="text-right">
                        <div className="text-slate-500 text-[11px]">Points:</div>
                        <div className="font-black text-[#FF7700] font-mono text-base">
                          ₹{bid.points}
                        </div>
                      </div>
                    </div>

                    {/* If won, display prominent payout celebration bar */}
                    {isWon && (
                      <div className="mt-2.5 p-2 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-1.5 text-emerald-800 font-bold">
                          <Sparkles className="w-4 h-4 text-emerald-600" />
                          <span>Winning Payout Credited:</span>
                        </div>
                        <span className="font-black font-mono text-emerald-700 text-sm">
                          +₹{calculatedWin}
                        </span>
                      </div>
                    )}

                    {/* Bottom Row: Timestamp & Reference */}
                    <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                      <span>{bid.date || 'Recent'}</span>
                      <span>ID: #{bid.id ? String(bid.id).slice(-8) : '777'}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
