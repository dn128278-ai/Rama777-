import React, { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Transaction } from '../types';

interface PassbookTabProps {
  transactions: Transaction[];
}

export const PassbookTab: React.FC<PassbookTabProps> = ({ transactions }) => {
  const [currentPage, setCurrentPage] = useState<number>(1);
  const itemsPerPage = 5;

  const totalPages = Math.ceil(transactions.length / itemsPerPage) || 1;
  const currentItems = transactions.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <div className="pb-6 pt-2 px-4 space-y-3 transition-colors bg-white min-h-full">
      {/* Table Header Strip (Orange gradient matching brand) */}
      <div className="bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white rounded-2xl px-4 py-3 flex items-center justify-between text-xs font-bold shadow-xs">
        <span className="w-2/5 text-left">Description</span>
        <span className="w-2/5 text-center">Transaction Amount</span>
        <span className="w-1/5 text-right">Balance</span>
      </div>

      {/* Transaction Cards */}
      <div className="space-y-3">
        {transactions.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center shadow-xs">
            <p className="text-sm font-semibold text-slate-800">
              No passbook transactions found
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Add funds or place bids to see your account passbook entries here.
            </p>
          </div>
        ) : (
          currentItems.map((tx) => {
            const isCredit = tx.type === 'credit';
            const isFailed = tx.status === 'FAILED';

            return (
              <div
                key={tx.id}
                className="bg-white rounded-3xl p-4 border border-slate-200 shadow-xs space-y-2.5"
              >
                {/* Top Row: Description Title, Amount, Balance */}
                <div className="flex items-start justify-between gap-2">
                  <div className="w-3/5">
                    <h4 className="font-extrabold text-xs text-slate-900 leading-snug break-words">
                      {tx.title}
                    </h4>
                    <p className="text-[11px] text-slate-500 font-mono mt-0.5 break-all">
                      {tx.referenceId}
                    </p>
                  </div>

                  <div className="w-1/5 text-center">
                    <span
                      className={`font-mono font-extrabold text-sm ${
                        isFailed
                          ? 'text-rose-600'
                          : isCredit
                          ? 'text-emerald-600'
                          : 'text-slate-900'
                      }`}
                    >
                      {isCredit ? '+' : '-'}₹{tx.amount}
                    </span>
                  </div>

                  <div className="w-1/5 text-right">
                    <span className="font-mono font-bold text-sm text-[#FF7700]">
                      ₹{tx.currentBalance}
                    </span>
                  </div>
                </div>

                {/* Bottom Row: Timestamp and Previous Balance */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                  <span className="font-mono">{tx.date}</span>
                  <span className="font-medium">
                    Previous Balance :{' '}
                    <strong className="text-slate-700 font-mono">
                      ₹{tx.previousBalance}
                    </strong>
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Pagination Bar */}
      {transactions.length > itemsPerPage && (
        <div className="pt-3 flex items-center justify-center gap-2">
          <button
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="h-10 px-5 rounded-full bg-slate-100 border border-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1 disabled:opacity-40 cursor-pointer active:scale-95 transition-all shadow-2xs"
          >
            <ChevronLeft className="w-4 h-4 text-[#FF7700]" />
            <span>Previous</span>
          </button>

          <div className="w-9 h-9 rounded-full bg-[#FF7700] text-white flex items-center justify-center font-bold text-xs shadow-xs">
            {currentPage}
          </div>

          <button
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="h-10 px-5 rounded-full bg-slate-100 border border-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1 disabled:opacity-40 cursor-pointer active:scale-95 transition-all shadow-2xs"
          >
            <span>Next</span>
            <ChevronRight className="w-4 h-4 text-[#FF7700]" />
          </button>
        </div>
      )}
    </div>
  );
};
