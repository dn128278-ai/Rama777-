/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * MpinScreen alias pointing to LoginScreen for RAMA777
 */

export { LoginScreen as MpinScreen, LoginScreen } from './LoginScreen';
export default './LoginScreen';
