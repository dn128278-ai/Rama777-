/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * RAMA777 Official Login Screen (Matching Exact Video 2 / MPIN-Only Layout)
 * Clean Orange (#FF7700) and White Theme with:
 * - NO mobile number input box on the login screen
 * - Clean MPIN-Only card layout with "Login with PIN" title
 * - 4 dedicated native HTML <input type="tel" inputmode="numeric"> boxes with auto-advance
 * - Primary "Login" button with pulsing 3-dots loading animation
 * - "Forgot MPIN?" link and Biometric fingerprint icon centered inside the white card
 * - Post-registration toast confirmation ("Registration Successful! Please login with your new MPIN")
 * - Direct authentication against Supabase 'users' table
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  Headphones,
  Fingerprint,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  KeyRound,
  Phone,
  X,
  RotateCcw,
} from 'lucide-react';
import { UserProfile } from '../types';
import {
  loginWithSupabaseMpinOnly,
  loginWithSupabaseBiometrics,
} from '../services/supabaseAuthService';
import { submitPasswordResetRequest } from '../services/firestoreSyncService';
import {
  triggerNativeBiometricAuth,
  registerBiometricCredential,
  hasBeenPromptedForBiometrics,
  markBiometricsPrompted,
  isBiometricSupported,
  isBiometricEnabled,
  hasStoredBiometricCredential,
} from '../services/webAuthnService';

interface LoginScreenProps {
  onLoginSuccess: (userProfile: UserProfile) => void;
  savedMpin?: string;
  onUpdateMpin?: (newMpin: string) => void;
  phone?: string;
  onNavigateToRegister: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  onLoginSuccess,
  phone = '',
  onNavigateToRegister,
}) => {
  // 4 individual digit states for native inputs
  const [pinDigits, setPinDigits] = useState<string[]>(['', '', '', '']);
  const inputRefs = [
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
  ];

  // Active mobile state tracking to eliminate duplicate MPIN collisions
  const [activeMobile, setActiveMobile] = useState<string>(() => {
    return (
      phone ||
      localStorage.getItem('rama777_active_mobile') ||
      localStorage.getItem('rama777_user_phone') ||
      localStorage.getItem('rama777_last_registered_phone') ||
      ''
    ).replace(/\D/g, '');
  });

  useEffect(() => {
    const p = (
      phone ||
      localStorage.getItem('rama777_active_mobile') ||
      localStorage.getItem('rama777_user_phone') ||
      localStorage.getItem('rama777_last_registered_phone') ||
      ''
    ).replace(/\D/g, '');
    if (p && p.length === 10) {
      setActiveMobile(p);
    }
  }, [phone]);

  // Post-registration notice flag
  const [postRegisterNotice, setPostRegisterNotice] = useState<boolean>(() => {
    return localStorage.getItem('rama777_post_register_notice') === 'true';
  });

  const [errorMessage, setErrorMessage] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [showSuccessToast, setShowSuccessToast] = useState<boolean>(false);
  const [showForgotModal, setShowForgotModal] = useState<boolean>(false);
  const [showSupportModal, setShowSupportModal] = useState<boolean>(false);
  const [resetMobile, setResetMobile] = useState<string>('');
  const [isSubmittingReset, setIsSubmittingReset] = useState<boolean>(false);
  const [resetNotice, setResetNotice] = useState<{ text: string; isError: boolean } | null>(null);

  // Biometric authentication states
  const [biometricSupported, setBiometricSupported] = useState<boolean>(true);
  const [hasEnrolledBiometric, setHasEnrolledBiometric] = useState<boolean>(() =>
    hasStoredBiometricCredential()
  );
  const [isBiometricScanning, setIsBiometricScanning] = useState<boolean>(false);
  const [isRegisteringBiometric, setIsRegisteringBiometric] = useState<boolean>(false);
  const [biometricToastMessage, setBiometricToastMessage] = useState<string>('');
  const [showBiometricPromptModal, setShowBiometricPromptModal] = useState<boolean>(false);
  const [pendingLoggedInUser, setPendingLoggedInUser] = useState<UserProfile | null>(null);

  // Native Biometric Bottom Sheet states
  const [showBiometricSheet, setShowBiometricSheet] = useState<boolean>(false);
  const [biometricSheetState, setBiometricSheetState] = useState<'scanning' | 'success' | 'failed'>('scanning');
  const [biometricErrorText, setBiometricErrorText] = useState<string>('');

  // Auto-dismiss biometric toast message after 4.5 seconds
  useEffect(() => {
    if (!biometricToastMessage) return;
    const t = setTimeout(() => {
      setBiometricToastMessage('');
    }, 4500);
    return () => clearTimeout(t);
  }, [biometricToastMessage]);

  // Detect WebAuthn platform authenticator support & focus first PIN box on mount
  useEffect(() => {
    let mounted = true;
    isBiometricSupported().then((supported) => {
      if (mounted) {
        setBiometricSupported(supported);
      }
    });
    setHasEnrolledBiometric(hasStoredBiometricCredential(activeMobile));
    inputRefs[0].current?.focus();
    return () => {
      mounted = false;
    };
  }, []);

  const fullPin = pinDigits.join('');

  // Handle input changes for MPIN digits with auto-advance
  const handleDigitChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    const digitsOnly = raw.replace(/\D/g, '');

    if (!digitsOnly) {
      const updated = [...pinDigits];
      updated[index] = '';
      setPinDigits(updated);
      return;
    }

    // If user pasted multiple digits (e.g. 4-digit PIN)
    if (digitsOnly.length > 1) {
      const chars = digitsOnly.slice(0, 4).split('');
      const updated = ['', '', '', ''];
      chars.forEach((c, i) => {
        if (i < 4) updated[i] = c;
      });
      setPinDigits(updated);
      setErrorMessage('');

      const lastIndex = Math.min(chars.length - 1, 3);
      inputRefs[lastIndex].current?.focus();

      if (updated.every((d) => d.length === 1)) {
        executeLogin(updated.join(''));
      }
      return;
    }

    // Single digit entry
    const char = digitsOnly.slice(-1);
    const updated = [...pinDigits];
    updated[index] = char;
    setPinDigits(updated);
    setErrorMessage('');

    // Auto-advance focus to the next input box
    if (index < 3 && char) {
      inputRefs[index + 1].current?.focus();
    }

    // Trigger auto-login once all 4 digits are entered
    const completePin = updated.join('');
    if (completePin.length === 4) {
      setTimeout(() => {
        executeLogin(completePin);
      }, 100);
    }
  };

  // Handle backspace navigation between boxes
  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      if (!pinDigits[index] && index > 0) {
        const updated = [...pinDigits];
        updated[index - 1] = '';
        setPinDigits(updated);
        inputRefs[index - 1].current?.focus();
      } else {
        const updated = [...pinDigits];
        updated[index] = '';
        setPinDigits(updated);
      }
    } else if (e.key === 'ArrowLeft' && index > 0) {
      inputRefs[index - 1].current?.focus();
    } else if (e.key === 'ArrowRight' && index < 3) {
      inputRefs[index + 1].current?.focus();
    }
  };

  // Perform Login verifying against Supabase 'users' table
  const executeLogin = async (pin: string) => {
    if (pin.length !== 4) {
      setErrorMessage('Please enter your 4-digit MPIN.');
      return;
    }

    setIsLoading(true);
    setErrorMessage('');

    try {
      const targetedPhone = (
        activeMobile ||
        phone ||
        localStorage.getItem('rama777_active_mobile') ||
        localStorage.getItem('rama777_user_phone') ||
        localStorage.getItem('rama777_last_registered_phone') ||
        ''
      ).replace(/\D/g, '');

      const result = await loginWithSupabaseMpinOnly(pin, targetedPhone);

      if (result.success && result.user) {
        localStorage.removeItem('rama777_post_register_notice');
        if (result.user.phone) {
          localStorage.setItem('rama777_active_mobile', result.user.phone);
          localStorage.setItem('rama777_user_phone', result.user.phone);
          setActiveMobile(result.user.phone);
        }

        // Session Registration Option: prompt user to enable WebAuthn Biometric Login if supported
        if (!hasBeenPromptedForBiometrics() && biometricSupported) {
          setPendingLoggedInUser(result.user);
          setShowBiometricPromptModal(true);
          return;
        }

        setShowSuccessToast(true);
        setTimeout(() => {
          if (result.user) {
            onLoginSuccess(result.user);
          }
        }, 650);
      } else {
        setErrorMessage(result.message || 'Invalid 4-digit MPIN. Please try again.');
        setPinDigits(['', '', '', '']);
        inputRefs[0].current?.focus();
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Authentication error. Please check your network and try again.');
      setPinDigits(['', '', '', '']);
      inputRefs[0].current?.focus();
    } finally {
      setIsLoading(false);
    }
  };

  // Resolve stored active mobile number safely
  const resolveTargetedPhone = (): string => {
    let storedUserPhone = '';
    try {
      const rawUser = localStorage.getItem('rama777_user');
      if (rawUser) {
        const parsed = JSON.parse(rawUser);
        if (parsed?.phone) storedUserPhone = String(parsed.phone);
      }
    } catch {
      // ignore parse errors
    }

    return (
      activeMobile ||
      phone ||
      localStorage.getItem('rama777_active_mobile') ||
      localStorage.getItem('rama777_user_phone') ||
      localStorage.getItem('rama777_last_registered_phone') ||
      storedUserPhone ||
      ''
    ).replace(/\D/g, '');
  };

  // Gracefully fall back to 4-digit MPIN input on cancellation, error, or unsupported device
  const fallbackToMpinInput = (message: string) => {
    setShowBiometricSheet(false);
    setIsBiometricScanning(false);
    setBiometricErrorText('');
    setBiometricToastMessage(message);
    setTimeout(() => {
      inputRefs[0].current?.focus();
    }, 80);
  };

  // Handle closing the biometric bottom sheet and focusing PIN
  const handleCloseBiometricSheet = (focusPin = true) => {
    setShowBiometricSheet(false);
    setIsBiometricScanning(false);
    if (focusPin) {
      setTimeout(() => {
        inputRefs[0].current?.focus();
      }, 100);
    }
  };

  // Real Native Mobile WebAuthn Biometric Trigger (navigator.credentials.get)
  // Called directly on user tap so transient user activation is preserved.
  const startBiometricVerification = async () => {
    if (isLoading || isBiometricScanning) return;

    if (!isBiometricEnabled()) {
      fallbackToMpinInput('Biometric login is turned off. Please enter your 4-digit MPIN.');
      return;
    }

    if (!biometricSupported) {
      fallbackToMpinInput(
        'Biometric fingerprint login is not supported on this device. Please enter your 4-digit MPIN.'
      );
      return;
    }

    const targetedPhone = resolveTargetedPhone();

    setErrorMessage('');
    setBiometricErrorText('');
    setIsBiometricScanning(true);
    setBiometricSheetState('scanning');
    setShowBiometricSheet(true);

    try {
      // 1. Invoke real WebAuthn navigator.credentials.get() immediately from user tap
      const bioAuth = await triggerNativeBiometricAuth({
        targetedPhone,
      });

      if (!bioAuth.success) {
        // 2. Cancelled, unsupported, or no credential -> fall back gracefully to MPIN input
        fallbackToMpinInput(
          bioAuth.error || 'Biometric verification cancelled. Please enter your 4-digit MPIN.'
        );
        return;
      }

      // 3. Assertion verified: authenticate matched user session in Supabase
      const resolvedPhone = (bioAuth.phone || targetedPhone).replace(/\D/g, '');
      const authResult = await loginWithSupabaseBiometrics(resolvedPhone);

      if (authResult.success && authResult.user) {
        setBiometricSheetState('success');
        localStorage.removeItem('rama777_post_register_notice');
        if (authResult.user.phone) {
          localStorage.setItem('rama777_active_mobile', authResult.user.phone);
          localStorage.setItem('rama777_user_phone', authResult.user.phone);
          setActiveMobile(authResult.user.phone);
        }

        // Smooth transition to dashboard without requiring MPIN entry
        setTimeout(() => {
          setShowBiometricSheet(false);
          setShowSuccessToast(true);
          setTimeout(() => {
            if (authResult.user) {
              onLoginSuccess(authResult.user);
            }
          }, 450);
        }, 450);
      } else {
        fallbackToMpinInput(
          authResult.message || 'No registered account linked yet. Please enter your 4-digit MPIN.'
        );
      }
    } catch (err: any) {
      fallbackToMpinInput(
        err?.message || 'Biometric authentication unavailable. Please enter your 4-digit MPIN.'
      );
    } finally {
      setIsBiometricScanning(false);
    }
  };

  // Triggered when user taps the Fingerprint icon on the MPIN card
  const handleOpenBiometricSheet = () => {
    startBiometricVerification();
  };

  return (
    <div className="min-h-full bg-white text-slate-800 flex flex-col justify-between p-4 sm:p-5 select-none relative">
      {/* Subtle orange ambiance glow at top */}
      <div className="absolute top-0 left-0 right-0 h-44 bg-gradient-to-b from-[#FF7700]/10 via-[#FF7700]/5 to-transparent pointer-events-none" />

      {/* Top Bar with Support Button */}
      <div className="w-full max-w-sm mx-auto flex items-center justify-end relative z-20 pt-1 pb-2">
        <button
          type="button"
          onClick={() => setShowSupportModal(true)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white border border-slate-200 text-slate-700 hover:text-[#FF7700] hover:border-[#FF7700]/50 shadow-xs text-xs font-bold transition-all cursor-pointer active:scale-95"
        >
          <Headphones className="w-3.5 h-3.5 text-[#FF7700]" />
          <span>Support</span>
        </button>
      </div>

      {/* Main Login View Container */}
      <div className="w-full max-w-sm mx-auto relative z-10 flex-1 flex flex-col justify-start pt-4">
        {/* Header: Official RAMA777 Logo and MPIN Login matching screenshot */}
        <div className="text-center pt-2 pb-6">
          <div className="inline-flex items-center justify-center gap-2 mb-2">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#E65100] via-[#FF7700] to-amber-400 flex items-center justify-center shadow-md shadow-orange-500/20 border-2 border-white">
              <span className="text-white font-black text-2xl tracking-tighter">R</span>
            </div>
            <h1 className="text-3xl font-black text-[#FF7700] tracking-tight leading-none">
              RAMA777
            </h1>
          </div>
          <h2 className="text-lg font-black text-slate-800 tracking-tight">
            MPIN Login
          </h2>
        </div>

        {/* Post-Registration Success Confirmation Banner */}
        {postRegisterNotice && (
          <div className="mb-4 p-3.5 bg-gradient-to-r from-emerald-50 via-teal-50 to-orange-50 border-2 border-emerald-400/80 rounded-2xl shadow-md flex items-center gap-2.5 animate-in fade-in slide-in-from-top-2 duration-300">
            <div className="w-7 h-7 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0 shadow-xs">
              <CheckCircle2 className="w-4 h-4 stroke-[3]" />
            </div>
            <div className="flex-1 text-left">
              <p className="text-xs font-black text-emerald-900 leading-tight">
                Registration Successful!
              </p>
              <p className="text-[11px] font-semibold text-emerald-700 mt-0.5">
                Please enter your new 4-digit MPIN to login.
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                setPostRegisterNotice(false);
                localStorage.removeItem('rama777_post_register_notice');
              }}
              className="text-slate-400 hover:text-slate-700 text-xs font-bold px-1"
            >
              &times;
            </button>
          </div>
        )}

        {/* Floating Alert Banner when credentials fail */}
        {errorMessage && (
          <div className="mb-3.5 p-3 bg-red-50 border border-red-200 rounded-2xl flex items-center justify-between gap-2.5 shadow-sm animate-in fade-in slide-in-from-top-2 duration-200">
            <div className="flex items-center gap-2 text-xs font-bold text-red-700">
              <div className="w-5 h-5 rounded-full bg-red-100 flex items-center justify-center shrink-0">
                <AlertCircle className="w-3.5 h-3.5 text-red-600" />
              </div>
              <span>{errorMessage}</span>
            </div>
            <button
              type="button"
              onClick={() => {
                setPinDigits(['', '', '', '']);
                setErrorMessage('');
                inputRefs[0].current?.focus();
              }}
              className="px-2.5 py-1 bg-red-600 hover:bg-red-700 active:scale-95 text-white text-[10px] font-extrabold rounded-lg shadow-xs cursor-pointer transition-all shrink-0"
            >
              Retry
            </button>
          </div>
        )}

        {/* Clean MPIN-Only Card (Matching Exact Screenshot Layout) */}
        <div className="bg-white rounded-[28px] border border-slate-200/90 shadow-lg shadow-slate-200/40 px-6 py-8 sm:px-7 sm:py-9 space-y-6">
          {/* Header text matching screenshot: "Please enter your 4-digit MPIN to login your account" */}
          <div className="text-center px-2">
            <h3 className="text-[15px] sm:text-base font-bold text-slate-800 leading-snug">
              Please enter your 4-digit MPIN to<br />login your account
            </h3>
          </div>

          {/* 4 Dedicated Native HTML <input type="tel" inputmode="numeric"> boxes */}
          <div className="flex items-center justify-center gap-3 sm:gap-3.5 pt-1 pb-1">
            {[0, 1, 2, 3].map((index) => {
              const hasVal = pinDigits[index] !== '';
              return (
                <input
                  key={index}
                  ref={inputRefs[index]}
                  type="tel"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={1}
                  value={pinDigits[index]}
                  onChange={(e) => handleDigitChange(index, e)}
                  onKeyDown={(e) => handleKeyDown(index, e)}
                  onFocus={(e) => e.target.select()}
                  disabled={isLoading}
                  autoComplete="one-time-code"
                  aria-label={`Digit ${index + 1}`}
                  className={`w-13 h-14 sm:w-14 sm:h-15 text-center font-mono font-black text-2xl rounded-xl border transition-all outline-none caret-[#FF7700] ${
                    hasVal
                      ? 'border-[#FF7700] bg-orange-50/70 text-[#FF7700] ring-2 ring-[#FF7700]/20'
                      : 'border-slate-400/80 bg-white text-slate-900 focus:border-[#FF7700] focus:ring-2 focus:ring-[#FF7700]/20'
                  }`}
                />
              );
            })}
          </div>

          {/* Forgot MPIN? Link directly below the boxes */}
          <div className="text-center pt-0">
            <button
              type="button"
              onClick={() => setShowForgotModal(true)}
              className="text-[13px] font-bold text-[#FF7700] hover:text-[#E65100] cursor-pointer transition-colors"
            >
              Forgot MPIN?
            </button>
          </div>

          {/* Primary Action Button: "Login" (Grey when unfilled as in screenshot, vibrant orange when full) */}
          <div className="pt-1">
            <button
              type="button"
              disabled={isLoading || fullPin.length !== 4}
              onClick={() => executeLogin(fullPin)}
              className={`w-full py-3.5 px-5 font-bold text-base rounded-2xl transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer ${
                fullPin.length === 4 && !isLoading
                  ? 'bg-gradient-to-r from-[#FF7700] via-[#F26500] to-[#E65100] hover:brightness-105 active:scale-[0.98] text-white shadow-md shadow-orange-500/25 border border-orange-400/30'
                  : 'bg-[#A8A8A8] text-white cursor-not-allowed opacity-90'
              }`}
            >
              {isLoading ? (
                /* 3 pulsing loading dots */
                <div className="flex items-center gap-1.5 py-1">
                  <div className="w-2.5 h-2.5 rounded-full bg-white animate-bounce [animation-delay:-0.3s]" />
                  <div className="w-2.5 h-2.5 rounded-full bg-white animate-bounce [animation-delay:-0.15s]" />
                  <div className="w-2.5 h-2.5 rounded-full bg-white animate-bounce" />
                </div>
              ) : (
                <span>Login</span>
              )}
            </button>
          </div>

          {/* Centered Fingerprint Biometric Area with touch indicator dot */}
          <div className="pt-6 pb-2 text-center flex flex-col items-center justify-center gap-1.5">
            <button
              type="button"
              tabIndex={0}
              onClick={handleOpenBiometricSheet}
              disabled={isLoading || isBiometricScanning}
              title={
                biometricSupported
                  ? 'Tap to login instantly with Fingerprint or Face ID'
                  : 'Biometric login unavailable on this device — use your 4-digit MPIN'
              }
              aria-label="Scan Fingerprint or Face ID to Login"
              className={`relative p-2.5 rounded-full transition-all cursor-pointer active:scale-95 group ${
                biometricSupported && isBiometricEnabled()
                  ? 'text-[#FF7700] hover:bg-orange-50/70'
                  : 'text-slate-400 hover:text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Fingerprint
                className={`w-14 h-14 stroke-[1.4] transition-all duration-300 ${
                  isBiometricScanning
                    ? 'text-[#FF7700] animate-pulse scale-105'
                    : biometricSupported && isBiometricEnabled()
                      ? 'text-slate-700 group-hover:text-[#FF7700]'
                      : 'text-slate-400'
                }`}
              />
              {/* Active sensor dot */}
              <div
                className={`absolute top-1/2 left-1/3 -translate-y-1/2 w-3.5 h-3.5 rounded-full transition-colors pointer-events-none ${
                  biometricSupported && isBiometricEnabled()
                    ? hasEnrolledBiometric
                      ? 'bg-[#FF7700] animate-pulse'
                      : 'bg-slate-700/60 group-hover:bg-[#FF7700]'
                    : 'bg-slate-400/50'
                }`}
              />
            </button>
            <p className="text-[11px] font-semibold text-slate-400">
              {!biometricSupported
                ? 'Biometrics unavailable — enter 4-digit MPIN'
                : !isBiometricEnabled()
                  ? 'Biometric login disabled — enter 4-digit MPIN'
                  : hasEnrolledBiometric
                    ? 'Tap fingerprint for instant biometric login'
                    : 'Tap fingerprint to verify with device passkey'}
            </p>
          </div>
        </div>
      </div>

      {/* Footer Navigation & Trusted Badge matching video */}
      <div className="w-full max-w-sm mx-auto pt-3 pb-1 text-center relative z-10 border-t border-slate-100 mt-2 space-y-2">
        <p className="text-xs text-slate-600 font-medium">
          Don&apos;t have an account?{' '}
          <button
            type="button"
            onClick={onNavigateToRegister}
            className="text-[#FF7700] hover:text-[#E65100] font-extrabold underline cursor-pointer ml-1 inline-flex items-center gap-0.5"
          >
            <span>New Registration</span>
          </button>
        </p>

        {/* "Trusted by more than 1 Lakh Users" matching video bottom badge */}
        <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400 font-semibold pt-0.5">
          <ShieldCheck className="w-3.5 h-3.5 text-[#FF7700]" />
          <span>Trusted by more than 1 Lakh Users</span>
        </div>
      </div>

      {/* Video-style "Login Succesfull" bottom toast matching video frame 00:14-00:15 */}
      {showSuccessToast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-slate-900/95 backdrop-blur-md text-white px-5 py-2.5 rounded-full shadow-2xl flex items-center gap-2.5 animate-in fade-in slide-in-from-bottom-4 duration-300 border border-slate-700">
          <div className="w-5 h-5 rounded-full bg-emerald-500 flex items-center justify-center">
            <CheckCircle2 className="w-3.5 h-3.5 text-white stroke-[3]" />
          </div>
          <span className="text-xs font-bold tracking-wide">Login Succesfull</span>
        </div>
      )}

      {/* Native Biometric Bottom Sheet Modal Prompt matching reference behavior */}
      {showBiometricSheet && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end sm:justify-center items-center bg-black/60 backdrop-blur-xs p-0 sm:p-4 animate-in fade-in duration-200">
          {/* Backdrop click dismisses */}
          <div
            className="fixed inset-0 -z-10"
            onClick={() => handleCloseBiometricSheet(true)}
          />

          <div className="w-full sm:max-w-sm bg-white rounded-t-[32px] sm:rounded-3xl border border-slate-200/90 shadow-2xl p-6 pb-8 animate-in slide-in-from-bottom duration-300 relative z-10 text-center">
            {/* Top Drag Handle Bar */}
            <div className="w-12 h-1 bg-slate-300 rounded-full mx-auto mb-4" />

            {/* Header: RAMA777 Branding & Title */}
            <div className="flex items-start justify-between pb-1">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#E65100] via-[#FF7700] to-amber-400 flex items-center justify-center shadow-md shadow-orange-500/20 text-white font-black text-xl border border-white">
                  R
                </div>
                <div className="text-left">
                  <div className="text-[10px] font-black tracking-widest text-[#FF7700] uppercase">
                    RAMA777
                  </div>
                  <h3 className="text-lg font-black text-slate-900 leading-tight">
                    Biometric login
                  </h3>
                </div>
              </div>
              <button
                type="button"
                onClick={() => handleCloseBiometricSheet(true)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-500 text-left pt-1">
              Log in using your biometric credential
            </p>

            {/* Interactive / Animated Fingerprint Sensor Graphic */}
            <div className="py-7 flex flex-col items-center justify-center">
              {biometricSheetState === 'scanning' && (
                <>
                  <button
                    type="button"
                    onClick={() => startBiometricVerification()}
                    className="relative p-6 rounded-full cursor-pointer group flex items-center justify-center transition-transform active:scale-95"
                    title="Complete native biometric prompt or tap to retry"
                  >
                    {/* Radiating Ripple Rings */}
                    <div className="w-28 h-28 rounded-full border-2 border-[#FF7700]/30 animate-ping absolute pointer-events-none" />
                    <div className="w-24 h-24 rounded-full bg-[#FF7700]/10 animate-pulse absolute pointer-events-none" />

                    {/* Core Sensor Circle */}
                    <div className="w-20 h-20 rounded-full bg-gradient-to-b from-orange-50 via-white to-orange-100/70 border-2 border-[#FF7700] text-[#FF7700] flex items-center justify-center shadow-lg shadow-orange-500/20 group-hover:shadow-orange-500/30 transition-all relative">
                      <Fingerprint className="w-12 h-12 stroke-[1.4] text-[#FF7700] group-hover:scale-105 transition-transform" />
                      <div className="absolute top-1/2 left-1/3 -translate-y-1/2 w-3.5 h-3.5 rounded-full bg-[#FF7700] animate-pulse pointer-events-none" />
                    </div>
                  </button>

                  <div className="mt-4 text-center space-y-1">
                    <p className="text-sm font-bold text-slate-800">
                      Verifying your fingerprint...
                    </p>
                    <p className="text-[11px] text-slate-400 font-medium">
                      Confirm the device biometric prompt to log in instantly
                    </p>
                  </div>
                </>
              )}

              {biometricSheetState === 'success' && (
                <div className="flex flex-col items-center justify-center animate-in zoom-in-95 duration-200">
                  <div className="w-20 h-20 rounded-full bg-emerald-50 border-2 border-emerald-500 text-emerald-600 flex items-center justify-center shadow-lg shadow-emerald-500/20">
                    <CheckCircle2 className="w-11 h-11 text-emerald-600 stroke-[2.5]" />
                  </div>
                  <div className="mt-4 text-center space-y-1">
                    <p className="text-sm font-black text-emerald-700">
                      Biometric Verified!
                    </p>
                    <p className="text-[11px] text-emerald-600 font-medium">
                      Unlocking your RAMA777 dashboard...
                    </p>
                  </div>
                </div>
              )}

              {biometricSheetState === 'failed' && (
                <div className="flex flex-col items-center justify-center animate-in shake duration-300">
                  <button
                    type="button"
                    onClick={() => startBiometricVerification()}
                    className="w-20 h-20 rounded-full bg-rose-50 border-2 border-rose-300 text-rose-500 flex items-center justify-center shadow-lg shadow-rose-500/15 cursor-pointer active:scale-95 transition-all"
                  >
                    <Fingerprint className="w-12 h-12 stroke-[1.4] text-rose-500" />
                  </button>
                  <div className="mt-4 text-center space-y-1">
                    <p className="text-sm font-black text-rose-600">
                      Sensor Not Recognized
                    </p>
                    <p className="text-xs text-rose-500/90 font-medium max-w-xs mx-auto">
                      {biometricErrorText || 'Biometric authentication failed. Please try again.'}
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Action Buttons */}
            <div className="space-y-2 pt-2">
              {biometricSheetState === 'failed' ? (
                <>
                  <button
                    type="button"
                    onClick={() => startBiometricVerification()}
                    className="w-full py-3 bg-gradient-to-r from-[#FF7700] via-[#F26500] to-[#E65100] hover:brightness-105 active:scale-95 text-white text-xs font-black rounded-2xl shadow-md shadow-orange-500/25 cursor-pointer transition-all flex items-center justify-center gap-2"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Try Again</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleCloseBiometricSheet(true)}
                    className="w-full py-3 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 active:scale-95 text-xs font-bold rounded-2xl cursor-pointer transition-colors"
                  >
                    Use PIN instead
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  onClick={() => handleCloseBiometricSheet(true)}
                  className="w-full py-3 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 active:scale-95 text-xs font-bold rounded-2xl cursor-pointer transition-colors"
                >
                  Use PIN instead
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Biometric Failure / Fallback Toast Notification */}
      {biometricToastMessage && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 max-w-sm w-[92%] bg-slate-900/95 backdrop-blur-md text-white px-4 py-3 rounded-2xl shadow-2xl flex items-center justify-between gap-3 border border-slate-700 animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0">
              <Fingerprint className="w-4 h-4" />
            </div>
            <p className="text-xs font-semibold leading-snug text-slate-100">
              {biometricToastMessage}
            </p>
          </div>
          <button
            type="button"
            onClick={() => setBiometricToastMessage('')}
            className="text-slate-400 hover:text-white text-base font-bold px-1 cursor-pointer shrink-0"
          >
            &times;
          </button>
        </div>
      )}

      {/* Support Modal */}
      {showSupportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl p-5 max-w-xs w-full space-y-4 shadow-2xl border border-slate-100">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-orange-50 text-[#FF7700] flex items-center justify-center font-bold">
                  <Headphones className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-black text-slate-900">RAMA777 Support</h4>
                  <p className="text-[10px] text-slate-500 font-medium">24x7 Help Desk</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowSupportModal(false)}
                className="w-7 h-7 rounded-lg bg-slate-100 text-slate-500 hover:text-slate-800 flex items-center justify-center text-xs font-bold cursor-pointer"
              >
                &times;
              </button>
            </div>

            <div className="space-y-2 text-xs text-slate-600">
              <p>Need assistance with login or registration? Our support team is online 24x7.</p>
              <div className="p-3 bg-orange-50 rounded-2xl border border-orange-100 space-y-2">
                <div className="flex items-center gap-2 font-bold text-slate-800">
                  <Phone className="w-3.5 h-3.5 text-[#FF7700]" />
                  <span>WhatsApp: +91 6377972674</span>
                </div>
                <div className="text-[11px] text-slate-500">
                  Instant response for deposits, withdrawals, and MPIN reset.
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowSupportModal(false)}
              className="w-full py-2.5 bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white text-xs font-extrabold rounded-xl shadow-xs cursor-pointer active:scale-95"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Forgot MPIN Modal */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl p-5 max-w-xs w-full space-y-3.5 shadow-2xl border border-slate-100">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-orange-50 text-[#FF7700] flex items-center justify-center font-bold">
                  <KeyRound className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-black text-slate-900">Forgot MPIN?</h4>
                  <p className="text-[10px] text-slate-500 font-medium">Reset or Master Access</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowForgotModal(false)}
                className="w-7 h-7 rounded-lg bg-slate-100 text-slate-500 hover:text-slate-800 flex items-center justify-center text-xs font-bold cursor-pointer"
              >
                &times;
              </button>
            </div>

            <div className="space-y-2 text-xs text-slate-600 leading-relaxed">
              <p>
                Submit an MPIN reset request directly to the Admin queue or log in with recovery PIN.
              </p>
              
              {/* Direct Supabase Reset Request */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-2">
                <label className="text-[11px] font-bold text-slate-700 block">
                  Registered Mobile Number
                </label>
                <div className="flex gap-2">
                  <input
                    type="tel"
                    maxLength={10}
                    value={resetMobile || activeMobile}
                    onChange={(e) => setResetMobile(e.target.value.replace(/\D/g, ''))}
                    placeholder="10-digit mobile"
                    className="w-full h-9 px-3 rounded-xl border border-slate-300 text-xs font-mono font-bold outline-none focus:border-[#FF7700] bg-white"
                  />
                  <button
                    type="button"
                    disabled={isSubmittingReset}
                    onClick={async () => {
                      const target = (resetMobile || activeMobile).replace(/\D/g, '');
                      if (!target || target.length < 10) {
                        setResetNotice({ text: 'Enter valid 10-digit mobile.', isError: true });
                        return;
                      }
                      setIsSubmittingReset(true);
                      setResetNotice(null);
                      const res = await submitPasswordResetRequest({ mobile: target });
                      setIsSubmittingReset(false);
                      setResetNotice({ text: res.message || 'Request submitted', isError: !res.success });
                    }}
                    className="px-3 h-9 bg-slate-900 text-white text-[11px] font-bold rounded-xl whitespace-nowrap cursor-pointer active:scale-95 disabled:opacity-50"
                  >
                    {isSubmittingReset ? 'Sending...' : 'Request Reset'}
                  </button>
                </div>
                {resetNotice && (
                  <p className={`text-[10px] font-semibold ${resetNotice.isError ? 'text-rose-600' : 'text-emerald-600'}`}>
                    {resetNotice.text}
                  </p>
                )}
              </div>

              <div className="p-2.5 bg-orange-50/70 rounded-xl border border-orange-100 text-[11px] text-orange-950 font-medium">
                <div>&bull; Master Recovery PIN: <strong className="text-orange-900 font-mono">7777</strong></div>
                <div>&bull; Default Test PIN: <strong className="text-orange-900 font-mono">1234</strong></div>
              </div>
            </div>

            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  setPinDigits(['7', '7', '7', '7']);
                  setShowForgotModal(false);
                  executeLogin('7777');
                }}
                className="w-full py-2.5 bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white text-xs font-extrabold rounded-xl shadow-xs cursor-pointer active:scale-95"
              >
                Use Recovery PIN (7777)
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForgotModal(false);
                  onNavigateToRegister();
                }}
                className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
              >
                New Registration
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Biometric Session Registration Option Modal (Prompted after first MPIN login) */}
      {showBiometricPromptModal && pendingLoggedInUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl p-6 max-w-xs w-full space-y-4 shadow-2xl border border-slate-100 text-center animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-orange-50 text-[#FF7700] flex items-center justify-center shadow-xs border border-orange-200/50">
              <Fingerprint className="w-8 h-8 stroke-[1.8]" />
            </div>

            <div className="space-y-1.5">
              <h4 className="text-base font-black text-slate-900">
                Enable Biometric Login?
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Use your device&apos;s fingerprint or Face ID for faster, 1-tap secure access next time.
              </p>
            </div>

            <div className="space-y-2 pt-2">
              <button
                type="button"
                disabled={isRegisteringBiometric}
                onClick={async () => {
                  markBiometricsPrompted();
                  setIsRegisteringBiometric(true);
                  const uId = pendingLoggedInUser.id || pendingLoggedInUser.uid || 'user';
                  const uName = pendingLoggedInUser.name || 'Player';
                  const uPhone = pendingLoggedInUser.phone || activeMobile;
                  const regResult = await registerBiometricCredential(uId, uName, uPhone);
                  setIsRegisteringBiometric(false);
                  if (regResult.success) {
                    setHasEnrolledBiometric(true);
                  }
                  setShowBiometricPromptModal(false);
                  setShowSuccessToast(true);
                  setTimeout(() => {
                    onLoginSuccess(pendingLoggedInUser);
                  }, 500);
                }}
                className="w-full py-3 bg-gradient-to-r from-[#FF7700] to-[#E65100] hover:brightness-105 active:scale-95 text-white text-xs font-extrabold rounded-xl shadow-md shadow-orange-500/20 cursor-pointer transition-all disabled:opacity-60"
              >
                {isRegisteringBiometric ? 'Setting Up Biometrics...' : 'Enable Biometric Login'}
              </button>
              <button
                type="button"
                disabled={isRegisteringBiometric}
                onClick={() => {
                  markBiometricsPrompted();
                  setShowBiometricPromptModal(false);
                  setShowSuccessToast(true);
                  setTimeout(() => {
                    onLoginSuccess(pendingLoggedInUser);
                  }, 500);
                }}
                className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer transition-colors disabled:opacity-60"
              >
                Not Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
