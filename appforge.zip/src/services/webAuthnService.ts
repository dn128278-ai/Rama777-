/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

const BIO_PROMPTED_KEY = 'rama777_biometrics_prompted';
const BIO_ENABLED_KEY = 'rama777_biometrics_enabled';
const WEBAUTHN_CREDS_KEY = 'rama777_webauthn_credentials';

export interface StoredWebAuthnCredential {
  credentialId: string;
  userId: string;
  userName: string;
  phone: string;
  rpId: string;
  createdAt: string;
}

export interface BiometricAuthResult {
  success: boolean;
  credentialId?: string;
  phone?: string;
  userId?: string;
  cancelled?: boolean;
  unsupported?: boolean;
  needsEnrollment?: boolean;
  error?: string;
}

function bufferToBase64Url(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function base64UrlToBuffer(base64url: string): ArrayBuffer {
  const base64 = base64url.replace(/-/g, '+').replace(/_/g, '/');
  const padLen = (4 - (base64.length % 4)) % 4;
  const padded = base64 + '='.repeat(padLen);
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

function generateChallenge(): Uint8Array<ArrayBuffer> {
  const challenge = new Uint8Array(new ArrayBuffer(32));
  window.crypto.getRandomValues(challenge);
  return challenge;
}

function getCurrentRpId(): string {
  if (typeof window === 'undefined') return 'localhost';
  return window.location.hostname || 'localhost';
}

export function getStoredCredentials(): StoredWebAuthnCredential[] {
  try {
    const raw = localStorage.getItem(WEBAUTHN_CREDS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveStoredCredential(cred: StoredWebAuthnCredential): void {
  const existing = getStoredCredentials().filter(
    (c) => c.credentialId !== cred.credentialId
  );
  existing.push(cred);
  localStorage.setItem(WEBAUTHN_CREDS_KEY, JSON.stringify(existing));
}

export function hasStoredBiometricCredential(phone?: string): boolean {
  const rpId = getCurrentRpId();
  const cleanPhone = (phone || '').replace(/\D/g, '');
  const creds = getStoredCredentials().filter((c) => c.rpId === rpId);
  if (!cleanPhone) return creds.length > 0;
  return creds.some((c) => c.phone === cleanPhone) || creds.length > 0;
}

export function hasBeenPromptedForBiometrics(): boolean {
  return localStorage.getItem(BIO_PROMPTED_KEY) === 'true';
}

export function markBiometricsPrompted(): void {
  localStorage.setItem(BIO_PROMPTED_KEY, 'true');
}

export function isBiometricEnabled(): boolean {
  const val = localStorage.getItem(BIO_ENABLED_KEY);
  if (val === null) return true; // Default enabled
  return val === 'true';
}

export function setBiometricEnabled(enabled: boolean): void {
  localStorage.setItem(BIO_ENABLED_KEY, enabled ? 'true' : 'false');
}

/**
 * Checks if WebAuthn and a platform biometric authenticator (TouchID / FaceID / Fingerprint / Windows Hello)
 * are supported in the current browser/device context.
 */
export async function isBiometricSupported(): Promise<boolean> {
  try {
    if (
      typeof window === 'undefined' ||
      typeof window.PublicKeyCredential === 'undefined' ||
      !navigator.credentials ||
      typeof navigator.credentials.get !== 'function' ||
      typeof navigator.credentials.create !== 'function'
    ) {
      return false;
    }

    if (
      typeof window.PublicKeyCredential
        .isUserVerifyingPlatformAuthenticatorAvailable === 'function'
    ) {
      const available =
        await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
      return Boolean(available);
    }

    return true;
  } catch {
    return false;
  }
}

/**
 * Registers a real WebAuthn platform credential (Fingerprint / Face ID / Windows Hello)
 * using navigator.credentials.create() and saves the credential ID locally.
 */
export async function registerBiometricCredential(
  userId: string,
  userName: string,
  phone?: string
): Promise<BiometricAuthResult> {
  if (
    typeof window === 'undefined' ||
    typeof window.PublicKeyCredential === 'undefined' ||
    !navigator.credentials ||
    typeof navigator.credentials.create !== 'function'
  ) {
    return {
      success: false,
      unsupported: true,
      error: 'Biometric authentication is not supported on this browser.',
    };
  }

  const cleanPhone = (phone || '').replace(/\D/g, '');
  const rpId = getCurrentRpId();
  const encoder = new TextEncoder();
  const userHandleBytes = encoder.encode(userId || cleanPhone || `rama_${Date.now()}`);

  try {
    const credential = (await navigator.credentials.create({
      publicKey: {
        challenge: generateChallenge(),
        rp: {
          name: 'RAMA777',
          id: rpId,
        },
        user: {
          id: userHandleBytes,
          name: cleanPhone || userName || 'RAMA Player',
          displayName: userName || cleanPhone || 'RAMA Player',
        },
        pubKeyCredParams: [
          { type: 'public-key', alg: -7 },   // ES256
          { type: 'public-key', alg: -257 }, // RS256
        ],
        authenticatorSelection: {
          authenticatorAttachment: 'platform',
          userVerification: 'required',
          residentKey: 'preferred',
        },
        timeout: 60000,
        attestation: 'none',
      },
    })) as PublicKeyCredential | null;

    if (!credential) {
      return {
        success: false,
        cancelled: true,
        error: 'Biometric registration was cancelled.',
      };
    }

    const credentialId = bufferToBase64Url(credential.rawId);
    saveStoredCredential({
      credentialId,
      userId: userId || cleanPhone || 'user',
      userName: userName || 'RAMA Player',
      phone: cleanPhone,
      rpId,
      createdAt: new Date().toISOString(),
    });
    setBiometricEnabled(true);

    return {
      success: true,
      credentialId,
      phone: cleanPhone,
      userId,
    };
  } catch (err: any) {
    const name = err?.name || '';
    if (name === 'NotAllowedError' || name === 'AbortError') {
      return {
        success: false,
        cancelled: true,
        error: 'Biometric setup was cancelled or timed out.',
      };
    }
    if (name === 'SecurityError' || name === 'NotSupportedError') {
      return {
        success: false,
        unsupported: true,
        error: 'Biometric setup is unavailable in this browser context.',
      };
    }
    return {
      success: false,
      error: err?.message || 'Unable to register biometric credential.',
    };
  }
}

/**
 * Triggers real native WebAuthn biometric authentication via navigator.credentials.get().
 * Must be invoked directly from a user click/tap gesture to preserve transient user activation.
 * Never fakes success; returns structured failure info so UI falls back to MPIN gracefully.
 */
export async function triggerNativeBiometricAuth(options?: {
  targetedPhone?: string;
}): Promise<BiometricAuthResult> {
  if (
    typeof window === 'undefined' ||
    typeof window.PublicKeyCredential === 'undefined' ||
    !navigator.credentials ||
    typeof navigator.credentials.get !== 'function'
  ) {
    return {
      success: false,
      unsupported: true,
      error: 'Biometric login is not supported on this device. Please enter your 4-digit MPIN.',
    };
  }

  const rpId = getCurrentRpId();
  const cleanPhone = (options?.targetedPhone || '').replace(/\D/g, '');
  const allRpCreds = getStoredCredentials().filter((c) => c.rpId === rpId);

  // Prefer credentials matching the active mobile if available, otherwise any credential for this origin
  const phoneCreds = cleanPhone
    ? allRpCreds.filter((c) => c.phone === cleanPhone)
    : [];
  const targetCreds = phoneCreds.length > 0 ? phoneCreds : allRpCreds;

  const allowCredentials: PublicKeyCredentialDescriptor[] = targetCreds.map(
    (c) => ({
      id: base64UrlToBuffer(c.credentialId),
      type: 'public-key',
      transports: ['internal'],
    })
  );

  try {
    const assertion = (await navigator.credentials.get({
      publicKey: {
        challenge: generateChallenge(),
        rpId,
        allowCredentials,
        userVerification: 'required',
        timeout: 60000,
      },
    })) as PublicKeyCredential | null;

    if (!assertion || assertion.type !== 'public-key') {
      return {
        success: false,
        cancelled: true,
        error: 'Biometric verification did not complete. Please enter your 4-digit MPIN.',
      };
    }

    const assertionCredId = bufferToBase64Url(assertion.rawId);
    const matched = allRpCreds.find((c) => c.credentialId === assertionCredId);

    return {
      success: true,
      credentialId: assertionCredId,
      phone: matched?.phone || cleanPhone,
      userId: matched?.userId,
    };
  } catch (err: any) {
    const name = err?.name || '';
    if (name === 'NotAllowedError' || name === 'AbortError') {
      const noLocalCred = targetCreds.length === 0;
      return {
        success: false,
        cancelled: true,
        needsEnrollment: noLocalCred,
        error: noLocalCred
          ? 'No fingerprint enrolled yet or prompt cancelled. Enter your 4-digit MPIN to log in.'
          : 'Biometric login cancelled. Please enter your 4-digit MPIN.',
      };
    }
    if (name === 'SecurityError' || name === 'NotSupportedError') {
      return {
        success: false,
        unsupported: true,
        error: 'Biometric sensor is unavailable here. Please enter your 4-digit MPIN.',
      };
    }
    if (name === 'InvalidStateError') {
      return {
        success: false,
        needsEnrollment: true,
        error: 'Biometric credential needs re-enrollment. Please enter your 4-digit MPIN.',
      };
    }
    return {
      success: false,
      error: err?.message || 'Biometric login failed. Please enter your 4-digit MPIN.',
    };
  }
}
