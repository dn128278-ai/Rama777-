import { MarketItem } from '../types';
import {
  evaluateMarkets,
  formatRemainingDuration,
  parseTimeString,
  formatMarketResult,
} from '../utils/marketEngine';

/**
 * Evaluates dynamic status and countdown for a MarketItem given a specific reference time.
 */
export function evaluateSingleMarket(
  market: MarketItem,
  currentTime: Date
): MarketItem {
  const year = currentTime.getFullYear();
  const month = currentTime.getMonth();
  const day = currentTime.getDate();
  const nowMs = currentTime.getTime();
  const currentDateKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

  const isPreviousDay = market.marketDate && market.marketDate !== currentDateKey;

  const formattedRes = formatMarketResult({
    openPana: isPreviousDay ? '***' : market.openPana,
    jodi: isPreviousDay ? '**' : market.jodi,
    closePana: isPreviousDay ? '***' : market.closePana,
  });

  const parsedOpen =
    market.openHour !== undefined && market.openMinute !== undefined
      ? { hour: market.openHour, minute: market.openMinute }
      : parseTimeString(market.openTime);

  const parsedClose =
    market.closeHour !== undefined && market.closeMinute !== undefined
      ? { hour: market.closeHour, minute: market.closeMinute }
      : parseTimeString(market.closeTime);

  if (!parsedOpen || !parsedClose) {
    return {
      ...market,
      openPana: formattedRes.openPana,
      jodi: formattedRes.jodi,
      closePana: formattedRes.closePana,
      isOpen: market.isOpen ?? true,
      countdownText: market.countdownText || market.status || 'Active',
      marketDate: currentDateKey,
    };
  }

  const openHour = parsedOpen.hour;
  const openMinute = parsedOpen.minute;
  const closeHour = parsedClose.hour;
  const closeMinute = parsedClose.minute;

  const crossesMidnight =
    closeHour < openHour || (closeHour === openHour && closeMinute < openMinute);

  const openDateTime = new Date(year, month, day, openHour, openMinute, 0, 0);
  const closeDateTime = crossesMidnight
    ? new Date(year, month, day + 1, closeHour, closeMinute, 0, 0)
    : new Date(year, month, day, closeHour, closeMinute, 0, 0);

  const openMs = openDateTime.getTime();
  const closeMs = closeDateTime.getTime();

  let autoStatus: 'Running for Open' | 'Running for Close' | 'Closed for Today';
  let autoIsOpen: boolean;
  let autoAllowedSession: 'all' | 'close_only' | 'none';
  let countdownText: string;
  let timeRemainingMs: number;

  if (nowMs < openMs) {
    autoStatus = 'Running for Open';
    autoIsOpen = true;
    autoAllowedSession = 'all';
    timeRemainingMs = openMs - nowMs;
    countdownText = `Open Bids close in ${formatRemainingDuration(timeRemainingMs)}`;
  } else if (nowMs >= openMs && nowMs < closeMs) {
    autoStatus = 'Running for Close';
    autoIsOpen = true;
    autoAllowedSession = 'close_only';
    timeRemainingMs = closeMs - nowMs;
    countdownText = `Close Bids close in ${formatRemainingDuration(timeRemainingMs)}`;
  } else {
    autoStatus = 'Closed for Today';
    autoIsOpen = false;
    autoAllowedSession = 'none';
    timeRemainingMs = 0;
    countdownText = `Closed • Next Open tomorrow at ${market.openTime}`;
  }

  const status = (market as any).isDisabled
    ? 'Closed for Today'
    : !isPreviousDay && market.status
    ? market.status
    : autoStatus;

  const isOpen = (market as any).isDisabled
    ? false
    : !isPreviousDay && typeof market.isOpen === 'boolean'
    ? market.isOpen
    : status === 'Closed for Today'
    ? false
    : autoIsOpen;

  const allowedSession =
    !isPreviousDay && market.allowedSession
      ? market.allowedSession
      : (!isOpen
      ? 'none'
      : status === 'Running for Close'
      ? 'close_only'
      : autoAllowedSession);

  return {
    ...market,
    openPana: formattedRes.openPana,
    jodi: formattedRes.jodi,
    closePana: formattedRes.closePana,
    openHour,
    openMinute,
    closeHour,
    closeMinute,
    status,
    isOpen,
    allowedSession,
    timeRemainingMs,
    countdownText: (market as any).isDisabled
      ? 'Market Temporarily Closed'
      : market.countdownText && !isPreviousDay
      ? market.countdownText
      : countdownText,
    marketDate: currentDateKey,
  };
}

/**
 * Subscribes to market updates locally with zero external network dependencies.
 */
export function subscribeToRealtimeMarkets(
  onMarketsUpdate: (markets: MarketItem[], source: 'firestore' | 'fallback') => void,
  getCurrentTime: () => Date
): () => void {
  const evaluate = () => {
    const currentTime = getCurrentTime();
    let overrides: Record<string, Partial<MarketItem>> = {};
    try {
      const stored = localStorage.getItem('rama777_markets_override');
      if (stored) overrides = JSON.parse(stored);
    } catch {
      // Ignore
    }

    const baseMarkets = evaluateMarkets(currentTime);
    const updated = baseMarkets.map((m) => {
      if (overrides[m.id]) {
        return evaluateSingleMarket({ ...m, ...overrides[m.id] }, currentTime);
      }
      return m;
    });

    onMarketsUpdate(updated, 'fallback');
  };

  evaluate();
  return () => {};
}
