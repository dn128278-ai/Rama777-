/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { UserAccount, UserProfile, UserRole, PermissionFlag } from '../types';

const ACCOUNTS_STORAGE_KEY = 'rama777_registered_accounts';
const SESSION_STORAGE_KEY = 'rama777_active_session';

export const ROLE_PERMISSIONS: Record<UserRole, PermissionFlag[]> = {
  user: ['bet_play', 'deposit', 'withdraw', 'view_passbook'],
  admin: [
    'bet_play',
    'deposit',
    'withdraw',
    'view_passbook',
    'manage_markets',
    'declare_results',
    'manage_users',
    'approve_deposits',
    'system_settings',
  ],
};

const SEED_ACCOUNTS: UserAccount[] = [
  {
    id: 'user_girish_12',
    name: 'Girish Meena',
    username: 'Girish12',
    phone: '6377972674',
    email: 'girish12@rama777.com',
    passwordHash: 'rama123',
    mpin: '7777',
    role: 'user',
    walletBalance: 1500,
    biometricEnabled: true,
    registeredAt: '2025-01-10T08:00:00Z',
    lastLoginAt: new Date().toISOString(),
    status: 'active',
  },
  {
    id: 'admin_bred_777',
    name: 'Rama Administrator',
    username: 'AdminRama',
    phone: '9876543210',
    email: 'bred56225@gmail.com',
    passwordHash: 'admin777',
    mpin: '9999',
    role: 'admin',
    walletBalance: 100000,
    biometricEnabled: true,
    registeredAt: '2025-01-01T00:00:00Z',
    lastLoginAt: new Date().toISOString(),
    status: 'active',
  },
];

/**
 * Retrieve all registered accounts from local storage, seeding defaults if missing
 */
export function getRegisteredAccounts(): UserAccount[] {
  try {
    const raw = localStorage.getItem(ACCOUNTS_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(SEED_ACCOUNTS));
      return SEED_ACCOUNTS;
    }
    const parsed: UserAccount[] = JSON.parse(raw);
    // Ensure seed accounts exist if cleared
    let updated = false;
    for (const seed of SEED_ACCOUNTS) {
      const exists = parsed.some(
        (acc) =>
          acc.username.toLowerCase() === seed.username.toLowerCase() ||
          acc.phone === seed.phone ||
          (seed.email && acc.email?.toLowerCase() === seed.email.toLowerCase())
      );
      if (!exists) {
        parsed.push(seed);
        updated = true;
      }
    }
    if (updated) {
      localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(parsed));
    }
    return parsed;
  } catch (err) {
    console.error('Failed to parse accounts from localStorage:', err);
    return SEED_ACCOUNTS;
  }
}

/**
 * Save accounts to local storage
 */
export function saveRegisteredAccounts(accounts: UserAccount[]): void {
  try {
    localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(accounts));
  } catch (err) {
    console.error('Failed to save accounts to localStorage:', err);
  }
}

/**
 * Convert internal UserAccount to public UserProfile
 */
export function accountToProfile(acc: UserAccount): UserProfile {
  return {
    id: acc.id,
    uid: acc.id,
    name: acc.name,
    username: acc.username,
    phone: acc.phone,
    email: acc.email,
    walletBalance: acc.walletBalance,
    mpin: acc.mpin,
    biometricEnabled: acc.biometricEnabled,
    role: acc.role,
    permissions: ROLE_PERMISSIONS[acc.role] || ROLE_PERMISSIONS.user,
    appVersion: '2.0.4',
    createdAt: acc.registeredAt,
    lastLoginAt: acc.lastLoginAt,
  };
}

/**
 * Check if a role possesses a specific permission
 */
export function checkPermission(role: UserRole | undefined, permission: PermissionFlag): boolean {
  if (!role) return false;
  const perms = ROLE_PERMISSIONS[role] || [];
  return perms.includes(permission);
}

export interface AuthSuccessResult {
  success: true;
  user: UserProfile;
  message?: string;
}

export interface AuthFailureResult {
  success: false;
  message: string;
}

export type AuthResult = AuthSuccessResult | AuthFailureResult;

/**
 * Find account by identifier (Username, Phone 10-digit, or Email)
 */
export function findAccountByIdentifier(identifier: string): UserAccount | undefined {
  const clean = identifier.trim().toLowerCase();
  const accounts = getRegisteredAccounts();
  return accounts.find((acc) => {
    return (
      acc.username.toLowerCase() === clean ||
      acc.phone.replace(/\D/g, '') === clean.replace(/\D/g, '') ||
      (acc.email && acc.email.toLowerCase() === clean)
    );
  });
}

/**
 * Login using Username or Mobile Number and Password
 */
export function loginWithPassword(identifier: string, password: string): AuthResult {
  if (!identifier.trim()) {
    return { success: false, message: 'Please enter your Username, Mobile number, or Email.' };
  }
  if (!password) {
    return { success: false, message: 'Please enter your password.' };
  }

  const account = findAccountByIdentifier(identifier);
  if (!account) {
    return {
      success: false,
      message: 'Account not found. Please check your credentials or register a new account.',
    };
  }

  if (account.status === 'suspended') {
    return { success: false, message: 'This account has been suspended. Please contact Support.' };
  }

  if (account.passwordHash !== password) {
    return { success: false, message: 'Incorrect password. Please try again.' };
  }

  // Update last login
  account.lastLoginAt = new Date().toISOString();
  saveCurrentAccount(account);

  const profile = accountToProfile(account);
  persistSession(profile);

  return {
    success: true,
    user: profile,
    message: `Welcome back, ${account.name}!`,
  };
}

/**
 * Login using 4-digit MPIN
 */
export function loginWithMpin(identifier: string, mpin: string): AuthResult {
  if (mpin.length !== 4) {
    return { success: false, message: 'Please enter complete 4-digit MPIN.' };
  }

  // If no identifier provided, default to currently stored or first player account
  let account: UserAccount | undefined;
  if (identifier && identifier.trim()) {
    account = findAccountByIdentifier(identifier);
  } else {
    // Check last active user from storage
    const current = getActiveSession();
    if (current?.username) {
      account = findAccountByIdentifier(current.username);
    }
    if (!account) {
      const accounts = getRegisteredAccounts();
      account = accounts[0];
    }
  }

  if (!account) {
    return { success: false, message: 'User account not found.' };
  }

  // Allow either exact account MPIN or default demo PIN '1234'
  if (account.mpin === mpin || mpin === '1234' || (account.role === 'admin' && mpin === '9999')) {
    account.lastLoginAt = new Date().toISOString();
    saveCurrentAccount(account);
    const profile = accountToProfile(account);
    persistSession(profile);
    return {
      success: true,
      user: profile,
      message: `Login successful with MPIN!`,
    };
  }

  return {
    success: false,
    message: 'Incorrect MPIN. Please try again or use Password.',
  };
}

/**
 * Login using Biometrics
 */
export function loginWithBiometrics(identifier?: string): AuthResult {
  let account: UserAccount | undefined;
  if (identifier && identifier.trim()) {
    account = findAccountByIdentifier(identifier);
  } else {
    const current = getActiveSession();
    if (current?.username) {
      account = findAccountByIdentifier(current.username);
    }
    if (!account) {
      const accounts = getRegisteredAccounts();
      account = accounts[0];
    }
  }

  if (!account) {
    return { success: false, message: 'User account not found for biometric login.' };
  }

  account.lastLoginAt = new Date().toISOString();
  saveCurrentAccount(account);
  const profile = accountToProfile(account);
  persistSession(profile);

  return {
    success: true,
    user: profile,
    message: `Biometric authentication verified! Welcome, ${account.name}.`,
  };
}

/**
 * Register a new user account
 */
export interface RegisterPayload {
  name: string;
  username: string;
  phone: string;
  password: string;
  mpin: string;
  referralCode?: string;
  biometricEnabled?: boolean;
}

export function registerAccount(payload: RegisterPayload): AuthResult {
  const { name, username, phone, password, mpin, referralCode, biometricEnabled } = payload;

  const cleanName = name.trim();
  const cleanUsername = username.trim();
  const cleanPhone = phone.replace(/\D/g, '');

  if (!cleanName || cleanName.length < 2) {
    return { success: false, message: 'Please enter your full name.' };
  }

  if (!cleanUsername || cleanUsername.length < 3) {
    return { success: false, message: 'Username must be at least 3 characters long.' };
  }

  if (!/^[a-zA-Z0-9_]+$/.test(cleanUsername)) {
    return { success: false, message: 'Username can only contain letters, numbers, and underscores.' };
  }

  if (cleanPhone.length !== 10) {
    return { success: false, message: 'Please enter a valid 10-digit mobile number.' };
  }

  if (!password || password.length < 4) {
    return { success: false, message: 'Password must be at least 4 characters.' };
  }

  if (!mpin || mpin.length !== 4 || !/^\d{4}$/.test(mpin)) {
    return { success: false, message: 'Please enter a 4-digit numerical MPIN.' };
  }

  const accounts = getRegisteredAccounts();

  // Check unique username
  const usernameTaken = accounts.some(
    (acc) => acc.username.toLowerCase() === cleanUsername.toLowerCase()
  );
  if (usernameTaken) {
    return { success: false, message: `Username "${cleanUsername}" is already registered. Please choose another.` };
  }

  // Check unique phone
  const phoneTaken = accounts.some((acc) => acc.phone === cleanPhone);
  if (phoneTaken) {
    return { success: false, message: `Mobile number ${cleanPhone} is already registered. Please sign in instead.` };
  }

  // New user gets a ₹500 welcome bonus + ₹100 if referral code is applied
  const welcomeBonus = referralCode?.trim() ? 600 : 500;

  const newAccount: UserAccount = {
    id: `user_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    name: cleanName,
    username: cleanUsername,
    phone: cleanPhone,
    passwordHash: password,
    mpin,
    role: 'user', // Default role is user/player
    walletBalance: welcomeBonus,
    biometricEnabled: !!biometricEnabled,
    registeredAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
    referralCode: referralCode?.trim() || undefined,
    status: 'active',
  };

  accounts.push(newAccount);
  saveRegisteredAccounts(accounts);

  const profile = accountToProfile(newAccount);
  persistSession(profile);

  return {
    success: true,
    user: profile,
    message: `Account created successfully! ₹${welcomeBonus} Welcome Bonus added to your wallet!`,
  };
}

/**
 * Persist active session in local storage
 */
export function persistSession(profile: UserProfile): void {
  try {
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(profile));
    localStorage.setItem('rama777_auth_session', 'true');
    localStorage.setItem('rama777_user_uid', profile.uid || profile.id || '');
    localStorage.setItem('rama777_user_phone', profile.phone);
    localStorage.setItem('rama777_user_name', profile.name);
    localStorage.setItem('rama777_user_role', profile.role || 'user');
    if (profile.username) {
      localStorage.setItem('rama777_user_username', profile.username);
    }
  } catch (err) {
    console.error('Failed to persist session:', err);
  }
}

/**
 * Get active session
 */
export function getActiveSession(): UserProfile | null {
  try {
    const raw = localStorage.getItem(SESSION_STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (err) {
    return null;
  }
}

/**
 * Clear session
 */
export function clearSession(): void {
  try {
    localStorage.removeItem(SESSION_STORAGE_KEY);
    localStorage.setItem('rama777_auth_session', 'false');
    localStorage.removeItem('rama777_user_role');
  } catch (err) {
    console.error('Failed to clear session:', err);
  }
}

/**
 * Update current account in storage
 */
export function saveCurrentAccount(updated: UserAccount): void {
  const accounts = getRegisteredAccounts();
  const idx = accounts.findIndex((a) => a.id === updated.id);
  if (idx >= 0) {
    accounts[idx] = updated;
  } else {
    accounts.push(updated);
  }
  saveRegisteredAccounts(accounts);
}

/**
 * Update wallet balance for an account
 */
export function adjustUserBalance(userId: string, newBalance: number): boolean {
  const accounts = getRegisteredAccounts();
  const acc = accounts.find((a) => a.id === userId || a.phone === userId || a.username === userId);
  if (acc) {
    acc.walletBalance = newBalance;
    saveRegisteredAccounts(accounts);
    return true;
  }
  return false;
}

/**
 * Change MPIN for a user
 */
export function updateUserMpin(identifier: string, newMpin: string): boolean {
  const accounts = getRegisteredAccounts();
  const acc = accounts.find(
    (a) => a.id === identifier || a.phone === identifier || a.username === identifier
  );
  if (acc && newMpin.length === 4) {
    acc.mpin = newMpin;
    saveRegisteredAccounts(accounts);
    return true;
  }
  return false;
}

/**
 * Switch role (e.g. for testing or administrative privilege grant)
 */
export function switchUserRole(identifier: string, newRole: UserRole): UserProfile | null {
  const accounts = getRegisteredAccounts();
  const acc = accounts.find(
    (a) => a.id === identifier || a.phone === identifier || a.username === identifier
  );
  if (acc) {
    acc.role = newRole;
    saveRegisteredAccounts(accounts);
    const profile = accountToProfile(acc);
    persistSession(profile);
    return profile;
  }
  return null;
}
