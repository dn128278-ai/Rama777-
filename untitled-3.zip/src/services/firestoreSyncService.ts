/**
 * Local Storage & State Management Service for RAMA777
 * Replaces external Firebase SDK integrations and remote network endpoints
 * with high-performance, persistent browser local storage and reactive event listeners.
 */

import {
  UserProfile,
  Transaction,
  FundHistoryItem,
  BankAccount,
  GameBid,
  AppNotification,
} from '../types';

export interface PaymentGatewayConfig {
  merchantVpa: string;
  merchantName: string;
  status: 'active' | 'maintenance';
  minDeposit: number;
  maxDeposit?: number;
  minWithdrawal: number;
  welcomeBonusEnabled: boolean;
  bonusAmount: number;
  activeGateway?: string;
  phonepe?: {
    enabled?: boolean;
    merchantId?: string;
  };
  paytm?: {
    enabled?: boolean;
    mid?: string;
  };
  updatedAt?: string;
}

export const DEFAULT_GATEWAY_CONFIG: PaymentGatewayConfig = {
  merchantVpa: '0793748A0296660.bqr@kotak',
  merchantName: 'RAMA77 GAMING ENTERPRISES',
  status: 'active',
  minDeposit: 100,
  maxDeposit: 100000,
  minWithdrawal: 300,
  welcomeBonusEnabled: true,
  bonusAmount: 100,
  activeGateway: 'upi_intent',
};

export interface UserAuthScope {
  uid: string;
  phone: string;
}

// Local Storage Keys
const STORAGE_KEYS = {
  USERS: 'rama777_users_data',
  WITHDRAWALS: 'rama777_withdrawals_data',
  DEPOSITS: 'rama777_deposits_data',
  TRANSACTIONS: 'rama777_transactions_data',
  BIDS: 'rama777_bids_data',
  BANKS: 'rama777_banks_data',
  NOTIFICATIONS: 'rama777_notifications_data',
  GATEWAY: 'rama777_gateway_data',
};

// Event bus for real-time reactivity across components
type EventCallback = () => void;
const eventListeners: Record<string, Set<EventCallback>> = {};

function emitChangeEvent(key: string) {
  if (eventListeners[key]) {
    eventListeners[key].forEach((cb) => {
      try {
        cb();
      } catch (e) {
        console.warn('Listener notification error:', e);
      }
    });
  }
}

function addStorageListener(key: string, callback: EventCallback): () => void {
  if (!eventListeners[key]) {
    eventListeners[key] = new Set();
  }
  eventListeners[key].add(callback);
  return () => {
    eventListeners[key]?.delete(callback);
  };
}

function getStoredJson<T>(key: string, defaultValue: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return defaultValue;
    return JSON.parse(raw);
  } catch {
    return defaultValue;
  }
}

function setStoredJson<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    emitChangeEvent(key);
  } catch (e) {
    console.warn('LocalStorage save notice:', e);
  }
}

export function resolveUserAuthScope(userParam?: Partial<UserProfile> | string | null): UserAuthScope {
  let uid = '';
  let phone = '';

  if (typeof userParam === 'string') {
    const digits = userParam.replace(/\D/g, '');
    if (digits.length === 10) phone = digits;
    uid = userParam.trim();
  } else if (userParam && typeof userParam === 'object') {
    if (userParam.uid) uid = String(userParam.uid).trim();
    else if (userParam.id) uid = String(userParam.id).trim();
    if (userParam.phone) {
      const digits = String(userParam.phone).replace(/\D/g, '');
      if (digits) phone = digits;
    }
  }

  if (!uid && typeof window !== 'undefined') {
    const storedUid = localStorage.getItem('rama777_user_uid');
    if (storedUid) uid = storedUid.trim();
  }
  if (!phone && typeof window !== 'undefined') {
    const storedPhone = localStorage.getItem('rama777_user_phone');
    if (storedPhone) phone = storedPhone.replace(/\D/g, '');
  }

  if (!uid && phone) {
    uid = phone;
  }

  return { uid, phone };
}

export function getUserIdentifier(userOrPhone?: Partial<UserProfile> | string | null): string {
  const scope = resolveUserAuthScope(userOrPhone);
  return scope.uid || scope.phone;
}

// ==========================================
// 1. User Profile & Wallet
// ==========================================
export function subscribeToUserWallet(
  userParam: string | Partial<UserProfile>,
  onUpdate: (userData: Partial<UserProfile>) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);
  const targetId = scope.uid || scope.phone || 'default';

  const readData = () => {
    const allUsers = getStoredJson<Record<string, Partial<UserProfile>>>(STORAGE_KEYS.USERS, {});
    const stored = allUsers[targetId] || allUsers[scope.phone] || {};
    onUpdate({
      uid: targetId,
      id: targetId,
      ...stored,
    });
  };

  readData();
  return addStorageListener(STORAGE_KEYS.USERS, readData);
}

export async function syncUserToFirestore(user: UserProfile): Promise<void> {
  const scope = resolveUserAuthScope(user);
  const uid = scope.uid || scope.phone || 'default';
  const allUsers = getStoredJson<Record<string, Partial<UserProfile>>>(STORAGE_KEYS.USERS, {});

  allUsers[uid] = {
    ...allUsers[uid],
    ...user,
    uid,
    id: uid,
  };

  if (scope.phone) {
    allUsers[scope.phone] = allUsers[uid];
  }

  setStoredJson(STORAGE_KEYS.USERS, allUsers);
}

// ==========================================
// 2. Withdrawals
// ==========================================
export function subscribeToWithdrawals(
  userParam: string | Partial<UserProfile>,
  onUpdate: (withdrawals: FundHistoryItem[], hasData: boolean) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);

  const readData = () => {
    const all = getStoredJson<FundHistoryItem[]>(STORAGE_KEYS.WITHDRAWALS, []);
    const filtered = all.filter((item) => {
      if (!scope.phone && !scope.uid) return true;
      const itemPhone = (item as any).userPhone || (item as any).phone || '';
      const itemUid = (item as any).userId || (item as any).uid || '';
      return (
        (scope.phone && itemPhone.includes(scope.phone)) ||
        (scope.uid && itemUid === scope.uid) ||
        (!itemPhone && !itemUid)
      );
    });
    onUpdate(filtered, filtered.length > 0);
  };

  readData();
  return addStorageListener(STORAGE_KEYS.WITHDRAWALS, readData);
}

export async function createWithdrawalInFirestore(
  item: FundHistoryItem,
  user: UserProfile
): Promise<void> {
  const scope = resolveUserAuthScope(user);
  const all = getStoredJson<FundHistoryItem[]>(STORAGE_KEYS.WITHDRAWALS, []);
  const newItem = {
    ...item,
    userId: scope.uid,
    userPhone: scope.phone,
    userName: user.name,
  };
  setStoredJson(STORAGE_KEYS.WITHDRAWALS, [newItem, ...all.filter((w) => w.id !== item.id)]);
}

// ==========================================
// 3. Deposits
// ==========================================
export function subscribeToDeposits(
  userParam: string | Partial<UserProfile>,
  onUpdate: (deposits: FundHistoryItem[], hasData: boolean) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);

  const readData = () => {
    const all = getStoredJson<FundHistoryItem[]>(STORAGE_KEYS.DEPOSITS, []);
    const filtered = all.filter((item) => {
      if (!scope.phone && !scope.uid) return true;
      const itemPhone = (item as any).userPhone || (item as any).phone || '';
      const itemUid = (item as any).userId || (item as any).uid || '';
      return (
        (scope.phone && itemPhone.includes(scope.phone)) ||
        (scope.uid && itemUid === scope.uid) ||
        (!itemPhone && !itemUid)
      );
    });
    onUpdate(filtered, filtered.length > 0);
  };

  readData();
  return addStorageListener(STORAGE_KEYS.DEPOSITS, readData);
}

export async function createDepositInFirestore(
  item: FundHistoryItem,
  user: UserProfile,
  bonus: number = 0
): Promise<void> {
  const scope = resolveUserAuthScope(user);
  const all = getStoredJson<FundHistoryItem[]>(STORAGE_KEYS.DEPOSITS, []);
  const newItem = {
    ...item,
    bonus,
    userId: scope.uid,
    userPhone: scope.phone,
    userName: user.name,
  };
  setStoredJson(STORAGE_KEYS.DEPOSITS, [newItem, ...all.filter((d) => d.id !== item.id)]);
}

// ==========================================
// 4. Transactions (Passbook)
// ==========================================
export function subscribeToTransactions(
  userParam: string | Partial<UserProfile>,
  onUpdate: (transactions: Transaction[], hasData: boolean) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);

  const readData = () => {
    const all = getStoredJson<Transaction[]>(STORAGE_KEYS.TRANSACTIONS, []);
    const filtered = all.filter((tx) => {
      if (!scope.phone && !scope.uid) return true;
      const txUid = (tx as any).userId || (tx as any).uid || '';
      const txPhone = (tx as any).userPhone || (tx as any).phone || '';
      return (
        (scope.phone && txPhone.includes(scope.phone)) ||
        (scope.uid && txUid === scope.uid) ||
        (!txUid && !txPhone)
      );
    });
    onUpdate(filtered, filtered.length > 0);
  };

  readData();
  return addStorageListener(STORAGE_KEYS.TRANSACTIONS, readData);
}

export async function recordTransactionInFirestore(
  tx: Transaction,
  userParam: string | Partial<UserProfile>
): Promise<void> {
  const scope = resolveUserAuthScope(userParam);
  const all = getStoredJson<Transaction[]>(STORAGE_KEYS.TRANSACTIONS, []);
  const newTx = {
    ...tx,
    userId: scope.uid,
    userPhone: scope.phone,
  };
  setStoredJson(STORAGE_KEYS.TRANSACTIONS, [newTx, ...all.filter((t) => t.id !== tx.id)]);
}

// ==========================================
// 5. Game Bids
// ==========================================
export function subscribeToBids(
  userParam: string | Partial<UserProfile>,
  onUpdate: (bids: GameBid[], hasData: boolean) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);

  const readData = () => {
    const all = getStoredJson<GameBid[]>(STORAGE_KEYS.BIDS, []);
    const filtered = all.filter((bid) => {
      if (!scope.phone && !scope.uid) return true;
      const bidUid = (bid as any).userId || (bid as any).uid || '';
      const bidPhone = (bid as any).userPhone || (bid as any).phone || '';
      return (
        (scope.phone && bidPhone.includes(scope.phone)) ||
        (scope.uid && bidUid === scope.uid) ||
        (!bidUid && !bidPhone)
      );
    });
    onUpdate(filtered, filtered.length > 0);
  };

  readData();
  return addStorageListener(STORAGE_KEYS.BIDS, readData);
}

export async function placeBidInFirestore(
  bid: Omit<GameBid, 'id' | 'date' | 'status'>,
  user: UserProfile
): Promise<string> {
  const scope = resolveUserAuthScope(user);
  const all = getStoredJson<GameBid[]>(STORAGE_KEYS.BIDS, []);
  const now = new Date();
  const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
    .toString()
    .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  })}`;
  const bidId = `bid-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const newBid: GameBid = {
    ...bid,
    id: bidId,
    date: dateStr,
    status: 'Placed',
    userId: scope.uid,
    userPhone: scope.phone,
    userName: user.name,
  } as any;

  setStoredJson(STORAGE_KEYS.BIDS, [newBid, ...all]);
  return bidId;
}

// ==========================================
// 6. Payment Gateway Config
// ==========================================
export function subscribeToPaymentGateway(
  onUpdate: (config: PaymentGatewayConfig) => void
): () => void {
  const readData = () => {
    const cfg = getStoredJson<PaymentGatewayConfig>(STORAGE_KEYS.GATEWAY, DEFAULT_GATEWAY_CONFIG);
    onUpdate(cfg);
  };

  readData();
  return addStorageListener(STORAGE_KEYS.GATEWAY, readData);
}

export async function updatePaymentGatewayConfig(
  config: Partial<PaymentGatewayConfig>
): Promise<void> {
  const current = getStoredJson<PaymentGatewayConfig>(STORAGE_KEYS.GATEWAY, DEFAULT_GATEWAY_CONFIG);
  setStoredJson(STORAGE_KEYS.GATEWAY, {
    ...current,
    ...config,
    updatedAt: new Date().toISOString(),
  });
}

// ==========================================
// 7. Bank Accounts
// ==========================================
export function subscribeToBankAccounts(
  userParam: string | Partial<UserProfile>,
  onUpdate: (banks: BankAccount[], hasData: boolean) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);

  const readData = () => {
    const all = getStoredJson<BankAccount[]>(STORAGE_KEYS.BANKS, []);
    const filtered = all.filter((b) => {
      if (!scope.phone && !scope.uid) return true;
      const bUid = (b as any).userId || (b as any).uid || '';
      const bPhone = (b as any).userPhone || (b as any).phone || '';
      return (
        (scope.phone && bPhone.includes(scope.phone)) ||
        (scope.uid && bUid === scope.uid) ||
        (!bUid && !bPhone)
      );
    });
    onUpdate(filtered, filtered.length > 0);
  };

  readData();
  return addStorageListener(STORAGE_KEYS.BANKS, readData);
}

export async function addBankAccountToFirestore(
  bank: Omit<BankAccount, 'id' | 'updatedAt'>,
  user: UserProfile
): Promise<void> {
  const scope = resolveUserAuthScope(user);
  const all = getStoredJson<BankAccount[]>(STORAGE_KEYS.BANKS, []);
  const now = new Date();
  const dateStr = `${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1)
    .toString()
    .padStart(2, '0')}/${now.getFullYear()} ${now.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  })}`;
  const lockDate = new Date();
  lockDate.setDate(lockDate.getDate() + 30);
  const lockDateStr = `${lockDate.getDate().toString().padStart(2, '0')}/${(lockDate.getMonth() + 1)
    .toString()
    .padStart(2, '0')}/${lockDate.getFullYear()}`;

  const newBank: BankAccount = {
    ...bank,
    id: `bank-${Date.now()}`,
    updatedAt: dateStr,
    lockUntil: lockDateStr,
    status: bank.status || 'Success',
    userId: scope.uid,
    userPhone: scope.phone,
  } as any;

  setStoredJson(STORAGE_KEYS.BANKS, [newBank, ...all]);
}

// ==========================================
// 8. Notifications
// ==========================================
export function subscribeToNotifications(
  userParam: string | Partial<UserProfile>,
  onUpdate: (notifications: AppNotification[], hasData: boolean) => void
): () => void {
  const scope = resolveUserAuthScope(userParam);

  const readData = () => {
    const all = getStoredJson<AppNotification[]>(STORAGE_KEYS.NOTIFICATIONS, [
      {
        id: 'n-1',
        title: 'Welcome to RAMA777!',
        message: 'Fast & secure mobile Matka platform. Enjoy instant withdrawals and 24/7 support.',
        time: 'Just now',
        read: false,
        type: 'bonus',
      },
      {
        id: 'n-2',
        title: 'Kalyan Market Bids Open',
        message: 'Kalyan Day is running for Open bids until 04:15 PM. Place your lucky digit bids now!',
        time: '1h ago',
        read: false,
        type: 'bid',
      },
    ]);
    const filtered = all.filter((n) => {
      const target = (n as any).targetPhone;
      if (!target || target === 'all') return true;
      return scope.phone && target.includes(scope.phone);
    });
    onUpdate(filtered, filtered.length > 0);
  };

  readData();
  return addStorageListener(STORAGE_KEYS.NOTIFICATIONS, readData);
}

export async function broadcastNotificationInFirestore(
  notif: Omit<AppNotification, 'id'> & { id?: string; targetPhone?: string }
): Promise<void> {
  const all = getStoredJson<AppNotification[]>(STORAGE_KEYS.NOTIFICATIONS, []);
  const newNotif: AppNotification = {
    ...notif,
    id: notif.id || `notif-${Date.now()}`,
    read: false,
  };
  setStoredJson(STORAGE_KEYS.NOTIFICATIONS, [newNotif, ...all]);
}

export async function seedInitialDataToFirestore(): Promise<void> {
  // Pure local storage operation - no-op
}
