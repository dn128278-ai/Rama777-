import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Wallet,
  FileClock,
  Building2,
  ChevronRight,
  ArrowLeft,
  Gift,
  CheckCircle2,
  AlertCircle,
  Plus,
  ShieldAlert,
  Lock,
  Clock,
  XCircle,
  Sparkles,
  Smartphone,
  Info,
  Calendar,
  Check,
  Zap,
  Copy,
  ExternalLink,
  ShieldCheck,
  ArrowRight,
  Download,
  Share2,
  User,
  Landmark,
} from 'lucide-react';
import { UserProfile, FundHistoryItem, BankAccount } from '../types';
import {
  subscribeToPaymentGateway,
  createDepositInFirestore,
  PaymentGatewayConfig,
  DEFAULT_GATEWAY_CONFIG,
} from '../services/firestoreSyncService';

interface FundsTabProps {
  user: UserProfile;
  addFundsHistory: FundHistoryItem[];
  withdrawFundsHistory: FundHistoryItem[];
  bankAccounts: BankAccount[];
  onAddFunds: (
    amount: number,
    bonus?: number,
    depositMode?: string,
    utr?: string,
    status?: 'Success' | 'Pending'
  ) => void;
  onAddFundsFailure?: (orderId: string, amount: number, depositMode: string, reason: string) => void;
  onWithdrawFunds: (amount: number, bankId: string) => boolean;
  onAddBank: (bank: Omit<BankAccount, 'id' | 'updatedAt'>) => void;
  gatewayConfig?: PaymentGatewayConfig;
}

export const FundsTab: React.FC<FundsTabProps> = ({
  user,
  addFundsHistory,
  withdrawFundsHistory,
  bankAccounts,
  onAddFunds,
  onAddFundsFailure,
  onWithdrawFunds,
  onAddBank,
  gatewayConfig: initialGatewayConfig,
}) => {
  const [subView, setSubView] = useState<string | null>(null);

  // Dynamic Payment Gateway Configuration synced with Firestore admin panel
  const [liveGatewayConfig, setLiveGatewayConfig] = useState<PaymentGatewayConfig>(
    initialGatewayConfig || DEFAULT_GATEWAY_CONFIG
  );

  useEffect(() => {
    const unsub = subscribeToPaymentGateway((cfg) => {
      setLiveGatewayConfig(cfg);
    });
    return () => unsub();
  }, []);

  const ACTIVE_VPA = liveGatewayConfig.merchantVpa || DEFAULT_GATEWAY_CONFIG.merchantVpa;
  const ACTIVE_MERCHANT = liveGatewayConfig.merchantName || DEFAULT_GATEWAY_CONFIG.merchantName;
  const MIN_DEPOSIT = liveGatewayConfig.minDeposit || 100;
  const MAX_DEPOSIT = liveGatewayConfig.maxDeposit || 100000;

  // Add Funds state
  const [depositAmount, setDepositAmount] = useState<string>('500');
  const [showBonusSheet, setShowBonusSheet] = useState<boolean>(false);
  const [showSecurityInfoModal, setShowSecurityInfoModal] = useState<boolean>(false);
  const [depositError, setDepositError] = useState<string>('');
  const [activePaymentType, setActivePaymentType] = useState<'normal' | 'bonus'>('normal');
  const [addFundsSuccess, setAddFundsSuccess] = useState<string>('');
  const [addFundsFilter, setAddFundsFilter] = useState<'ALL' | 'Success' | 'Pending' | 'Failure'>('ALL');

  // Withdrawal state
  const [withdrawAmount, setWithdrawAmount] = useState<string>('');
  const [withdrawError, setWithdrawError] = useState<string>('');
  const [withdrawSuccess, setWithdrawSuccess] = useState<string>('');
  const [withdrawFilter, setWithdrawFilter] = useState<'ALL' | 'Success' | 'Pending' | 'Failure'>('ALL');

  // Bank state
  const [accountHolder, setAccountHolder] = useState<string>('');
  const [bankName, setBankName] = useState<string>('');
  const [accountNumber, setAccountNumber] = useState<string>('');
  const [confirmAccountNumber, setConfirmAccountNumber] = useState<string>('');
  const [ifscCode, setIfscCode] = useState<string>('');
  const [bankAgreement, setBankAgreement] = useState<boolean>(false);
  const [bankSuccess, setBankSuccess] = useState<string>('');
  const [bankError, setBankError] = useState<string>('');

  // Selected receipt modal
  const [selectedReceipt, setSelectedReceipt] = useState<FundHistoryItem | null>(null);

  const fundsMenu = [
    { id: 'add_funds', label: 'Add Fund', desc: 'Instant top-up via UPI & Netbanking', icon: 'wallet-up' },
    { id: 'withdraw_funds', label: 'Withdraw Fund', desc: 'Instant withdrawal to bank account', icon: 'wallet-down' },
    { id: 'add_funds_history', label: 'Add Fund History', desc: 'Check deposit status & receipts', icon: 'history' },
    { id: 'withdraw_funds_history', label: 'Withdraw Fund History', desc: 'Check payout status & UTR', icon: 'history' },
    { id: 'bank_details', label: 'Add Bank Details', desc: 'Link your savings or current account', icon: 'bank' },
    { id: 'bank_details_history', label: 'Bank Details History', desc: 'View linked & verified accounts', icon: 'bank-check' },
  ];

  const popularBanks = [
    'State Bank of India',
    'HDFC Bank',
    'ICICI Bank',
    'Kotak Mahindra Bank',
    'Punjab National Bank',
    'Bank of Baroda',
    'Axis Bank',
    'Canara Bank',
  ];

  // Direct Add Fund: immediately credits local wallet balance without any payment modal
  const handleDirectAddFund = () => {
    const amt = parseInt(depositAmount, 10);
    if (isNaN(amt) || amt < MIN_DEPOSIT) {
      setDepositError(`Minimum deposit amount is ₹${MIN_DEPOSIT}`);
      return;
    }
    if (amt > MAX_DEPOSIT) {
      setDepositError(`Maximum deposit amount is ₹${MAX_DEPOSIT}`);
      return;
    }
    setDepositError('');

    const orderId = `RAMA-${Math.floor(100000 + Math.random() * 900000)}`;
    onAddFunds(amt, 0, 'Instant Wallet Topup', orderId, 'Success');
    setAddFundsSuccess(`✓ ₹${amt.toLocaleString('en-IN')} successfully added to your wallet! (Ref: ${orderId})`);

    setTimeout(() => {
      setAddFundsSuccess('');
    }, 4500);
  };

  // Direct UPI Intent Launch & instant local deposit completion
  const handleLaunchKotakUpi = (appScheme: 'upi' | 'phonepe' | 'gpay' | 'paytm', appTitle: string) => {
    const amt = activePaymentType === 'bonus' ? 1 : (parseInt(depositAmount, 10) || 500);
    const bonusAmt = activePaymentType === 'bonus' ? 99 : 0;
    const orderId = `KTK-${Math.floor(100000 + Math.random() * 900000)}`;

    let deepLink = '';
    if (appScheme === 'phonepe') {
      deepLink = `phonepe://pay?pa=${ACTIVE_VPA}&pn=${encodeURIComponent(ACTIVE_MERCHANT)}&am=${amt}&tn=Wallet_Topup&cu=INR&mcc=0000&mode=02`;
    } else if (appScheme === 'gpay') {
      deepLink = `tez://upi/pay?pa=${ACTIVE_VPA}&pn=${encodeURIComponent(ACTIVE_MERCHANT)}&am=${amt}&tn=Wallet_Topup&cu=INR&mcc=0000&mode=02`;
    } else if (appScheme === 'paytm') {
      deepLink = `paytmmp://pay?pa=${ACTIVE_VPA}&pn=${encodeURIComponent(ACTIVE_MERCHANT)}&am=${amt}&tn=Wallet_Topup&cu=INR&mcc=0000&mode=02`;
    } else {
      deepLink = `upi://pay?pa=${ACTIVE_VPA}&pn=${encodeURIComponent(ACTIVE_MERCHANT)}&am=${amt}&tn=Wallet_Topup&cu=INR&mcc=0000&mode=02`;
    }

    try {
      if (typeof window !== 'undefined' && /android|iphone|ipad/i.test(navigator.userAgent)) {
        window.location.href = deepLink;
      }
    } catch {}

    // Instant local deposit recording and wallet crediting
    onAddFunds(amt, bonusAmt, appTitle, orderId, 'Success');
    setAddFundsSuccess(`✓ Payment Successful! ₹${amt + bonusAmt} credited to wallet via ${appTitle} (Ref: ${orderId})`);

    setTimeout(() => {
      setAddFundsSuccess('');
      setSubView('add_funds_history');
    }, 1500);
  };

  const handleWithdrawSubmit = () => {
    const amt = parseInt(withdrawAmount, 10);
    if (isNaN(amt) || amt < 300) {
      setWithdrawError('Minimum withdrawal limit is ₹300');
      return;
    }
    if (amt > user.walletBalance) {
      setWithdrawError(`Insufficient balance. Current balance is ₹${user.walletBalance}`);
      return;
    }
    if (bankAccounts.length === 0) {
      setWithdrawError('Please add a verified bank account first');
      return;
    }

    const defaultBank = bankAccounts.find((b) => b.isDefault) || bankAccounts[0];
    const success = onWithdrawFunds(amt, defaultBank.id);
    if (success) {
      setWithdrawError('');
      setWithdrawSuccess(`Withdrawal request of ₹${amt} initiated successfully!`);
      setTimeout(() => {
        setWithdrawSuccess('');
        setSubView('withdraw_funds_history');
      }, 1500);
    }
  };

  const handleAddBankSubmit = () => {
    if (!accountHolder.trim() || !bankName.trim() || !accountNumber.trim() || !ifscCode.trim()) {
      setBankError('Please fill all bank details');
      return;
    }
    if (accountNumber !== confirmAccountNumber) {
      setBankError('Account numbers do not match. Please verify.');
      return;
    }
    if (!bankAgreement) {
      setBankError('Please acknowledge the 30-day update policy checkbox.');
      return;
    }

    onAddBank({
      accountHolder: accountHolder.toUpperCase(),
      bankName: bankName.trim(),
      branch: 'MAIN BRANCH',
      ifscCode: ifscCode.toUpperCase().trim(),
      accountNumber: accountNumber.trim(),
      isDefault: bankAccounts.length === 0,
      status: 'Success',
    });

    setBankSuccess('Bank account added & verified successfully!');
    setBankError('');
    setTimeout(() => {
      setBankSuccess('');
      setSubView('bank_details_history');
    }, 1200);
  };

  const filteredAddFunds = addFundsHistory.filter(
    (item) => addFundsFilter === 'ALL' || item.status === addFundsFilter
  );

  const filteredWithdrawFunds = withdrawFundsHistory.filter(
    (item) => withdrawFilter === 'ALL' || item.status === withdrawFilter
  );

  // Check if bank update is locked under 30 days
  const latestBank = bankAccounts[0];
  const isBankUpdateLocked = !!(latestBank && latestBank.lockUntil);

  return (
    <div className="pb-6 pt-2 px-4 transition-colors min-h-full bg-[#0a0b10] text-slate-100">
      {!subView ? (
        /* Funds Menu with deep dark background and orange/amber branding */
        <div className="space-y-4">
          {/* Quick Balance Header Card */}
          <div className="bg-gradient-to-r from-[#141624] via-[#1c2033] to-[#131522] border border-orange-500/30 rounded-3xl p-5 text-white shadow-xl shadow-black/50 relative overflow-hidden">
            <div className="absolute -right-6 -bottom-6 w-32 h-32 rounded-full bg-orange-500/10 blur-xl pointer-events-none" />
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs uppercase tracking-wider text-amber-300 font-bold block">
                  Total Wallet Balance
                </span>
                <div className="text-3xl font-black font-mono tracking-tight mt-1 text-[#facc15]">
                  ₹{user.walletBalance.toLocaleString('en-IN')}
                </div>
              </div>
              <div className="w-12 h-12 rounded-2xl bg-[#1b1e2c] border border-orange-500/40 backdrop-blur-sm flex items-center justify-center text-amber-400 shadow-md">
                <Wallet className="w-6 h-6" />
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-zinc-800 flex items-center justify-between text-xs">
              <span className="text-zinc-400">Safe & Instant Deposits/Withdrawals</span>
              <button
                onClick={() => setSubView('add_funds')}
                className="px-4 py-1.5 rounded-full bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-black font-black text-xs active:scale-95 transition-all shadow-md shadow-orange-500/20 cursor-pointer"
              >
                + Add Funds
              </button>
            </div>
          </div>

          {/* Menu Options */}
          <div className="space-y-3">
            {fundsMenu.map((item) => (
              <button
                key={item.id}
                onClick={() => setSubView(item.id)}
                className="w-full bg-[#11131c] hover:bg-[#171a26] rounded-2xl p-4 border border-zinc-800 flex items-center justify-between shadow-xs hover:border-orange-500/50 active:scale-[0.99] transition-all cursor-pointer text-left"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-md shadow-orange-600/30 shrink-0">
                    {item.icon === 'wallet-up' || item.icon === 'wallet-down' ? (
                      <Wallet className="w-5 h-5" />
                    ) : item.icon === 'bank' || item.icon === 'bank-check' ? (
                      <Building2 className="w-5 h-5" />
                    ) : (
                      <FileClock className="w-5 h-5" />
                    )}
                  </div>
                  <div>
                    <span className="font-bold text-white text-sm block">
                      {item.label}
                    </span>
                    <span className="text-[11px] text-zinc-400 block mt-0.5">
                      {item.desc}
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-orange-400/80 shrink-0" />
              </button>
            ))}
          </div>
        </div>
      ) : subView === 'add_funds' ? (
        /* Clean Add Fund screen matching reference design style in deep dark/black and orange/amber theme */
        <div className="flex flex-col min-h-[calc(100vh-140px)] justify-between space-y-4">
          <div>
            {/* Top Bar matching reference: Circular back button, Add Fund title, Dark wallet balance pill */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setSubView(null)}
                  className="w-10 h-10 rounded-full bg-[#151722] shadow-xs border border-zinc-800 text-zinc-200 flex items-center justify-center cursor-pointer active:scale-95 transition-all hover:bg-[#1c202e] hover:border-orange-500/50"
                  aria-label="Back"
                >
                  <ArrowLeft className="w-5 h-5 stroke-[2.2]" />
                </button>
                <h1 className="text-xl font-black text-white tracking-tight">
                  Add Fund
                </h1>
              </div>

              {/* Wallet Pill: Dark container with wallet icon and balance */}
              <div className="bg-[#151722] text-white border border-orange-500/30 rounded-full px-3.5 py-1.5 flex items-center gap-1.5 shadow-xs">
                <Wallet className="w-3.5 h-3.5 text-[#FF7700] shrink-0" />
                <span className="text-xs font-bold font-mono tracking-tight text-amber-300">
                  ₹{Number(user.walletBalance || 0).toFixed(2)}
                </span>
              </div>
            </div>

            {/* User Profile Summary Card: Deep dark/black card with amber avatar and shield watermark */}
            <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#131624] via-[#1a1e2f] to-[#12141e] p-4 text-white border border-orange-500/30 shadow-xl shadow-black/50 mb-4">
              {/* Subtle watermark shield on right */}
              <div className="absolute -right-2 -bottom-3 pointer-events-none opacity-10 text-orange-400">
                <svg width="110" height="110" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z" />
                </svg>
              </div>

              <div className="flex items-center justify-between relative z-10">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 text-black flex items-center justify-center shrink-0 shadow-md">
                    <User className="w-6 h-6 stroke-[2.5]" />
                  </div>
                  <div>
                    <h2 className="font-bold text-base text-white tracking-tight leading-tight">
                      {user.name || 'Girish12'}
                    </h2>
                    <p className="text-xs text-zinc-400 font-mono mt-0.5 tracking-wide">
                      {user.phone ? (user.phone.replace(/\D/g, '').length === 10 ? user.phone.replace(/\D/g, '') : user.phone) : '6377972674'}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <div className="flex items-center justify-end gap-1 text-[11px] font-medium text-zinc-400 mb-0.5">
                    <Wallet className="w-3 h-3 text-amber-400" />
                    <span>Available Balance</span>
                  </div>
                  <div className="text-lg font-black font-mono tracking-tight text-[#facc15]">
                    ₹ {Number(user.walletBalance || 0).toFixed(2)}
                  </div>
                </div>
              </div>
            </div>

            {/* Success confirmation message banner */}
            {addFundsSuccess && (
              <div className="mb-4 p-4 rounded-2xl bg-orange-950/40 border border-orange-500/50 text-amber-200 text-xs sm:text-sm font-semibold flex items-center gap-3 shadow-lg shadow-black/40 animate-in fade-in zoom-in-95">
                <CheckCircle2 className="w-6 h-6 text-amber-400 shrink-0" />
                <span className="leading-snug">{addFundsSuccess}</span>
              </div>
            )}

            {/* Section 1: Add Fund (Enter Amount Input Field) */}
            <div className="mb-4">
              <label className="text-xs font-bold text-zinc-300 uppercase tracking-wider block mb-2">
                Add Fund
              </label>
              <div className="bg-[#11131c] rounded-2xl border border-zinc-800 shadow-inner p-3 px-3.5 flex items-center justify-between focus-within:border-orange-500 focus-within:ring-2 focus-within:ring-orange-500/20 transition-all">
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-500 to-orange-600 text-black flex items-center justify-center shrink-0 shadow-xs">
                    <Building2 className="w-5 h-5 stroke-[2.2]" />
                  </div>
                  <input
                    type="number"
                    inputMode="numeric"
                    value={depositAmount}
                    onChange={(e) => {
                      setDepositAmount(e.target.value);
                      if (depositError) setDepositError('');
                    }}
                    placeholder="Enter Amount"
                    className="w-full bg-transparent text-base sm:text-lg font-black text-white placeholder:text-zinc-600 outline-none"
                  />
                </div>
                <span className="text-amber-400 font-black text-lg pr-2 select-none">
                  ₹
                </span>
              </div>
              {depositError && (
                <p className="text-xs font-semibold text-rose-400 mt-1.5 pl-1 flex items-center gap-1.5 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{depositError}</span>
                </p>
              )}
            </div>

            {/* Section 2: Quick Select Buttons (₹500, ₹1,000, ₹5,000, ₹10,000) */}
            <div className="mb-5">
              <label className="text-xs font-bold text-zinc-300 uppercase tracking-wider block mb-2">
                Quick Select
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { label: '₹500', value: '500' },
                  { label: '₹1,000', value: '1000' },
                  { label: '₹5,000', value: '5000' },
                  { label: '₹10,000', value: '10000' },
                ].map((opt) => {
                  const isSelected = depositAmount === opt.value;
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => {
                        setDepositAmount(opt.value);
                        if (depositError) setDepositError('');
                      }}
                      className={`py-3 px-1 rounded-xl text-xs sm:text-sm text-center transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-gradient-to-r from-orange-500 to-amber-500 border-2 border-amber-300 text-black font-black shadow-lg shadow-orange-500/30 scale-[1.02]'
                          : 'bg-[#11131c] border border-zinc-800 text-zinc-300 hover:border-orange-500/60 hover:text-white font-bold shadow-2xs'
                      }`}
                    >
                      {opt.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Section 3: 100% Secure Transactions Card */}
            <div
              onClick={() => setShowSecurityInfoModal(true)}
              className="bg-[#11131c] border border-zinc-800 hover:border-orange-500/50 rounded-2xl p-4 flex items-center justify-between shadow-xs mb-4 cursor-pointer transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/30 text-orange-400 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-6 h-6 stroke-[2.2]" />
                </div>
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-white leading-snug">
                    100% Secure Transactions
                  </h3>
                  <p className="text-[11px] text-zinc-400 mt-0.5">
                    Your money is safe with us
                  </p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-orange-400 shrink-0" />
            </div>

            {/* Quick Helper Links: Deposit History & Welcome Bonus */}
            <div className="flex items-center justify-between text-xs px-1 text-zinc-400 mb-2">
              <button
                type="button"
                onClick={() => setSubView('add_funds_history')}
                className="hover:text-amber-300 flex items-center gap-1 cursor-pointer font-semibold"
              >
                <FileClock className="w-3.5 h-3.5" />
                <span>View Deposit History</span>
              </button>

              <button
                type="button"
                onClick={() => setShowBonusSheet(true)}
                className="text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer font-bold"
              >
                <Gift className="w-3.5 h-3.5" />
                <span>Claim ₹100 Bonus</span>
              </button>
            </div>
          </div>

          {/* Section 4: Prominent Bottom 'Add Fund' Action Button (Direct Instant Credit - No Modal) */}
          <div className="pt-3 pb-2">
            <button
              type="button"
              onClick={handleDirectAddFund}
              className={`w-full rounded-2xl py-4 px-4 flex items-center justify-between transition-all cursor-pointer shadow-xl active:scale-[0.99] border ${
                depositAmount && parseInt(depositAmount, 10) >= MIN_DEPOSIT
                  ? 'bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 hover:from-orange-400 hover:to-amber-400 text-black font-black shadow-orange-500/25 border-amber-300/40'
                  : 'bg-[#151722] text-zinc-500 border-zinc-800'
              }`}
            >
              <div className="w-8 h-8 rounded-full bg-black/20 backdrop-blur-xs flex items-center justify-center text-black shrink-0">
                <Lock className="w-4 h-4" />
              </div>
              <span className="font-black text-sm sm:text-base tracking-wide text-black uppercase">
                Add Fund {depositAmount && parseInt(depositAmount, 10) > 0 ? `• ₹${depositAmount}` : ''}
              </span>
              <ArrowRight className="w-5 h-5 text-black shrink-0 stroke-[2.5]" />
            </button>
          </div>

          {/* Modal: 100% Secure Transactions Information Modal */}
          {showSecurityInfoModal && (
            <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 animate-in fade-in">
              <div className="w-full max-w-sm bg-[#11131c] rounded-3xl p-6 shadow-2xl border border-zinc-800 relative space-y-4 text-white">
                <button
                  onClick={() => setShowSecurityInfoModal(false)}
                  className="absolute top-4 right-4 text-zinc-400 hover:text-white text-sm font-bold cursor-pointer"
                >
                  ✕
                </button>

                <div className="w-12 h-12 rounded-2xl bg-orange-500/10 border border-orange-500/30 text-orange-400 flex items-center justify-center mx-auto shadow-xs">
                  <ShieldCheck className="w-7 h-7" />
                </div>

                <div className="text-center">
                  <h3 className="text-base font-bold text-white">
                    100% Secure & Regulated
                  </h3>
                  <p className="text-xs text-zinc-400 mt-1">
                    Your transactions are protected with industry-grade security protocols.
                  </p>
                </div>

                <div className="space-y-2.5 text-xs text-zinc-300">
                  <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-[#151722] border border-zinc-800">
                    <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white block font-bold">Bank Grade 256-Bit SSL</strong>
                      <span className="text-zinc-400 text-[11px]">All payment links and UPI intent payloads are encrypted end-to-end.</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-[#151722] border border-zinc-800">
                    <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white block font-bold">Direct Wallet Settlement</strong>
                      <span className="text-zinc-400 text-[11px]">Points are credited directly to your local balance without delays.</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-[#151722] border border-zinc-800">
                    <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white block font-bold">Instant Passbook Recording</strong>
                      <span className="text-zinc-400 text-[11px]">View deposit history and balance receipts any time.</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setShowSecurityInfoModal(false)}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-black font-black text-xs active:scale-95 transition-all cursor-pointer shadow-md shadow-orange-500/25"
                >
                  Understood
                </button>
              </div>
            </div>
          )}

          {/* Welcome Bonus Bottom Sheet Modal with dark/amber aesthetic */}
          {showBonusSheet && (
            <div className="absolute inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-xs p-4 animate-in fade-in">
              <div className="w-full max-w-sm bg-[#11131c] rounded-3xl p-6 shadow-2xl border border-zinc-800 text-center animate-in slide-in-from-bottom duration-200 relative text-white">
                <button
                  onClick={() => setShowBonusSheet(false)}
                  className="absolute top-4 right-4 text-zinc-400 hover:text-white text-sm font-bold cursor-pointer"
                >
                  ✕
                </button>

                {/* Gift Box with Coin Popping Out */}
                <div className="w-20 h-20 mx-auto mb-3 relative flex items-center justify-center">
                  <div className="w-16 h-14 bg-gradient-to-tr from-orange-500 to-amber-500 rounded-2xl shadow-md flex items-center justify-center text-black">
                    <Gift className="w-8 h-8 text-black" />
                  </div>
                  <div className="absolute -top-2 w-8 h-8 rounded-full bg-amber-400 border-2 border-zinc-900 shadow-md flex items-center justify-center text-black font-black text-xs">
                    ₹
                  </div>
                </div>

                <div className="inline-block px-3 py-1 rounded-full border border-orange-500/40 bg-[#151722] text-xs font-bold text-amber-300 mb-2">
                  Welcome Bonus
                </div>

                <h3 className="text-lg font-black text-white">
                  Pay ₹1, Get ₹100
                </h3>
                <p className="text-[11px] text-zinc-400 mt-0.5 mb-5 font-medium">
                  *New Users Only, instant bonus credited to your wallet balance
                </p>

                <div className="space-y-2">
                  <button
                    onClick={() => {
                      setActivePaymentType('bonus');
                      setShowBonusSheet(false);
                      handleLaunchKotakUpi('phonepe', 'PhonePe Welcome Bonus');
                    }}
                    className="w-full py-3.5 rounded-2xl bg-[#5f259f] hover:bg-[#501f87] text-white font-extrabold text-sm shadow-md shadow-purple-950/40 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <span>Pay ₹1 via PhonePe</span>
                  </button>
                  <button
                    onClick={() => {
                      setActivePaymentType('bonus');
                      setShowBonusSheet(false);
                      handleLaunchKotakUpi('upi', 'Kotak UPI Welcome Bonus');
                    }}
                    className="w-full py-3 rounded-2xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-black font-black text-sm shadow-md shadow-orange-500/25 active:scale-95 transition-all cursor-pointer"
                  >
                    Pay ₹1 via Any UPI
                  </button>
                  <button
                    onClick={() => setShowBonusSheet(false)}
                    className="w-full py-2 text-xs font-bold text-zinc-400 hover:text-white cursor-pointer"
                  >
                    Skip for now
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>
      ) : subView === 'add_funds_history' ? (
        /* Add Funds History matching f_028.jpg */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setSubView(null)}
                className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <h2 className="text-base font-extrabold text-[#FF7700]">Add Funds History</h2>
            </div>
            <span className="text-xs font-mono text-slate-400">
              {filteredAddFunds.length} records
            </span>
          </div>

          {/* Status Filter Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {(['ALL', 'Success', 'Pending', 'Failure'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setAddFundsFilter(filter)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                  addFundsFilter === filter
                    ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-black font-black shadow-md shadow-orange-500/20'
                    : 'bg-[#11131c] border border-zinc-800 text-zinc-400 hover:text-white'
                }`}
              >
                {filter === 'ALL' ? 'All' : filter}
              </button>
            ))}
          </div>

          <div className="space-y-3">
            {filteredAddFunds.length === 0 ? (
              <div className="bg-[#11131c] rounded-3xl p-8 border border-zinc-800 text-center shadow-lg">
                <FileClock className="w-10 h-10 text-zinc-600 mx-auto mb-2" />
                <p className="text-sm font-semibold text-zinc-400">
                  No {addFundsFilter !== 'ALL' ? addFundsFilter.toLowerCase() : ''} records found
                </p>
              </div>
            ) : (
              filteredAddFunds.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedReceipt(item)}
                  className="bg-[#11131c] rounded-3xl p-4 border border-zinc-800 shadow-md space-y-3 cursor-pointer hover:border-orange-500/50 transition-all text-white"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-zinc-400 font-mono flex items-center gap-1.5">
                      📅 {item.date}
                    </span>
                    <span className="text-base font-black text-amber-400 font-mono">
                      +₹{item.amount}
                    </span>
                  </div>

                  <div className="bg-[#151722] rounded-2xl p-3 flex items-center justify-between border border-zinc-800/60">
                    <div>
                      <span className="text-[10px] text-zinc-500 font-semibold block uppercase">
                        Order Id
                      </span>
                      <span className="text-xs font-bold text-zinc-200 font-mono">
                        {item.orderId}
                      </span>
                    </div>

                    {/* Proper status indicator */}
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 ${
                        item.status === 'Failure'
                          ? 'bg-rose-950/60 text-rose-400 border border-rose-900'
                          : item.status === 'Pending'
                          ? 'bg-amber-950/60 text-amber-400 border border-amber-900'
                          : 'bg-emerald-950/60 text-emerald-400 border border-emerald-900'
                      }`}
                    >
                      {item.status === 'Failure' ? (
                        <XCircle className="w-3.5 h-3.5" />
                      ) : item.status === 'Pending' ? (
                        <Clock className="w-3.5 h-3.5" />
                      ) : (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      )}
                      <span>{item.status}</span>
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-1">
                    <div>
                      <span className="text-[10px] text-zinc-500 block">Request Type</span>
                      <span className="font-semibold text-emerald-400">{item.requestType}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-zinc-500 block">Deposit Mode</span>
                      <span className="font-semibold text-zinc-300">
                        {item.depositMode}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      ) : subView === 'withdraw_funds' ? (
        /* Withdraw Funds Flow */
        <div className="space-y-4">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setSubView(null)}
              className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <h2 className="text-base font-extrabold text-[#FF7700]">Withdraw Funds</h2>
          </div>

          <div className="bg-[#11131c] rounded-3xl p-5 border border-zinc-800 shadow-xl space-y-4 text-white">
            <div className="flex items-center justify-between text-xs pb-3 border-b border-zinc-800">
              <span className="text-zinc-400 font-semibold">Available for Withdrawal</span>
              <span className="font-black text-base text-amber-400 font-mono">
                ₹{user.walletBalance}
              </span>
            </div>

            {withdrawError && (
              <div className="p-3.5 rounded-xl bg-rose-950/50 text-rose-400 border border-rose-900/50 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{withdrawError}</span>
              </div>
            )}
            {withdrawSuccess && (
              <div className="p-3.5 rounded-xl bg-emerald-950/50 text-emerald-400 border border-emerald-900/50 text-xs font-semibold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{withdrawSuccess}</span>
              </div>
            )}

            <div>
              <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block mb-1">
                Enter Amount (Min. ₹300)
              </label>
              <input
                type="number"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
                placeholder="300"
                className="w-full bg-[#151722] border border-zinc-800 rounded-xl px-3.5 py-2.5 text-base font-bold font-mono outline-none text-white focus:border-orange-500"
              />

              {/* Preset Quick Chips for Withdrawal */}
              <div className="grid grid-cols-4 gap-2 mt-2">
                {['300', '500', '1000'].map((amt) => (
                  <button
                    key={amt}
                    onClick={() => setWithdrawAmount(amt)}
                    className="py-1.5 rounded-xl text-xs font-bold font-mono bg-[#151722] border border-zinc-800 hover:border-orange-500/50 text-zinc-300 transition-all cursor-pointer"
                  >
                    ₹{amt}
                  </button>
                ))}
                <button
                  onClick={() => setWithdrawAmount(user.walletBalance.toString())}
                  className="py-1.5 rounded-xl text-xs font-bold font-mono bg-orange-950/40 border border-orange-500/50 text-amber-300 hover:bg-orange-900/40 transition-all cursor-pointer"
                >
                  Max (All)
                </button>
              </div>
            </div>

            {/* Select Bank */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
                  Transfer to Bank Account
                </label>
                <button
                  onClick={() => setSubView('bank_details_history')}
                  className="text-[11px] font-bold text-amber-400 hover:underline cursor-pointer"
                >
                  Manage Bank
                </button>
              </div>

              {bankAccounts.length === 0 ? (
                <button
                  onClick={() => setSubView('add_bank_details')}
                  className="w-full p-3 rounded-2xl border border-dashed border-orange-500/60 text-amber-400 text-xs font-bold flex items-center justify-center gap-2 cursor-pointer bg-orange-950/20 hover:bg-orange-900/30"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Bank Account First</span>
                </button>
              ) : (
                <div className="p-3.5 rounded-2xl bg-[#151722] border border-zinc-800 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-xs text-zinc-200 flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-amber-400" />
                      <span>{bankAccounts[0].bankName}</span>
                      <span className="text-[10px] px-2 py-0.2 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold">
                        Verified
                      </span>
                    </div>
                    <div className="text-[11px] text-zinc-400 font-mono mt-1">
                      A/c: {bankAccounts[0].accountNumber} · IFSC: {bankAccounts[0].ifscCode}
                    </div>
                  </div>
                  <span className="text-xs text-zinc-400 font-bold uppercase">
                    {bankAccounts[0].accountHolder}
                  </span>
                </div>
              )}
            </div>

            {/* Withdrawal Guidelines Card */}
            <div className="p-3 rounded-2xl bg-[#151722] border border-orange-500/20 text-zinc-300 text-[11px] space-y-1">
              <div className="font-bold flex items-center gap-1 text-amber-400">
                <Info className="w-3.5 h-3.5 shrink-0" />
                <span>Withdrawal Policy</span>
              </div>
              <ul className="list-disc pl-4 space-y-0.5 text-[10.5px] text-zinc-400">
                <li>Withdrawal Timing: 10:00 AM to 05:00 PM daily.</li>
                <li>Minimum withdrawal ₹300, Maximum ₹50,000 per request.</li>
                <li>Transfers processed instantly via IMPS / NEFT.</li>
              </ul>
            </div>

            <button
              onClick={handleWithdrawSubmit}
              disabled={bankAccounts.length === 0}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-black font-black text-sm shadow-lg shadow-orange-500/25 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
            >
              Submit Withdrawal Request
            </button>
          </div>
        </div>
      ) : subView === 'withdraw_funds_history' ? (
        /* Withdraw Funds History matching f_030.jpg */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setSubView(null)}
                className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <h2 className="text-base font-extrabold text-[#FF7700]">Withdraw Funds History</h2>
            </div>
            <span className="text-xs font-mono text-zinc-400">
              {filteredWithdrawFunds.length} records
            </span>
          </div>

          {/* Status Filter Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {(['ALL', 'Success', 'Pending', 'Failure'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setWithdrawFilter(filter)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                  withdrawFilter === filter
                    ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-black font-black shadow-md shadow-orange-500/20'
                    : 'bg-[#11131c] border border-zinc-800 text-zinc-400 hover:text-white'
                }`}
              >
                {filter === 'ALL' ? 'All' : filter}
              </button>
            ))}
          </div>

          <div className="space-y-3">
            {filteredWithdrawFunds.length === 0 ? (
              <div className="bg-[#11131c] rounded-3xl p-8 border border-zinc-800 text-center shadow-lg">
                <FileClock className="w-10 h-10 text-zinc-600 mx-auto mb-2" />
                <p className="text-sm font-semibold text-zinc-400">
                  No {withdrawFilter !== 'ALL' ? withdrawFilter.toLowerCase() : ''} withdrawal records found
                </p>
              </div>
            ) : (
              filteredWithdrawFunds.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedReceipt(item)}
                  className="bg-[#11131c] rounded-3xl p-4 border border-zinc-800 shadow-md space-y-3 cursor-pointer hover:border-orange-500/50 transition-all text-white"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-zinc-400 font-mono flex items-center gap-1.5">
                      📅 {item.date}
                    </span>
                    <span className="text-base font-black text-rose-400 font-mono">
                      -₹{item.amount}
                    </span>
                  </div>

                  <div className="bg-[#151722] rounded-2xl p-3 flex items-center justify-between border border-zinc-800/60">
                    <div>
                      <span className="text-[10px] text-zinc-500 font-semibold block uppercase">
                        Order Id
                      </span>
                      <span className="text-xs font-bold text-zinc-200 font-mono">
                        {item.orderId}
                      </span>
                    </div>

                    {/* Proper status indicator */}
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 ${
                        item.status === 'Failure'
                          ? 'bg-rose-950/60 text-rose-400 border border-rose-900'
                          : item.status === 'Pending'
                          ? 'bg-amber-950/60 text-amber-400 border border-amber-900'
                          : 'bg-emerald-950/60 text-emerald-400 border border-emerald-900'
                      }`}
                    >
                      {item.status === 'Failure' ? (
                        <XCircle className="w-3.5 h-3.5" />
                      ) : item.status === 'Pending' ? (
                        <Clock className="w-3.5 h-3.5" />
                      ) : (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      )}
                      <span>{item.status}</span>
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-xs pt-1 text-zinc-400">
                    <div>
                      <span className="text-[10px] block">Bank Name</span>
                      <span className="font-semibold text-zinc-200 truncate block">
                        {item.bankName || 'Bank of Baroda'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] block">Account Number</span>
                      <span className="font-semibold text-zinc-200 font-mono truncate block">
                        {item.accountNumber || '•••• 4600'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] block">IFSC Code</span>
                      <span className="font-semibold text-zinc-200 font-mono truncate block">
                        {item.ifscCode || 'BARB0DHAKAR'}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      ) : subView === 'add_bank_details' ? (
        /* Add Bank Details with 30-Day Restriction Notice */
        <div className="space-y-4">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setSubView(null)}
              className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <h2 className="text-base font-extrabold text-[#FF7700]">Add Bank Details</h2>
          </div>

          {/* 30-Day Restriction Notice Banner matching specifications */}
          <div className="p-4 rounded-3xl bg-[#151722] border border-orange-500/30 shadow-md space-y-2">
            <div className="flex items-center gap-2 text-amber-300 font-black text-xs uppercase tracking-wider">
              <ShieldAlert className="w-4 h-4 text-orange-400 shrink-0" />
              <span>30-Day Security Restriction Policy</span>
            </div>
            <p className="text-xs text-zinc-300 leading-relaxed">
              <strong>Notice:</strong> For your account safety and fraud prevention, bank details can only be updated or added once every <strong>30 days</strong>. Please verify your Account Number and IFSC Code carefully before submitting.
            </p>
            {isBankUpdateLocked && latestBank.lockUntil && (
              <div className="p-2 rounded-xl bg-orange-950/40 border border-orange-500/30 text-[11px] font-bold text-amber-300 flex items-center gap-1.5 font-mono">
                <Lock className="w-3.5 h-3.5 shrink-0 text-orange-400" />
                <span>Existing Bank account is locked until {latestBank.lockUntil}.</span>
              </div>
            )}
          </div>

          <div className="bg-[#11131c] rounded-3xl p-5 border border-zinc-800 shadow-xl space-y-3.5 text-white">
            {bankError && (
              <div className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-900 text-rose-300 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{bankError}</span>
              </div>
            )}
            {bankSuccess && (
              <div className="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-900 text-emerald-300 text-xs font-semibold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{bankSuccess}</span>
              </div>
            )}

            <div>
              <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block mb-1">
                Account Holder Name
              </label>
              <input
                type="text"
                value={accountHolder}
                onChange={(e) => setAccountHolder(e.target.value)}
                placeholder={user.name ? user.name.toUpperCase() : "Account Holder Name"}
                className="w-full bg-[#151722] border border-zinc-800 rounded-xl px-3.5 py-2.5 text-xs font-bold text-white outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block mb-1">
                Bank Name
              </label>
              <input
                type="text"
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
                placeholder="e.g. State Bank of India"
                className="w-full bg-[#151722] border border-zinc-800 rounded-xl px-3.5 py-2.5 text-xs font-bold text-white outline-none focus:border-orange-500"
              />

              {/* Popular Banks Quick Select */}
              <div className="flex flex-wrap gap-1.5 mt-2">
                {popularBanks.map((b) => (
                  <button
                    key={b}
                    type="button"
                    onClick={() => setBankName(b)}
                    className={`text-[10px] px-2.5 py-1 rounded-lg font-medium transition-all cursor-pointer ${
                      bankName === b
                        ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-black font-black'
                        : 'bg-[#151722] border border-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {b}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block mb-1">
                Account Number
              </label>
              <input
                type="text"
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                placeholder="Enter Account Number"
                className="w-full bg-[#151722] border border-zinc-800 rounded-xl px-3.5 py-2.5 text-xs font-bold font-mono text-white outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block mb-1">
                Confirm Account Number
              </label>
              <input
                type="text"
                value={confirmAccountNumber}
                onChange={(e) => setConfirmAccountNumber(e.target.value)}
                placeholder="Re-enter Account Number"
                className="w-full bg-[#151722] border border-zinc-800 rounded-xl px-3.5 py-2.5 text-xs font-bold font-mono text-white outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block mb-1">
                IFSC Code
              </label>
              <input
                type="text"
                value={ifscCode}
                onChange={(e) => setIfscCode(e.target.value.toUpperCase())}
                placeholder="e.g. SBIN0001234"
                className="w-full bg-[#151722] border border-zinc-800 rounded-xl px-3.5 py-2.5 text-xs font-bold font-mono uppercase text-white outline-none focus:border-orange-500"
              />
            </div>

            {/* 30-day agreement acknowledgment */}
            <label className="flex items-start gap-2.5 pt-2 cursor-pointer">
              <input
                type="checkbox"
                checked={bankAgreement}
                onChange={(e) => setBankAgreement(e.target.checked)}
                className="mt-0.5 accent-[#FF7700] w-4 h-4 cursor-pointer"
              />
              <span className="text-xs text-zinc-400 leading-snug">
                I understand that this bank account will be locked for <strong>30 days</strong> and cannot be modified until the lock period expires.
              </span>
            </label>

            <button
              onClick={handleAddBankSubmit}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-black font-black text-sm shadow-lg shadow-orange-500/25 active:scale-95 transition-all cursor-pointer mt-2"
            >
              Save & Lock Bank Details (30 Days)
            </button>
          </div>
        </div>
      ) : (
        /* Bank Details History matching f_010.jpg with 30-Day Restriction Notice */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setSubView(null)}
                className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <h2 className="text-base font-extrabold text-[#FF7700]">My Bank Details</h2>
            </div>
            <button
              onClick={() => setSubView('add_bank_details')}
              className="text-xs font-bold text-amber-400 flex items-center gap-1 hover:underline cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add New</span>
            </button>
          </div>

          {/* 30-day restriction notice banner */}
          <div className="p-4 rounded-3xl bg-[#151722] border border-orange-500/30 shadow-md space-y-2">
            <div className="flex items-center gap-2 text-amber-300 font-extrabold text-xs uppercase tracking-wide">
              <Lock className="w-4 h-4 text-orange-400 shrink-0" />
              <span>30-Day Modification Rule Active</span>
            </div>
            <p className="text-xs text-zinc-300 leading-relaxed">
              As per security regulations, bank account modifications are restricted for <strong>30 days</strong> from the update date.
            </p>
            {latestBank && latestBank.lockUntil && (
              <div className="flex items-center justify-between pt-1 text-[11px] font-mono text-amber-300 border-t border-zinc-800">
                <span>Last Updated: {latestBank.updatedAt}</span>
                <span className="font-bold text-amber-400">Locked Until: {latestBank.lockUntil}</span>
              </div>
            )}
          </div>

          <div className="space-y-3">
            {bankAccounts.length === 0 ? (
              <div className="bg-[#11131c] rounded-3xl p-8 border border-zinc-800 text-center shadow-lg">
                <Building2 className="w-10 h-10 text-zinc-600 mx-auto mb-2" />
                <p className="text-sm font-semibold text-zinc-400">
                  No bank accounts linked yet
                </p>
                <button
                  onClick={() => setSubView('add_bank_details')}
                  className="mt-3 px-4 py-2 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 text-black font-black text-xs shadow-md shadow-orange-500/20 cursor-pointer"
                >
                  Add Bank Account
                </button>
              </div>
            ) : (
              bankAccounts.map((b) => (
                <div
                  key={b.id}
                  className="bg-[#11131c] rounded-3xl p-5 border border-zinc-800 shadow-xl space-y-3 relative text-white"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-extrabold text-sm text-white uppercase tracking-wide">
                        {b.accountHolder}
                      </h3>
                      <p className="text-xs font-semibold text-amber-400 mt-0.5">{b.bankName}</p>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {b.isDefault && (
                        <span className="px-2.5 py-0.5 rounded-full bg-orange-950 text-amber-400 border border-orange-500/40 text-[10px] font-bold">
                          Default
                        </span>
                      )}
                      {/* Proper status indicator */}
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 ${
                          b.status === 'Failure'
                            ? 'bg-rose-950 text-rose-400 border border-rose-900'
                            : b.status === 'Pending'
                            ? 'bg-amber-950 text-amber-400 border border-amber-900'
                            : 'bg-emerald-950 text-emerald-400 border border-emerald-900'
                        }`}
                      >
                        <Check className="w-3 h-3" />
                        <span>{b.status || 'Verified'}</span>
                      </span>
                    </div>
                  </div>

                  <div className="text-xs text-zinc-400 space-y-1 bg-[#151722] p-3 rounded-2xl border border-zinc-800/60">
                    <p className="uppercase text-[11px] font-medium text-zinc-300">Branch: {b.branch}</p>
                    <p className="font-mono">IFSC Code : <strong className="text-white">{b.ifscCode}</strong></p>
                    <p className="font-mono">A/c Number : <strong className="text-white">{b.accountNumber}</strong></p>
                    <div className="pt-2 border-t border-zinc-800 flex items-center justify-between text-[11px] text-zinc-500 font-mono">
                      <span>Updated: {b.updatedAt}</span>
                      {b.lockUntil && (
                        <span className="text-amber-400 flex items-center gap-1">
                          <Lock className="w-3 h-3" />
                          Lock: {b.lockUntil}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Full Receipt Modal */}
      {selectedReceipt && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-[#11131c] rounded-3xl p-6 shadow-2xl border border-zinc-800 space-y-4 text-white">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h3 className="font-extrabold text-sm text-white">
                Transaction Details
              </h3>
              <button
                onClick={() => setSelectedReceipt(null)}
                className="text-zinc-400 hover:text-white text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="text-center py-2">
              <span className="text-xs text-zinc-400 block font-medium">Amount</span>
              <span className="text-3xl font-black text-amber-400 font-mono">
                ₹{selectedReceipt.amount}
              </span>
              <div className="mt-2">
                <span
                  className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${
                    selectedReceipt.status === 'Failure'
                      ? 'bg-rose-950/60 text-rose-400 border border-rose-900'
                      : selectedReceipt.status === 'Pending'
                      ? 'bg-amber-950/60 text-amber-400 border border-amber-900'
                      : 'bg-emerald-950/60 text-emerald-400 border border-emerald-900'
                  }`}
                >
                  ● {selectedReceipt.status}
                </span>
              </div>
            </div>

            <div className="space-y-2 text-xs text-zinc-300 bg-[#151722] p-3.5 rounded-2xl font-mono border border-zinc-800">
              <div className="flex justify-between">
                <span className="text-zinc-400">Order ID:</span>
                <span className="font-bold text-white">{selectedReceipt.orderId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">Date & Time:</span>
                <span>{selectedReceipt.date}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">Type:</span>
                <span className="text-amber-400 font-bold">{selectedReceipt.requestType}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">Payment Mode:</span>
                <span>{selectedReceipt.depositMode}</span>
              </div>
              {selectedReceipt.bankName && selectedReceipt.bankName !== 'N/A' && (
                <div className="flex justify-between">
                  <span className="text-zinc-400">Bank:</span>
                  <span>{selectedReceipt.bankName}</span>
                </div>
              )}
            </div>

            <button
              onClick={() => setSelectedReceipt(null)}
              className="w-full py-3 rounded-2xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs active:scale-95 transition-all cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
