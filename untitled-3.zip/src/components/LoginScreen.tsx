/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Fingerprint,
  Delete,
  Check,
  ShieldCheck,
  Smartphone,
  Lock,
  User,
  Eye,
  EyeOff,
  Sparkles,
  ArrowRight,
  Crown,
  KeyRound,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import { UserProfile } from '../types';
import {
  loginWithPassword,
  loginWithMpin,
  loginWithBiometrics,
  getRegisteredAccounts,
  updateUserMpin,
} from '../services/authService';
import { authenticateWithDeviceBiometrics } from '../utils/biometricAuth';

interface LoginScreenProps {
  onLoginSuccess: (userProfile: UserProfile) => void;
  savedMpin?: string;
  onUpdateMpin?: (newMpin: string) => void;
  phone?: string;
  onNavigateToRegister: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  onLoginSuccess,
  phone = '',
  onNavigateToRegister,
}) => {
  // Login Method: 'password' or 'mpin'
  const [loginMethod, setLoginMethod] = useState<'mpin' | 'password'>('mpin');

  // Input states
  const [identifier, setIdentifier] = useState<string>(phone || 'Girish12');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [enteredPin, setEnteredPin] = useState<string>('');
  const [rememberMe, setRememberMe] = useState<boolean>(true);

  // Status and animation states
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [successMessage, setSuccessMessage] = useState<string>('');
  const [isBiometricScanning, setIsBiometricScanning] = useState<boolean>(false);
  const [showForgotModal, setShowForgotModal] = useState<boolean>(false);

  // Forgot password / reset MPIN state
  const [forgotStep, setForgotStep] = useState<'id' | 'otp' | 'reset'>('id');
  const [forgotIdentifier, setForgotIdentifier] = useState<string>('');
  const [forgotOtp, setForgotOtp] = useState<string>('');
  const [resetNewMpin, setResetNewMpin] = useState<string>('');

  // Handle number pad for MPIN
  const handlePinPress = (num: string) => {
    if (enteredPin.length < 4) {
      const updated = enteredPin + num;
      setEnteredPin(updated);
      setErrorMessage('');
      if (updated.length === 4) {
        // Auto trigger submit after 4 digits
        submitMpinLogin(updated);
      }
    }
  };

  const handleBackspace = () => {
    if (enteredPin.length > 0) {
      setEnteredPin(enteredPin.slice(0, -1));
      setErrorMessage('');
    }
  };

  const handleClearPin = () => {
    setEnteredPin('');
    setErrorMessage('');
  };

  const submitMpinLogin = (pinToSubmit = enteredPin) => {
    if (pinToSubmit.length !== 4) {
      setErrorMessage('Please enter complete 4-digit MPIN.');
      return;
    }

    const result = loginWithMpin(identifier, pinToSubmit);
    if (result.success) {
      setSuccessMessage(result.message || 'Login successful!');
      setErrorMessage('');
      setTimeout(() => {
        onLoginSuccess(result.user);
      }, 500);
    } else {
      setErrorMessage(result.message);
      setEnteredPin('');
      // Shake MPIN dots
      const box = document.getElementById('mpin-dot-container');
      if (box) {
        box.classList.add('animate-bounce');
        setTimeout(() => box.classList.remove('animate-bounce'), 600);
      }
    }
  };

  const handlePasswordLogin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!identifier.trim()) {
      setErrorMessage('Please enter your Username or Mobile number.');
      return;
    }
    if (!password) {
      setErrorMessage('Please enter your account password.');
      return;
    }

    const result = loginWithPassword(identifier, password);
    if (result.success) {
      setSuccessMessage(result.message || 'Login successful!');
      setErrorMessage('');
      setTimeout(() => {
        onLoginSuccess(result.user);
      }, 500);
    } else {
      setErrorMessage(result.message);
    }
  };

  const handleBiometricLogin = async () => {
    setIsBiometricScanning(true);
    setErrorMessage('');
    try {
      const bioResult = await authenticateWithDeviceBiometrics(
        'Scan your fingerprint to unlock RAMA777'
      );
      if (bioResult.success) {
        const authResult = loginWithBiometrics(identifier);
        if (authResult.success) {
          setSuccessMessage(authResult.message || 'Biometric authentication successful!');
          setTimeout(() => {
            onLoginSuccess(authResult.user);
          }, 600);
        } else {
          setErrorMessage(authResult.message);
        }
      } else {
        // Fallback simulation for sandbox if hardware prompt is unavailable
        const authResult = loginWithBiometrics(identifier);
        if (authResult.success) {
          setSuccessMessage('Biometric fingerprint verified!');
          setTimeout(() => {
            onLoginSuccess(authResult.user);
          }, 600);
        } else {
          setErrorMessage(bioResult.message || 'Fingerprint scan failed. Please use MPIN: 1234');
        }
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Biometric sensor error. Please use MPIN.');
    } finally {
      setIsBiometricScanning(false);
    }
  };

  // Quick Account Select
  const handleSelectDemoAccount = (role: 'user' | 'admin') => {
    if (role === 'user') {
      setIdentifier('Girish12');
      setPassword('rama123');
      setEnteredPin('7777');
      setErrorMessage('');
      const res = loginWithPassword('Girish12', 'rama123');
      if (res.success) {
        setSuccessMessage('Logged in as Player Girish12');
        setTimeout(() => onLoginSuccess(res.user), 400);
      }
    } else {
      setIdentifier('AdminRama');
      setPassword('admin777');
      setEnteredPin('9999');
      setErrorMessage('');
      const res = loginWithPassword('AdminRama', 'admin777');
      if (res.success) {
        setSuccessMessage('Logged in as Super Admin');
        setTimeout(() => onLoginSuccess(res.user), 400);
      }
    }
  };

  // Reset MPIN
  const handleResetMpin = () => {
    if (!resetNewMpin || resetNewMpin.length !== 4) {
      setErrorMessage('Please enter a new 4-digit MPIN.');
      return;
    }
    const target = forgotIdentifier || identifier;
    const ok = updateUserMpin(target, resetNewMpin);
    if (ok) {
      setSuccessMessage('MPIN reset successfully! Please log in now.');
      setShowForgotModal(false);
      setForgotStep('id');
      setEnteredPin(resetNewMpin);
    } else {
      setErrorMessage('Failed to reset MPIN. Account not found.');
    }
  };

  return (
    <div className="w-full min-h-screen bg-[#090a0f] text-white flex flex-col justify-between p-4 sm:p-6 overflow-y-auto">
      {/* Top Branding Section */}
      <div className="w-full max-w-sm mx-auto flex flex-col items-center pt-4 sm:pt-6">
        <div className="relative mb-3 flex items-center justify-center">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-[#E65100] via-[#FF7700] to-[#FFA000] p-0.5 shadow-2xl shadow-orange-600/20 flex items-center justify-center border border-orange-400/50">
            <div className="w-full h-full bg-[#0a0b10] rounded-2xl flex flex-col items-center justify-center">
              <span className="text-2xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-orange-400 to-amber-200">
                RAMA
              </span>
              <span className="text-xs font-extrabold tracking-widest text-[#FF7700] -mt-1">
                777
              </span>
            </div>
          </div>
          <div className="absolute -bottom-1 -right-1 bg-amber-400 text-black p-1 rounded-full shadow-md">
            <ShieldCheck className="w-4 h-4" />
          </div>
        </div>

        <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
          RAMA 777
          <span className="text-[10px] uppercase font-bold tracking-widest bg-orange-500/20 text-amber-400 px-2 py-0.5 rounded-full border border-orange-500/30">
            Secure Portal
          </span>
        </h1>
        <p className="text-xs text-zinc-400 mt-1">
          India&apos;s Trusted Mobile Gaming &amp; Matka Platform
        </p>

        {/* Quick Demo Switcher Pills */}
        <div className="w-full mt-4 bg-[#11131c] p-2.5 rounded-2xl border border-zinc-800 flex flex-col gap-1.5 shadow-md">
          <div className="flex items-center justify-between text-[11px] text-zinc-300 font-medium px-1">
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              1-Tap Fast Demo Login:
            </span>
            <span className="text-[10px] text-amber-400 font-semibold">RBAC Ready</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => handleSelectDemoAccount('user')}
              className="py-1.5 px-2 rounded-xl bg-[#151722] hover:bg-[#1a1e2d] border border-zinc-800 hover:border-orange-500/50 text-left transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
            >
              <div className="w-6 h-6 rounded-lg bg-orange-500/20 text-orange-400 flex items-center justify-center shrink-0">
                <User className="w-3.5 h-3.5" />
              </div>
              <div className="truncate">
                <div className="text-[11px] font-bold text-white truncate">Player (Girish12)</div>
                <div className="text-[9px] text-zinc-400 truncate">PIN: 7777 / 1234</div>
              </div>
            </button>

            <button
              type="button"
              onClick={() => handleSelectDemoAccount('admin')}
              className="py-1.5 px-2 rounded-xl bg-amber-950/40 hover:bg-amber-900/50 border border-amber-500/40 text-left transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
            >
              <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                <Crown className="w-3.5 h-3.5" />
              </div>
              <div className="truncate">
                <div className="text-[11px] font-bold text-amber-300 truncate">Super Admin</div>
                <div className="text-[9px] text-amber-200/70 truncate">Admin Controls</div>
              </div>
            </button>
          </div>
        </div>

        {/* Tab Switcher: MPIN vs Password */}
        <div className="w-full grid grid-cols-2 p-1 bg-[#11131c] rounded-2xl border border-zinc-800 mt-3.5 text-xs font-bold shadow-md">
          <button
            type="button"
            onClick={() => {
              setLoginMethod('mpin');
              setErrorMessage('');
            }}
            className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              loginMethod === 'mpin'
                ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-black font-black shadow-md shadow-orange-500/25'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5" />
            4-Digit MPIN
          </button>
          <button
            type="button"
            onClick={() => {
              setLoginMethod('password');
              setErrorMessage('');
            }}
            className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              loginMethod === 'password'
                ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-black font-black shadow-md shadow-orange-500/25'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            Password Login
          </button>
        </div>

        {/* Messages */}
        {errorMessage && (
          <div className="w-full mt-3 p-2.5 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2 animate-in fade-in">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}
        {successMessage && (
          <div className="w-full mt-3 p-2.5 rounded-xl bg-orange-950/50 border border-orange-500/50 text-amber-200 text-xs flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* TAB 1: 4-DIGIT MPIN LOGIN */}
        {loginMethod === 'mpin' && (
          <div className="w-full mt-4 flex flex-col items-center">
            {/* User identifier input */}
            <div className="w-full mb-3">
              <label className="text-[11px] font-semibold text-zinc-400 block mb-1">
                Username / 10-Digit Mobile Number
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-500">
                  <Smartphone className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="e.g. Girish12 or 6377972674"
                  className="w-full pl-9 pr-3 py-2 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-sm text-white placeholder-zinc-600 outline-none transition-colors"
                />
              </div>
            </div>

            {/* MPIN Display Dots */}
            <div className="w-full bg-[#11131c] p-4 rounded-2xl border border-zinc-800 flex flex-col items-center shadow-lg">
              <span className="text-xs text-zinc-300 font-semibold mb-3">
                Enter 4-Digit Security MPIN
              </span>

              <div id="mpin-dot-container" className="flex items-center gap-4 mb-2">
                {[0, 1, 2, 3].map((idx) => {
                  const filled = enteredPin.length > idx;
                  return (
                    <div
                      key={idx}
                      className={`w-11 h-12 rounded-xl flex items-center justify-center font-bold text-lg transition-all ${
                        filled
                          ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-black border-2 border-amber-300 shadow-lg shadow-orange-500/30 scale-105'
                          : 'bg-[#151722] border border-zinc-800 text-zinc-600'
                      }`}
                    >
                      {filled ? '•' : ''}
                    </div>
                  );
                })}
              </div>

              {/* Biometric Scan Trigger Button */}
              <button
                type="button"
                onClick={handleBiometricLogin}
                disabled={isBiometricScanning}
                className="mt-3 flex items-center gap-2 px-4 py-2 rounded-xl bg-[#151722] hover:bg-[#1a1e2d] border border-orange-500/30 hover:border-orange-500 text-amber-300 text-xs font-bold transition-all active:scale-95 cursor-pointer shadow-sm"
              >
                <Fingerprint
                  className={`w-4 h-4 text-orange-400 ${
                    isBiometricScanning ? 'animate-pulse text-amber-300' : ''
                  }`}
                />
                <span>
                  {isBiometricScanning ? 'Verifying Fingerprint...' : 'Login with Biometrics'}
                </span>
              </button>
            </div>

            {/* Numeric Keypad for MPIN */}
            <div className="w-full grid grid-cols-3 gap-2 mt-3.5">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                <button
                  key={digit}
                  type="button"
                  onClick={() => handlePinPress(digit)}
                  className="h-12 rounded-xl bg-[#11131c] hover:bg-[#181a26] active:bg-orange-500/20 border border-zinc-800 hover:border-orange-500/40 text-white text-lg font-bold transition-all active:scale-95 cursor-pointer flex items-center justify-center shadow-xs"
                >
                  {digit}
                </button>
              ))}
              <button
                type="button"
                onClick={handleClearPin}
                className="h-12 rounded-xl bg-[#11131c]/60 hover:bg-[#181a26] border border-zinc-800 text-zinc-500 hover:text-white text-xs font-bold transition-all active:scale-95 cursor-pointer flex items-center justify-center"
              >
                CLEAR
              </button>
              <button
                type="button"
                onClick={() => handlePinPress('0')}
                className="h-12 rounded-xl bg-[#11131c] hover:bg-[#181a26] active:bg-orange-500/20 border border-zinc-800 hover:border-orange-500/40 text-white text-lg font-bold transition-all active:scale-95 cursor-pointer flex items-center justify-center shadow-xs"
              >
                0
              </button>
              <button
                type="button"
                onClick={handleBackspace}
                className="h-12 rounded-xl bg-[#11131c]/60 hover:bg-[#181a26] border border-zinc-800 text-rose-400 text-sm font-bold transition-all active:scale-95 cursor-pointer flex items-center justify-center"
              >
                <Delete className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: PASSWORD LOGIN */}
        {loginMethod === 'password' && (
          <form onSubmit={handlePasswordLogin} className="w-full mt-4 space-y-3.5">
            <div>
              <label className="text-[11px] font-semibold text-zinc-400 block mb-1">
                Username, Mobile, or Email
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-500">
                  <User className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="e.g. Girish12 or AdminRama"
                  className="w-full pl-9 pr-3 py-2.5 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-sm text-white placeholder-zinc-600 outline-none transition-colors"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[11px] font-semibold text-zinc-400">Password</label>
                <button
                  type="button"
                  onClick={() => setShowForgotModal(true)}
                  className="text-[11px] text-amber-400 hover:underline cursor-pointer"
                >
                  Forgot?
                </button>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-500">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your account password"
                  className="w-full pl-9 pr-10 py-2.5 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-sm text-white placeholder-zinc-600 outline-none transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-zinc-400 hover:text-white cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Remember Me Toggle */}
            <div className="flex items-center justify-between py-1">
              <label className="flex items-center gap-2 cursor-pointer text-xs text-zinc-300">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 rounded bg-[#151722] border-zinc-700 text-[#FF7700] accent-[#FF7700] focus:ring-0 cursor-pointer"
                />
                <span>Remember this device</span>
              </label>
            </div>

            {/* Submit Password Button */}
            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-black font-black text-sm shadow-lg shadow-orange-500/25 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Sign In to RAMA 777</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* Forgot MPIN Link */}
        <div className="mt-3 flex items-center justify-center">
          <button
            type="button"
            onClick={() => setShowForgotModal(true)}
            className="text-xs text-zinc-400 hover:text-amber-300 transition-colors flex items-center gap-1 cursor-pointer"
          >
            <HelpCircle className="w-3.5 h-3.5 text-zinc-500" />
            <span>Forgot 4-digit MPIN or Password?</span>
          </button>
        </div>
      </div>

      {/* Bottom Registration CTA & Footer */}
      <div className="w-full max-w-sm mx-auto pt-4 pb-2 flex flex-col items-center">
        <div className="w-full bg-[#11131c] p-3 rounded-2xl border border-zinc-800 flex items-center justify-between shadow-md">
          <div className="text-left">
            <p className="text-xs font-bold text-white">Don&apos;t have an account?</p>
            <p className="text-[10px] text-amber-400">Get ₹500 Welcome Bonus upon registration</p>
          </div>
          <button
            type="button"
            onClick={onNavigateToRegister}
            className="py-1.5 px-3.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-black text-xs font-black shadow-md cursor-pointer active:scale-95 transition-all"
          >
            Register
          </button>
        </div>

        <div className="mt-3 flex items-center gap-1.5 text-[10px] text-zinc-500">
          <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
          <span>256-Bit Encrypted &bull; ISO/IEC Certified RNG Gaming</span>
        </div>
      </div>

      {/* Forgot MPIN / Password Modal */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#11131c] border border-zinc-800 rounded-3xl p-5 w-full max-w-xs shadow-2xl text-white">
            <h3 className="text-base font-bold text-white flex items-center gap-2 mb-2">
              <RotateCcw className="w-4 h-4 text-amber-400" />
              Reset Security MPIN
            </h3>
            <p className="text-xs text-zinc-400 mb-4">
              Enter your username or mobile number and set a new 4-digit MPIN.
            </p>

            <div className="space-y-3">
              <div>
                <label className="text-[11px] font-semibold text-zinc-400 block mb-1">
                  Username or Mobile Number
                </label>
                <input
                  type="text"
                  value={forgotIdentifier}
                  onChange={(e) => setForgotIdentifier(e.target.value)}
                  placeholder="e.g. Girish12"
                  className="w-full px-3 py-2 bg-[#151722] border border-zinc-800 rounded-xl text-sm text-white outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-zinc-400 block mb-1">
                  New 4-Digit MPIN
                </label>
                <input
                  type="password"
                  maxLength={4}
                  value={resetNewMpin}
                  onChange={(e) => setResetNewMpin(e.target.value.replace(/\D/g, ''))}
                  placeholder="e.g. 5555"
                  className="w-full px-3 py-2 bg-[#151722] border border-zinc-800 rounded-xl text-sm text-center font-mono tracking-widest text-white outline-none focus:border-orange-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 mt-5">
              <button
                type="button"
                onClick={() => setShowForgotModal(false)}
                className="py-2 rounded-xl bg-zinc-800 text-zinc-300 text-xs font-bold cursor-pointer hover:bg-zinc-700"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleResetMpin}
                className="py-2 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-black text-xs font-black cursor-pointer shadow-md shadow-orange-500/20"
              >
                Save New MPIN
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
