/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  X,
  Crown,
  ShieldCheck,
  Users,
  Trophy,
  Wallet,
  Settings,
  PlusCircle,
  MinusCircle,
  CheckCircle2,
  AlertCircle,
  Search,
  Sparkles,
  ArrowRight,
  TrendingUp,
  RefreshCw,
  Clock,
} from 'lucide-react';
import { MarketItem, UserProfile, UserAccount } from '../types';
import {
  getRegisteredAccounts,
  adjustUserBalance,
  switchUserRole,
  saveRegisteredAccounts,
} from '../services/authService';
import { declareMarketResult } from '../services/marketResultService';
import { formatMarketResult, getDigitFromPana } from '../utils/marketEngine';

interface AdminPanelModalProps {
  currentUser: UserProfile;
  markets: MarketItem[];
  currentTime: Date;
  onClose: () => void;
  onUpdateMarkets?: (updated: MarketItem[]) => void;
  onSwitchUser?: (newUser: UserProfile) => void;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  currentUser,
  markets,
  currentTime,
  onClose,
  onUpdateMarkets,
  onSwitchUser,
}) => {
  const isAdmin = currentUser.role === 'admin';

  // Sub-tabs in Admin Panel: 'results' | 'users' | 'markets'
  const [activeTab, setActiveTab] = useState<'results' | 'users' | 'markets'>('results');

  // Admin elevation passcode for standard users
  const [adminPasscode, setAdminPasscode] = useState<string>('');
  const [authError, setAuthError] = useState<string>('');
  const [actionNotice, setActionNotice] = useState<string>('');

  // Results declaration state
  const [selectedMarketId, setSelectedMarketId] = useState<string>(markets[0]?.id || 'kalyan');
  const [openPanaInput, setOpenPanaInput] = useState<string>('');
  const [closePanaInput, setClosePanaInput] = useState<string>('');
  const [isSubmittingResult, setIsSubmittingResult] = useState<boolean>(false);

  // Users management state
  const [accounts, setAccounts] = useState<UserAccount[]>(() => getRegisteredAccounts());
  const [userSearchQuery, setUserSearchQuery] = useState<string>('');
  const [adjustAmount, setAdjustAmount] = useState<string>('500');

  // Selected market derived
  const selectedMarket = markets.find((m) => m.id === selectedMarketId) || markets[0];
  const currentOpenDigit =
    openPanaInput.length === 3 ? getDigitFromPana(openPanaInput) : null;
  const currentCloseDigit =
    closePanaInput.length === 3 ? getDigitFromPana(closePanaInput) : null;
  const previewJodi =
    currentOpenDigit !== null && currentCloseDigit !== null
      ? `${currentOpenDigit}${currentCloseDigit}`
      : currentOpenDigit !== null
      ? `${currentOpenDigit}*`
      : currentCloseDigit !== null
      ? `*${currentCloseDigit}`
      : '**';

  // Handle Elevate to Admin with Master PIN 9999
  const handleElevateToAdmin = () => {
    if (adminPasscode === '9999' || adminPasscode === 'admin777') {
      const elevated = switchUserRole(currentUser.id || currentUser.phone, 'admin');
      if (elevated && onSwitchUser) {
        onSwitchUser(elevated);
      }
      setAuthError('');
      setActionNotice('Admin access granted successfully.');
    } else {
      setAuthError('Invalid Admin Passcode. Use "9999" or switch to the Admin account.');
    }
  };

  // Declare Result Handler
  const handleDeclareResult = async () => {
    if (!openPanaInput && !closePanaInput) {
      setActionNotice('Please enter at least Open Pana or Close Pana.');
      return;
    }

    setIsSubmittingResult(true);
    setActionNotice('');

    try {
      const now = currentTime || new Date();

      const res = await declareMarketResult({
        marketId: selectedMarket.id,
        marketName: selectedMarket.name,
        openPana: openPanaInput || selectedMarket.openPana,
        closePana: closePanaInput || selectedMarket.closePana,
        date: now,
        action: 'declare_full',
      });

      if (res.success) {
        setActionNotice(`Result declared for ${selectedMarket.name}: ${res.marketResult.jodi}`);
        // Clear inputs
        setOpenPanaInput('');
        setClosePanaInput('');
      } else {
        setActionNotice('Result declaration failed.');
      }
    } catch (err: any) {
      setActionNotice(err.message || 'Failed to declare result.');
    } finally {
      setIsSubmittingResult(false);
    }
  };

  // Quick Wallet Credit/Debit for a user
  const handleAdjustBalance = (userAcc: UserAccount, delta: number) => {
    const newBal = Math.max(0, userAcc.walletBalance + delta);
    adjustUserBalance(userAcc.id, newBal);
    setAccounts(getRegisteredAccounts());
    setActionNotice(`Updated ${userAcc.username}'s wallet to ₹${newBal.toLocaleString('en-IN')}`);
    if (currentUser.id === userAcc.id && onSwitchUser) {
      onSwitchUser({ ...currentUser, walletBalance: newBal });
    }
  };

  // Toggle User Role
  const handleToggleRole = (userAcc: UserAccount) => {
    const newRole = userAcc.role === 'admin' ? 'user' : 'admin';
    switchUserRole(userAcc.id, newRole);
    setAccounts(getRegisteredAccounts());
    setActionNotice(`${userAcc.username} role updated to "${newRole.toUpperCase()}".`);
  };

  // Filtered accounts
  const filteredAccounts = accounts.filter(
    (a) =>
      a.username.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
      a.name.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
      a.phone.includes(userSearchQuery)
  );

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex flex-col justify-end sm:justify-center items-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full sm:max-w-md h-[92vh] sm:h-[85vh] bg-[#090a0f] text-slate-100 rounded-t-3xl sm:rounded-3xl border border-zinc-800 shadow-2xl flex flex-col overflow-hidden">
        {/* Top Header */}
        <div className="p-4 bg-gradient-to-r from-[#141624] via-[#1a130d] to-[#0f1018] border-b border-zinc-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-orange-500/20 text-orange-400 border border-orange-500/40 flex items-center justify-center">
              <Crown className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-black text-white flex items-center gap-1.5">
                <span>RAMA777 Admin Hub</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-orange-400/20 text-orange-300 border border-orange-400/30 font-bold">
                  SUPER ADMIN
                </span>
              </h2>
              <p className="text-[10px] text-slate-400">
                Authorized Personnel: {currentUser.name} ({currentUser.role})
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#11131c] text-slate-300 hover:text-white flex items-center justify-center border border-zinc-800 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* If Not Admin: Security Guard Screen */}
        {!isAdmin ? (
          <div className="flex-1 p-6 flex flex-col items-center justify-center text-center overflow-y-auto">
            <div className="w-16 h-16 rounded-3xl bg-rose-950/60 border border-rose-500/40 text-rose-400 flex items-center justify-center mb-4 shadow-xl">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-white mb-1">Administrator Access Required</h3>
            <p className="text-xs text-slate-400 max-w-xs mb-5">
              You are currently signed in as a standard Player (<b>{currentUser.name}</b>). This section
              is restricted to market operators and platform administrators.
            </p>

            {authError && (
              <div className="w-full max-w-xs mb-3 p-2 rounded-xl bg-rose-950 border border-rose-500/50 text-rose-300 text-xs">
                {authError}
              </div>
            )}

            <div className="w-full max-w-xs bg-[#11131c] p-4 rounded-2xl border border-zinc-800 mb-4 text-left">
              <label className="text-[11px] font-bold text-slate-300 block mb-1">
                Enter Admin Master PIN / Passcode
              </label>
              <input
                type="password"
                value={adminPasscode}
                onChange={(e) => setAdminPasscode(e.target.value)}
                placeholder="Enter 9999"
                className="w-full px-3 py-2 bg-[#090a0f] border border-zinc-800 focus:border-orange-500 rounded-xl text-sm font-mono tracking-widest text-center text-white outline-none mb-3"
              />
              <button
                type="button"
                onClick={handleElevateToAdmin}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs cursor-pointer shadow-md active:scale-95 transition-all"
              >
                Elevate Current Session to Admin
              </button>
            </div>

            <p className="text-[11px] text-slate-500">
              Demo Admin Passcode: <span className="font-mono text-orange-400 font-bold">9999</span>
            </p>
          </div>
        ) : (
          /* Admin Authorized View */
          <>
            {/* Sub-tab Navigation */}
            <div className="grid grid-cols-3 p-1.5 bg-[#0d0f16] border-b border-zinc-800 text-xs font-bold shrink-0">
              <button
                type="button"
                onClick={() => {
                  setActiveTab('results');
                  setActionNotice('');
                }}
                className={`py-2 rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'results'
                    ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-black font-black shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Trophy className="w-3.5 h-3.5" />
                Declare Results
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('users');
                  setActionNotice('');
                }}
                className={`py-2 rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'users'
                    ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-black font-black shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                User Ledger
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('markets');
                  setActionNotice('');
                }}
                className={`py-2 rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'markets'
                    ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-black font-black shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Clock className="w-3.5 h-3.5" />
                Markets
              </button>
            </div>

            {/* Notification Banner */}
            {actionNotice && (
              <div className="mx-4 mt-3 p-2.5 rounded-xl bg-orange-950/60 border border-orange-500/50 text-orange-200 text-xs flex items-center gap-2 shrink-0 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 text-orange-400 shrink-0" />
                <span>{actionNotice}</span>
              </div>
            )}

            {/* TAB 1: DECLARE RESULTS */}
            {activeTab === 'results' && (
              <div className="flex-1 p-4 overflow-y-auto space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1.5">
                    Select Target Market
                  </label>
                  <select
                    value={selectedMarketId}
                    onChange={(e) => setSelectedMarketId(e.target.value)}
                    className="w-full px-3 py-2.5 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs font-bold text-white outline-none cursor-pointer"
                  >
                    {markets.map((m) => (
                      <option key={m.id} value={m.id} className="bg-[#090a0f]">
                        {m.name} &bull; {m.openTime} - {m.closeTime}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Market Current Status Card */}
                {selectedMarket && (
                  <div className="bg-[#11131c] p-3.5 rounded-2xl border border-zinc-800">
                    <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                      <span>Currently Declared</span>
                      <span className="font-mono text-orange-400">{selectedMarket.status}</span>
                    </div>
                    <div className="text-lg font-mono font-black text-amber-400 tracking-wider">
                      {formatMarketResult(selectedMarket).formatted}
                    </div>
                  </div>
                )}

                {/* Input Open Pana & Close Pana */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-300 block mb-1">
                      Open Pana (3-Digits)
                    </label>
                    <input
                      type="text"
                      maxLength={3}
                      value={openPanaInput}
                      onChange={(e) => setOpenPanaInput(e.target.value.replace(/\D/g, ''))}
                      placeholder="e.g. 140"
                      className="w-full px-3 py-2 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-sm font-mono text-center text-white outline-none"
                    />
                    {currentOpenDigit !== null && (
                      <span className="text-[10px] text-orange-400 mt-0.5 block text-center font-bold">
                        Open Digit: {currentOpenDigit}
                      </span>
                    )}
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-slate-300 block mb-1">
                      Close Pana (3-Digits)
                    </label>
                    <input
                      type="text"
                      maxLength={3}
                      value={closePanaInput}
                      onChange={(e) => setClosePanaInput(e.target.value.replace(/\D/g, ''))}
                      placeholder="e.g. 180"
                      className="w-full px-3 py-2 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-sm font-mono text-center text-white outline-none"
                    />
                    {currentCloseDigit !== null && (
                      <span className="text-[10px] text-orange-400 mt-0.5 block text-center font-bold">
                        Close Digit: {currentCloseDigit}
                      </span>
                    )}
                  </div>
                </div>

                {/* Preview Jodi Box */}
                <div className="bg-[#151724] p-3 rounded-2xl border border-zinc-800 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">
                      Calculated Preview Result
                    </span>
                    <span className="text-lg font-mono font-black text-amber-400 tracking-widest">
                      {openPanaInput || '***'}-{previewJodi}-{closePanaInput || '***'}
                    </span>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center font-black text-base border border-orange-500/40 font-mono">
                    {previewJodi}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleDeclareResult}
                  disabled={isSubmittingResult}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-orange-500 via-amber-500 to-orange-400 hover:from-orange-400 hover:to-amber-300 text-slate-950 font-black text-xs cursor-pointer shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isSubmittingResult ? (
                    <span>Declaring &amp; Syncing Chart...</span>
                  ) : (
                    <>
                      <span>Declare Official Result &amp; Credit Winners</span>
                      <Trophy className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            )}

            {/* TAB 2: USER LEDGER & ACCOUNTS */}
            {activeTab === 'users' && (
              <div className="flex-1 p-4 overflow-y-auto space-y-3">
                {/* Search */}
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={userSearchQuery}
                    onChange={(e) => setUserSearchQuery(e.target.value)}
                    placeholder="Search player by name, username, or phone..."
                    className="w-full pl-9 pr-3 py-2 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white placeholder-slate-500 outline-none"
                  />
                </div>

                <div className="text-[11px] font-bold text-slate-400 flex items-center justify-between px-1">
                  <span>Registered Users ({filteredAccounts.length})</span>
                  <span className="text-orange-400">Instant Credit Adjust</span>
                </div>

                <div className="space-y-2 max-h-[50vh] overflow-y-auto pr-0.5">
                  {filteredAccounts.map((acc) => (
                    <div
                      key={acc.id}
                      className="bg-[#11131c] p-3 rounded-2xl border border-zinc-800 flex flex-col gap-2"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-xs font-bold text-white flex items-center gap-1.5">
                            <span>{acc.name}</span>
                            <span className="text-[10px] text-slate-400">(@{acc.username})</span>
                            <span
                              className={`text-[9px] px-1.5 py-0.2 rounded-md font-mono font-bold ${
                                acc.role === 'admin'
                                  ? 'bg-orange-400/20 text-orange-300 border border-orange-400/30'
                                  : 'bg-zinc-800 text-slate-300 border border-zinc-700'
                              }`}
                            >
                              {acc.role.toUpperCase()}
                            </span>
                          </div>
                          <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                            {acc.phone} &bull; PIN: {acc.mpin}
                          </div>
                        </div>

                        <div className="text-right">
                          <div className="text-xs font-black text-amber-400 font-mono">
                            ₹{acc.walletBalance.toLocaleString('en-IN')}
                          </div>
                          <span className="text-[9px] text-slate-400">Balance</span>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center justify-between pt-1 border-t border-zinc-800">
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleAdjustBalance(acc, 500)}
                            className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-orange-400 rounded-lg text-[10px] font-bold cursor-pointer"
                          >
                            +₹500
                          </button>
                          <button
                            type="button"
                            onClick={() => handleAdjustBalance(acc, 1000)}
                            className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-orange-400 rounded-lg text-[10px] font-bold cursor-pointer"
                          >
                            +₹1000
                          </button>
                          <button
                            type="button"
                            onClick={() => handleAdjustBalance(acc, -500)}
                            className="px-2 py-1 bg-rose-950/80 hover:bg-rose-900 text-rose-300 rounded-lg text-[10px] font-bold cursor-pointer"
                          >
                            -₹500
                          </button>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleToggleRole(acc)}
                          className="text-[10px] text-slate-400 hover:text-orange-400 font-semibold cursor-pointer underline"
                        >
                          Make {acc.role === 'admin' ? 'User' : 'Admin'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 3: MARKET CONTROLS */}
            {activeTab === 'markets' && (
              <div className="flex-1 p-4 overflow-y-auto space-y-2">
                <div className="text-xs font-bold text-slate-300 mb-2">
                  Live Market Operating Status
                </div>
                {markets.map((m) => (
                  <div
                    key={m.id}
                    className="bg-[#11131c] p-3 rounded-2xl border border-zinc-800 flex items-center justify-between"
                  >
                    <div>
                      <div className="text-xs font-bold text-white">{m.name}</div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {m.openTime} - {m.closeTime}
                      </div>
                    </div>
                    <span
                      className={`text-[10px] px-2.5 py-1 rounded-full font-bold font-mono ${
                        m.isOpen
                          ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-500/30'
                          : 'bg-rose-950/60 text-rose-400 border border-rose-500/30'
                      }`}
                    >
                      {m.isOpen ? 'ACTIVE / OPEN' : 'CLOSED'}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
