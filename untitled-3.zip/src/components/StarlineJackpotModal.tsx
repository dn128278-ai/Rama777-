import React, { useState, useEffect } from 'react';
import { ArrowLeft, Play, Sparkles, CheckCircle2, AlertCircle, Clock, Zap } from 'lucide-react';
import { StarlineResult, GameBid } from '../types';
import {
  evaluateStarlineSlots,
  evaluateJackpotSlots,
  StarlineSlotItem,
  JackpotSlotItem,
} from '../utils/marketEngine';

interface StarlineJackpotModalProps {
  type: 'starline' | 'jackpot';
  walletBalance: number;
  starlineResults?: StarlineResult[];
  currentTime?: Date;
  onBack: () => void;
  onPlaceBid: (bid: Omit<GameBid, 'id' | 'date' | 'status'> | Omit<GameBid, 'id' | 'date' | 'status'>[]) => boolean;
}

export const StarlineJackpotModal: React.FC<StarlineJackpotModalProps> = ({
  type,
  walletBalance,
  currentTime = new Date(),
  onBack,
  onPlaceBid,
}) => {
  const isStarline = type === 'starline';
  const title = isStarline ? 'Bombay Starline' : 'Bombay Jackpot';

  // Evaluate dynamic slots based on real current system time
  const starlineSlots: StarlineSlotItem[] = isStarline ? evaluateStarlineSlots(currentTime) : [];
  const jackpotSlots: JackpotSlotItem[] = !isStarline ? evaluateJackpotSlots(currentTime) : [];
  const currentSlots = isStarline ? starlineSlots : jackpotSlots;

  // Find the first active or upcoming slot
  const defaultSlot = currentSlots.find((s) => s.status === 'Running for Open') || currentSlots[0];

  const [selectedSlotTime, setSelectedSlotTime] = useState<string>(
    defaultSlot ? defaultSlot.time : ''
  );
  const [betDigit, setBetDigit] = useState<string>('');
  const [points, setPoints] = useState<string>('50');
  const [msg, setMsg] = useState<{ text: string; error: boolean } | null>(null);

  // Sync selectedSlotTime if needed
  useEffect(() => {
    if (!selectedSlotTime && defaultSlot) {
      setSelectedSlotTime(defaultSlot.time);
    }
  }, [defaultSlot, selectedSlotTime]);

  const selectedSlotObj = currentSlots.find((s) => s.time === selectedSlotTime);
  const isSelectedSlotClosed = selectedSlotObj?.status === 'Closed';

  const handlePlaceBid = () => {
    if (isSelectedSlotClosed) {
      setMsg({
        text: `Slot ${selectedSlotTime} is already Closed. Please select an active open slot.`,
        error: true,
      });
      return;
    }

    const pts = parseInt(points, 10);
    if (!betDigit.trim()) {
      setMsg({
        text: isStarline
          ? 'Please enter your lucky number (0-9 or 3-digit pana)'
          : 'Please enter your lucky 2-digit Jackpot number (00-99)',
        error: true,
      });
      return;
    }
    if (isNaN(pts) || pts <= 0) {
      setMsg({ text: 'Please enter valid bid points', error: true });
      return;
    }
    if (pts > walletBalance) {
      setMsg({ text: `Insufficient balance (₹${walletBalance})`, error: true });
      return;
    }

    onPlaceBid({
      marketName: `${title} (${selectedSlotTime})`,
      gameType: isStarline ? 'SINGLE DIGIT' : 'JACKPOT',
      session: 'Open',
      digitOrPana: betDigit,
      points: pts,
    });

    setMsg({
      text: `Bid placed for ${title} on #${betDigit} with ₹${pts}!`,
      error: false,
    });
    setBetDigit('');

    setTimeout(() => {
      setMsg(null);
    }, 2500);
  };

  return (
    <div className="pb-24 pt-2 px-4 transition-colors">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2.5">
          <button
            onClick={onBack}
            className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h2 className="text-base font-extrabold text-[#FF7700]">{title}</h2>
            <span className="text-[10px] text-slate-400 font-medium">Real-Time Draw Engine</span>
          </div>
        </div>

        <div className="bg-[#151724] border border-zinc-800 rounded-full px-3 py-1">
          <span className="text-xs font-bold text-amber-400 font-mono">
            ₹{walletBalance}
          </span>
        </div>
      </div>

      {msg && (
        <div
          className={`mb-4 p-3 rounded-2xl text-xs font-semibold flex items-center gap-2 ${
            msg.error
              ? 'bg-rose-950/60 text-rose-300 border border-rose-500/40'
              : 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/40'
          }`}
        >
          {msg.error ? (
            <AlertCircle className="w-4 h-4 shrink-0" />
          ) : (
            <CheckCircle2 className="w-4 h-4 shrink-0" />
          )}
          <span>{msg.text}</span>
        </div>
      )}

      {/* Active Slot Countdown Banner */}
      {selectedSlotObj && (
        <div className="mb-3 p-3 rounded-2xl bg-orange-950/30 border border-orange-500/30 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#FF7700]" />
            <div>
              <span className="text-xs font-bold text-white">
                Slot {selectedSlotObj.time}
              </span>
              <p className="text-[10px] text-slate-400">
                {selectedSlotObj.status === 'Running for Open'
                  ? selectedSlotObj.countdownText || 'Bids Active'
                  : selectedSlotObj.status === 'Closed'
                  ? `Declared Result: ${selectedSlotObj.result}`
                  : 'Scheduled Upcoming Draw'}
              </p>
            </div>
          </div>
          <span
            className={`px-2.5 py-0.5 rounded-full text-[10px] font-black ${
              selectedSlotObj.status === 'Running for Open'
                ? 'bg-emerald-500 text-slate-950 animate-pulse'
                : selectedSlotObj.status === 'Closed'
                ? 'bg-zinc-800 text-slate-400'
                : 'bg-amber-950/80 text-amber-300 border border-amber-500/30'
            }`}
          >
            {selectedSlotObj.status}
          </span>
        </div>
      )}

      {/* Live Slot Selector */}
      <div className="bg-[#11131c] rounded-3xl p-5 border border-zinc-800 shadow-sm space-y-4 mb-4">
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              Daily Schedule & Live Results
            </span>
            <span className="text-[10px] text-orange-400 font-bold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" />
              Live Sync
            </span>
          </div>

          <div className="grid grid-cols-4 gap-2">
            {currentSlots.map((slot) => {
              const isSelected = selectedSlotTime === slot.time;
              const isClosed = slot.status === 'Closed';
              const isRunning = slot.status === 'Running for Open';

              return (
                <button
                  key={slot.time}
                  onClick={() => setSelectedSlotTime(slot.time)}
                  className={`p-2 rounded-xl text-center text-xs font-bold transition-all cursor-pointer border ${
                    isSelected
                      ? 'bg-[#FF7700] text-white border-[#FF7700] shadow-sm ring-2 ring-orange-400/40'
                      : isRunning
                      ? 'bg-orange-950/40 text-orange-300 border-orange-500/50 animate-pulse'
                      : isClosed
                      ? 'bg-[#090a0f] text-slate-500 border-zinc-800/80'
                      : 'bg-[#151724] text-slate-300 border-zinc-800 hover:border-zinc-700'
                  }`}
                >
                  <div className="text-[10px] leading-tight font-mono">{slot.time}</div>
                  <div className="text-[10px] mt-0.5 font-black text-white">
                    {slot.result}
                  </div>
                  <div className="text-[8px] uppercase tracking-tighter opacity-75 mt-0.5">
                    {slot.status === 'Running for Open' ? 'ACTIVE' : slot.status}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Bidding Controls */}
        <div className="space-y-3 pt-2 border-t border-zinc-800">
          <div>
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              {isStarline ? 'Enter Single Digit (0-9) or Pana (100-999)' : 'Enter Jackpot Digit (00-99)'}
            </label>
            <input
              type="text"
              value={betDigit}
              onChange={(e) => setBetDigit(e.target.value.replace(/\D/g, '').slice(0, 3))}
              placeholder={isStarline ? 'e.g. 7' : 'e.g. 77'}
              disabled={isSelectedSlotClosed}
              className={`w-full bg-[#090a0f] border rounded-xl px-3.5 py-2.5 text-base font-bold font-mono outline-none text-white ${
                isSelectedSlotClosed
                  ? 'border-zinc-800 text-slate-600 cursor-not-allowed opacity-50'
                  : 'border-zinc-800 focus:border-[#FF7700]'
              }`}
            />
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Bid Points (₹)
            </label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                value={points}
                onChange={(e) => setPoints(e.target.value)}
                placeholder="50"
                disabled={isSelectedSlotClosed}
                className={`flex-1 bg-[#090a0f] border rounded-xl px-3.5 py-2.5 text-base font-bold font-mono outline-none text-white ${
                  isSelectedSlotClosed
                    ? 'border-zinc-800 text-slate-600 cursor-not-allowed opacity-50'
                    : 'border-zinc-800 focus:border-[#FF7700]'
                }`}
              />
              {['50', '100', '200'].map((p) => (
                <button
                  key={p}
                  disabled={isSelectedSlotClosed}
                  onClick={() => setPoints(p)}
                  className={`px-3 py-2.5 rounded-xl text-xs font-bold font-mono active:scale-95 cursor-pointer ${
                    isSelectedSlotClosed
                      ? 'bg-zinc-800 text-slate-600 cursor-not-allowed'
                      : 'bg-orange-950/60 text-[#FF7700] border border-orange-500/30'
                  }`}
                >
                  +{p}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handlePlaceBid}
            disabled={isSelectedSlotClosed}
            className={`w-full py-3.5 rounded-2xl font-bold text-sm shadow-md transition-all mt-2 ${
              isSelectedSlotClosed
                ? 'bg-zinc-800 text-slate-500 cursor-not-allowed shadow-none'
                : 'bg-gradient-to-r from-[#FF7700] to-[#E65100] text-white shadow-orange-500/25 active:scale-95 cursor-pointer hover:brightness-105'
            }`}
          >
            {isSelectedSlotClosed
              ? `Slot ${selectedSlotTime} Closed`
              : `Submit ${title} Bid (${selectedSlotTime})`}
          </button>
        </div>
      </div>
    </div>
  );
};
