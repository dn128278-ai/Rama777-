import React from 'react';
import { Info, Play, Clock } from 'lucide-react';
import { MarketItem } from '../types';
import { formatMarketResult } from '../utils/marketEngine';

export interface MarketCardProps {
  market: MarketItem;
  onPlay: (market: MarketItem) => void;
  onOpenChart: (marketName: string) => void;
}

/**
 * MarketCard component for displaying Matka market items and dynamic results.
 * Deep dark/black background with orange/amber branding accents.
 */
export const MarketCard: React.FC<MarketCardProps> = ({
  market,
  onPlay,
  onOpenChart,
}) => {
  const isClosed = !market.isOpen;
  const isRunningOpen = market.status === 'Running for Open';
  const isRunningClose = market.status === 'Running for Close';

  // Dynamically resolve full formatted result
  const result = formatMarketResult({
    openPana: market.openPana,
    jodi: market.jodi,
    closePana: market.closePana,
  });

  return (
    <div className="bg-[#11131c] rounded-3xl p-4.5 border border-zinc-800/90 hover:border-orange-500/40 shadow-lg shadow-black/40 relative transition-all">
      {/* Card Top Row: Name + Info and Orange Play Button */}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-black text-base tracking-tight text-[#FF7700] truncate">
              {market.name}
            </h3>
            <button
              onClick={() => onOpenChart(market.name)}
              className="text-[#FF7700] hover:text-amber-300 p-1 rounded-full cursor-pointer active:scale-90 transition-transform"
              title="View Panel & Jodi Chart"
              aria-label={`View chart for ${market.name}`}
            >
              <Info className="w-4 h-4" />
            </button>
          </div>

          {/* Triplet Result with dynamic format resolution (e.g., 333 - 99 - 333) */}
          <div
            className="text-lg font-black font-mono tracking-tight mt-1 flex items-center gap-1.5 text-white"
            data-testid="market-result-display"
          >
            <span className="font-extrabold text-zinc-100">{result.openPana}</span>
            <span className="text-zinc-500 font-normal">-</span>
            <span
              className={`font-black ${
                result.jodi !== '**' && !result.jodi.includes('*')
                  ? 'text-[#FF7700]'
                  : 'text-amber-400'
              }`}
            >
              {result.jodi}
            </span>
            <span className="text-zinc-500 font-normal">-</span>
            <span className="font-extrabold text-zinc-100">{result.closePana}</span>
          </div>
        </div>

        {/* Orange Play Button for Active/Running Markets */}
        <button
          onClick={() => onPlay(market)}
          disabled={isClosed}
          className={`px-6 py-2.5 rounded-full font-black text-xs flex items-center gap-1.5 transition-all shadow-md shrink-0 ${
            !isClosed
              ? 'bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-black active:scale-95 cursor-pointer shadow-orange-500/30'
              : 'bg-zinc-800 text-zinc-500 shadow-none cursor-not-allowed border border-zinc-700/60'
          }`}
        >
          <Play
            className={`w-3.5 h-3.5 ${
              !isClosed ? 'fill-black text-black' : 'fill-zinc-500 text-zinc-500'
            }`}
          />
          <span>Play</span>
        </button>
      </div>

      {/* Countdown & Session info pill */}
      <div className="mt-3 flex items-center justify-between gap-2">
        <span
          className={`px-3 py-1 rounded-full text-[11px] font-bold flex items-center gap-1.5 ${
            isRunningOpen
              ? 'bg-orange-500/10 text-amber-300 border border-orange-500/30'
              : isRunningClose
              ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
              : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>{market.countdownText || market.status}</span>
        </span>

        <span className="text-[11px] font-bold text-zinc-400 shrink-0">
          {market.allowedSession === 'all' && '🟡 Open & Close'}
          {market.allowedSession === 'close_only' && '🟠 Close Only'}
          {market.allowedSession === 'none' && '🔴 Closed'}
        </span>
      </div>

      {/* Hairline Divider */}
      <div className="my-3 border-t border-zinc-800/80" />

      {/* Card Bottom Row: Timings & Status */}
      <div className="flex items-end justify-between text-xs gap-2">
        <div className="space-y-0.5 text-zinc-400 font-medium text-[11px]">
          <div>
            Open Bids :{' '}
            <span className="font-bold text-zinc-200">
              {market.openTime}
            </span>
          </div>
          <div>
            Close Bids :{' '}
            <span className="font-bold text-zinc-200">
              {market.closeTime}
            </span>
          </div>
        </div>

        <div>
          <span
            className={`font-black text-xs ${
              isRunningOpen
                ? 'text-amber-400'
                : isRunningClose
                ? 'text-orange-400'
                : 'text-rose-400'
            }`}
          >
            {market.status}
          </span>
        </div>
      </div>
    </div>
  );
};
