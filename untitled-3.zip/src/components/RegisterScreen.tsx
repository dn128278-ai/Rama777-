/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  User,
  Phone,
  Lock,
  Eye,
  EyeOff,
  Fingerprint,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  ArrowLeft,
  Sparkles,
  Gift,
  KeyRound,
  Check,
} from 'lucide-react';
import { UserProfile } from '../types';
import { registerAccount } from '../services/authService';
import { registerDeviceBiometric } from '../utils/biometricAuth';

interface RegisterScreenProps {
  onRegisterSuccess: (newUser: UserProfile) => void;
  onNavigateToLogin: () => void;
}

export const RegisterScreen: React.FC<RegisterScreenProps> = ({
  onRegisterSuccess,
  onNavigateToLogin,
}) => {
  const [name, setName] = useState<string>('');
  const [mobileNumber, setMobileNumber] = useState<string>('');
  const [username, setUsername] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState<boolean>(false);
  const [mpin, setMpin] = useState<string>('');
  const [confirmMpin, setConfirmMpin] = useState<string>('');
  const [referralCode, setReferralCode] = useState<string>('');
  const [biometricEnabled, setBiometricEnabled] = useState<boolean>(true);
  const [agreeTerms, setAgreeTerms] = useState<boolean>(true);

  // Status and animation states
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [successMessage, setSuccessMessage] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!name.trim()) {
      setErrorMessage('Please enter your full name.');
      return;
    }

    const cleanPhone = mobileNumber.replace(/\D/g, '');
    if (cleanPhone.length !== 10) {
      setErrorMessage('Please enter a valid 10-digit mobile number.');
      return;
    }

    if (!username.trim() || username.trim().length < 3) {
      setErrorMessage('Username must be at least 3 characters.');
      return;
    }

    if (!password || password.length < 4) {
      setErrorMessage('Password must be at least 4 characters.');
      return;
    }

    if (password !== confirmPassword) {
      setErrorMessage('Passwords do not match. Please check and re-enter.');
      return;
    }

    if (mpin.length !== 4) {
      setErrorMessage('Please set a 4-digit security MPIN.');
      return;
    }

    if (mpin !== confirmMpin) {
      setErrorMessage('4-Digit MPINs do not match. Please verify.');
      return;
    }

    if (!agreeTerms) {
      setErrorMessage('Please accept the RAMA777 Terms & Fair Play conditions to continue.');
      return;
    }

    setIsSubmitting(true);

    try {
      // Optional biometric registration
      if (biometricEnabled) {
        try {
          await registerDeviceBiometric(cleanPhone, name.trim());
        } catch (e) {
          console.warn('Biometric registration optional notice:', e);
        }
      }

      const result = registerAccount({
        name: name.trim(),
        username: username.trim(),
        phone: cleanPhone,
        password,
        mpin,
        referralCode: referralCode.trim() || undefined,
        biometricEnabled,
      });

      if (result.success) {
        setSuccessMessage(result.message || 'Registration completed successfully!');
        setTimeout(() => {
          onRegisterSuccess(result.user);
        }, 600);
      } else {
        setErrorMessage(result.message);
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Registration failed. Please check inputs.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="w-full min-h-screen bg-[#090a0f] text-slate-100 flex flex-col justify-between p-4 sm:p-6 overflow-y-auto">
      {/* Top Header Bar */}
      <div className="w-full max-w-sm mx-auto flex items-center justify-between pb-3 pt-2 border-b border-zinc-800/80">
        <button
          type="button"
          onClick={onNavigateToLogin}
          className="w-9 h-9 rounded-xl bg-[#11131c] hover:bg-[#1a1d2c] border border-zinc-800 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div className="text-center">
          <h2 className="text-sm font-black tracking-wide text-white">Create New Account</h2>
          <p className="text-[10px] text-orange-400 font-medium">Join 500,000+ Registered Players</p>
        </div>
        <div className="w-9" />
      </div>

      {/* Main Registration Card */}
      <div className="w-full max-w-sm mx-auto flex flex-col pt-3">
        {/* Welcome Bonus Callout Banner */}
        <div className="bg-gradient-to-r from-[#18120c] via-[#21160c] to-[#141622] p-3 rounded-2xl border border-orange-500/30 flex items-center gap-3 mb-3.5 shadow-md">
          <div className="w-9 h-9 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center shrink-0">
            <Gift className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-black text-amber-300 flex items-center gap-1.5">
              <span>Instant ₹500 Welcome Bonus</span>
              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
            </div>
            <p className="text-[10px] text-slate-300">
              Credited directly to your wallet immediately upon sign-up.
            </p>
          </div>
        </div>

        {/* Error / Success Feedback */}
        {errorMessage && (
          <div className="mb-3 p-2.5 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2 animate-in fade-in">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}
        {successMessage && (
          <div className="mb-3 p-2.5 rounded-xl bg-emerald-950/70 border border-emerald-500/60 text-emerald-200 text-xs flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleRegister} className="space-y-3">
          {/* Full Name */}
          <div>
            <label className="text-[11px] font-semibold text-slate-300 block mb-1">
              Full Name (As per Bank Account)
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <User className="w-4 h-4" />
              </div>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Ramesh Kumar"
                className="w-full pl-9 pr-3 py-2 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white placeholder-slate-500 outline-none transition-colors"
              />
            </div>
          </div>

          {/* Mobile Number & Username in 2 Columns */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                Mobile Number
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-2 flex items-center pointer-events-none text-xs text-slate-400 font-bold">
                  +91
                </div>
                <input
                  type="tel"
                  maxLength={10}
                  required
                  value={mobileNumber}
                  onChange={(e) => setMobileNumber(e.target.value.replace(/\D/g, ''))}
                  placeholder="9876543210"
                  className="w-full pl-9 pr-2 py-2 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs font-mono text-white placeholder-slate-500 outline-none transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                Username
              </label>
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value.replace(/\s+/g, ''))}
                placeholder="e.g. ramesh77"
                className="w-full px-3 py-2 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white placeholder-slate-500 outline-none transition-colors"
              />
            </div>
          </div>

          {/* Password & Confirm Password */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Min 4 chars"
                  className="w-full pl-3 pr-7 py-2 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white placeholder-slate-500 outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-2 flex items-center text-slate-400 hover:text-white cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                Confirm Pass
              </label>
              <div className="relative">
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Repeat pass"
                  className="w-full pl-3 pr-7 py-2 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white placeholder-slate-500 outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute inset-y-0 right-0 pr-2 flex items-center text-slate-400 hover:text-white cursor-pointer"
                >
                  {showConfirmPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          </div>

          {/* 4-Digit Security MPIN Setup */}
          <div className="bg-[#11131c] p-3 rounded-2xl border border-zinc-800/80">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5 text-orange-400" />
                Set 4-Digit Security MPIN
              </span>
              <span className="text-[10px] text-slate-400">Used for fast login</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-slate-400 block mb-1">New 4-Digit PIN</label>
                <input
                  type="password"
                  maxLength={4}
                  required
                  value={mpin}
                  onChange={(e) => setMpin(e.target.value.replace(/\D/g, ''))}
                  placeholder="••••"
                  className="w-full py-2 bg-[#090a0f] border border-zinc-800 focus:border-orange-500 rounded-xl text-sm font-mono tracking-widest text-center text-white outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 block mb-1">Confirm 4-Digit PIN</label>
                <input
                  type="password"
                  maxLength={4}
                  required
                  value={confirmMpin}
                  onChange={(e) => setConfirmMpin(e.target.value.replace(/\D/g, ''))}
                  placeholder="••••"
                  className="w-full py-2 bg-[#090a0f] border border-zinc-800 focus:border-orange-500 rounded-xl text-sm font-mono tracking-widest text-center text-white outline-none"
                />
              </div>
            </div>
          </div>

          {/* Referral Code (Optional) */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-[11px] font-semibold text-slate-300">
                Referral Code (Optional)
              </label>
              <span className="text-[10px] text-orange-400 font-semibold">+₹100 Extra Bonus</span>
            </div>
            <input
              type="text"
              value={referralCode}
              onChange={(e) => setReferralCode(e.target.value.toUpperCase())}
              placeholder="e.g. RAMA777"
              className="w-full px-3 py-2 bg-[#11131c] border border-zinc-800 focus:border-orange-500 rounded-xl text-xs uppercase tracking-wider text-white placeholder-slate-500 outline-none"
            />
          </div>

          {/* Checkboxes: Biometric & Terms */}
          <div className="space-y-2 pt-1">
            <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
              <input
                type="checkbox"
                checked={biometricEnabled}
                onChange={(e) => setBiometricEnabled(e.target.checked)}
                className="w-4 h-4 rounded bg-[#11131c] border-zinc-700 text-orange-500 focus:ring-0 cursor-pointer accent-orange-500"
              />
              <span className="flex items-center gap-1.5">
                <Fingerprint className="w-3.5 h-3.5 text-orange-400" />
                Enable 1-Touch Fingerprint / Biometric Login
              </span>
            </label>

            <label className="flex items-start gap-2 cursor-pointer text-[11px] text-slate-400 leading-tight">
              <input
                type="checkbox"
                checked={agreeTerms}
                onChange={(e) => setAgreeTerms(e.target.checked)}
                className="w-4 h-4 rounded bg-[#11131c] border-zinc-700 text-orange-500 focus:ring-0 cursor-pointer accent-orange-500 mt-0.5"
              />
              <span>
                I agree to the RAMA777 Fair Play Rules, Terms of Service, and certify I am 18+ years of age.
              </span>
            </label>
          </div>

          {/* Register Action Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full mt-3 py-3.5 rounded-xl bg-gradient-to-r from-orange-500 via-amber-500 to-orange-400 hover:from-orange-400 hover:to-amber-300 text-slate-950 font-black text-sm shadow-lg shadow-orange-500/25 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isSubmitting ? (
              <span>Creating Your Account...</span>
            ) : (
              <>
                <span>Complete Registration &bull; Claim ₹500</span>
                <Check className="w-4 h-4" />
              </>
            )}
          </button>
        </form>
      </div>

      {/* Bottom Switch to Login */}
      <div className="w-full max-w-sm mx-auto pt-3 pb-2 text-center">
        <p className="text-xs text-slate-400">
          Already registered on RAMA 777?{' '}
          <button
            type="button"
            onClick={onNavigateToLogin}
            className="text-orange-400 hover:underline font-bold cursor-pointer ml-1"
          >
            Sign In Here
          </button>
        </p>
      </div>
    </div>
  );
};
