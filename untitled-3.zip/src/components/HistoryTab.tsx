import React, { useState } from 'react';
import {
  Clock,
  FileCheck2,
  ChevronRight,
  ArrowLeft,
  Calendar,
  Layers,
  Sparkles,
} from 'lucide-react';
import { GameBid, StarlineResult } from '../types';

interface HistoryTabProps {
  bids: GameBid[];
  starlineResults: StarlineResult[];
}

export const HistoryTab: React.FC<HistoryTabProps> = ({ bids, starlineResults }) => {
  const [activeSubView, setActiveSubView] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>('20/10/2026');

  const historyOptions = [
    { id: 'game_bid_history', title: 'Game Bid History', type: 'clock' },
    { id: 'starline_bid_history', title: 'Starline Bid History', type: 'clock' },
    { id: 'jackpot_bid_history', title: 'Jackpot Bid History', type: 'clock' },
    { id: 'game_result_history', title: 'Game Result History', type: 'check' },
    { id: 'starline_result_history', title: 'Starline Result History', type: 'check' },
    { id: 'jackpot_result_history', title: 'Jackpot Result History', type: 'check' },
  ];

  return (
    <div className="pb-6 pt-2 px-4 transition-colors">
      {!activeSubView ? (
        <div className="space-y-3">
          {historyOptions.map((opt) => (
            <button
              key={opt.id}
              onClick={() => setActiveSubView(opt.id)}
              className="w-full bg-[#11131c] rounded-2xl p-3.5 border border-zinc-800 flex items-center justify-between shadow-xs hover:border-[#FF7700] hover:bg-[#161824] active:scale-[0.99] transition-all cursor-pointer text-left"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs shrink-0">
                  {opt.type === 'clock' ? (
                    <Clock className="w-5 h-5" />
                  ) : (
                    <FileCheck2 className="w-5 h-5" />
                  )}
                </div>
                <span className="font-bold text-white text-sm">
                  {opt.title}
                </span>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-400 shrink-0" />
            </button>
          ))}
        </div>
      ) : activeSubView === 'starline_result_history' ? (
        /* Starline Result History */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setActiveSubView(null)}
                className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <h2 className="text-base font-extrabold text-[#FF7700]">
                Starline Result History
              </h2>
            </div>
          </div>

          {/* Date Selector Row */}
          <div className="flex items-center justify-between bg-[#11131c] rounded-2xl p-3 border border-zinc-800 shadow-xs">
            <span className="text-xs font-bold text-slate-300">
              Select Date :
            </span>
            <div className="border border-[#FF7700] text-orange-400 bg-orange-950/30 px-4 py-1.5 rounded-full text-xs font-bold font-mono">
              {selectedDate}
            </div>
          </div>

          {/* Hourly Result Cards */}
          <div className="space-y-2.5">
            {starlineResults.map((sr, idx) => (
              <div
                key={idx}
                className="bg-[#11131c] rounded-2xl p-3.5 border border-zinc-800 flex items-center justify-between shadow-xs"
              >
                <div>
                  <div className="font-extrabold text-sm text-white">
                    {sr.time}
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                    {sr.date}
                  </div>
                </div>

                <div className="w-28 py-2 rounded-xl bg-[#151724] text-center font-black font-mono text-sm text-amber-400 tracking-wider border border-zinc-800">
                  {sr.result}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Subview for Game Bid History or other subviews */
        <div className="space-y-4">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setActiveSubView(null)}
              className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF7700] to-[#E65100] text-white flex items-center justify-center shadow-xs cursor-pointer active:scale-95"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <h2 className="text-base font-extrabold text-[#FF7700]">
              {historyOptions.find((o) => o.id === activeSubView)?.title}
            </h2>
          </div>

          {(() => {
            const relevantBids = bids.filter((b) => {
              if (activeSubView === 'starline_bid_history') {
                return b.marketName.toLowerCase().includes('starline');
              }
              if (activeSubView === 'jackpot_bid_history') {
                return b.marketName.toLowerCase().includes('jackpot');
              }
              if (activeSubView === 'game_bid_history') {
                return (
                  !b.marketName.toLowerCase().includes('starline') &&
                  !b.marketName.toLowerCase().includes('jackpot')
                );
              }
              return true;
            });

            return relevantBids.length === 0 ? (
              <div className="bg-[#11131c] rounded-3xl p-8 border border-zinc-800 text-center shadow-xs">
                <Clock className="w-10 h-10 text-zinc-600 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-300">
                  No history records found for today
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  Place a bid in Kalyan or other markets to see records here.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {relevantBids.map((bid) => (
                  <div
                    key={bid.id}
                    className="bg-[#11131c] rounded-2xl p-4 border border-zinc-800 shadow-xs"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-extrabold text-sm text-white">
                          {bid.marketName}
                        </h4>
                        <p className="text-xs text-slate-400 font-medium">
                          {bid.gameType} · {bid.session} Session
                        </p>
                      </div>
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          bid.status === 'Won'
                            ? 'bg-emerald-950/70 text-emerald-400 border border-emerald-500/40'
                            : bid.status === 'Lost'
                            ? 'bg-rose-950/70 text-rose-400 border border-rose-500/40'
                            : 'bg-orange-950/70 text-orange-400 border border-orange-500/40'
                        }`}
                      >
                        {bid.status === 'Won' && bid.winAmount
                          ? `Won · ₹${bid.winAmount}`
                          : bid.status}
                      </span>
                    </div>

                    <div className="mt-3 pt-2 border-t border-zinc-800 flex items-center justify-between text-xs">
                      <span className="text-slate-400 font-mono">
                        Digit: <strong className="text-white">{bid.digitOrPana}</strong>
                      </span>
                      <span className="font-bold text-[#FF7700] font-mono text-sm">
                        ₹{bid.points}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            );
          })()}
        </div>
      )}
    </div>
  );
};
