import React from 'react';
import { History, BookOpen, Home, Wallet, Headphones } from 'lucide-react';
import { MainTab } from '../types';

interface BottomNavBarProps {
  currentTab: MainTab;
  onTabChange: (tab: MainTab) => void;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({ currentTab, onTabChange }) => {
  const tabs: { id: MainTab; label: string; icon: React.ElementType }[] = [
    { id: 'history', label: 'History', icon: History },
    { id: 'passbook', label: 'Passbook', icon: BookOpen },
    { id: 'home', label: 'Home', icon: Home },
    { id: 'funds', label: 'Funds', icon: Wallet },
    { id: 'support', label: 'Support', icon: Headphones },
  ];

  return (
    <nav
      style={{ flexShrink: 0 }}
      className="shrink-0 z-30 bg-[#0a0b10]/95 backdrop-blur-md border-t border-zinc-800/90 text-white transition-colors shadow-[0_-4px_16px_rgba(0,0,0,0.5)]"
    >
      <div className="max-w-md mx-auto grid grid-cols-5 h-16 items-center px-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center justify-center py-1.5 transition-all active:scale-95 cursor-pointer relative h-full ${
                isActive
                  ? 'text-[#FF7700]'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {isActive && (
                <span className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-[#FF7700] shadow-[0_0_8px_#FF7700] rounded-full" />
              )}
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform ${
                    isActive ? 'scale-110 stroke-[2.4] text-[#FF7700]' : 'stroke-[1.8] text-zinc-400'
                  }`}
                />
              </div>
              <span
                className={`text-[11px] tracking-tight mt-1 ${
                  isActive ? 'font-black text-[#FF7700]' : 'font-medium text-zinc-400'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
