/**
 * Local offline stub replacing remote Firebase SDK connections.
 * Provides clean local fallbacks without network overhead.
 */

export interface FirebaseUser {
  uid: string;
  displayName: string | null;
  email: string | null;
  phoneNumber: string | null;
}

export const firebaseConfig = {
  projectId: 'rama777-local',
};

export const app = { name: '[DEFAULT]' };
export const db = {};
export const auth = { currentUser: null };

export const onAuthStateChanged = (
  _auth: any,
  callback: (user: FirebaseUser | null) => void
) => {
  callback(null);
  return () => {};
};

export const signInWithPopup = async (_auth: any, _provider: any): Promise<{ user: FirebaseUser }> => {
  const mockUser: FirebaseUser = {
    uid: 'google_user_' + Date.now(),
    displayName: 'Google Player',
    email: 'player@gmail.com',
    phoneNumber: '6377972674',
  };
  return { user: mockUser };
};

export class GoogleAuthProvider {}

export const signOut = async (_auth: any) => {};
export const signInAnonymously = async (_auth: any) => ({
  user: { uid: 'anon_' + Date.now() },
});

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export function handleFirestoreError(
  _error: unknown,
  _operationType: OperationType,
  _path: string | null
) {
  // Offline local operation notice
}
